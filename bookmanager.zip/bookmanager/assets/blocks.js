/* BookManager — bloki edytora: nakładka na shortcode'y, podgląd renderowany przez serwer. */
(function (wp) {
	var el = wp.element.createElement, SSR = wp.serverSideRender, IC = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody, TextControl = wp.components.TextControl;

	function idField(props, help) {
		return el(TextControl, { label: 'ID apartamentu', type: 'number', help: help,
			value: props.attributes.id || '', onChange: function (v) { props.setAttributes({ id: parseInt(v, 10) || 0 }); } });
	}

	wp.blocks.registerBlockType('bookmanager/rezerwacja', {
		title: 'Rezerwacja apartamentu', icon: 'calendar-alt', category: 'widgets',
		description: 'Kalendarz, goście, opcje i cena. Na stronie apartamentu bez ID.',
		attributes: { id: { type: 'number', default: 0 } },
		edit: function (props) {
			return [
				el(IC, { key: 'i' }, el(PanelBody, { title: 'Ustawienia' }, idField(props, 'Puste = bieżący apartament.'))),
				el('div', { key: 'p', className: 'bm-editor-placeholder', style: { padding: '16px', border: '1px dashed #999' } },
					'Widżet rezerwacji' + (props.attributes.id ? ' — apartament #' + props.attributes.id : ' — bieżący apartament') + ' (działa na stronie)')
			];
		},
		save: function () { return null; }
	});

	wp.blocks.registerBlockType('bookmanager/o-obiekcie', {
		title: 'O obiekcie', icon: 'admin-home', category: 'widgets',
		description: 'Opis, udogodnienia (wspólne oznaczone) i zasady pobytu.',
		attributes: { id: { type: 'number', default: 0 }, obiekt: { type: 'string', default: '' } },
		edit: function (props) {
			return [
				el(IC, { key: 'i' }, el(PanelBody, { title: 'Ustawienia' },
					idField(props, 'Puste = bieżący apartament.'),
					el(TextControl, { label: 'albo obiekt (nazwa lub ID)', value: props.attributes.obiekt,
						onChange: function (v) { props.setAttributes({ obiekt: v }); } }))),
				el(SSR, { key: 's', block: 'bookmanager/o-obiekcie', attributes: props.attributes })
			];
		},
		save: function () { return null; }
	});
})(window.wp);
