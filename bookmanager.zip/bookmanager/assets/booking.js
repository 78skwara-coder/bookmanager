/**
 * BookManager — widżet rezerwacji (czysty JS, bez bibliotek).
 * Kalendarz z zajętymi nocami, minimum i lukami → skład gości z dostawkami → opcje → cena na żywo z serwera.
 * Serwer i tak sprawdza wszystko ponownie; tu tylko prowadzimy gościa, żeby nie trafiał na błędy.
 */
(function () {
	'use strict';

	var MONTHS = ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
	var DAYS = ['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'];

	/* ---------- daty jako 'YYYY-MM-DD' (bez stref czasowych) ---------- */
	function parse(s) { var p = s.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); }
	function fmt(d) { return d.toISOString().slice(0, 10); }
	function addDays(s, n) { var d = parse(s); d.setUTCDate(d.getUTCDate() + n); return fmt(d); }
	function monthStart(s) { return s.slice(0, 8) + '01'; }
	function addMonths(s, n) { var d = parse(monthStart(s)); d.setUTCMonth(d.getUTCMonth() + n); return fmt(d); }
	function diffDays(a, b) { return Math.round((parse(b) - parse(a)) / 864e5); }
	var MONTHS_GEN = ['stycznia', 'lutego', 'marca', 'kwietnia', 'maja', 'czerwca', 'lipca', 'sierpnia', 'września', 'października', 'listopada', 'grudnia'];
	function human(s) { var d = parse(s); return d.getUTCDate() + ' ' + MONTHS_GEN[d.getUTCMonth()] + ' ' + d.getUTCFullYear(); }
	function pl(n, one, few, many) { if (n === 1) return one; var d = n % 10, t = n % 100; return d >= 2 && d <= 4 && (t < 12 || t > 14) ? few : many; }

	/** Adres endpointu — działa i z ładnymi adresami (/wp-json/…), i ze zwykłymi (?rest_route=…). */
	function endpoint(api, path, qs) { var u = api + path; return u + (u.indexOf('?') === -1 ? '?' : '&') + qs; }

	function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

	function Widget(root) {
		this.root = root;
		this.cfg = JSON.parse(root.getAttribute('data-bm-config'));
		this.money = new Intl.NumberFormat('pl-PL', { style: 'currency', currency: this.cfg.currency || 'PLN' });
		this.booked = {}; this.firm = {}; this.loaded = {};
		this.today = null; this.view = null;
		this.checkIn = null; this.checkOut = null;
		this.party = { adults: Math.min(2, Math.max(1, this.cfg.beds || 1)), children: [], ebA: 0, ebC: 0 };
		this.extras = {};
		this.deposit = null; this.accepted = false;
		this.quoteTimer = null; this.quoteSeq = 0;
		this.build();
		this.loadMonths(null, 3);
	}

	/* ================= szkielet ================= */

	Widget.prototype.build = function () {
		var r = this.root; r.innerHTML = '';
		this.elCal = el('div', 'bm-cal'); r.appendChild(this.elCal);
		this.elDates = el('p', 'bm-booking__dates'); r.appendChild(this.elDates);
		this.elParty = el('div', 'bm-party'); r.appendChild(this.elParty);
		if (this.cfg.extras.length) { this.elExtras = el('div', 'bm-extras'); r.appendChild(this.elExtras); }
		this.elQuote = el('div', 'bm-quote'); r.appendChild(this.elQuote);
		this.elAction = el('div', 'bm-booking__action'); r.appendChild(this.elAction);
		this.renderParty(); this.renderExtras(); this.renderDates(); this.renderAction();
	};

	/* ================= dane kalendarza ================= */

	Widget.prototype.loadMonths = function (from, count) {
		var self = this, start = from || null, jobs = [];
		if (!start) { // pierwsze ładowanie — dziś z serwera
			var t = new Date(); start = monthStart(fmt(new Date(Date.UTC(t.getFullYear(), t.getMonth(), 1))));
		}
		for (var i = 0; i < count; i++) {
			var m = addMonths(start, i);
			if (self.loaded[m]) continue;
			self.loaded[m] = 'loading';
			jobs.push(self.fetchMonth(m));
		}
		return Promise.all(jobs).then(function () { if (!self.view) self.view = monthStart(self.today); self.renderCal(); });
	};

	Widget.prototype.fetchMonth = function (m) {
		var self = this, url = endpoint(this.cfg.api, '/calendar', 'from=' + m + '&to=' + addMonths(m, 1));
		return fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			if (!d || !d.booked) { self.loaded[m] = false; return; }
			self.today = d.today;
			d.booked.forEach(function (x) { self.booked[x] = 1; });
			d.firm.forEach(function (x) { self.firm[x] = 1; });
			self.loaded[m] = true;
		}).catch(function () { self.loaded[m] = false; });
	};

	/* ================= logika dat ================= */

	/** Pierwsza zajęta noc od dnia `from` (włącznie) w załadowanych danych albo null. */
	Widget.prototype.nextBooked = function (from) {
		for (var i = 0, d = from; i < 400; i++, d = addDays(d, 1)) {
			if (this.booked[d]) return d;
			if (!this.loaded[monthStart(d)]) return null;
		}
		return null;
	};

	Widget.prototype.canCheckIn = function (d) { return d >= this.today && !this.booked[d]; };

	/** Czy `d` może być dniem wyjazdu dla wybranego przyjazdu (noce wolne, minimum albo luka). */
	Widget.prototype.canCheckOut = function (d) {
		var ci = this.checkIn; if (!ci || d <= ci) return false;
		var block = this.nextBooked(ci);
		if (block && d > block) return false;
		var n = diffDays(ci, d);
		if (n >= this.cfg.min_nights) return true;
		// luka: dokładnie do następnej trwałej rezerwacji, a przed przyjazdem trwała rezerwacja albo dziś
		return this.cfg.fill_gaps && block === d && !!this.firm[d] && (ci === this.today || !!this.firm[addDays(ci, -1)]);
	};

	Widget.prototype.pick = function (d) {
		if (this.checkIn && !this.checkOut && this.canCheckOut(d)) {
			this.checkOut = d;
		} else if (this.canCheckIn(d)) {
			this.checkIn = d; this.checkOut = null;
			this.loadMonths(this.view, 3); // dociągnij dane do sprawdzania kolejnych nocy
		}
		this.renderCal(); this.renderDates(); this.requestQuote();
	};

	/* ================= kalendarz ================= */

	Widget.prototype.renderCal = function () {
		var self = this, c = this.elCal; c.innerHTML = '';
		if (!this.today) { c.appendChild(el('p', 'bm-error', 'Nie udało się wczytać kalendarza. Odśwież stronę.')); return; }

		var head = el('div', 'bm-cal__head');
		var prev = el('button', 'bm-cal__nav bm-cal__prev', '‹'); prev.type = 'button'; prev.setAttribute('aria-label', 'Poprzedni miesiąc');
		var next = el('button', 'bm-cal__nav bm-cal__next', '›'); next.type = 'button'; next.setAttribute('aria-label', 'Następny miesiąc');
		prev.disabled = this.view <= monthStart(this.today);
		prev.onclick = function () { self.view = addMonths(self.view, -1); self.renderCal(); };
		next.onclick = function () { self.view = addMonths(self.view, 1); self.loadMonths(self.view, 2); self.renderCal(); };
		var v = parse(this.view);
		head.appendChild(prev); head.appendChild(el('span', 'bm-cal__title', MONTHS[v.getUTCMonth()] + ' ' + v.getUTCFullYear())); head.appendChild(next);
		c.appendChild(head);

		var grid = el('div', 'bm-cal__grid');
		DAYS.forEach(function (d) { grid.appendChild(el('span', 'bm-cal__dow', d)); });
		var offset = (v.getUTCDay() + 6) % 7; // poniedziałek = 0
		for (var i = 0; i < offset; i++) grid.appendChild(el('span', 'bm-cal__pad'));

		var days = new Date(Date.UTC(v.getUTCFullYear(), v.getUTCMonth() + 1, 0)).getUTCDate();
		for (var day = 1; day <= days; day++) {
			var d = this.view.slice(0, 8) + (day < 10 ? '0' : '') + day;
			var b = el('button', 'bm-cal__day', String(day)); b.type = 'button'; b.setAttribute('data-date', d);
			var cls = [], ok;
			if (d < this.today) cls.push('is-past');
			if (this.booked[d]) cls.push('is-booked');
			if (d === this.checkIn) cls.push('is-start');
			if (d === this.checkOut) cls.push('is-end');
			if (this.checkIn && this.checkOut && d > this.checkIn && d < this.checkOut) cls.push('is-range');
			if (this.checkIn && !this.checkOut) {
				ok = this.canCheckOut(d) || this.canCheckIn(d);
				if (this.canCheckOut(d)) cls.push('is-checkout');
			} else ok = this.canCheckIn(d);
			if (!this.loaded[monthStart(d)]) ok = false;
			b.disabled = !ok;
			if (cls.length) b.className += ' ' + cls.join(' ');
			b.onclick = (function (date) { return function () { self.pick(date); }; })(d);
			grid.appendChild(b);
		}
		c.appendChild(grid);
		var minTxt = 'Minimalny pobyt: ' + this.cfg.min_nights + ' ' + pl(this.cfg.min_nights, 'noc', 'noce', 'nocy') + '.';
		var hint = this.checkIn && this.checkOut ? 'Aby zmienić termin, wybierz nowy dzień przyjazdu.'
			: this.checkIn ? 'Wybierz dzień wyjazdu (dni z ramką). ' + minTxt : 'Wybierz dzień przyjazdu. ' + minTxt;
		c.appendChild(el('p', 'bm-cal__hint', hint));
	};

	Widget.prototype.renderDates = function () {
		var t = this.elDates;
		if (this.checkIn && this.checkOut) {
			var n = diffDays(this.checkIn, this.checkOut);
			t.textContent = human(this.checkIn) + ' → ' + human(this.checkOut) + ' · ' + n + ' ' + pl(n, 'noc', 'noce', 'nocy');
		} else t.textContent = this.checkIn ? 'Przyjazd: ' + human(this.checkIn) : '';
	};

	/* ================= goście i dostawki ================= */

	Widget.prototype.sleepers = function (children) {
		var inf = this.cfg.infant_age;
		return children.filter(function (a) { return a === '' || inf === null || a > inf; }).length;
	};
	Widget.prototype.fits = function (a, kids, ebA, ebC) {
		var s = this.sleepers(kids), beds = this.cfg.beds;
		return a <= beds + ebA && a + s <= beds + ebA + ebC;
	};
	Widget.prototype.ebAvail = function (type, n, other) {
		var eb = this.cfg[type]; return !!eb && n <= eb.max && n + other <= this.cfg.eb_max_total;
	};
	/** Zdejmij dostawki, które przestały być potrzebne. */
	Widget.prototype.normalize = function () {
		var p = this.party;
		while (p.ebA > 0 && this.fits(p.adults, p.children, p.ebA - 1, p.ebC)) p.ebA--;
		while (p.ebC > 0 && this.fits(p.adults, p.children, p.ebA, p.ebC - 1)) p.ebC--;
	};

	Widget.prototype.renderParty = function () {
		var self = this, p = this.party, box = this.elParty; box.innerHTML = '';
		box.appendChild(el('h4', 'bm-booking__label', 'Goście'));

		function stepper(label, value, onMinus, onPlus, minusOk, plusOk, cls) {
			var row = el('div', 'bm-step ' + (cls || ''));
			row.appendChild(el('span', 'bm-step__label', label));
			var m = el('button', 'bm-step__btn', '−'); m.type = 'button'; m.disabled = !minusOk; m.onclick = onMinus;
			var v = el('span', 'bm-step__value', String(value));
			var pbtn = el('button', 'bm-step__btn', '+'); pbtn.type = 'button'; pbtn.disabled = !plusOk; pbtn.onclick = onPlus;
			row.appendChild(m); row.appendChild(v); row.appendChild(pbtn);
			return row;
		}
		var changed = function () { self.normalize(); self.renderParty(); self.requestQuote(); };

		var addAdultOk = this.fits(p.adults + 1, p.children, p.ebA, p.ebC);
		box.appendChild(stepper('Dorośli', p.adults,
			function () { p.adults--; changed(); }, function () { p.adults++; changed(); },
			p.adults > 1, addAdultOk, 'bm-step--adults'));

		var addChildOk = this.fits(p.adults, p.children.concat(['']), p.ebA, p.ebC);
		box.appendChild(stepper('Dzieci (0–' + this.cfg.max_child + ' lat)', p.children.length,
			function () { p.children.pop(); changed(); }, function () { p.children.push(''); changed(); },
			p.children.length > 0, addChildOk && p.children.length < 20, 'bm-step--children'));

		// wiek każdego dziecka
		p.children.forEach(function (age, i) {
			var row = el('label', 'bm-child');
			row.appendChild(el('span', 'bm-child__label', 'Wiek dziecka ' + (i + 1)));
			var sel = el('select', 'bm-child__age');
			var o0 = el('option', '', 'wybierz'); o0.value = ''; sel.appendChild(o0);
			for (var a = 0; a <= self.cfg.max_child; a++) { var o = el('option', '', a + ' ' + pl(a, 'rok', 'lata', 'lat')); o.value = a; if (age === a) o.selected = true; sel.appendChild(o); }
			sel.onchange = function () { p.children[i] = sel.value === '' ? '' : +sel.value; changed(); };
			row.appendChild(sel); box.appendChild(row);
		});

		// propozycje dostawek, gdy brak miejsc
		var offers = el('div', 'bm-offers');
		var price = function (eb) { return eb.price > 0 ? ' (+' + self.money.format(eb.price) + ' / noc)' : ''; };
		if (!addAdultOk && this.ebAvail('eb_adult', p.ebA + 1, p.ebC) && this.fits(p.adults + 1, p.children, p.ebA + 1, p.ebC)) {
			offers.appendChild(this.offer('Brak wolnych miejsc dla kolejnej osoby dorosłej. Dodaj dostawkę dorosłą' + price(this.cfg.eb_adult) + '.', 'Dodaj dostawkę i dorosłego',
				function () { p.ebA++; p.adults++; changed(); }));
		}
		if (!addChildOk) {
			if (this.ebAvail('eb_child', p.ebC + 1, p.ebA) && this.fits(p.adults, p.children.concat(['']), p.ebA, p.ebC + 1)) {
				offers.appendChild(this.offer('Brak wolnych miejsc dla kolejnego dziecka. Dodaj dostawkę dziecięcą' + price(this.cfg.eb_child) + '.', 'Dodaj dostawkę i dziecko',
					function () { p.ebC++; p.children.push(''); changed(); }));
			} else if (this.ebAvail('eb_adult', p.ebA + 1, p.ebC) && this.fits(p.adults, p.children.concat(['']), p.ebA + 1, p.ebC)) {
				offers.appendChild(this.offer('Brak wolnych miejsc dla kolejnego dziecka. Dodaj dostawkę' + price(this.cfg.eb_adult) + '.', 'Dodaj dostawkę i dziecko',
					function () { p.ebA++; p.children.push(''); changed(); }));
			}
		}
		if (offers.childNodes.length) box.appendChild(offers);

		// wybrane dostawki
		[['ebA', 'eb_adult', 'Dostawka dorosła'], ['ebC', 'eb_child', 'Dostawka dziecięca']].forEach(function (t) {
			if (!p[t[0]]) return;
			var row = el('div', 'bm-eb');
			row.appendChild(el('span', 'bm-eb__label', t[2] + ': ' + p[t[0]] + price(self.cfg[t[1]])));
			box.appendChild(row);
		});
		var total = p.adults + p.children.length;
		box.appendChild(el('p', 'bm-party__summary', total + ' ' + pl(total, 'osoba', 'osoby', 'osób') + ' · apartament ma ' + this.cfg.beds + ' ' + pl(this.cfg.beds, 'miejsce', 'miejsca', 'miejsc') +
			(this.cfg.infant_age !== null ? ' (dzieci do ' + this.cfg.infant_age + ' lat nie zajmują miejsca)' : '')));
	};

	Widget.prototype.offer = function (text, btnText, onClick) {
		var o = el('div', 'bm-offer'); o.appendChild(el('span', 'bm-offer__text', text));
		var b = el('button', 'bm-offer__btn', btnText); b.type = 'button'; b.onclick = onClick; o.appendChild(b);
		return o;
	};

	/* ================= opcje dodatkowe ================= */

	Widget.prototype.renderExtras = function () {
		if (!this.elExtras) return;
		var self = this, box = this.elExtras; box.innerHTML = '';
		box.appendChild(el('h4', 'bm-booking__label', 'Opcje dodatkowe'));
		this.cfg.extras.forEach(function (x) {
			var row = el('label', 'bm-extra');
			var price = x.price > 0 ? self.money.format(x.price) + (x.charge_type === 'night' ? ' / noc' : ' / pobyt') : 'bezpłatnie';
			var input;
			if (x.allow_qty) {
				input = el('input', 'bm-extra__qty'); input.type = 'number'; input.min = 0; input.max = x.max_qty; input.value = self.extras[x.id] || 0;
				input.onchange = function () { var v = Math.max(0, Math.min(x.max_qty, parseInt(input.value, 10) || 0)); input.value = v; if (v) self.extras[x.id] = v; else delete self.extras[x.id]; self.requestQuote(); };
			} else {
				input = el('input', 'bm-extra__check'); input.type = 'checkbox'; input.checked = !!self.extras[x.id];
				input.onchange = function () { if (input.checked) self.extras[x.id] = 1; else delete self.extras[x.id]; self.requestQuote(); };
			}
			row.appendChild(input);
			row.appendChild(el('span', 'bm-extra__name', x.name));
			row.appendChild(el('span', 'bm-extra__price', price));
			if (x.description) row.appendChild(el('span', 'bm-extra__desc', x.description));
			box.appendChild(row);
		});
	};

	/* ================= wycena ================= */

	Widget.prototype.requestQuote = function () {
		var self = this;
		clearTimeout(this.quoteTimer);
		if (!this.checkIn || !this.checkOut) { this.quote = null; this.renderQuote(); return; }
		if (this.party.children.indexOf('') !== -1) { this.quote = { message: 'Podaj wiek każdego dziecka, aby zobaczyć cenę.' }; this.renderQuote(); return; }
		this.elQuote.classList.add('is-loading');
		this.quoteTimer = setTimeout(function () { self.fetchQuote(); }, 250);
	};

	Widget.prototype.fetchQuote = function () {
		var self = this, p = this.party, seq = ++this.quoteSeq;
		var ex = Object.keys(this.extras).map(function (id) { return id + ':' + self.extras[id]; }).join(',');
		var q = 'check_in=' + this.checkIn + '&check_out=' + this.checkOut + '&adults=' + p.adults +
			'&children=' + p.children.join(',') + '&eb_adult=' + p.ebA + '&eb_child=' + p.ebC + (ex ? '&extras=' + ex : '');
		fetch(endpoint(this.cfg.api, '/quote', q), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			if (seq !== self.quoteSeq) return; // nowsze zapytanie w drodze
			self.quote = d; self.renderQuote();
		}).catch(function () { if (seq === self.quoteSeq) { self.quote = { message: 'Nie udało się pobrać ceny. Spróbuj ponownie.' }; self.renderQuote(); } });
	};

	Widget.prototype.renderQuote = function () {
		var self = this, box = this.elQuote, q = this.quote; box.innerHTML = ''; box.classList.remove('is-loading');
		if (!q) { this.renderAction(); return; }
		if (q.code || q.message && q.total === undefined) {
			box.appendChild(el('p', 'bm-error', q.message || 'Nie można wycenić pobytu.'));
			if (q.code === 'bm_unavailable') { this.checkOut = null; this.renderCal(); }
			this.renderAction(); return;
		}
		if (q.is_gap) box.appendChild(el('p', 'bm-quote__gap', 'Wolne okienko między rezerwacjami — krótszy pobyt możliwy.'));
		var ul = el('ul', 'bm-quote__lines');
		q.lines.forEach(function (l) {
			var li = el('li', 'bm-quote__line bm-quote__line--' + l.type);
			li.appendChild(el('span', 'bm-quote__label', l.label));
			li.appendChild(el('span', 'bm-quote__amount', l.amount > 0 ? self.money.format(l.amount) : 'gratis'));
			ul.appendChild(li);
		});
		box.appendChild(ul);
		var tot = el('p', 'bm-quote__total');
		tot.appendChild(el('span', 'bm-quote__label', 'Razem'));
		tot.appendChild(el('strong', 'bm-quote__amount', self.money.format(q.total)));
		box.appendChild(tot);
		box.appendChild(el('p', 'bm-quote__per-night', self.money.format(q.per_night) + ' za noc'));
		if (q.city_tax && q.city_tax.amount > 0) {
			box.appendChild(el('p', 'bm-quote__city-tax', 'Opłata miejscowa ' + self.money.format(q.city_tax.amount) + ' — płatna na miejscu, poza ceną.'));
		}
		// Zaliczka: minimum ustala obiekt, gość może zapłacić więcej (do całości).
		if (this.deposit === null || this.deposit < q.deposit_min) this.deposit = q.deposit_min;
		if (this.deposit > q.total) this.deposit = q.total;
		var dep = el('div', 'bm-deposit');
		var lab = el('label', 'bm-deposit__label', 'Zaliczka płatna teraz ');
		var inp = el('input', 'bm-deposit__input'); inp.type = 'number'; inp.step = '0.01'; inp.min = q.deposit_min; inp.max = q.total; inp.value = this.deposit.toFixed(2);
		lab.appendChild(inp); dep.appendChild(lab);
		var rest = el('p', 'bm-deposit__rest');
		var showRest = function () { rest.textContent = 'Pozostanie do zapłaty zgodnie z umową: ' + self.money.format(Math.max(0, q.total - self.deposit)) + '. Minimalna zaliczka: ' + self.money.format(q.deposit_min) + ' (' + q.deposit_percent + '%).'; };
		inp.onchange = function () {
			var v = parseFloat(String(inp.value).replace(',', '.')) || 0;
			self.deposit = Math.round(Math.min(q.total, Math.max(q.deposit_min, v)) * 100) / 100;
			inp.value = self.deposit.toFixed(2); showRest();
		};
		showRest(); dep.appendChild(rest); box.appendChild(dep);
		this.renderAction();
	};

	Widget.prototype.renderAction = function () {
		var self = this, box = this.elAction; box.innerHTML = '';
		var ready = this.quote && this.quote.total !== undefined;
		var b = el('button', 'bm-booking__submit', 'Rezerwuj'); b.type = 'button';
		var update = function () { b.disabled = !ready || !self.cfg.booking_open || (self.cfg.acceptance && !self.accepted); };

		if (ready && this.cfg.acceptance) {
			var t = el('div', 'bm-terms');
			t.appendChild(el('h4', 'bm-booking__label', 'Warunki pobytu'));
			t.appendChild(el('div', 'bm-terms__text', this.cfg.acceptance));
			var l = el('label', 'bm-terms__accept'), c = el('input'); c.type = 'checkbox'; c.checked = this.accepted;
			c.onchange = function () { self.accepted = c.checked; update(); };
			l.appendChild(c); l.appendChild(document.createTextNode(' Zapoznałem(-am) się i akceptuję powyższe warunki pobytu'));
			t.appendChild(l); box.appendChild(t);
		}
		update();
		b.onclick = function () { self.submit(b); };
		box.appendChild(b);
		if (ready && !this.cfg.booking_open) box.appendChild(el('p', 'bm-booking__soon', 'Rezerwacja online zostanie uruchomiona wkrótce.'));
	};

	/** Zwykły formularz add-to-cart WooCommerce — serwer liczy i sprawdza wszystko jeszcze raz. */
	Widget.prototype.submit = function (btn) {
		var self = this, p = this.party, f = document.createElement('form');
		f.method = 'post'; f.action = this.cfg.cart_url; f.style.display = 'none';
		var add = function (k, v) { var i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); };
		add('add-to-cart', this.cfg.apartment_id); add('quantity', 1);
		add('bm_check_in', this.checkIn); add('bm_check_out', this.checkOut);
		add('bm_adults', p.adults); add('bm_children', p.children.join(','));
		add('bm_eb_adult', p.ebA); add('bm_eb_child', p.ebC);
		add('bm_extras', Object.keys(this.extras).map(function (id) { return id + ':' + self.extras[id]; }).join(','));
		add('bm_deposit', (this.deposit || 0).toFixed(2));
		add('bm_accept', this.accepted ? 1 : 0);
		document.body.appendChild(f);
		btn.disabled = true; btn.textContent = 'Rezerwuję…';
		f.submit();
	};

	/* ---------- start ---------- */
	function init() {
		document.querySelectorAll('.bm-booking[data-bm-config]').forEach(function (n) {
			if (!n.bmWidget) n.bmWidget = new Widget(n);
		});
	}
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
