/**
 * BookManager — widżet rezerwacji (czysty JS, bez bibliotek).
 * Kalendarz z zajętymi nocami, minimum i lukami → skład gości z dostawkami → opcje → cena na żywo z serwera.
 * Serwer i tak sprawdza wszystko ponownie; tu tylko prowadzimy gościa, żeby nie trafiał na błędy.
 */
(function () {
	'use strict';

	var MONTHS = ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
	var DAYS = ['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'];

	/* ---------- daty jako 'YYYY-MM-DD' (bez stref czasowych) ---------- */
	function parse(s) { var p = s.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); }
	function fmt(d) { return d.toISOString().slice(0, 10); }
	function addDays(s, n) { var d = parse(s); d.setUTCDate(d.getUTCDate() + n); return fmt(d); }
	function monthStart(s) { return s.slice(0, 8) + '01'; }
	function addMonths(s, n) { var d = parse(monthStart(s)); d.setUTCMonth(d.getUTCMonth() + n); return fmt(d); }
	function diffDays(a, b) { return Math.round((parse(b) - parse(a)) / 864e5); }
	var MONTHS_GEN = ['stycznia', 'lutego', 'marca', 'kwietnia', 'maja', 'czerwca', 'lipca', 'sierpnia', 'września', 'października', 'listopada', 'grudnia'];
	function human(s) { var d = parse(s); return d.getUTCDate() + ' ' + MONTHS_GEN[d.getUTCMonth()] + ' ' + d.getUTCFullYear(); }
	function pl(n, one, few, many) { if (n === 1) return one; var d = n % 10, t = n % 100; return d >= 2 && d <= 4 && (t < 12 || t > 14) ? few : many; }

	/** Adres endpointu — działa i z ładnymi adresami (/wp-json/…), i ze zwykłymi (?rest_route=…). */
	function endpoint(api, path, qs) { var u = api + path; return u + (u.indexOf('?') === -1 ? '?' : '&') + qs; }

	function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

	var MONTHS_SHORT = ['sty', 'lut', 'mar', 'kwi', 'maj', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru'];
	function short(s) { var d = parse(s); return d.getUTCDate() + ' ' + MONTHS_SHORT[d.getUTCMonth()] + ' ' + d.getUTCFullYear(); }

	var ICON = {
		left: '<path d="M15 5l-7 7 7 7"/>', right: '<path d="M9 5l7 7-7 7"/>',
		minus: '<path d="M6 12h12"/>', plus: '<path d="M12 6v12M6 12h12"/>', check: '<path d="M5 12l5 5L20 7"/>'
	};
	function icon(n) { return '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + ICON[n] + '</svg>'; }
	function btn(cls, html, label) { var b = el('button', cls); b.type = 'button'; b.innerHTML = html; if (label) b.setAttribute('aria-label', label); return b; }

	function Widget(root) {
		this.root = root;
		this.cfg = JSON.parse(root.getAttribute('data-bm-config'));
		this.money = new Intl.NumberFormat('pl-PL', { style: 'currency', currency: this.cfg.currency || 'PLN' });
		this.booked = {}; this.firm = {}; this.loaded = {}; this.seasons = [];
		this.today = null; this.view = null;
		this.checkIn = null; this.checkOut = null; this.hover = null;
		this.party = { adults: Math.min(2, Math.max(1, this.cfg.beds || 1)), children: [], ebA: 0, ebC: 0 };
		this.extras = {};
		this.deposit = null; this.accepted = false;
		this.quoteTimer = null; this.quoteSeq = 0;
		this.step = 0;
		this.build();
		var self = this, pre = this.cfg.panel ? null : this.prefill();
		this.loadMonths(null, Math.max(3, (this.cfg.months || 1) + 1)).then(function () { if (pre) self.applyPrefill(pre); });
	}

	/* ================= termin z adresu (lista apartamentów, „Zmień termin”) ================= */

	Widget.prototype.prefill = function () {
		var q = new URLSearchParams(window.location.search), ci = q.get('bm_in'), co = q.get('bm_out');
		var ok = function (s) { return s && /^\d{4}-\d{2}-\d{2}$/.test(s); };
		if (!ok(ci) || !ok(co) || co <= ci) return null;
		var kids = (q.get('bm_children') || '').split(',').filter(function (x) { return /^\d{1,2}$/.test(x); }).map(Number);
		return { ci: ci, co: co, adults: Math.max(1, parseInt(q.get('bm_adults'), 10) || 0), kids: kids };
	};

	Widget.prototype.applyPrefill = function (pre) {
		var self = this;
		if (!this.today || pre.ci < this.today) return;
		var p = this.party;
		p.adults = Math.min(pre.adults, 30); p.children = pre.kids.slice(0, 20);
		// dostawki, jeśli bez nich skład się nie mieści
		for (var guard = 0; guard < 20 && !this.fits(p.adults, p.children, p.ebA, p.ebC); guard++) {
			var needA = p.adults > this.cfg.beds + p.ebA;
			if (needA && this.ebAvail('eb_adult', p.ebA + 1, p.ebC)) p.ebA++;
			else if (this.ebAvail('eb_child', p.ebC + 1, p.ebA)) p.ebC++;
			else if (this.ebAvail('eb_adult', p.ebA + 1, p.ebC)) p.ebA++;
			else break;
		}
		this.view = monthStart(pre.ci);
		this.loadMonths(this.view, (this.cfg.months || 1) + 2).then(function () {
			if (self.canCheckIn(pre.ci)) {
				self.checkIn = pre.ci; self.checkOut = null;
				if (self.canCheckOut(pre.co)) self.checkOut = pre.co;
			}
			if (!self.checkOut) self.prefillNote = 'Termin ' + short(pre.ci) + ' – ' + short(pre.co) + ' nie jest dostępny w całości — wybierz inny w kalendarzu.';
			self.renderParty(); self.renderExtras(); self.renderCal(); self.renderDates(); self.requestQuote();
			if (self.cfg.wizard) { self.step = self.checkOut && self.stepError(1) === '' ? self.steps.length - 1 : 0; self.renderWizard(); }
		});
	};

	/* ================= szkielet ================= */

	Widget.prototype.build = function () {
		var self = this, r = this.root; r.innerHTML = '';
		if (this.cfg.show_price && this.cfg.from) {
			var head = el('div', 'bm-booking__price'); head.textContent = this.cfg.from; r.appendChild(head);
		}
		this.elDatesPane = el('div', 'bm-pane bm-pane--dates');
		this.elDates = el('div', 'bm-dates'); this.elDatesPane.appendChild(this.elDates);
		this.elCal = el('div', 'bm-cal'); this.elDatesPane.appendChild(this.elCal);
		this.elParty = el('div', 'bm-party');
		if (this.cfg.extras.length) this.elExtras = el('div', 'bm-extras');
		this.elQuote = el('div', 'bm-quote');
		this.elAction = el('div', 'bm-booking__action');

		if (this.cfg.wizard) {
			this.steps = [
				{ name: 'Termin', nodes: [this.elDatesPane] },
				{ name: 'Goście', nodes: [this.elParty] }
			];
			if (this.elExtras) this.steps.push({ name: 'Opcje', nodes: [this.elExtras] });
			this.steps.push({ name: 'Podsumowanie', nodes: [this.elQuote, this.elAction] });
			this.elSteps = el('ol', 'bm-steps'); r.appendChild(this.elSteps);
			this.elPanels = el('div', 'bm-wpanels'); r.appendChild(this.elPanels);
			this.steps.forEach(function (st) {
				st.panel = el('div', 'bm-wpanel');
				st.nodes.forEach(function (n) { st.panel.appendChild(n); });
				self.elPanels.appendChild(st.panel);
			});
			this.elNav = el('div', 'bm-wnav'); r.appendChild(this.elNav);
		} else {
			var body = el('div', 'bm-booking__body'), rest = el('div', 'bm-pane bm-pane--rest');
			body.appendChild(this.elDatesPane);
			[this.elParty, this.elExtras, this.elQuote, this.elAction].forEach(function (n) { if (n) rest.appendChild(n); });
			body.appendChild(rest); r.appendChild(body);
		}
		this.renderParty(); this.renderExtras(); this.renderDates(); this.renderAction(); this.renderWizard();
	};

	/* ================= kreator (kroki) ================= */

	Widget.prototype.stepError = function (i) {
		var name = this.steps[i].name;
		if (name === 'Termin' && !(this.checkIn && this.checkOut)) return 'Wybierz dzień przyjazdu i wyjazdu.';
		if (name === 'Goście' && this.party.children.indexOf('') !== -1) return 'Podaj wiek każdego dziecka.';
		return '';
	};

	Widget.prototype.goStep = function (i) {
		for (var k = 0; k < i; k++) { var e = this.stepError(k); if (e) { i = k; this.navError = e; break; } }
		this.step = Math.max(0, Math.min(this.steps.length - 1, i));
		this.renderWizard();
		var top = this.root.getBoundingClientRect().top;
		if (top < 0) this.root.scrollIntoView({ behavior: 'smooth', block: 'start' });
	};

	Widget.prototype.renderWizard = function () {
		if (!this.cfg.wizard) return;
		var self = this, last = this.steps.length - 1;
		this.elSteps.innerHTML = '';
		this.steps.forEach(function (st, i) {
			var li = el('li', 'bm-steps__item' + (i === self.step ? ' is-current' : '') + (i < self.step ? ' is-done' : ''));
			var b = btn('bm-steps__btn', '<span class="bm-steps__num">' + (i < self.step ? icon('check') : i + 1) + '</span><span class="bm-steps__name">' + st.name + '</span>');
			if (i === self.step) b.setAttribute('aria-current', 'step');
			b.onclick = function () { self.navError = ''; self.goStep(i); };
			li.appendChild(b); self.elSteps.appendChild(li);
			st.panel.hidden = i !== self.step;
		});
		var n = this.elNav; n.innerHTML = '';
		if (this.step > 0) {
			var back = btn('bm-btn bm-btn--ghost bm-wnav__back', icon('left') + '<span>Wstecz</span>');
			back.onclick = function () { self.navError = ''; self.goStep(self.step - 1); };
			n.appendChild(back);
		} else n.appendChild(el('span'));
		var mid = el('div', 'bm-wnav__mid');
		if (this.navError) mid.appendChild(el('span', 'bm-error', this.navError));
		else if (this.quote && this.quote.total !== undefined) mid.appendChild(el('span', 'bm-wnav__total', 'Razem ' + this.money.format(this.quote.total)));
		n.appendChild(mid);
		if (this.step < last) {
			var next = btn('bm-btn bm-btn--primary bm-wnav__next', '<span>Dalej</span>' + icon('right'));
			next.onclick = function () {
				var e = self.stepError(self.step);
				self.navError = e;
				if (e) { self.renderWizard(); return; }
				self.goStep(self.step + 1);
			};
			n.appendChild(next);
		}
		n.hidden = false;
	};

	/* ================= dane kalendarza ================= */

	Widget.prototype.loadMonths = function (from, count) {
		var self = this, start = from || null, jobs = [];
		if (!start) { // pierwsze ładowanie — dziś z serwera
			var t = new Date(); start = monthStart(fmt(new Date(Date.UTC(t.getFullYear(), t.getMonth(), 1))));
		}
		for (var i = 0; i < count; i++) {
			var m = addMonths(start, i);
			if (self.loaded[m]) continue;
			self.loaded[m] = 'loading';
			jobs.push(self.fetchMonth(m));
		}
		return Promise.all(jobs).then(function () { if (!self.view) self.view = monthStart(self.today); self.renderCal(); });
	};

	Widget.prototype.fetchMonth = function (m) {
		var self = this, url = endpoint(this.cfg.api, '/calendar', 'from=' + m + '&to=' + addMonths(m, 1));
		return fetch(url, { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			if (!d || !d.booked) { self.loaded[m] = false; return; }
			self.today = d.today;
			d.booked.forEach(function (x) { self.booked[x] = 1; });
			d.firm.forEach(function (x) { self.firm[x] = 1; });
			(d.seasons || []).forEach(function (r) { if (!self.seasons.some(function (x) { return x.id === r.id; })) self.seasons.push(r); });
			self.loaded[m] = true;
		}).catch(function () { self.loaded[m] = false; });
	};

	/* ================= logika dat ================= */

	/** Pierwsza zajęta noc od dnia `from` (włącznie) w załadowanych danych albo null. */
	Widget.prototype.nextBooked = function (from) {
		for (var i = 0, d = from; i < 400; i++, d = addDays(d, 1)) {
			if (this.booked[d]) return d;
			if (!this.loaded[monthStart(d)]) return null;
		}
		return null;
	};

	/** Sezon obowiązujący w danej nocy (jak na serwerze: krótszy wygrywa, przy remisie nowszy). */
	Widget.prototype.seasonOf = function (d) {
		var best = null;
		this.seasons.forEach(function (s) {
			if (d < s.from || d > s.to) return;
			if (!best || s.length < best.length || (s.length === best.length && s.id > best.id)) best = s;
		});
		return best;
	};
	Widget.prototype.minFor = function (d) { var s = this.seasonOf(d); return s ? s.min_nights : this.cfg.min_nights; };
	/** Początek luki: noc przed przyjazdem zajęta na stałe albo przyjazd dziś. */
	Widget.prototype.gapStart = function (d) { return this.cfg.fill_gaps && (d === this.today || !!this.firm[addDays(d, -1)]); };
	Widget.prototype.arrivalOk = function (d) {
		var s = this.seasonOf(d);
		if (!s || !s.arrival_days.length) return true;
		var dow = (parse(d).getUTCDay() + 6) % 7 + 1; // 1 = poniedziałek
		return s.arrival_days.indexOf(dow) !== -1 || this.gapStart(d);
	};

	Widget.prototype.canCheckIn = function (d) { return d >= this.today && !this.booked[d] && this.arrivalOk(d); };

	/** Czy `d` może być dniem wyjazdu dla wybranego przyjazdu (noce wolne, minimum albo luka). */
	Widget.prototype.canCheckOut = function (d) {
		var ci = this.checkIn; if (!ci || d <= ci) return false;
		var block = this.nextBooked(ci);
		if (block && d > block) return false;
		var n = diffDays(ci, d);
		if (n >= this.minFor(ci)) return true;
		// luka: dokładnie do następnej trwałej rezerwacji, a przed przyjazdem trwała rezerwacja albo dziś
		return this.cfg.fill_gaps && block === d && !!this.firm[d] && this.gapStart(ci);
	};

	Widget.prototype.pick = function (d) {
		if (this.checkIn && !this.checkOut && this.canCheckOut(d)) {
			this.checkOut = d;
		} else if (this.canCheckIn(d)) {
			this.checkIn = d; this.checkOut = null;
			this.loadMonths(this.view, (this.cfg.months || 1) + 2); // dociągnij dane do sprawdzania kolejnych nocy
		}
		this.hover = null;
		this.renderCal(); this.renderDates(); this.requestQuote();
		if (this.cfg.wizard && this.checkOut) this.renderWizard();
	};

	Widget.prototype.clearDates = function () {
		this.checkIn = this.checkOut = this.hover = null;
		this.renderCal(); this.renderDates(); this.requestQuote();
	};

	/* ================= kalendarz ================= */

	Widget.prototype.renderCal = function () {
		var self = this, c = this.elCal; c.innerHTML = '';
		if (!this.today) { c.appendChild(el('p', 'bm-error', 'Nie udało się wczytać kalendarza. Odśwież stronę.')); return; }

		var prev = btn('bm-round bm-cal__nav bm-cal__prev', icon('left'), 'Poprzedni miesiąc');
		var next = btn('bm-round bm-cal__nav bm-cal__next', icon('right'), 'Następny miesiąc');
		prev.disabled = this.view <= monthStart(this.today);
		prev.onclick = function () { self.view = addMonths(self.view, -1); self.renderCal(); };
		next.onclick = function () { self.view = addMonths(self.view, 1); self.loadMonths(self.view, (self.cfg.months || 1) + 1); self.renderCal(); };
		c.appendChild(prev); c.appendChild(next);

		var months = el('div', 'bm-cal__months');
		for (var m = 0; m < (this.cfg.months || 1); m++) months.appendChild(this.renderMonth(addMonths(this.view, m)));
		c.appendChild(months);

		var mn = this.minFor(this.checkIn || this.view), minTxt = 'Minimalny pobyt: ' + mn + ' ' + pl(mn, 'noc', 'noce', 'nocy') + '.';
		var hint = this.checkIn && this.checkOut ? 'Aby zmienić termin, kliknij nowy dzień przyjazdu.'
			: this.checkIn ? 'Teraz wybierz dzień wyjazdu. ' + minTxt : 'Wybierz dzień przyjazdu. ' + minTxt;
		c.appendChild(el('p', 'bm-cal__hint', hint));
		// Zasady sezonów widocznych miesięcy (inny minimalny pobyt albo dni przyjazdu).
		var self2 = this, from = this.view, to = addMonths(this.view, this.cfg.months || 1), DOWN = ['', 'pon', 'wt', 'śr', 'czw', 'pt', 'sob', 'niedz'];
		this.seasons.filter(function (s) { return s.to >= from && s.from < to && (s.min_nights !== self2.cfg.min_nights || s.arrival_days.length); }).forEach(function (s) {
			var t = s.name + ' (' + short(s.from) + ' – ' + short(s.to) + '): ';
			var bits = [];
			if (s.min_nights !== self2.cfg.min_nights) bits.push('minimalny pobyt ' + s.min_nights + ' ' + pl(s.min_nights, 'noc', 'noce', 'nocy'));
			if (s.arrival_days.length) bits.push('przyjazd: ' + s.arrival_days.map(function (d) { return DOWN[d]; }).join(', '));
			c.appendChild(el('p', 'bm-cal__season', t + bits.join(', ') + '.'));
		});
	};

	Widget.prototype.renderMonth = function (month) {
		var self = this, v = parse(month), box = el('div', 'bm-cal__month');
		box.appendChild(el('div', 'bm-cal__title', MONTHS[v.getUTCMonth()] + ' ' + v.getUTCFullYear()));
		var grid = el('div', 'bm-cal__grid');
		DAYS.forEach(function (d) { grid.appendChild(el('span', 'bm-cal__dow', d)); });
		var offset = (v.getUTCDay() + 6) % 7; // poniedziałek = 0
		for (var i = 0; i < offset; i++) grid.appendChild(el('span', 'bm-cal__pad'));

		var days = new Date(Date.UTC(v.getUTCFullYear(), v.getUTCMonth() + 1, 0)).getUTCDate();
		for (var day = 1; day <= days; day++) {
			var d = month.slice(0, 8) + (day < 10 ? '0' : '') + day;
			var b = el('button', 'bm-cal__day'); b.type = 'button'; b.setAttribute('data-date', d);
			b.appendChild(el('span', 'bm-cal__num', String(day)));
			var cls = [], ok, label = human(d);
			if (d < this.today) cls.push('is-past');
			if (d === this.today) cls.push('is-today');
			if (this.booked[d]) { cls.push('is-booked'); label += ', zajęte'; }
			if (d === this.checkIn) { cls.push('is-start'); label += ', przyjazd'; }
			if (d === this.checkOut) { cls.push('is-end'); label += ', wyjazd'; }
			if (this.checkIn && this.checkOut && d > this.checkIn && d < this.checkOut) cls.push('is-range');
			if (this.checkIn && !this.checkOut) {
				ok = this.canCheckOut(d) || this.canCheckIn(d);
				if (this.canCheckOut(d)) cls.push('is-checkout');
				else if (d > this.checkIn) cls.push('is-dim');
			} else ok = this.canCheckIn(d);
			if (this.checkIn && this.checkOut && this.checkIn !== this.checkOut) {
				if (d === this.checkIn) cls.push('has-range-after');
				if (d === this.checkOut) cls.push('has-range-before');
			}
			if (!this.loaded[monthStart(d)]) ok = false;
			b.disabled = !ok;
			b.setAttribute('aria-label', label);
			if (cls.length) b.className += ' ' + cls.join(' ');
			b.onclick = (function (date) { return function () { self.pick(date); }; })(d);
			b.onmouseenter = (function (date) { return function () { self.preview(date); }; })(d);
			grid.appendChild(b);
		}
		grid.onmouseleave = function () { self.preview(null); };
		box.appendChild(grid);
		return box;
	};

	/** Podgląd zakresu po najechaniu na możliwy dzień wyjazdu. */
	Widget.prototype.preview = function (d) {
		if (!this.checkIn || this.checkOut) return;
		var to = d && this.canCheckOut(d) ? d : null, ci = this.checkIn;
		this.elCal.querySelectorAll('.bm-cal__day').forEach(function (b) {
			var x = b.getAttribute('data-date');
			b.classList.toggle('is-hover-range', !!to && x > ci && x < to);
			b.classList.toggle('is-hover-end', !!to && x === to);
			b.classList.toggle('has-range-after', !!to && x === ci);
		});
	};

	Widget.prototype.renderDates = function () {
		var self = this, t = this.elDates; t.innerHTML = '';
		var cell = function (label, value, active) {
			var c = el('div', 'bm-dates__cell' + (active ? ' is-active' : ''));
			c.appendChild(el('span', 'bm-dates__label', label));
			c.appendChild(el('span', 'bm-dates__value' + (value ? '' : ' is-empty'), value ? short(value) : 'wybierz'));
			return c;
		};
		t.appendChild(cell('Przyjazd', this.checkIn, !this.checkIn));
		t.appendChild(cell('Wyjazd', this.checkOut, this.checkIn && !this.checkOut));
		var foot = el('div', 'bm-dates__foot');
		if (this.checkIn && this.checkOut) {
			var n = diffDays(this.checkIn, this.checkOut);
			foot.appendChild(el('span', 'bm-dates__nights', n + ' ' + pl(n, 'noc', 'noce', 'nocy')));
		}
		if (this.checkIn) {
			var clr = btn('bm-link bm-dates__clear', 'Wyczyść daty');
			clr.onclick = function () { self.clearDates(); };
			foot.appendChild(clr);
		}
		if (foot.childNodes.length) t.appendChild(foot);
		if (this.prefillNote) { t.appendChild(el('p', 'bm-dates__note', this.prefillNote)); this.prefillNote = ''; }
	};

	/* ================= goście i dostawki ================= */

	/** Ile dzieci zajmuje miejsce: starsze niż próg + maluchy ponad limit „bez miejsca” (jak na serwerze). Wiek nieznany = zajmuje. */
	Widget.prototype.sleepers = function (children) {
		var inf = this.cfg.infant_age;
		if (inf === null) return children.length;
		var small = children.filter(function (a) { return a !== '' && a <= inf; }).length;
		return children.length - Math.min(small, this.cfg.infant_max || 0);
	};
	Widget.prototype.fits = function (a, kids, ebA, ebC) {
		var s = this.sleepers(kids), beds = this.cfg.beds;
		return a <= beds + ebA && a + s <= beds + ebA + ebC;
	};
	Widget.prototype.ebAvail = function (type, n, other) {
		var eb = this.cfg[type]; return !!eb && n <= eb.max && n + other <= this.cfg.eb_max_total;
	};
	/** Zdejmij dostawki, które przestały być potrzebne. */
	Widget.prototype.normalize = function () {
		var p = this.party;
		while (p.ebA > 0 && this.fits(p.adults, p.children, p.ebA - 1, p.ebC)) p.ebA--;
		while (p.ebC > 0 && this.fits(p.adults, p.children, p.ebA, p.ebC - 1)) p.ebC--;
	};

	Widget.prototype.renderParty = function () {
		var self = this, p = this.party, box = this.elParty; box.innerHTML = '';
		box.appendChild(el('h4', 'bm-booking__label', 'Goście'));

		function stepper(label, sub, value, onMinus, onPlus, minusOk, plusOk, cls) {
			var row = el('div', 'bm-step ' + (cls || ''));
			var lab = el('span', 'bm-step__label'); lab.appendChild(el('span', 'bm-step__name', label));
			if (sub) lab.appendChild(el('span', 'bm-step__sub', sub));
			row.appendChild(lab);
			var m = btn('bm-step__btn', icon('minus'), label + ': mniej'); m.disabled = !minusOk; m.onclick = onMinus;
			var v = el('span', 'bm-step__value', String(value)); v.setAttribute('aria-live', 'polite');
			var pb = btn('bm-step__btn', icon('plus'), label + ': więcej'); pb.disabled = !plusOk; pb.onclick = onPlus;
			row.appendChild(m); row.appendChild(v); row.appendChild(pb);
			return row;
		}
		var changed = function () { self.normalize(); self.renderParty(); self.requestQuote(); if (self.cfg.wizard) { self.navError = ''; self.renderWizard(); } };

		var addAdultOk = this.fits(p.adults + 1, p.children, p.ebA, p.ebC);
		box.appendChild(stepper('Dorośli', '', p.adults,
			function () { p.adults--; changed(); }, function () { p.adults++; changed(); },
			p.adults > 1, addAdultOk, 'bm-step--adults'));

		// Nowe dziecko może być maluchem bez miejsca — dopuszczamy je, jeśli jest wolny limit; po wyborze wieku sprawdzamy ponownie.
		var maybeInfant = this.cfg.infant_age !== null ? 0 : '';
		var addChildOk = this.fits(p.adults, p.children.concat([maybeInfant]), p.ebA, p.ebC);
		box.appendChild(stepper('Dzieci', '0–' + this.cfg.max_child + ' lat', p.children.length,
			function () { p.children.pop(); changed(); }, function () { p.children.push(''); changed(); },
			p.children.length > 0, addChildOk && p.children.length < 20, 'bm-step--children'));

		// wiek każdego dziecka
		if (p.children.length) {
			var ages = el('div', 'bm-ages');
			p.children.forEach(function (age, i) {
				var row = el('label', 'bm-child');
				row.appendChild(el('span', 'bm-child__label', 'Wiek dziecka ' + (i + 1)));
				var sel = el('select', 'bm-select bm-child__age' + (age === '' ? ' is-missing' : ''));
				var o0 = el('option', '', 'wybierz'); o0.value = ''; sel.appendChild(o0);
				for (var a = 0; a <= self.cfg.max_child; a++) { var o = el('option', '', a + ' ' + pl(a, 'rok', 'lata', 'lat')); o.value = a; if (age === a) o.selected = true; sel.appendChild(o); }
				sel.onchange = function () { p.children[i] = sel.value === '' ? '' : +sel.value; changed(); };
				row.appendChild(sel); ages.appendChild(row);
			});
			box.appendChild(ages);
		}

		// dostawki: wybrane + podpowiedź, gdy zabrakło miejsc
		var price = function (eb) { return eb.price > 0 ? ' · ' + self.money.format(eb.price) + ' / noc' : ''; };
		[['ebA', 'eb_adult', 'Dostawka dla dorosłego'], ['ebC', 'eb_child', 'Dostawka dla dziecka']].forEach(function (t) {
			if (!p[t[0]]) return;
			var row = el('div', 'bm-eb');
			row.appendChild(el('span', 'bm-eb__label', t[2] + (p[t[0]] > 1 ? ' × ' + p[t[0]] : '') + price(self.cfg[t[1]])));
			box.appendChild(row);
		});
		var acts = [];
		if (!addAdultOk && this.ebAvail('eb_adult', p.ebA + 1, p.ebC) && this.fits(p.adults + 1, p.children, p.ebA + 1, p.ebC)) {
			acts.push(['+ Dorosły na dostawce' + price(this.cfg.eb_adult), function () { p.ebA++; p.adults++; changed(); }]);
		}
		if (!addChildOk) {
			if (this.ebAvail('eb_child', p.ebC + 1, p.ebA) && this.fits(p.adults, p.children.concat(['']), p.ebA, p.ebC + 1)) {
				acts.push(['+ Dziecko na dostawce' + price(this.cfg.eb_child), function () { p.ebC++; p.children.push(''); changed(); }]);
			} else if (this.ebAvail('eb_adult', p.ebA + 1, p.ebC) && this.fits(p.adults, p.children.concat(['']), p.ebA + 1, p.ebC)) {
				acts.push(['+ Dziecko na dostawce' + price(this.cfg.eb_adult), function () { p.ebA++; p.children.push(''); changed(); }]);
			}
		}
		// Za dużo osób po wyborze wieku dziecka (np. drugi maluch ponad limit „bez miejsca”) — podpowiedz, jak to naprawić.
		var known = p.children.map(function (a) { return a === '' ? maybeInfant : a; }); // wiek jeszcze niewybrany = może być maluchem
		if (!this.fits(p.adults, known, p.ebA, p.ebC)) {
			acts = [];
			if (this.ebAvail('eb_child', p.ebC + 1, p.ebA) && this.fits(p.adults, known, p.ebA, p.ebC + 1)) {
				acts.push(['+ Dostawka dla dziecka' + price(this.cfg.eb_child), function () { p.ebC++; changed(); }]);
			} else if (this.ebAvail('eb_adult', p.ebA + 1, p.ebC) && this.fits(p.adults, known, p.ebA + 1, p.ebC)) {
				acts.push(['+ Dostawka' + price(this.cfg.eb_adult), function () { p.ebA++; changed(); }]);
			}
			box.appendChild(acts.length ? this.offer('Brakuje miejsca dla wszystkich osób. Dodaj dostawkę albo zmniejsz liczbę gości.', acts)
				: el('p', 'bm-error bm-party__over', 'Za dużo osób dla tego apartamentu — zmniejsz liczbę gości.'));
			acts = [];
		}
		if (acts.length) box.appendChild(this.offer(p.ebA + p.ebC ? 'Brak kolejnych miejsc. Możesz dodać:' : 'Wszystkie miejsca zajęte. Możesz dodać:', acts));
		box.appendChild(el('p', 'bm-party__summary', 'Apartament ma ' + this.cfg.beds + ' ' + pl(this.cfg.beds, 'miejsce', 'miejsca', 'miejsc') +
			(this.cfg.infant_age !== null && this.cfg.infant_max ? '; ' + (this.cfg.infant_max === 1 ? 'jedno dziecko' : 'do ' + this.cfg.infant_max + ' dzieci') + ' w wieku do ' + this.cfg.infant_age + ' lat bez osobnego miejsca.' : '.')));
	};

	Widget.prototype.offer = function (text, acts) {
		var o = el('div', 'bm-offer'); o.appendChild(el('span', 'bm-offer__text', text));
		acts.forEach(function (x) { var b = btn('bm-link bm-offer__btn', ''); b.textContent = x[0]; b.onclick = x[1]; o.appendChild(b); });
		return o;
	};

	/* ================= opcje dodatkowe ================= */

	Widget.prototype.renderExtras = function () {
		if (!this.elExtras) return;
		var self = this, box = this.elExtras; box.innerHTML = '';
		box.appendChild(el('h4', 'bm-booking__label', 'Opcje dodatkowe'));
		this.cfg.extras.forEach(function (x) {
			var row = el('div', 'bm-extra' + (self.extras[x.id] ? ' is-on' : ''));
			var price = x.price > 0 ? self.money.format(x.price) + (x.charge_type === 'night' ? ' / noc' : ' / pobyt') : 'bezpłatnie';
			var text = el('div', 'bm-extra__text');
			var name = el('label', 'bm-extra__name', x.name);
			text.appendChild(name);
			text.appendChild(el('span', 'bm-extra__price', price + (x.allow_qty ? ' · za sztukę' : '')));
			if (x.description) text.appendChild(el('span', 'bm-extra__desc', x.description));
			var set = function (v) { if (v) self.extras[x.id] = v; else delete self.extras[x.id]; self.renderExtras(); self.requestQuote(); };
			if (x.allow_qty) {
				var q = self.extras[x.id] || 0, ctl = el('div', 'bm-extra__qty');
				var m = btn('bm-step__btn', icon('minus'), x.name + ': mniej'); m.disabled = q < 1; m.onclick = function () { set(q - 1); };
				var pb = btn('bm-step__btn', icon('plus'), x.name + ': więcej'); pb.disabled = q >= x.max_qty; pb.onclick = function () { set(q + 1); };
				ctl.appendChild(m); ctl.appendChild(el('span', 'bm-step__value', String(q))); ctl.appendChild(pb);
				row.appendChild(text); row.appendChild(ctl);
			} else {
				var id = 'bm-x-' + self.cfg.apartment_id + '-' + x.id;
				var input = el('input', 'bm-check'); input.type = 'checkbox'; input.id = id; input.checked = !!self.extras[x.id];
				input.onchange = function () { set(input.checked ? 1 : 0); };
				name.htmlFor = id;
				row.appendChild(input); row.appendChild(text);
				row.className += ' bm-extra--check';
			}
			box.appendChild(row);
		});
	};

	/* ================= wycena ================= */

	Widget.prototype.requestQuote = function () {
		var self = this;
		clearTimeout(this.quoteTimer);
		if (!this.checkIn || !this.checkOut) { this.quote = null; this.renderQuote(); return; }
		if (this.party.children.indexOf('') !== -1) { this.quote = { message: 'Podaj wiek każdego dziecka, aby zobaczyć cenę.' }; this.renderQuote(); return; }
		this.elQuote.classList.add('is-loading');
		this.quoteTimer = setTimeout(function () { self.fetchQuote(); }, 250);
	};

	Widget.prototype.fetchQuote = function () {
		var self = this, p = this.party, seq = ++this.quoteSeq;
		var ex = Object.keys(this.extras).map(function (id) { return id + ':' + self.extras[id]; }).join(',');
		var q = 'check_in=' + this.checkIn + '&check_out=' + this.checkOut + '&adults=' + p.adults +
			'&children=' + p.children.join(',') + '&eb_adult=' + p.ebA + '&eb_child=' + p.ebC + (ex ? '&extras=' + ex : '');
		fetch(endpoint(this.cfg.api, '/quote', q), { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
			if (seq !== self.quoteSeq) return; // nowsze zapytanie w drodze
			self.quote = d; self.renderQuote();
		}).catch(function () { if (seq === self.quoteSeq) { self.quote = { message: 'Nie udało się pobrać ceny. Spróbuj ponownie.' }; self.renderQuote(); } });
	};

	/** Powiadom stronę (np. pasek na telefonie) o aktualnej cenie. */
	Widget.prototype.announce = function () {
		var q = this.quote, ok = q && q.total !== undefined;
		this.root.dispatchEvent(new CustomEvent('bm:quote', { bubbles: true, detail: ok ? {
			total: this.money.format(q.total), nights: diffDays(this.checkIn, this.checkOut),
			dates: short(this.checkIn) + ' – ' + short(this.checkOut)
		} : null }));
	};

	Widget.prototype.renderQuote = function () {
		var self = this, box = this.elQuote, q = this.quote; box.innerHTML = ''; box.classList.remove('is-loading');
		this.announce();
		if (this.cfg.wizard) this.renderWizard();
		if (!q) {
			if (this.cfg.wizard) box.appendChild(el('p', 'bm-quote__empty', 'Wybierz termin, aby zobaczyć cenę.'));
			this.renderAction(); return;
		}
		if (q.code || q.message && q.total === undefined) {
			box.appendChild(el('p', 'bm-error', q.message || 'Nie można wycenić pobytu.'));
			if (q.code === 'bm_unavailable') { this.checkOut = null; this.renderCal(); this.renderDates(); }
			this.renderAction(); return;
		}
		box.appendChild(el('h4', 'bm-booking__label', 'Cena pobytu'));
		if (this.cfg.wizard) {
			var sum = el('p', 'bm-quote__summary');
			var who = this.party.adults + ' ' + pl(this.party.adults, 'dorosły', 'dorosłych', 'dorosłych') +
				(this.party.children.length ? ', ' + this.party.children.length + ' ' + pl(this.party.children.length, 'dziecko', 'dzieci', 'dzieci') : '');
			sum.textContent = short(this.checkIn) + ' – ' + short(this.checkOut) + ' · ' + who;
			box.appendChild(sum);
		}
		if (q.is_gap) box.appendChild(el('p', 'bm-quote__gap', 'Wolne okienko między rezerwacjami — krótszy pobyt możliwy.'));
		var ul = el('ul', 'bm-quote__lines');
		q.lines.forEach(function (l) {
			var li = el('li', 'bm-quote__line bm-quote__line--' + l.type);
			li.appendChild(el('span', 'bm-quote__label', l.label));
			li.appendChild(el('span', 'bm-quote__amount', l.amount > 0 ? self.money.format(l.amount) : 'gratis'));
			ul.appendChild(li);
		});
		box.appendChild(ul);
		var tot = el('p', 'bm-quote__total');
		tot.appendChild(el('span', 'bm-quote__label', 'Razem'));
		tot.appendChild(el('strong', 'bm-quote__amount', self.money.format(q.total)));
		box.appendChild(tot);
		box.appendChild(el('p', 'bm-quote__per-night', 'średnio ' + self.money.format(q.per_night) + ' za noc'));
		if (q.city_tax && q.city_tax.amount > 0) {
			box.appendChild(el('p', 'bm-quote__city-tax', 'Opłata miejscowa ' + self.money.format(q.city_tax.amount) + ' — płatna na miejscu, poza ceną.'));
		}
		// Zaliczka: minimum ustala obiekt, gość może zapłacić więcej (do całości). W panelu płatność ustala obsługa w następnym kroku.
		if (this.cfg.panel) { this.renderAction(); return; }
		if (this.deposit === null || this.deposit < q.deposit_min) this.deposit = q.deposit_min;
		if (this.deposit > q.total) this.deposit = q.total;
		var dep = el('div', 'bm-deposit');
		var id = 'bm-dep-' + this.cfg.apartment_id;
		var lab = el('label', 'bm-deposit__label', 'Zaliczka płatna teraz'); lab.htmlFor = id;
		var field = el('div', 'bm-deposit__field');
		var inp = el('input', 'bm-input bm-deposit__input'); inp.id = id; inp.type = 'number'; inp.step = '0.01'; inp.min = q.deposit_min; inp.max = q.total; inp.value = this.deposit.toFixed(2);
		field.appendChild(inp); field.appendChild(el('span', 'bm-deposit__cur', 'zł'));
		dep.appendChild(lab); dep.appendChild(field);
		var rest = el('p', 'bm-deposit__rest');
		var showRest = function () { rest.textContent = 'Minimum ' + self.money.format(q.deposit_min) + ' (' + q.deposit_percent + '%). Pozostałe ' + self.money.format(Math.max(0, q.total - self.deposit)) + ' zgodnie z umową.'; };
		inp.onchange = function () {
			var v = parseFloat(String(inp.value).replace(',', '.')) || 0;
			self.deposit = Math.round(Math.min(q.total, Math.max(q.deposit_min, v)) * 100) / 100;
			inp.value = self.deposit.toFixed(2); showRest();
		};
		showRest(); dep.appendChild(rest); box.appendChild(dep);
		this.renderAction();
	};

	Widget.prototype.renderAction = function () {
		var self = this, box = this.elAction; box.innerHTML = '';
		var ready = this.quote && this.quote.total !== undefined;
		var b = btn('bm-btn bm-btn--primary bm-btn--block bm-booking__submit', this.cfg.panel ? 'Dalej: dane gościa' : 'Rezerwuj');
		var update = function () { b.disabled = !ready || !self.cfg.booking_open || (self.cfg.acceptance && !self.accepted); };

		if (ready && this.cfg.acceptance) {
			var t = el('div', 'bm-terms');
			t.appendChild(el('h4', 'bm-booking__label', 'Warunki pobytu'));
			t.appendChild(el('div', 'bm-terms__text', this.cfg.acceptance));
			var id = 'bm-acc-' + this.cfg.apartment_id;
			var l = el('div', 'bm-terms__accept'), c = el('input', 'bm-check'); c.type = 'checkbox'; c.id = id; c.checked = this.accepted;
			c.onchange = function () { self.accepted = c.checked; update(); };
			var lt = el('label', '', 'Zapoznałem(-am) się i akceptuję powyższe warunki pobytu'); lt.htmlFor = id;
			l.appendChild(c); l.appendChild(lt);
			t.appendChild(l); box.appendChild(t);
		}
		update();
		b.onclick = function () { self.submit(b); };
		box.appendChild(b);
		if (!ready && !this.cfg.wizard) box.appendChild(el('p', 'bm-booking__note', this.checkIn && this.checkOut ? '' : 'Wybierz termin, aby zobaczyć cenę.'));
		if (ready && !this.cfg.booking_open) box.appendChild(el('p', 'bm-booking__soon', 'Rezerwacja online zostanie uruchomiona wkrótce.'));
	};

	/** Zwykły formularz add-to-cart WooCommerce — serwer liczy i sprawdza wszystko jeszcze raz. W panelu: przekazanie wyboru dalej. */
	Widget.prototype.submit = function (btn) {
		var self = this, p = this.party;
		if (this.cfg.panel) {
			this.root.dispatchEvent(new CustomEvent('bm:pick', { bubbles: true, detail: {
				apartment_id: this.cfg.apartment_id, check_in: this.checkIn, check_out: this.checkOut, quote: this.quote,
				party: { adults: p.adults, children_ages: p.children.join(','), eb_adult: p.ebA, eb_child: p.ebC, extras: this.extras }
			} }));
			return;
		}
		var f = document.createElement('form');
		f.method = 'post'; f.action = this.cfg.cart_url; f.style.display = 'none';
		var add = function (k, v) { var i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); };
		add('add-to-cart', this.cfg.apartment_id); add('quantity', 1);
		add('bm_check_in', this.checkIn); add('bm_check_out', this.checkOut);
		add('bm_adults', p.adults); add('bm_children', p.children.join(','));
		add('bm_eb_adult', p.ebA); add('bm_eb_child', p.ebC);
		add('bm_extras', Object.keys(this.extras).map(function (id) { return id + ':' + self.extras[id]; }).join(','));
		add('bm_deposit', (this.deposit || 0).toFixed(2));
		add('bm_accept', this.accepted ? 1 : 0);
		document.body.appendChild(f);
		btn.disabled = true; btn.textContent = 'Rezerwuję…';
		f.submit();
	};

	/* ---------- start ---------- */
	function init() {
		document.querySelectorAll('.bm-booking[data-bm-config]').forEach(function (n) {
			if (!n.bmWidget) n.bmWidget = new Widget(n);
		});
	}
	window.BookManagerWidget = function (node) { if (!node.bmWidget) node.bmWidget = new Widget(node); return node.bmWidget; }; // panel: widżet tworzony w locie
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
