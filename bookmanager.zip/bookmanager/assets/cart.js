/**
 * BookManager — pasek „Rozpoczęta rezerwacja” (zamiast koszyka).
 * Pojawia się na stronach serwisu, gdy gość wybrał termin, ale nie dokończył rezerwacji.
 * Pyta serwer tylko wtedy, gdy WooCommerce ustawił ciasteczko koszyka — strony mogą być w cache.
 */
(function () {
	'use strict';
	var C = window.BM_CART;
	if (!C || !/(^|;\s*)woocommerce_items_in_cart=1/.test(document.cookie)) return;
	try { if (sessionStorage.getItem('bm_pill_hidden')) return; } catch (e) { /* prywatne okno */ }

	fetch(C.api, { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
		if (!d || !d.items || !d.items.length) return;
		var css = '.bm-pill{position:fixed;left:16px;bottom:16px;z-index:9999;display:flex;align-items:center;gap:12px;max-width:min(560px,calc(100vw - 32px));'
			+ 'padding:10px 10px 10px 16px;border-radius:999px;background:#fff;color:#1f1f1f;box-shadow:0 8px 30px rgba(0,0,0,.16),0 0 0 1px rgba(0,0,0,.06);'
			+ 'font:14px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;animation:bm-pill-in .3s ease-out}'
			+ '@keyframes bm-pill-in{from{transform:translateY(20px);opacity:0}to{transform:none;opacity:1}}'
			+ '.bm-pill__dot{flex:none;width:9px;height:9px;border-radius:50%;background:' + C.accent + ';box-shadow:0 0 0 4px ' + C.accent + '22}'
			+ '.bm-pill__txt{min-width:0;display:flex;flex-direction:column}.bm-pill__txt strong{font-weight:600}'
			+ '.bm-pill__txt span{color:#666;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
			+ '.bm-pill__go{flex:none;padding:9px 16px;border-radius:999px;background:' + C.accent + ';color:' + C.on + ' !important;text-decoration:none !important;font-weight:600}'
			+ '.bm-pill__x{flex:none;width:30px;height:30px;border:0;border-radius:50%;background:transparent;color:#888;font-size:20px;line-height:1;cursor:pointer}'
			+ '.bm-pill__x:hover{background:#f2f2f2;color:#222}'
			+ '@media (max-width:600px){.bm-pill{left:12px;right:12px;bottom:12px;border-radius:16px}.bm-pill.has-bar{bottom:84px}}';
		var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

		var first = d.items[0], more = d.items.length - 1;
		var p = document.createElement('div'); p.className = 'bm-pill'; p.setAttribute('role', 'status');
		if (document.querySelector('.bm-mbar')) p.classList.add('has-bar');
		var dot = document.createElement('i'); dot.className = 'bm-pill__dot';
		var t = document.createElement('div'); t.className = 'bm-pill__txt';
		var a = document.createElement('strong'); a.textContent = 'Rozpoczęta rezerwacja';
		var b = document.createElement('span'); b.textContent = first.name + ' · ' + first.dates + (more ? ' (+' + more + ')' : '');
		t.appendChild(a); t.appendChild(b);
		var go = document.createElement('a'); go.className = 'bm-pill__go'; go.href = d.checkout; go.textContent = 'Dokończ';
		var x = document.createElement('button'); x.type = 'button'; x.className = 'bm-pill__x'; x.setAttribute('aria-label', 'Ukryj'); x.textContent = '×';
		x.onclick = function () { p.remove(); try { sessionStorage.setItem('bm_pill_hidden', '1'); } catch (e) { /* bez znaczenia */ } };
		[dot, t, go, x].forEach(function (n) { p.appendChild(n); });
		document.body.appendChild(p);
	}).catch(function () { /* bez paska */ });
})();
