/**
 * BookManager — strona zamówienia rezerwacji: faktura na żądanie, odliczanie blokady terminu,
 * potwierdzenie usunięcia apartamentu, zwijane podsumowanie na telefonie.
 */
(function ($) {
	'use strict';

	function invoice() {
		var on = $('#billing_bm_invoice').is(':checked');
		$('.bm-inv').toggle(on);
	}
	$(document.body).on('change', '#billing_bm_invoice', invoice);
	$(document.body).on('updated_checkout', invoice);
	$(invoice);

	// Usunięcie apartamentu — z potwierdzeniem.
	$(document).on('click', '[data-bm-confirm]', function (e) {
		if (!window.confirm(this.getAttribute('data-bm-confirm'))) e.preventDefault();
	});

	// Podsumowanie zwinięte na telefonie (kwota widoczna w nagłówku).
	$(function () {
		var box = document.querySelector('.bm-co-sum__box');
		if (box && window.matchMedia('(max-width: 899px)').matches) box.open = false;
	});

	// Odliczanie: ile jeszcze termin jest trzymany. Po czasie — serwer i tak spróbuje go odnowić przy płatności.
	$(function () {
		var t = document.querySelector('[data-bm-expires]');
		if (!t) return;
		var end = Date.now() + (+t.getAttribute('data-bm-expires')) * 1000, out = t.querySelector('strong');
		var tick = function () {
			var s = Math.max(0, Math.round((end - Date.now()) / 1000));
			if (!s) {
				t.classList.add('is-over');
				t.querySelector('span').textContent = 'Czas na dokończenie minął — sprawdzimy, czy termin jest nadal wolny, gdy klikniesz „Rezerwuję”.';
				return;
			}
			out.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
			if (s <= 120) t.classList.add('is-soon');
			setTimeout(tick, 1000);
		};
		tick();
	});
})(jQuery);
