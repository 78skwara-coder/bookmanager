/**
 * BookManager — kontakt: mapa Google dopiero po kliknięciu, fokus na komunikacie.
 */
(function () {
	'use strict';
	document.querySelectorAll('[data-bm-map]').forEach(function (box) {
		var btn = box.querySelector('button');
		if (!btn) return;
		btn.addEventListener('click', function () {
			var f = document.createElement('iframe');
			f.src = box.getAttribute('data-bm-map');
			f.title = 'Mapa dojazdu';
			f.loading = 'lazy';
			f.referrerPolicy = 'no-referrer-when-downgrade';
			f.setAttribute('allowfullscreen', '');
			box.innerHTML = '';
			box.appendChild(f);
			box.classList.add('is-on');
		});
	});
	var ok = document.querySelector('.bm-contact__ok, .bm-cform__alert');
	if (ok && location.hash === '#bm-kontakt') {
		if (!ok.hasAttribute('tabindex')) ok.setAttribute('tabindex', '-1');
		ok.focus({ preventScroll: false });
	}
	// Wyjazd po przyjeździe.
	var from = document.getElementById('bm-c-from'), to = document.getElementById('bm-c-to');
	if (from && to) from.addEventListener('change', function () {
		if (!from.value) return;
		var d = new Date(from.value + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + 1);
		to.min = d.toISOString().slice(0, 10);
		if (to.value && to.value <= from.value) to.value = to.min;
	});
})();
