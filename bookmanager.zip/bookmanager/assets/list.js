/**
 * BookManager — lista apartamentów: wybór gości, pilnowanie dat, automatyczne wyszukiwanie
 * po zmianie sortowania/filtra, przewijane zdjęcia na kartach.
 */
(function () {
	'use strict';
	var pl = function (n, one, few, many) { if (n === 1) return one; var d = n % 10, t = n % 100; return d >= 2 && d <= 4 && (t < 12 || t > 14) ? few : many; };

	document.querySelectorAll('.bm-search').forEach(function (form) {
		var inEl = form.querySelector('[data-bm-in]'), outEl = form.querySelector('[data-bm-out]');
		var btn = form.querySelector('[data-bm-guests]'), pop = form.querySelector('.bm-gpop');
		var adults = form.querySelector('[data-bm-adults]'), kids = form.querySelector('[data-bm-kids]');
		var ages = Array.prototype.slice.call(form.querySelectorAll('[data-bm-age]')), hidden = form.querySelector('[data-bm-children]');

		// Wyjazd zawsze po przyjeździe.
		function plusDay(v) { var d = new Date(v + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + 1); return d.toISOString().slice(0, 10); }
		if (inEl && outEl) {
			var sync = function () {
				if (!inEl.value) return;
				outEl.min = plusDay(inEl.value);
				if (!outEl.value || outEl.value <= inEl.value) { outEl.value = plusDay(inEl.value); }
			};
			inEl.addEventListener('change', function () { sync(); if (outEl.showPicker) { try { outEl.showPicker(); } catch (e) { /* bez okna */ } } });
			sync();
		}

		function label() {
			var a = +adults.value, k = +kids.value;
			btn.textContent = a + ' ' + pl(a, 'dorosły', 'dorosłych', 'dorosłych') + (k ? ', ' + k + ' ' + pl(k, 'dziecko', 'dzieci', 'dzieci') : '');
		}
		function syncKids() {
			var k = +kids.value;
			ages.forEach(function (s, i) { s.parentNode.hidden = i >= k; });
			hidden.value = ages.slice(0, k).map(function (s) { return s.value; }).filter(function (v) { return v !== ''; }).join(',');
			label();
		}
		function open(on) {
			pop.hidden = !on; btn.setAttribute('aria-expanded', on ? 'true' : 'false');
			if (on) adults.focus();
		}
		if (btn && pop) {
			btn.addEventListener('click', function () { open(pop.hidden); });
			form.querySelector('[data-bm-gdone]').addEventListener('click', function () { open(false); btn.focus(); });
			kids.addEventListener('change', syncKids);
			adults.addEventListener('change', label);
			ages.forEach(function (s) { s.addEventListener('change', syncKids); });
			document.addEventListener('click', function (e) { if (!pop.hidden && !form.querySelector('.bm-search__guests').contains(e.target)) open(false); });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !pop.hidden) { open(false); btn.focus(); } });
		}

		form.addEventListener('submit', function (e) {
			if (kids && +kids.value && ages.slice(0, +kids.value).some(function (s) { return s.value === ''; })) {
				e.preventDefault(); open(true);
				var first = ages.filter(function (s, i) { return i < +kids.value && s.value === ''; })[0];
				if (first) { first.focus(); first.classList.add('is-error'); }
				return;
			}
			if (syncKids) syncKids();
			// Czysty adres: bez pustych pól.
			Array.prototype.forEach.call(form.elements, function (el) { if (el.name && el.value === '' && el.type !== 'checkbox') el.disabled = true; });
			setTimeout(function () { Array.prototype.forEach.call(form.elements, function (el) { el.disabled = false; }); }, 0);
		});
	});

	// Sortowanie i filtry — od razu.
	document.querySelectorAll('[data-bm-autosubmit]').forEach(function (el) {
		el.addEventListener('change', function () {
			var f = el.form || document.getElementById('bm-search');
			if (f) { if (f.requestSubmit) f.requestSubmit(); else f.submit(); }
		});
	});

	// Zdjęcia na kartach.
	document.querySelectorAll('.bm-lcard__media').forEach(function (m) {
		var track = m.querySelector('.bm-lcard__track'), prev = m.querySelector('.bm-lcard__prev'), next = m.querySelector('.bm-lcard__next');
		var dots = m.querySelectorAll('.bm-lcard__dots i');
		if (!track || !next) return;
		var n = track.children.length;
		function idx() { return Math.round(track.scrollLeft / Math.max(1, track.clientWidth)); }
		function upd() {
			var i = idx();
			prev.hidden = i <= 0; next.hidden = i >= n - 1;
			dots.forEach(function (d, j) { d.classList.toggle('is-on', j === i); });
		}
		function go(d) { track.scrollTo({ left: (idx() + d) * track.clientWidth, behavior: 'smooth' }); }
		prev.addEventListener('click', function () { go(-1); });
		next.addEventListener('click', function () { go(1); });
		track.addEventListener('scroll', function () { window.requestAnimationFrame(upd); }, { passive: true });
		upd();
	});
})();
