/**
 * BookManager — strona apartamentu: podgląd zdjęć na pełnym ekranie, miniatury, slider i pasek na telefonie.
 * Czysty JS, bez bibliotek.
 */
(function () {
	'use strict';

	var SVG = function (d) { return '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>'; };
	var I = { left: SVG('<path d="M15 5l-7 7 7 7"/>'), right: SVG('<path d="M9 5l7 7-7 7"/>'), close: SVG('<path d="M6 6l12 12M18 6L6 18"/>') };

	/* ================= podgląd zdjęć ================= */

	function Lightbox(images) {
		var self = this;
		this.images = images; this.i = 0;
		var d = this.dlg = document.createElement('dialog');
		d.className = 'bm-lightbox';
		d.setAttribute('aria-label', 'Zdjęcia apartamentu');
		d.innerHTML = '<div class="bm-lightbox__bar"><span class="bm-lightbox__count"></span>' +
			'<button type="button" class="bm-lightbox__btn bm-lightbox__close" aria-label="Zamknij">' + I.close + '</button></div>' +
			'<div class="bm-lightbox__stage"><img class="bm-lightbox__img" alt=""></div>' +
			'<button type="button" class="bm-lightbox__btn bm-lightbox__prev" aria-label="Poprzednie zdjęcie">' + I.left + '</button>' +
			'<button type="button" class="bm-lightbox__btn bm-lightbox__next" aria-label="Następne zdjęcie">' + I.right + '</button>';
		document.body.appendChild(d);
		this.img = d.querySelector('.bm-lightbox__img');
		this.count = d.querySelector('.bm-lightbox__count');
		d.querySelector('.bm-lightbox__close').onclick = function () { d.close(); };
		d.querySelector('.bm-lightbox__prev').onclick = function () { self.go(self.i - 1); };
		d.querySelector('.bm-lightbox__next').onclick = function () { self.go(self.i + 1); };
		d.addEventListener('click', function (e) { if (e.target === d || e.target.classList.contains('bm-lightbox__stage')) d.close(); });
		d.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') self.go(self.i - 1);
			if (e.key === 'ArrowRight') self.go(self.i + 1);
		});
		d.addEventListener('close', function () { document.documentElement.classList.remove('bm-noscroll'); });
		// przesunięcie palcem
		var x0 = null;
		d.addEventListener('pointerdown', function (e) { x0 = e.clientX; });
		d.addEventListener('pointerup', function (e) {
			if (x0 === null) return;
			var dx = e.clientX - x0; x0 = null;
			if (Math.abs(dx) > 50) self.go(self.i + (dx < 0 ? 1 : -1));
		});
		if (images.length < 2) d.classList.add('is-single');
	}
	Lightbox.prototype.go = function (i) {
		var n = this.images.length; this.i = (i + n) % n;
		var im = this.images[this.i];
		this.img.src = im.src; this.img.alt = im.alt || '';
		this.count.textContent = (this.i + 1) + ' / ' + n;
		var next = this.images[(this.i + 1) % n]; if (next) { var pre = new Image(); pre.src = next.src; }
	};
	Lightbox.prototype.open = function (i) {
		this.go(i || 0);
		document.documentElement.classList.add('bm-noscroll');
		if (this.dlg.showModal) this.dlg.showModal(); else this.dlg.setAttribute('open', '');
	};

	/* ================= strona ================= */

	function initPage(page) {
		var images = [];
		try { images = JSON.parse(page.getAttribute('data-bm-gallery') || '[]'); } catch (e) { images = []; }
		var lb = images.length ? new Lightbox(images) : null;

		page.addEventListener('click', function (e) {
			var o = e.target.closest('[data-bm-open]');
			if (o && lb) { e.preventDefault(); lb.open(+o.getAttribute('data-bm-open')); return; }
			var t = e.target.closest('[data-bm-show]');
			if (t) { showThumb(page, +t.getAttribute('data-bm-show')); }
		});

		page.querySelectorAll('.bm-gallery--slider').forEach(initSlider);
		initBar(page);
	}

	/** Klasyczna galeria: miniatura podmienia duże zdjęcie. */
	function showThumb(page, i) {
		var main = page.querySelector('.bm-gallery__current'), src = page.querySelectorAll('[data-bm-show]')[i];
		if (!main || !src) return;
		var big = main.querySelector('img'), small = src.querySelector('img'), data = JSON.parse(page.getAttribute('data-bm-gallery'))[i];
		big.removeAttribute('srcset'); big.removeAttribute('sizes');
		big.src = data.src; big.alt = data.alt || '';
		main.setAttribute('data-bm-open', i);
		page.querySelectorAll('[data-bm-show]').forEach(function (b, k) { b.classList.toggle('is-active', k === i); });
		if (small) small.blur();
	}

	function initSlider(box) {
		var track = box.querySelector('.bm-slider'), count = box.querySelector('.bm-slider__count');
		var slides = track.children, n = slides.length;
		var current = function () { return Math.round(track.scrollLeft / Math.max(1, track.clientWidth)); };
		var go = function (i) { track.scrollTo({ left: ((i + n) % n) * track.clientWidth, behavior: 'smooth' }); };
		var prev = box.querySelector('.bm-slider__prev'), next = box.querySelector('.bm-slider__next');
		if (prev) prev.onclick = function () { go(current() - 1); };
		if (next) next.onclick = function () { go(current() + 1); };
		track.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') { e.preventDefault(); go(current() - 1); }
			if (e.key === 'ArrowRight') { e.preventDefault(); go(current() + 1); }
		});
		var t; track.addEventListener('scroll', function () {
			clearTimeout(t); t = setTimeout(function () { if (count) count.textContent = (current() + 1) + ' / ' + n; }, 60);
		}, { passive: true });
	}

	/** Pasek na telefonie: widoczny, gdy rezerwacja jest poza ekranem; pokazuje cenę wybranego pobytu. */
	function initBar(page) {
		var bar = page.querySelector('.bm-mbar'), widget = page.querySelector('.bm-booking');
		if (!bar || !widget || !('IntersectionObserver' in window)) return;
		var price = bar.querySelector('.bm-mbar__price'), sub = bar.querySelector('.bm-mbar__sub'), cta = bar.querySelector('.bm-mbar__cta');
		var base = { price: price.textContent, sub: sub.textContent, cta: cta.textContent };
		var visible = false;
		new IntersectionObserver(function (es) {
			visible = es[0].isIntersecting;
			bar.hidden = visible;
			document.documentElement.classList.toggle('bm-has-bar', !visible);
		}, { rootMargin: '0px 0px -30% 0px' }).observe(widget);
		cta.addEventListener('click', function (e) {
			e.preventDefault();
			widget.scrollIntoView({ behavior: 'smooth', block: 'start' });
		});
		page.addEventListener('bm:quote', function (e) {
			var d = e.detail;
			price.textContent = d ? d.total : base.price;
			sub.textContent = d ? d.dates + ' · ' + d.nights + (d.nights === 1 ? ' noc' : (d.nights % 10 >= 2 && d.nights % 10 <= 4 && (d.nights % 100 < 12 || d.nights % 100 > 14) ? ' noce' : ' nocy')) : base.sub;
			cta.textContent = d ? 'Rezerwuj' : base.cta;
		});
	}

	function init() { document.querySelectorAll('.bm-page').forEach(initPage); }
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
