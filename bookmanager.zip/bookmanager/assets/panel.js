/**
 * BookManager — panel na stronie ([bookmanager_panel]).
 * Widoki: Kalendarz (oś czasu + dziś/jutro), Rezerwacje (lista z filtrami), Historia (właściciel).
 * Szczegóły i formularze w wysuwanym panelu bocznym. Wszystko przez REST /bookmanager/v1/panel.
 * Czysty JS, bez bibliotek. Adres (#kalendarz/2026-10, #rezerwacje, #rezerwacja/123) trzyma stan — działa „wstecz”.
 */
(function () {
	'use strict';

	var root = document.getElementById('bm-panel');
	if (!root) return;
	var CFG = JSON.parse(root.getAttribute('data-bm-panel'));
	var money = new Intl.NumberFormat('pl-PL', { style: 'currency', currency: CFG.currency || 'PLN' });
	var MON = ['sty', 'lut', 'mar', 'kwi', 'maj', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru'];
	var DOW = ['', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'];

	/* ================= narzędzia ================= */

	function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
	function btn(cls, text, onClick, title) { var b = el('button', cls, text); b.type = 'button'; if (onClick) b.onclick = onClick; if (title) b.title = title; return b; }
	function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
	function pl(n, a, b, c) { if (n === 1) return a; var d = n % 10, t = n % 100; return d >= 2 && d <= 4 && (t < 12 || t > 14) ? b : c; }
	function day(s) { var p = s.split('-'); return +p[2] + ' ' + MON[+p[1] - 1]; }
	function dayY(s) { return day(s) + ' ' + s.slice(0, 4); }
	function range(a, b) { return a.slice(0, 4) === b.slice(0, 4) ? day(a) + ' – ' + dayY(b) : dayY(a) + ' – ' + dayY(b); }
	function addDays(s, n) { var p = s.split('-'), d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + n)); return d.toISOString().slice(0, 10); }
	function people(b) { var t = b.adults + ' ' + pl(b.adults, 'dorosły', 'dorosłych', 'dorosłych'); if (b.children) t += ', ' + b.children + ' ' + pl(b.children, 'dziecko', 'dzieci', 'dzieci'); return t; }
	function chip(status, label) { return el('span', 'bm-chip bm-chip--' + status, label); }

	function api(path, opts) {
		opts = opts || {};
		var init = { method: opts.method || 'GET', credentials: 'same-origin', headers: { 'X-WP-Nonce': CFG.nonce } };
		if (opts.body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
		var url = CFG.api + path;
		if (opts.query) {
			var q = Object.keys(opts.query).filter(function (k) { return opts.query[k] !== '' && opts.query[k] != null; })
				.map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(opts.query[k]); }).join('&');
			if (q) url += (url.indexOf('?') === -1 ? '?' : '&') + q;
		}
		return fetch(url, init).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (d) {
				if (r.status === 401 || r.status === 403 && d.code === 'rest_cookie_invalid_nonce') { location.reload(); throw new Error('Sesja wygasła.'); }
				if (!r.ok) throw new Error(d.message || 'Coś poszło nie tak. Spróbuj ponownie.');
				return d;
			});
		});
	}

	var toastBox;
	function toast(msg, bad) {
		if (!toastBox) { toastBox = el('div', 'bm-toasts'); toastBox.setAttribute('aria-live', 'polite'); root.appendChild(toastBox); }
		var t = el('div', 'bm-toast' + (bad ? ' is-bad' : ''), msg); toastBox.appendChild(t);
		setTimeout(function () { t.classList.add('is-out'); setTimeout(function () { t.remove(); }, 300); }, bad ? 6000 : 3000);
	}
	function fail(e) { toast(e.message || String(e), true); }

	/* ================= szkielet ================= */

	var views = [['kalendarz', 'Kalendarz'], ['rezerwacje', 'Rezerwacje']];
	if (CFG.user.manage) views.push(['historia', 'Historia']);

	clear(root);
	var bar = el('header', 'bm-pbar');
	var brand = el('div', 'bm-pbar__brand'); brand.appendChild(el('strong', '', CFG.site)); brand.appendChild(el('span', '', 'Panel rezerwacji'));
	var nav = el('nav', 'bm-pnav'); nav.setAttribute('aria-label', 'Panel');
	var navLinks = {};
	views.forEach(function (v) { var a = el('a', 'bm-pnav__link', v[1]); a.href = '#' + v[0]; navLinks[v[0]] = a; nav.appendChild(a); });
	var who = el('div', 'bm-pbar__user');
	who.appendChild(el('span', 'bm-pbar__name', CFG.user.name));
	if (CFG.admin) { var ad = el('a', 'bm-pbar__link', 'Kokpit'); ad.href = CFG.admin; who.appendChild(ad); }
	var lo = el('a', 'bm-pbar__link', 'Wyloguj'); lo.href = CFG.logout; who.appendChild(lo);
	bar.appendChild(brand); bar.appendChild(nav); bar.appendChild(who);
	var main = el('div', 'bm-pmain');
	root.appendChild(bar); root.appendChild(main);

	// panel boczny
	var shade = el('div', 'bm-shade'); shade.hidden = true;
	var drawer = el('aside', 'bm-drawer'); drawer.hidden = true; drawer.setAttribute('role', 'dialog'); drawer.setAttribute('aria-modal', 'true');
	var dHead = el('div', 'bm-drawer__head'), dTitle = el('h2', 'bm-drawer__title'), dBody = el('div', 'bm-drawer__body');
	var dClose = btn('bm-round bm-drawer__close', '×', function () { closeDrawer(); }, 'Zamknij');
	dHead.appendChild(dTitle); dHead.appendChild(dClose); drawer.appendChild(dHead); drawer.appendChild(dBody);
	root.appendChild(shade); root.appendChild(drawer);
	shade.onclick = function () { closeDrawer(); };
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !drawer.hidden) closeDrawer(); });

	var drawerFromHash = false;
	function openDrawer(title, fromHash) {
		dTitle.textContent = title; clear(dBody);
		drawer.hidden = shade.hidden = false; document.documentElement.classList.add('bm-noscroll');
		drawerFromHash = !!fromHash;
		setTimeout(function () { dClose.focus(); }, 30);
		return dBody;
	}
	function closeDrawer() {
		if (drawer.hidden) return;
		drawer.hidden = shade.hidden = true; document.documentElement.classList.remove('bm-noscroll');
		if (drawerFromHash && /^#rezerwacja\//.test(location.hash)) history.replaceState(null, '', lastView || '#kalendarz');
	}

	/* ================= router ================= */

	var state = { view: '', month: '', scope: 'upcoming', q: '', apartment: '', page: 1 };
	var lastView = '';
	var apartmentsCache = null;
	function apartments() { return apartmentsCache ? Promise.resolve(apartmentsCache) : api('/apartments').then(function (d) { apartmentsCache = d; return d; }); }

	function route() {
		var h = location.hash.replace(/^#/, ''), parts = h.split('/');
		if (parts[0] === 'rezerwacja' && parts[1]) {
			if (!state.view) show('kalendarz');
			openBooking(+parts[1], true);
			return;
		}
		var v = views.some(function (x) { return x[0] === parts[0]; }) ? parts[0] : 'kalendarz';
		lastView = '#' + (h || v);
		if (v === 'kalendarz' && /^\d{4}-\d{2}$/.test(parts[1] || '')) state.month = parts[1];
		closeDrawer();
		show(v);
	}
	function show(v) {
		state.view = v;
		Object.keys(navLinks).forEach(function (k) { navLinks[k].classList.toggle('is-active', k === v); if (k === v) navLinks[k].setAttribute('aria-current', 'page'); else navLinks[k].removeAttribute('aria-current'); });
		if (v === 'rezerwacje') viewBookings(); else if (v === 'historia') viewLog(); else viewCalendar();
	}
	window.addEventListener('hashchange', route);

	function loading(box) { clear(box).appendChild(el('p', 'bm-muted bm-loading', 'Wczytywanie…')); }

	/* ================= kalendarz ================= */

	var sel = null; // zaznaczanie wolnych nocy: {apt, name, from}

	function viewCalendar() {
		clear(main);
		var today = el('section', 'bm-today'); main.appendChild(today);
		var cal = el('section', 'bm-tlbox'); main.appendChild(cal);
		loadToday(today); loadCalendar(cal);
	}

	function loadToday(box) {
		api('/today').then(function (d) {
			clear(box);
			var card = function (title, list, empty, kind) {
				var c = el('div', 'bm-tcard bm-tcard--' + kind);
				var h = el('div', 'bm-tcard__head'); h.appendChild(el('span', 'bm-tcard__title', title)); h.appendChild(el('strong', 'bm-tcard__n', String(list.length)));
				c.appendChild(h);
				if (!list.length) c.appendChild(el('p', 'bm-tcard__empty', empty));
				list.slice(0, 4).forEach(function (b) {
					var r = btn('bm-tcard__row', '', function () { location.hash = 'rezerwacja/' + b.id; });
					r.appendChild(el('span', 'bm-tcard__who', b.label));
					r.appendChild(el('span', 'bm-tcard__apt', b.apartment.name + (kind !== 'dep' ? ' · ' + people(b) : '')));
					c.appendChild(r);
				});
				if (list.length > 4) c.appendChild(el('p', 'bm-tcard__more', 'i ' + (list.length - 4) + ' więcej…'));
				return c;
			};
			box.appendChild(card('Przyjazdy dziś', d.arrivals, 'Brak przyjazdów.', 'arr'));
			box.appendChild(card('Wyjazdy dziś', d.departures, 'Brak wyjazdów.', 'dep'));
			box.appendChild(card('Przyjazdy jutro', d.tomorrow, 'Brak przyjazdów.', 'tom'));
			var s = el('div', 'bm-tcard bm-tcard--stay');
			var h = el('div', 'bm-tcard__head'); h.appendChild(el('span', 'bm-tcard__title', 'Zajęte tej nocy')); h.appendChild(el('strong', 'bm-tcard__n', String(d.staying)));
			s.appendChild(h); s.appendChild(el('p', 'bm-tcard__empty', d.staying ? pl(d.staying, 'apartament z gośćmi', 'apartamenty z gośćmi', 'apartamentów z gośćmi') : 'Nikt nie nocuje.'));
			box.appendChild(s);
		}).catch(function (e) { clear(box); fail(e); });
	}

	function loadCalendar(box) {
		loading(box);
		api('/calendar', { query: { month: state.month } }).then(function (d) { renderCalendar(box, d); }).catch(function (e) { clear(box); fail(e); });
	}

	function renderCalendar(box, d) {
		clear(box); sel = null;
		var tools = el('div', 'bm-tltools');
		var go = function (m) { location.hash = 'kalendarz/' + m; };
		tools.appendChild(btn('bm-round', '‹', function () { go(d.prev); }, 'Poprzedni miesiąc'));
		tools.appendChild(el('h2', 'bm-tltools__title', d.title));
		tools.appendChild(btn('bm-round', '›', function () { go(d.next); }, 'Następny miesiąc'));
		tools.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Dziś', function () { location.hash = 'kalendarz'; state.month = ''; if (location.hash === '#kalendarz') viewCalendar(); }));
		var legend = el('div', 'bm-legend');
		[['confirmed', 'potwierdzona'], ['hold', 'w trakcie płatności'], ['block', 'blokada'], ['conflict', 'konflikt']].forEach(function (x) {
			var i = el('span', 'bm-legend__item'); i.appendChild(el('i', 'bm-dot bm-dot--' + x[0])); i.appendChild(document.createTextNode(x[1])); legend.appendChild(i);
		});
		tools.appendChild(legend);
		tools.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm bm-tltools__add', '+ Blokada', function () { blockForm({}); }));
		box.appendChild(tools);
		var hint = el('p', 'bm-hint', 'Kliknij rezerwację, aby zobaczyć szczegóły. Aby zablokować termin, kliknij pierwszą i ostatnią wolną noc w wierszu apartamentu.');
		box.appendChild(hint);

		var groups = d.groups.filter(function (g) { return g.apartments.length || true; });
		if (!groups.length) { box.appendChild(el('p', 'bm-muted', 'Brak apartamentów.')); return; }

		var scroll = el('div', 'bm-tl'); var table = el('table', 'bm-tl__table');
		var thead = el('thead'), hr = el('tr'); hr.appendChild(el('th', 'bm-tl__name bm-tl__corner'));
		d.days.forEach(function (x) {
			var th = el('th', 'bm-tl__day' + (x.dow >= 6 ? ' is-we' : '') + (x.date === d.today ? ' is-today' : ''));
			th.appendChild(el('span', 'bm-tl__dow', DOW[x.dow])); th.appendChild(el('span', 'bm-tl__num', String(x.num)));
			hr.appendChild(th);
		});
		thead.appendChild(hr); table.appendChild(thead);
		var tbody = el('tbody');
		d.groups.forEach(function (g) {
			var gr = el('tr', 'bm-tl__group'); var gth = el('th'); gth.colSpan = d.days.length + 1;
			var gt = el('span', 'bm-tl__gtitle', g.title); gt.style.paddingLeft = (g.depth * 14) + 'px'; gth.appendChild(gt);
			gr.appendChild(gth); tbody.appendChild(gr);
			g.apartments.forEach(function (a) { tbody.appendChild(calRow(a, d, g.depth)); });
		});
		table.appendChild(tbody); scroll.appendChild(table); box.appendChild(scroll);
		// przewiń do dziś
		var t = table.querySelector('th.is-today');
		if (t) scroll.scrollLeft = Math.max(0, t.offsetLeft - 220);
		box.hint = hint;
	}

	function calRow(a, d, depth) {
		var tr = el('tr', 'bm-tl__row');
		var th = el('th', 'bm-tl__name', a.name); th.title = a.name; th.style.paddingLeft = (window.innerWidth < 720 ? 10 : 18 + depth * 14) + 'px'; tr.appendChild(th);
		var starts = {}; a.items.forEach(function (it) { starts[it.start] = it; });
		for (var i = 1; i <= d.days.length; i++) {
			var x = d.days[i - 1];
			if (starts[i]) {
				var it = starts[i], td = el('td', 'bm-tl__cell bm-tl__barcell'); td.colSpan = it.span;
				var b = btn('bm-bar bm-bar--' + it.status, '', null, it.label + ' · ' + range(it.check_in, it.check_out) + ' · ' + it.status_label);
				b.appendChild(el('span', 'bm-bar__label', it.label));
				b.onclick = (function (id) { return function () { location.hash = 'rezerwacja/' + id; }; })(it.id);
				td.appendChild(b); tr.appendChild(td); i += it.span - 1; continue;
			}
			var c = el('td', 'bm-tl__cell bm-tl__free' + (x.dow >= 6 ? ' is-we' : '') + (x.date === d.today ? ' is-today' : '') + (x.date < d.today ? ' is-past' : ''));
			c.setAttribute('data-date', x.date);
			if (x.date >= d.today) c.onclick = (function (date, cell) { return function () { pickNight(a, date, cell, tr); }; })(x.date, c);
			tr.appendChild(c);
		}
		return tr;
	}

	function pickNight(a, date, cell, tr) {
		if (sel && sel.apt === a.id && date >= sel.from) {
			// czy w zakresie nie ma zajętych nocy
			var ok = true, n = sel.from;
			while (n <= date) { var c = tr.querySelector('[data-date="' + n + '"]'); if (!c) { ok = false; break; } n = addDays(n, 1); }
			var from = sel.from; clearSel();
			if (!ok) { toast('W zaznaczonym zakresie jest już rezerwacja.', true); return; }
			blockForm({ apartment_id: a.id, check_in: from, check_out: addDays(date, 1) });
			return;
		}
		clearSel();
		sel = { apt: a.id, from: date, cell: cell };
		cell.classList.add('is-sel');
		toast('Pierwsza noc: ' + dayY(date) + '. Kliknij ostatnią noc blokady.');
	}
	function clearSel() { if (sel && sel.cell) sel.cell.classList.remove('is-sel'); sel = null; }

	/* ================= blokada ================= */

	function field(label, input, help) {
		var f = el('label', 'bm-field'); f.appendChild(el('span', 'bm-field__label', label)); f.appendChild(input);
		if (help) f.appendChild(el('span', 'bm-field__help', help));
		return f;
	}

	function blockForm(v) {
		var body = openDrawer('Nowa blokada terminu');
		var form = el('form', 'bm-form');
		var apt = el('select', 'bm-select'); apt.required = true;
		var o0 = el('option', '', 'wybierz apartament'); o0.value = ''; apt.appendChild(o0);
		apartments().then(function (list) {
			list.forEach(function (a) { var o = el('option', '', a.name + (a.group ? ' · ' + a.group : '')); o.value = a.id; if (+v.apartment_id === a.id) o.selected = true; apt.appendChild(o); });
		});
		var today = new Date(); var tISO = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())).toISOString().slice(0, 10);
		var from = el('input', 'bm-input'); from.type = 'date'; from.required = true; from.min = tISO; from.value = v.check_in || '';
		var to = el('input', 'bm-input'); to.type = 'date'; to.required = true; to.value = v.check_out || '';
		var note = el('input', 'bm-input'); note.type = 'text'; note.maxLength = 190; note.placeholder = 'np. remont, pobyt własny, rezerwacja telefoniczna';
		var info = el('p', 'bm-hint');
		var upd = function () {
			to.min = from.value ? addDays(from.value, 1) : tISO;
			if (from.value && to.value && to.value > from.value) {
				var n = Math.round((Date.parse(to.value) - Date.parse(from.value)) / 864e5);
				info.textContent = 'Zablokowane noce: ' + range(from.value, addDays(to.value, -1)) + ' (' + n + ' ' + pl(n, 'noc', 'noce', 'nocy') + '). Termin wraca do sprzedaży ' + dayY(to.value) + '.';
			} else info.textContent = '';
		};
		from.onchange = to.onchange = upd; upd();
		form.appendChild(field('Apartament', apt));
		var dates = el('div', 'bm-form__row');
		dates.appendChild(field('Pierwsza noc', from));
		dates.appendChild(field('Dzień zwolnienia', to, 'dzień po ostatniej nocy'));
		form.appendChild(dates);
		form.appendChild(info);
		form.appendChild(field('Opis (widzi tylko obsługa)', note));
		var submit = btn('bm-btn bm-btn--primary bm-btn--block', 'Zablokuj termin'); submit.type = 'submit';
		form.appendChild(submit);
		form.onsubmit = function (e) {
			e.preventDefault();
			if (!apt.value || !from.value || !to.value || to.value <= from.value) { toast('Uzupełnij apartament i poprawny zakres dat.', true); return; }
			submit.disabled = true;
			api('/blocks', { method: 'POST', body: { apartment_id: +apt.value, check_in: from.value, check_out: to.value, note: note.value } }).then(function (b) {
				toast('Termin zablokowany.');
				closeDrawer(); refresh();
				void b;
			}).catch(function (e) { submit.disabled = false; fail(e); });
		};
		body.appendChild(form);
		(v.apartment_id ? note : apt).focus();
	}

	function refresh() { if (state.view === 'kalendarz') viewCalendar(); else if (state.view === 'rezerwacje') viewBookings(true); }

	/* ================= szczegóły rezerwacji ================= */

	function openBooking(id, fromHash) {
		var body = openDrawer('Rezerwacja #' + id, fromHash);
		loading(body);
		api('/bookings/' + id).then(function (b) { renderBooking(b); }).catch(function (e) { clear(body); fail(e); });
	}

	function dl(rows) {
		var d = el('dl', 'bm-dl');
		rows.forEach(function (r) {
			if (r[1] == null || r[1] === '') return;
			d.appendChild(el('dt', '', r[0]));
			var dd = el('dd'); if (r[1] instanceof Node) dd.appendChild(r[1]); else dd.textContent = r[1]; d.appendChild(dd);
		});
		return d;
	}
	function section(title) { var s = el('section', 'bm-dsec'); if (title) s.appendChild(el('h3', 'bm-dsec__title', title)); return s; }
	function link(href, text) { var a = el('a', '', text); a.href = href; return a; }

	function renderBooking(b) {
		dTitle.textContent = b.status === 'block' ? 'Blokada terminu' : b.label;
		var body = clear(dBody);
		var top = el('div', 'bm-dtop');
		top.appendChild(chip(b.status, b.status_label));
		if (b.order_info) top.appendChild(el('span', 'bm-muted', 'zamówienie ' + b.order_info.number + ' · ' + b.order_info.status_label));
		body.appendChild(top);

		var s1 = section('Pobyt');
		s1.appendChild(dl([
			['Apartament', b.apartment.name],
			['Termin', range(b.check_in, b.check_out) + ' · ' + b.nights + ' ' + pl(b.nights, 'noc', 'noce', 'nocy')],
			['Przyjazd ok.', b.arrival_time],
			['Opis', b.block_note]
		]));
		body.appendChild(s1);

		if (b.status !== 'block') {
			if (b.contact) {
				var s2 = section('Gość');
				s2.appendChild(dl([
					['Imię i nazwisko', b.guest],
					['Telefon', b.contact.phone ? link('tel:' + b.contact.phone.replace(/\s+/g, ''), b.contact.phone) : ''],
					['E-mail', b.contact.email ? link('mailto:' + b.contact.email, b.contact.email) : ''],
					['Kraj', b.contact.country],
					['Uwagi gościa', b.contact.note]
				]));
				body.appendChild(s2);
			}
			var s3 = section('Osoby i opcje');
			var kids = b.children ? b.children + ' (' + b.children_ages.split(',').map(function (x) { return x + ' l.'; }).join(', ') + ')' : '';
			var beds = [b.extra_beds.adult ? b.extra_beds.adult + '× dla dorosłego' : '', b.extra_beds.child ? b.extra_beds.child + '× dla dziecka' : ''].filter(Boolean).join(', ');
			s3.appendChild(dl([
				['Dorośli', String(b.adults)],
				['Dzieci', kids],
				['Dostawki', beds],
				['Opcje', b.extras.map(function (x) { return x.name + (+x.qty > 1 ? ' × ' + x.qty : ''); }).join(', ')]
			]));
			body.appendChild(s3);

			var s4 = section('Płatność');
			if (b.lines.length) {
				var ul = el('ul', 'bm-lines');
				b.lines.forEach(function (l) { var li = el('li'); li.appendChild(el('span', '', l.label)); li.appendChild(el('span', '', l.amount > 0 ? money.format(l.amount) : 'gratis')); ul.appendChild(li); });
				var tot = el('li', 'is-total'); tot.appendChild(el('span', '', 'Razem')); tot.appendChild(el('span', '', money.format(b.total))); ul.appendChild(tot);
				s4.appendChild(ul);
			}
			s4.appendChild(dl([
				['Zaliczka', b.deposit ? money.format(b.deposit) : ''],
				['Do dopłaty', b.balance_due ? money.format(b.balance_due) + (b.balance_due_date ? ' (do ' + dayY(b.balance_due_date) + ')' : '') : ''],
				['Opłata miejscowa', b.city_tax ? money.format(b.city_tax) + ' — na miejscu' : ''],
				['Metoda płatności', b.order_info ? b.order_info.payment : '']
			]));
			if (b.order_info && b.order_info.url) { var oa = link(b.order_info.url, 'Otwórz zamówienie w WooCommerce ↗'); oa.target = '_blank'; oa.className = 'bm-link'; s4.appendChild(oa); }
			body.appendChild(s4);
		}

		if (b.can.note) {
			var s5 = section('Notatka obsługi');
			var ta = el('textarea', 'bm-input bm-textarea'); ta.rows = 3; ta.maxLength = 2000; ta.value = b.internal_note || ''; ta.placeholder = 'np. późny przyjazd, prośba o łóżeczko, klucze u sąsiada';
			ta.setAttribute('aria-label', 'Notatka obsługi');
			var save = btn('bm-btn bm-btn--ghost bm-btn--sm', 'Zapisz notatkę', function () {
				save.disabled = true;
				api('/bookings/' + b.id + '/note', { method: 'POST', body: { note: ta.value } }).then(function () { toast('Notatka zapisana.'); save.disabled = false; })
					.catch(function (e) { save.disabled = false; fail(e); });
			});
			s5.appendChild(ta); s5.appendChild(save);
			s5.appendChild(el('p', 'bm-hint', 'Widzi tylko obsługa — gość jej nie dostaje.'));
			body.appendChild(s5);
		}

		var acts = el('div', 'bm-dacts');
		if (b.can.delete_block) {
			acts.appendChild(btn('bm-btn bm-btn--danger', 'Usuń blokadę', function () {
				if (!window.confirm('Usunąć blokadę? Termin wróci do sprzedaży.')) return;
				api('/blocks/' + b.id, { method: 'DELETE' }).then(function () { toast('Blokada usunięta — termin wrócił do sprzedaży.'); closeDrawer(); refresh(); }).catch(fail);
			}));
		}
		if (b.can.cancel) acts.appendChild(btn('bm-btn bm-btn--danger', 'Anuluj rezerwację', function () { cancelForm(b); }));
		if (acts.childNodes.length) body.appendChild(acts);
		body.appendChild(el('p', 'bm-hint bm-dfoot', 'Rezerwacja #' + b.id + ' · utworzona ' + b.created_at));
	}

	function cancelForm(b) {
		var body = openDrawer('Anulowanie rezerwacji');
		var p = el('p', '', b.label + ' · ' + b.apartment.name + ' · ' + range(b.check_in, b.check_out));
		body.appendChild(p);
		var warn = el('div', 'bm-warn');
		warn.appendChild(el('p', '', b.order_info ? 'Zamówienie ' + b.order_info.number + ' zostanie oznaczone jako anulowane, a noce wrócą do sprzedaży. Gość dostanie standardowy mail WooCommerce o anulowaniu, jeśli jest włączony.' : 'Noce wrócą do sprzedaży.'));
		if (b.deposit) warn.appendChild(el('p', '', 'Zwrot zaliczki (' + money.format(b.deposit) + ') trzeba zrobić osobno — panel go nie wykonuje.'));
		body.appendChild(warn);
		var reason = el('input', 'bm-input'); reason.type = 'text'; reason.maxLength = 300; reason.placeholder = 'np. rezygnacja gościa telefonicznie';
		body.appendChild(field('Powód (trafi do historii i notatki zamówienia)', reason));
		var acts = el('div', 'bm-dacts');
		acts.appendChild(btn('bm-btn bm-btn--ghost', 'Wróć', function () { openBooking(b.id); }));
		var go = btn('bm-btn bm-btn--danger', 'Anuluj rezerwację', function () {
			go.disabled = true;
			api('/bookings/' + b.id + '/cancel', { method: 'POST', body: { reason: reason.value } }).then(function (nb) {
				toast('Rezerwacja anulowana.'); renderBooking(nb); refresh();
			}).catch(function (e) { go.disabled = false; fail(e); });
		});
		acts.appendChild(go); body.appendChild(acts);
		reason.focus();
	}

	/* ================= lista rezerwacji ================= */

	var listBox, moreBtn, qTimer;
	var SCOPES = [['upcoming', 'Nadchodzące'], ['current', 'Trwające'], ['past', 'Przeszłe'], ['blocks', 'Blokady'], ['cancelled', 'Anulowane'], ['all', 'Wszystkie']];

	function viewBookings(keep) {
		if (keep && listBox && main.contains(listBox)) { state.page = 1; loadBookings(false); return; }
		clear(main);
		var tools = el('div', 'bm-ltools');
		var seg = el('div', 'bm-seg'); seg.setAttribute('role', 'tablist');
		SCOPES.forEach(function (s) {
			var b = btn('bm-seg__btn' + (state.scope === s[0] ? ' is-active' : ''), s[1], function () {
				state.scope = s[0]; state.page = 1;
				seg.querySelectorAll('.bm-seg__btn').forEach(function (x) { x.classList.remove('is-active'); x.setAttribute('aria-selected', 'false'); });
				b.classList.add('is-active'); b.setAttribute('aria-selected', 'true'); loadBookings(false);
			});
			b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', state.scope === s[0] ? 'true' : 'false');
			seg.appendChild(b);
		});
		tools.appendChild(seg);
		var filters = el('div', 'bm-ltools__filters');
		var q = el('input', 'bm-input bm-search'); q.type = 'search'; q.placeholder = 'Szukaj: gość, telefon, e-mail, nr rezerwacji'; q.value = state.q; q.setAttribute('aria-label', 'Szukaj rezerwacji');
		q.oninput = function () { clearTimeout(qTimer); qTimer = setTimeout(function () { state.q = q.value.trim(); state.page = 1; loadBookings(false); }, 350); };
		var apt = el('select', 'bm-select'); apt.setAttribute('aria-label', 'Apartament');
		var o0 = el('option', '', 'Wszystkie apartamenty'); o0.value = ''; apt.appendChild(o0);
		apartments().then(function (list) { list.forEach(function (a) { var o = el('option', '', a.name); o.value = a.id; if (String(state.apartment) === String(a.id)) o.selected = true; apt.appendChild(o); }); });
		apt.onchange = function () { state.apartment = apt.value; state.page = 1; loadBookings(false); };
		filters.appendChild(q); filters.appendChild(apt);
		filters.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Blokada', function () { blockForm({}); }));
		tools.appendChild(filters);
		main.appendChild(tools);
		listBox = el('div', 'bm-list'); main.appendChild(listBox);
		moreBtn = btn('bm-btn bm-btn--ghost bm-list__more', 'Pokaż więcej', function () { state.page++; loadBookings(true); }); moreBtn.hidden = true;
		main.appendChild(moreBtn);
		loadBookings(false);
	}

	function loadBookings(append) {
		if (!append) loading(listBox);
		moreBtn.disabled = true;
		api('/bookings', { query: { scope: state.scope, q: state.q, apartment: state.apartment, page: state.page } }).then(function (d) {
			if (!append) clear(listBox);
			if (state.q && !append && d.items.length) listBox.appendChild(el('p', 'bm-list__info', 'Wyniki ze wszystkich rezerwacji: ' + d.total));
			if (!d.items.length && !append) {
				listBox.appendChild(el('p', 'bm-empty', state.q ? 'Nic nie znaleziono dla „' + state.q + '”.' : 'Brak rezerwacji w tej grupie.'));
			}
			d.items.forEach(function (b) { listBox.appendChild(listRow(b)); });
			moreBtn.hidden = d.page >= d.pages; moreBtn.disabled = false;
		}).catch(function (e) { clear(listBox); fail(e); });
	}

	function listRow(b) {
		var r = btn('bm-lrow', '', function () { location.hash = 'rezerwacja/' + b.id; });
		var when = el('div', 'bm-lrow__when');
		when.appendChild(el('strong', '', range(b.check_in, b.check_out)));
		when.appendChild(el('span', 'bm-muted', b.nights + ' ' + pl(b.nights, 'noc', 'noce', 'nocy')));
		var who = el('div', 'bm-lrow__who');
		who.appendChild(el('strong', '', b.label));
		who.appendChild(el('span', 'bm-muted', b.apartment.name + (b.status !== 'block' ? ' · ' + people(b) : '')));
		if (b.note) who.appendChild(el('span', 'bm-lrow__note', '✎ ' + b.note));
		var st = el('div', 'bm-lrow__st'); st.appendChild(chip(b.status, b.status_label));
		var m = el('div', 'bm-lrow__money');
		if (b.total) m.appendChild(el('strong', '', money.format(b.total)));
		if (b.balance_due) m.appendChild(el('span', 'bm-muted', 'do dopłaty ' + money.format(b.balance_due)));
		r.appendChild(when); r.appendChild(who); r.appendChild(st); r.appendChild(m);
		return r;
	}

	/* ================= historia ================= */

	function viewLog() {
		clear(main);
		main.appendChild(el('h2', 'bm-ptitle', 'Historia zmian'));
		main.appendChild(el('p', 'bm-hint', 'Kto i kiedy zablokował termin, anulował rezerwację, zmienił notatkę albo logował się do panelu.'));
		var box = el('div', 'bm-log'); main.appendChild(box);
		var page = 1;
		var more = btn('bm-btn bm-btn--ghost bm-list__more', 'Pokaż starsze', function () { page++; load(); }); more.hidden = true; main.appendChild(more);
		loading(box);
		function load() {
			api('/log', { query: { page: page } }).then(function (d) {
				if (page === 1) clear(box);
				if (!d.items.length && page === 1) box.appendChild(el('p', 'bm-empty', 'Historia jest pusta.'));
				d.items.forEach(function (x) {
					var r = el('div', 'bm-logrow');
					r.appendChild(el('span', 'bm-logrow__when', x.when));
					var w = el('div', 'bm-logrow__what'); w.appendChild(el('strong', '', x.label));
					var det = x.details || {};
					var bits = [det.apartment, det.from && det.to ? range(det.from, det.to) : '', det.order ? 'zamówienie ' + det.order : '', det.reason ? 'powód: ' + det.reason : '', det.attempts ? det.attempts + ' prób' : ''].filter(Boolean);
					if (bits.length) w.appendChild(el('span', 'bm-muted', bits.join(' · ')));
					r.appendChild(w);
					var whoEl = el('span', 'bm-logrow__who', x.who);
					r.appendChild(whoEl);
					if (x.object && x.object.indexOf('booking') === 0) {
						var id = +x.object.split('#')[1];
						r.classList.add('is-link'); r.tabIndex = 0; r.setAttribute('role', 'button');
						r.onclick = function () { location.hash = 'rezerwacja/' + id; };
						r.onkeydown = function (e) { if (e.key === 'Enter') r.onclick(); };
					}
					box.appendChild(r);
				});
				more.hidden = d.items.length < 50;
			}).catch(fail);
		}
		load();
	}

	route();
})();
