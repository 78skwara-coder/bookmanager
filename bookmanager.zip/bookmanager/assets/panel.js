/**
 * BookManager — panel na stronie ([bookmanager_panel]).
 * Widoki: Kalendarz (oś czasu + dziś/jutro), Rezerwacje (lista z filtrami), Historia (właściciel).
 * Szczegóły i formularze w wysuwanym panelu bocznym. Wszystko przez REST /bookmanager/v1/panel.
 * Czysty JS, bez bibliotek. Adres (#kalendarz/2026-10, #rezerwacje, #rezerwacja/123) trzyma stan — działa „wstecz”.
 */
(function () {
	'use strict';

	var root = document.getElementById('bm-panel');
	if (!root) return;
	var CFG = JSON.parse(root.getAttribute('data-bm-panel'));
	var money = new Intl.NumberFormat('pl-PL', { style: 'currency', currency: CFG.currency || 'PLN' });
	var MON = ['sty', 'lut', 'mar', 'kwi', 'maj', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru'];
	var DOW = ['', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'];

	/* ================= narzędzia ================= */

	function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
	function btn(cls, text, onClick, title) { var b = el('button', cls, text); b.type = 'button'; if (onClick) b.onclick = onClick; if (title) b.title = title; return b; }
	function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); return n; }
	function pl(n, a, b, c) { if (n === 1) return a; var d = n % 10, t = n % 100; return d >= 2 && d <= 4 && (t < 12 || t > 14) ? b : c; }
	function day(s) { var p = s.split('-'); return +p[2] + ' ' + MON[+p[1] - 1]; }
	function dayY(s) { return day(s) + ' ' + s.slice(0, 4); }
	function range(a, b) { return a.slice(0, 4) === b.slice(0, 4) ? day(a) + ' – ' + dayY(b) : dayY(a) + ' – ' + dayY(b); }
	function addDays(s, n) { var p = s.split('-'), d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + n)); return d.toISOString().slice(0, 10); }
	function people(b) { var t = b.adults + ' ' + pl(b.adults, 'dorosły', 'dorosłych', 'dorosłych'); if (b.children) t += ', ' + b.children + ' ' + pl(b.children, 'dziecko', 'dzieci', 'dzieci'); return t; }
	function chip(status, label) { return el('span', 'bm-chip bm-chip--' + status, label); }
	function bchip(b) { return chip(b.flag || b.status, b.status_label); }

	function api(path, opts) {
		opts = opts || {};
		var init = { method: opts.method || 'GET', credentials: 'same-origin', headers: { 'X-WP-Nonce': CFG.nonce } };
		if (opts.body) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
		var url = CFG.api + path;
		if (opts.query) {
			var q = Object.keys(opts.query).filter(function (k) { return opts.query[k] !== '' && opts.query[k] != null; })
				.map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(opts.query[k]); }).join('&');
			if (q) url += (url.indexOf('?') === -1 ? '?' : '&') + q;
		}
		return fetch(url, init).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (d) {
				if (r.status === 401 || r.status === 403 && d.code === 'rest_cookie_invalid_nonce') { location.reload(); throw new Error('Sesja wygasła.'); }
				if (!r.ok) throw new Error(d.message || 'Coś poszło nie tak. Spróbuj ponownie.');
				return d;
			});
		});
	}

	var toastBox;
	function toast(msg, bad) {
		if (!toastBox) { toastBox = el('div', 'bm-toasts'); toastBox.setAttribute('aria-live', 'polite'); root.appendChild(toastBox); }
		var t = el('div', 'bm-toast' + (bad ? ' is-bad' : ''), msg); toastBox.appendChild(t);
		setTimeout(function () { t.classList.add('is-out'); setTimeout(function () { t.remove(); }, 300); }, bad ? 6000 : 3000);
	}
	function fail(e) { toast(e.message || String(e), true); }

	/* ================= szkielet ================= */

	var views = [['kalendarz', 'Kalendarz'], ['rezerwacje', 'Rezerwacje']];
	if (CFG.user.manage) { views.push(['apartamenty', 'Apartamenty']); views.push(['sezony', 'Sezony']); views.push(['powiadomienia', 'Powiadomienia']); views.push(['historia', 'Historia']); }

	clear(root);
	var bar = el('header', 'bm-pbar');
	var brand = el('div', 'bm-pbar__brand'); brand.appendChild(el('strong', '', CFG.site)); brand.appendChild(el('span', '', 'Panel rezerwacji'));
	var nav = el('nav', 'bm-pnav'); nav.setAttribute('aria-label', 'Panel');
	var navLinks = {};
	views.forEach(function (v) { var a = el('a', 'bm-pnav__link', v[1]); a.href = '#' + v[0]; navLinks[v[0]] = a; nav.appendChild(a); });
	var who = el('div', 'bm-pbar__user');
	who.appendChild(el('span', 'bm-pbar__name', CFG.user.name));
	if (CFG.admin) { var ad = el('a', 'bm-pbar__link', 'Kokpit'); ad.href = CFG.admin; who.appendChild(ad); }
	var lo = el('a', 'bm-pbar__link', 'Wyloguj'); lo.href = CFG.logout; who.appendChild(lo);
	bar.appendChild(brand); bar.appendChild(nav); bar.appendChild(who);
	var main = el('div', 'bm-pmain');
	root.appendChild(bar); root.appendChild(main);

	// panel boczny
	var shade = el('div', 'bm-shade'); shade.hidden = true;
	var drawer = el('aside', 'bm-drawer'); drawer.hidden = true; drawer.setAttribute('role', 'dialog'); drawer.setAttribute('aria-modal', 'true');
	var dHead = el('div', 'bm-drawer__head'), dTitle = el('h2', 'bm-drawer__title'), dBody = el('div', 'bm-drawer__body');
	var dClose = btn('bm-round bm-drawer__close', '×', function () { closeDrawer(); }, 'Zamknij');
	dHead.appendChild(dTitle); dHead.appendChild(dClose); drawer.appendChild(dHead); drawer.appendChild(dBody);
	root.appendChild(shade); root.appendChild(drawer);
	shade.onclick = function () { closeDrawer(); };
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !drawer.hidden) closeDrawer(); });

	var drawerFromHash = false;
	function openDrawer(title, fromHash) {
		dTitle.textContent = title; clear(dBody);
		drawer.hidden = shade.hidden = false; document.documentElement.classList.add('bm-noscroll');
		drawerFromHash = !!fromHash;
		setTimeout(function () { dClose.focus(); }, 30);
		return dBody;
	}
	function closeDrawer() {
		if (drawer.hidden) return;
		drawer.hidden = shade.hidden = true; document.documentElement.classList.remove('bm-noscroll');
		if (drawerFromHash && /^#rezerwacja\//.test(location.hash)) history.replaceState(null, '', lastView || '#kalendarz');
	}

	/* ================= router ================= */

	var state = { view: '', month: '', scope: 'upcoming', q: '', apartment: '', page: 1 };
	var lastView = '';
	var apartmentsCache = null;
	function apartments() { return apartmentsCache ? Promise.resolve(apartmentsCache) : api('/apartments').then(function (d) { apartmentsCache = d; return d; }); }

	var dirty = false, curHash = location.hash;
	function route() {
		if (dirty && location.hash !== curHash) {
			if (!window.confirm('Masz niezapisane zmiany. Wyjść bez zapisywania?')) { history.replaceState(null, '', curHash); return; }
			dirty = false;
		}
		curHash = location.hash;
		var h = location.hash.replace(/^#/, ''), parts = h.split('/');
		if (parts[0] === 'rezerwacja' && parts[1]) {
			if (!state.view) show('kalendarz');
			openBooking(+parts[1], true);
			return;
		}
		if (parts[0] === 'nowa-rezerwacja') { lastView = '#rezerwacje'; closeDrawer(); state.view = 'rezerwacje'; Object.keys(navLinks).forEach(function (k) { navLinks[k].classList.toggle('is-active', k === 'rezerwacje'); }); manualBooking(); window.scrollTo(0, 0); return; }
		var alias = { apartament: 'apartamenty', sezon: 'sezony', powiadomienie: 'powiadomienia' };
		var v = alias[parts[0]] || parts[0];
		v = views.some(function (x) { return x[0] === v; }) ? v : 'kalendarz';
		lastView = '#' + (h || v);
		if (v === 'kalendarz' && /^\d{4}-\d{2}$/.test(parts[1] || '')) state.month = parts[1];
		closeDrawer();
		show(v, alias[parts[0]] ? parts[1] : null);
	}
	function show(v, arg) {
		state.view = v;
		Object.keys(navLinks).forEach(function (k) { navLinks[k].classList.toggle('is-active', k === v); if (k === v) navLinks[k].setAttribute('aria-current', 'page'); else navLinks[k].removeAttribute('aria-current'); });
		if (v === 'rezerwacje') viewBookings();
		else if (v === 'historia') viewLog();
		else if (v === 'apartamenty') { if (arg) editApartment(+arg); else viewApartments(); }
		else if (v === 'sezony') { if (arg) editSeason(arg === 'nowy' ? 0 : +arg); else viewSeasons(); }
		else if (v === 'powiadomienia') { if (arg) editNotification(arg === 'nowe' ? 0 : +arg); else viewNotifications(); }
		else viewCalendar();
		window.scrollTo(0, 0);
	}
	window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
	window.addEventListener('hashchange', route);

	function loading(box) { clear(box).appendChild(el('p', 'bm-muted bm-loading', 'Wczytywanie…')); }

	/* ================= kalendarz ================= */

	var sel = null; // zaznaczanie wolnych nocy: {apt, name, from}

	function viewCalendar() {
		clear(main);
		var today = el('section', 'bm-today'); main.appendChild(today);
		var cal = el('section', 'bm-tlbox'); main.appendChild(cal);
		loadToday(today); loadCalendar(cal);
	}

	function loadToday(box) {
		api('/today').then(function (d) {
			clear(box);
			var card = function (title, list, empty, kind) {
				var c = el('div', 'bm-tcard bm-tcard--' + kind);
				var h = el('div', 'bm-tcard__head'); h.appendChild(el('span', 'bm-tcard__title', title)); h.appendChild(el('strong', 'bm-tcard__n', String(list.length)));
				c.appendChild(h);
				if (!list.length) c.appendChild(el('p', 'bm-tcard__empty', empty));
				list.slice(0, 4).forEach(function (b) {
					var r = btn('bm-tcard__row', '', function () { location.hash = 'rezerwacja/' + b.id; });
					r.appendChild(el('span', 'bm-tcard__who', b.label));
					r.appendChild(el('span', 'bm-tcard__apt', b.apartment.name + (kind !== 'dep' ? ' · ' + people(b) : '')));
					c.appendChild(r);
				});
				if (list.length > 4) c.appendChild(el('p', 'bm-tcard__more', 'i ' + (list.length - 4) + ' więcej…'));
				return c;
			};
			if (d.overdue && d.overdue.length) {
				var ov = card('Termin wpłaty minął', d.overdue, '', 'overdue');
				ov.classList.add('bm-tcard--alert'); box.appendChild(ov); box.classList.add('has-alert');
			} else box.classList.remove('has-alert');
			box.appendChild(card('Przyjazdy dziś', d.arrivals, 'Brak przyjazdów.', 'arr'));
			box.appendChild(card('Wyjazdy dziś', d.departures, 'Brak wyjazdów.', 'dep'));
			box.appendChild(card('Przyjazdy jutro', d.tomorrow, 'Brak przyjazdów.', 'tom'));
			var s = el('div', 'bm-tcard bm-tcard--stay');
			var h = el('div', 'bm-tcard__head'); h.appendChild(el('span', 'bm-tcard__title', 'Zajęte tej nocy')); h.appendChild(el('strong', 'bm-tcard__n', String(d.staying)));
			s.appendChild(h); s.appendChild(el('p', 'bm-tcard__empty', d.staying ? pl(d.staying, 'apartament z gośćmi', 'apartamenty z gośćmi', 'apartamentów z gośćmi') : 'Nikt nie nocuje.'));
			box.appendChild(s);
		}).catch(function (e) { clear(box); fail(e); });
	}

	function loadCalendar(box) {
		loading(box);
		api('/calendar', { query: { month: state.month } }).then(function (d) { renderCalendar(box, d); }).catch(function (e) { clear(box); fail(e); });
	}

	function renderCalendar(box, d) {
		clear(box); sel = null;
		var tools = el('div', 'bm-tltools');
		var go = function (m) { location.hash = 'kalendarz/' + m; };
		tools.appendChild(btn('bm-round', '‹', function () { go(d.prev); }, 'Poprzedni miesiąc'));
		tools.appendChild(el('h2', 'bm-tltools__title', d.title));
		tools.appendChild(btn('bm-round', '›', function () { go(d.next); }, 'Następny miesiąc'));
		tools.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Dziś', function () { location.hash = 'kalendarz'; state.month = ''; if (location.hash === '#kalendarz') viewCalendar(); }));
		var legend = el('div', 'bm-legend');
		[['confirmed', 'potwierdzona'], ['hold', 'w trakcie płatności'], ['overdue', 'termin wpłaty minął'], ['block', 'blokada'], ['conflict', 'konflikt']].forEach(function (x) {
			var i = el('span', 'bm-legend__item'); i.appendChild(el('i', 'bm-dot bm-dot--' + x[0])); i.appendChild(document.createTextNode(x[1])); legend.appendChild(i);
		});
		tools.appendChild(legend);
		tools.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm bm-tltools__add', '+ Blokada', function () { blockForm({}); }));
		tools.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Rezerwacja', function () { location.hash = 'nowa-rezerwacja'; }));
		box.appendChild(tools);
		var hint = el('p', 'bm-hint', 'Kliknij rezerwację, aby zobaczyć szczegóły. Aby zablokować termin, kliknij pierwszą i ostatnią wolną noc w wierszu apartamentu.');
		box.appendChild(hint);

		var groups = d.groups.filter(function (g) { return g.apartments.length || true; });
		if (!groups.length) { box.appendChild(el('p', 'bm-muted', 'Brak apartamentów.')); return; }

		var scroll = el('div', 'bm-tl'); var table = el('table', 'bm-tl__table');
		var thead = el('thead'), hr = el('tr'); hr.appendChild(el('th', 'bm-tl__name bm-tl__corner'));
		d.days.forEach(function (x) {
			var th = el('th', 'bm-tl__day' + (x.dow >= 6 ? ' is-we' : '') + (x.date === d.today ? ' is-today' : ''));
			th.appendChild(el('span', 'bm-tl__dow', DOW[x.dow])); th.appendChild(el('span', 'bm-tl__num', String(x.num)));
			hr.appendChild(th);
		});
		thead.appendChild(hr); table.appendChild(thead);
		var tbody = el('tbody');
		d.groups.forEach(function (g) {
			var gr = el('tr', 'bm-tl__group'); var gth = el('th'); gth.colSpan = d.days.length + 1;
			var gt = el('span', 'bm-tl__gtitle', g.title); gt.style.paddingLeft = (g.depth * 14) + 'px'; gth.appendChild(gt);
			gr.appendChild(gth); tbody.appendChild(gr);
			g.apartments.forEach(function (a) { tbody.appendChild(calRow(a, d, g.depth)); });
		});
		table.appendChild(tbody); scroll.appendChild(table); box.appendChild(scroll);
		// przewiń do dziś
		var t = table.querySelector('th.is-today');
		if (t) scroll.scrollLeft = Math.max(0, t.offsetLeft - 220);
		box.hint = hint;
	}

	function calRow(a, d, depth) {
		var tr = el('tr', 'bm-tl__row');
		var th = el('th', 'bm-tl__name', a.name); th.title = a.name; th.style.paddingLeft = (window.innerWidth < 720 ? 10 : 18 + depth * 14) + 'px'; tr.appendChild(th);
		var starts = {}; a.items.forEach(function (it) { starts[it.start] = it; });
		for (var i = 1; i <= d.days.length; i++) {
			var x = d.days[i - 1];
			if (starts[i]) {
				var it = starts[i], td = el('td', 'bm-tl__cell bm-tl__barcell'); td.colSpan = it.span;
				var b = btn('bm-bar bm-bar--' + it.status + (it.flag ? ' bm-bar--' + it.flag : ''), '', null, it.label + ' · ' + range(it.check_in, it.check_out) + ' · ' + it.status_label);
				b.appendChild(el('span', 'bm-bar__label', it.label));
				b.onclick = (function (id) { return function () { location.hash = 'rezerwacja/' + id; }; })(it.id);
				td.appendChild(b); tr.appendChild(td); i += it.span - 1; continue;
			}
			var c = el('td', 'bm-tl__cell bm-tl__free' + (x.dow >= 6 ? ' is-we' : '') + (x.date === d.today ? ' is-today' : '') + (x.date < d.today ? ' is-past' : ''));
			c.setAttribute('data-date', x.date);
			if (x.date >= d.today) c.onclick = (function (date, cell) { return function () { pickNight(a, date, cell, tr); }; })(x.date, c);
			tr.appendChild(c);
		}
		return tr;
	}

	function pickNight(a, date, cell, tr) {
		if (sel && sel.apt === a.id && date >= sel.from) {
			// czy w zakresie nie ma zajętych nocy
			var ok = true, n = sel.from;
			while (n <= date) { var c = tr.querySelector('[data-date="' + n + '"]'); if (!c) { ok = false; break; } n = addDays(n, 1); }
			var from = sel.from; clearSel();
			if (!ok) { toast('W zaznaczonym zakresie jest już rezerwacja.', true); return; }
			blockForm({ apartment_id: a.id, check_in: from, check_out: addDays(date, 1) });
			return;
		}
		clearSel();
		sel = { apt: a.id, from: date, cell: cell };
		cell.classList.add('is-sel');
		toast('Pierwsza noc: ' + dayY(date) + '. Kliknij ostatnią noc blokady.');
	}
	function clearSel() { if (sel && sel.cell) sel.cell.classList.remove('is-sel'); sel = null; }

	/* ================= blokada ================= */

	function field(label, input, help) {
		var f = el('label', 'bm-field'); f.appendChild(el('span', 'bm-field__label', label)); f.appendChild(input);
		if (help) f.appendChild(el('span', 'bm-field__help', help));
		return f;
	}

	function blockForm(v) {
		var body = openDrawer('Nowa blokada terminu');
		var form = el('form', 'bm-form');
		var apt = el('select', 'bm-select'); apt.required = true;
		var o0 = el('option', '', 'wybierz apartament'); o0.value = ''; apt.appendChild(o0);
		apartments().then(function (list) {
			list.forEach(function (a) { var o = el('option', '', a.name + (a.group ? ' · ' + a.group : '')); o.value = a.id; if (+v.apartment_id === a.id) o.selected = true; apt.appendChild(o); });
		});
		var today = new Date(); var tISO = new Date(Date.UTC(today.getFullYear(), today.getMonth(), today.getDate())).toISOString().slice(0, 10);
		var from = el('input', 'bm-input'); from.type = 'date'; from.required = true; from.min = tISO; from.value = v.check_in || '';
		var to = el('input', 'bm-input'); to.type = 'date'; to.required = true; to.value = v.check_out || '';
		var note = el('input', 'bm-input'); note.type = 'text'; note.maxLength = 190; note.placeholder = 'np. remont, pobyt własny, rezerwacja telefoniczna';
		var info = el('p', 'bm-hint');
		var upd = function () {
			to.min = from.value ? addDays(from.value, 1) : tISO;
			if (from.value && to.value && to.value > from.value) {
				var n = Math.round((Date.parse(to.value) - Date.parse(from.value)) / 864e5);
				info.textContent = 'Zablokowane noce: ' + range(from.value, addDays(to.value, -1)) + ' (' + n + ' ' + pl(n, 'noc', 'noce', 'nocy') + '). Termin wraca do sprzedaży ' + dayY(to.value) + '.';
			} else info.textContent = '';
		};
		from.onchange = to.onchange = upd; upd();
		form.appendChild(field('Apartament', apt));
		var dates = el('div', 'bm-form__row');
		dates.appendChild(field('Pierwsza noc', from));
		dates.appendChild(field('Dzień zwolnienia', to, 'dzień po ostatniej nocy'));
		form.appendChild(dates);
		form.appendChild(info);
		form.appendChild(field('Opis (widzi tylko obsługa)', note));
		var submit = btn('bm-btn bm-btn--primary bm-btn--block', 'Zablokuj termin'); submit.type = 'submit';
		form.appendChild(submit);
		form.onsubmit = function (e) {
			e.preventDefault();
			if (!apt.value || !from.value || !to.value || to.value <= from.value) { toast('Uzupełnij apartament i poprawny zakres dat.', true); return; }
			submit.disabled = true;
			api('/blocks', { method: 'POST', body: { apartment_id: +apt.value, check_in: from.value, check_out: to.value, note: note.value } }).then(function (b) {
				toast('Termin zablokowany.');
				closeDrawer(); refresh();
				void b;
			}).catch(function (e) { submit.disabled = false; fail(e); });
		};
		body.appendChild(form);
		(v.apartment_id ? note : apt).focus();
	}

	function refresh() { if (state.view === 'kalendarz') viewCalendar(); else if (state.view === 'rezerwacje' && location.hash.indexOf('nowa-rezerwacja') === -1) viewBookings(true); }

	/* ================= szczegóły rezerwacji ================= */

	function openBooking(id, fromHash) {
		var body = openDrawer('Rezerwacja #' + id, fromHash);
		loading(body);
		api('/bookings/' + id).then(function (b) { renderBooking(b); }).catch(function (e) { clear(body); fail(e); });
	}

	function dl(rows) {
		var d = el('dl', 'bm-dl');
		rows.forEach(function (r) {
			if (r[1] == null || r[1] === '') return;
			d.appendChild(el('dt', '', r[0]));
			var dd = el('dd'); if (r[1] instanceof Node) dd.appendChild(r[1]); else dd.textContent = r[1]; d.appendChild(dd);
		});
		return d;
	}
	function section(title) { var s = el('section', 'bm-dsec'); if (title) s.appendChild(el('h3', 'bm-dsec__title', title)); return s; }
	function link(href, text) { var a = el('a', '', text); a.href = href; return a; }

	function renderBooking(b) {
		dTitle.textContent = b.status === 'block' ? 'Blokada terminu' : b.label;
		var body = clear(dBody);
		var top = el('div', 'bm-dtop');
		top.appendChild(bchip(b));
		if (b.order_info) top.appendChild(el('span', 'bm-muted', 'zamówienie ' + b.order_info.number + ' · ' + b.order_info.status_label));
		body.appendChild(top);
		if (b.awaiting) {
			var aw = el('div', b.awaiting.overdue ? 'bm-alert' : 'bm-warn');
			aw.appendChild(el('strong', '', b.awaiting.overdue ? 'Termin wpłaty zaliczki minął ' + dayY(b.awaiting.due) + '.' : 'Czeka na wpłatę zaliczki do ' + dayY(b.awaiting.due) + '.'));
			aw.appendChild(el('p', '', b.awaiting.overdue ? 'Termin nadal jest zablokowany dla gościa. Skontaktuj się z nim: zarejestruj wpłatę, gdy przyjdzie, albo anuluj rezerwację.' : 'Termin jest zablokowany. Po wpłacie zarejestruj ją poniżej — gość dostanie potwierdzenie rezerwacji.'));
			body.appendChild(aw);
		}
		if (b.no_email) body.appendChild(el('div', 'bm-warn', 'Gość nie podał adresu e-mail — powiadomienia do niego nie są wysyłane.'));

		var s1 = section('Pobyt');
		s1.appendChild(dl([
			['Apartament', b.apartment.name],
			['Termin', range(b.check_in, b.check_out) + ' · ' + b.nights + ' ' + pl(b.nights, 'noc', 'noce', 'nocy')],
			['Przyjazd ok.', b.arrival_time],
			['Opis', b.block_note]
		]));
		body.appendChild(s1);

		if (b.status !== 'block') {
			if (b.contact) {
				var s2 = section('Gość');
				s2.appendChild(dl([
					['Imię i nazwisko', b.guest],
					['Telefon', b.contact.phone ? link('tel:' + b.contact.phone.replace(/\s+/g, ''), b.contact.phone) : ''],
					['E-mail', b.contact.email ? link('mailto:' + b.contact.email, b.contact.email) : ''],
					['Kraj', b.contact.country],
					['Uwagi gościa', b.contact.note]
				]));
				body.appendChild(s2);
			}
			var s3 = section('Osoby i opcje');
			var kids = b.children ? b.children + ' (' + b.children_ages.split(',').map(function (x) { return x + ' l.'; }).join(', ') + ')' : '';
			var beds = [b.extra_beds.adult ? b.extra_beds.adult + '× dla dorosłego' : '', b.extra_beds.child ? b.extra_beds.child + '× dla dziecka' : ''].filter(Boolean).join(', ');
			s3.appendChild(dl([
				['Dorośli', String(b.adults)],
				['Dzieci', kids],
				['Dostawki', beds],
				['Opcje', b.extras.map(function (x) { return x.name + (+x.qty > 1 ? ' × ' + x.qty : ''); }).join(', ')]
			]));
			body.appendChild(s3);

			var s4 = section('Płatność');
			if (b.lines.length) {
				var ul = el('ul', 'bm-lines');
				b.lines.forEach(function (l) { var li = el('li'); li.appendChild(el('span', '', l.label)); li.appendChild(el('span', '', l.amount !== 0 ? money.format(l.amount) : 'gratis')); ul.appendChild(li); });
				var tot = el('li', 'is-total'); tot.appendChild(el('span', '', 'Razem')); tot.appendChild(el('span', '', money.format(b.total))); ul.appendChild(tot);
				s4.appendChild(ul);
			}
			s4.appendChild(dl([
				['Zaliczka', b.deposit ? money.format(b.deposit) : ''],
				['Do dopłaty', b.balance_due ? money.format(b.balance_due) + (b.balance_due_date ? ' (do ' + dayY(b.balance_due_date) + ')' : '') : ''],
				['Opłata miejscowa', b.city_tax ? money.format(b.city_tax) + ' — na miejscu' : ''],
				['Metoda płatności', b.order_info ? b.order_info.payment : '']
			]));
			if (b.price_reason) s4.appendChild(el('p', 'bm-hint', 'Korekta ceny: ' + b.price_reason));
			if (b.payments.length) {
				var pl2 = el('ul', 'bm-lines bm-pays');
				b.payments.forEach(function (x) { var li = el('li'); li.appendChild(el('span', '', x.when + ' · ' + (x.kind === 'deposit' ? 'zaliczka' : 'dopłata') + ' · ' + x.method + (x.by ? ' · ' + x.by : '') + (x.note ? ' — ' + x.note : ''))); li.appendChild(el('span', '', money.format(x.amount))); pl2.appendChild(li); });
				s4.appendChild(el('span', 'bm-field__label', 'Wpłaty zarejestrowane w panelu')); s4.appendChild(pl2);
			}
			if (b.can.payment) s4.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', b.awaiting ? 'Zarejestruj wpłatę zaliczki' : 'Zarejestruj wpłatę', function () { paymentForm(b); }));
			if (b.order_info && b.order_info.url) { var oa = link(b.order_info.url, 'Otwórz zamówienie w WooCommerce ↗'); oa.target = '_blank'; oa.className = 'bm-link'; s4.appendChild(oa); }
			body.appendChild(s4);

			var s6 = section('Powiadomienia');
			if (!b.notifications.length) s6.appendChild(el('p', 'bm-hint', 'Jeszcze nic nie wysłano.'));
			b.notifications.forEach(function (x) {
				var r = el('div', 'bm-nrow bm-nrow--' + x.status);
				r.appendChild(el('span', 'bm-nrow__name', x.name));
				r.appendChild(el('span', 'bm-muted', x.when + ' · ' + (x.status === 'sent' ? 'wysłano do ' + x.to : x.status === 'skipped' ? 'pominięto: ' + x.info : 'błąd: ' + x.info)));
				s6.appendChild(r);
			});
			if (b.templates.length) {
				var tsel = el('select', 'bm-select'); var o0 = el('option', '', 'Wyślij teraz…'); o0.value = ''; tsel.appendChild(o0);
				b.templates.forEach(function (t) { var o = el('option', '', t.name + (t.recipient === 'guest' ? '' : ' (do obsługi)')); o.value = t.id; tsel.appendChild(o); });
				var tgo = btn('bm-btn bm-btn--ghost bm-btn--sm', 'Wyślij', function () {
					if (!tsel.value) { toast('Wybierz powiadomienie.', true); return; }
					tgo.disabled = true;
					api('/bookings/' + b.id + '/notify', { method: 'POST', body: { notification_id: +tsel.value } }).then(function (nb) { toast('Wysłano.'); renderBooking(nb); }).catch(function (e) { tgo.disabled = false; fail(e); });
				});
				s6.appendChild(row2(tsel, tgo));
			}
			body.appendChild(s6);
		}

		if (b.can.note) {
			var s5 = section('Notatka obsługi');
			var ta = el('textarea', 'bm-input bm-textarea'); ta.rows = 3; ta.maxLength = 2000; ta.value = b.internal_note || ''; ta.placeholder = 'np. późny przyjazd, prośba o łóżeczko, klucze u sąsiada';
			ta.setAttribute('aria-label', 'Notatka obsługi');
			var save = btn('bm-btn bm-btn--ghost bm-btn--sm', 'Zapisz notatkę', function () {
				save.disabled = true;
				api('/bookings/' + b.id + '/note', { method: 'POST', body: { note: ta.value } }).then(function () { toast('Notatka zapisana.'); save.disabled = false; })
					.catch(function (e) { save.disabled = false; fail(e); });
			});
			s5.appendChild(ta); s5.appendChild(save);
			s5.appendChild(el('p', 'bm-hint', 'Widzi tylko obsługa — gość jej nie dostaje.'));
			body.appendChild(s5);
		}

		var acts = el('div', 'bm-dacts');
		if (b.can.delete_block) {
			acts.appendChild(btn('bm-btn bm-btn--danger', 'Usuń blokadę', function () {
				if (!window.confirm('Usunąć blokadę? Termin wróci do sprzedaży.')) return;
				api('/blocks/' + b.id, { method: 'DELETE' }).then(function () { toast('Blokada usunięta — termin wrócił do sprzedaży.'); closeDrawer(); refresh(); }).catch(fail);
			}));
		}
		if (b.can.cancel) acts.appendChild(btn('bm-btn bm-btn--danger', 'Anuluj rezerwację', function () { cancelForm(b); }));
		if (acts.childNodes.length) body.appendChild(acts);
		body.appendChild(el('p', 'bm-hint bm-dfoot', 'Rezerwacja #' + b.id + ' · utworzona ' + b.created_at));
	}

	function row2(a, b) { var r = el('div', 'bm-form__row bm-form__row--inline'); r.appendChild(a); r.appendChild(b); return r; }

	function paymentForm(b) {
		var body = openDrawer(b.awaiting ? 'Wpłata zaliczki' : 'Wpłata');
		body.appendChild(el('p', '', b.label + ' · ' + b.apartment.name + ' · ' + range(b.check_in, b.check_out)));
		var left = b.balance_due;
		var amt = el('input', 'bm-input'); amt.type = 'number'; amt.step = '0.01'; amt.min = '0.01'; amt.max = String(left); amt.inputMode = 'decimal';
		amt.value = b.awaiting && b.deposit ? b.deposit : left;
		var meth = el('select', 'bm-select'); Object.keys(b.methods).forEach(function (k) { var o = el('option', '', b.methods[k]); o.value = k; meth.appendChild(o); });
		if (b.awaiting) meth.value = 'transfer';
		var note = el('input', 'bm-input'); note.type = 'text'; note.maxLength = 200; note.placeholder = 'np. przelew z 14.10, nr transakcji';
		body.appendChild(row2(field('Kwota (zł)', amt, 'Pozostało: ' + money.format(left)), field('Sposób', meth)));
		body.appendChild(field('Notatka (opcjonalnie)', note));
		if (b.awaiting) body.appendChild(el('p', 'bm-hint', 'Po zapisaniu rezerwacja przestaje czekać na wpłatę, a gość dostaje potwierdzenie rezerwacji.'));
		var acts = el('div', 'bm-dacts');
		acts.appendChild(btn('bm-btn bm-btn--ghost', 'Wróć', function () { openBooking(b.id); }));
		var go = btn('bm-btn bm-btn--primary', 'Zapisz wpłatę', function () {
			var v = parseFloat(String(amt.value).replace(',', '.'));
			if (!(v > 0) || v > left + 0.004) { toast('Podaj kwotę od 0,01 do ' + money.format(left) + '.', true); return; }
			go.disabled = true;
			api('/bookings/' + b.id + '/payment', { method: 'POST', body: { amount: v, method: meth.value, note: note.value } }).then(function (nb) {
				toast('Wpłata zapisana.'); renderBooking(nb); refresh();
			}).catch(function (e) { go.disabled = false; fail(e); });
		});
		acts.appendChild(go); body.appendChild(acts); amt.focus();
	}

	function cancelForm(b) {
		var body = openDrawer('Anulowanie rezerwacji');
		var p = el('p', '', b.label + ' · ' + b.apartment.name + ' · ' + range(b.check_in, b.check_out));
		body.appendChild(p);
		var warn = el('div', 'bm-warn');
		warn.appendChild(el('p', '', b.order_info ? 'Zamówienie ' + b.order_info.number + ' zostanie oznaczone jako anulowane, a noce wrócą do sprzedaży. Gość dostanie standardowy mail WooCommerce o anulowaniu, jeśli jest włączony.' : 'Noce wrócą do sprzedaży.'));
		if (b.deposit) warn.appendChild(el('p', '', 'Zwrot zaliczki (' + money.format(b.deposit) + ') trzeba zrobić osobno — panel go nie wykonuje.'));
		body.appendChild(warn);
		var reason = el('input', 'bm-input'); reason.type = 'text'; reason.maxLength = 300; reason.placeholder = 'np. rezygnacja gościa telefonicznie';
		body.appendChild(field('Powód (trafi do historii i notatki zamówienia)', reason));
		var acts = el('div', 'bm-dacts');
		acts.appendChild(btn('bm-btn bm-btn--ghost', 'Wróć', function () { openBooking(b.id); }));
		var go = btn('bm-btn bm-btn--danger', 'Anuluj rezerwację', function () {
			go.disabled = true;
			api('/bookings/' + b.id + '/cancel', { method: 'POST', body: { reason: reason.value } }).then(function (nb) {
				toast('Rezerwacja anulowana.'); renderBooking(nb); refresh();
			}).catch(function (e) { go.disabled = false; fail(e); });
		});
		acts.appendChild(go); body.appendChild(acts);
		reason.focus();
	}

	/* ================= lista rezerwacji ================= */

	var listBox, moreBtn, qTimer;
	var SCOPES = [['upcoming', 'Nadchodzące'], ['current', 'Trwające'], ['past', 'Przeszłe'], ['blocks', 'Blokady'], ['cancelled', 'Anulowane'], ['all', 'Wszystkie']];

	function viewBookings(keep) {
		if (keep && listBox && main.contains(listBox)) { state.page = 1; loadBookings(false); return; }
		clear(main);
		var tools = el('div', 'bm-ltools');
		var seg = el('div', 'bm-seg'); seg.setAttribute('role', 'tablist');
		SCOPES.forEach(function (s) {
			var b = btn('bm-seg__btn' + (state.scope === s[0] ? ' is-active' : ''), s[1], function () {
				state.scope = s[0]; state.page = 1;
				seg.querySelectorAll('.bm-seg__btn').forEach(function (x) { x.classList.remove('is-active'); x.setAttribute('aria-selected', 'false'); });
				b.classList.add('is-active'); b.setAttribute('aria-selected', 'true'); loadBookings(false);
			});
			b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', state.scope === s[0] ? 'true' : 'false');
			seg.appendChild(b);
		});
		tools.appendChild(seg);
		var filters = el('div', 'bm-ltools__filters');
		var q = el('input', 'bm-input bm-search'); q.type = 'search'; q.placeholder = 'Szukaj: gość, telefon, e-mail, nr rezerwacji'; q.value = state.q; q.setAttribute('aria-label', 'Szukaj rezerwacji');
		q.oninput = function () { clearTimeout(qTimer); qTimer = setTimeout(function () { state.q = q.value.trim(); state.page = 1; loadBookings(false); }, 350); };
		var apt = el('select', 'bm-select'); apt.setAttribute('aria-label', 'Apartament');
		var o0 = el('option', '', 'Wszystkie apartamenty'); o0.value = ''; apt.appendChild(o0);
		apartments().then(function (list) { list.forEach(function (a) { var o = el('option', '', a.name); o.value = a.id; if (String(state.apartment) === String(a.id)) o.selected = true; apt.appendChild(o); }); });
		apt.onchange = function () { state.apartment = apt.value; state.page = 1; loadBookings(false); };
		filters.appendChild(q); filters.appendChild(apt);
		filters.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', '+ Blokada', function () { blockForm({}); }));
		filters.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Rezerwacja', function () { location.hash = 'nowa-rezerwacja'; }));
		tools.appendChild(filters);
		main.appendChild(tools);
		listBox = el('div', 'bm-list'); main.appendChild(listBox);
		moreBtn = btn('bm-btn bm-btn--ghost bm-list__more', 'Pokaż więcej', function () { state.page++; loadBookings(true); }); moreBtn.hidden = true;
		main.appendChild(moreBtn);
		loadBookings(false);
	}

	function loadBookings(append) {
		if (!append) loading(listBox);
		moreBtn.disabled = true;
		api('/bookings', { query: { scope: state.scope, q: state.q, apartment: state.apartment, page: state.page } }).then(function (d) {
			if (!append) clear(listBox);
			if (state.q && !append && d.items.length) listBox.appendChild(el('p', 'bm-list__info', 'Wyniki ze wszystkich rezerwacji: ' + d.total));
			if (!d.items.length && !append) {
				listBox.appendChild(el('p', 'bm-empty', state.q ? 'Nic nie znaleziono dla „' + state.q + '”.' : 'Brak rezerwacji w tej grupie.'));
			}
			d.items.forEach(function (b) { listBox.appendChild(listRow(b)); });
			moreBtn.hidden = d.page >= d.pages; moreBtn.disabled = false;
		}).catch(function (e) { clear(listBox); fail(e); });
	}

	function listRow(b) {
		var r = btn('bm-lrow', '', function () { location.hash = 'rezerwacja/' + b.id; });
		var when = el('div', 'bm-lrow__when');
		when.appendChild(el('strong', '', range(b.check_in, b.check_out)));
		when.appendChild(el('span', 'bm-muted', b.nights + ' ' + pl(b.nights, 'noc', 'noce', 'nocy')));
		var who = el('div', 'bm-lrow__who');
		who.appendChild(el('strong', '', b.label));
		who.appendChild(el('span', 'bm-muted', b.apartment.name + (b.status !== 'block' ? ' · ' + people(b) : '')));
		if (b.note) who.appendChild(el('span', 'bm-lrow__note', '✎ ' + b.note));
		var st = el('div', 'bm-lrow__st'); st.appendChild(bchip(b));
		var m = el('div', 'bm-lrow__money');
		if (b.total) m.appendChild(el('strong', '', money.format(b.total)));
		if (b.balance_due) m.appendChild(el('span', 'bm-muted', 'do dopłaty ' + money.format(b.balance_due)));
		r.appendChild(when); r.appendChild(who); r.appendChild(st); r.appendChild(m);
		return r;
	}

	/* ================= historia ================= */

	function viewLog() {
		clear(main);
		main.appendChild(el('h2', 'bm-ptitle', 'Historia zmian'));
		main.appendChild(el('p', 'bm-hint', 'Kto i kiedy zablokował termin, anulował rezerwację, zmienił notatkę albo logował się do panelu.'));
		var box = el('div', 'bm-log'); main.appendChild(box);
		var page = 1;
		var more = btn('bm-btn bm-btn--ghost bm-list__more', 'Pokaż starsze', function () { page++; load(); }); more.hidden = true; main.appendChild(more);
		loading(box);
		function load() {
			api('/log', { query: { page: page } }).then(function (d) {
				if (page === 1) clear(box);
				if (!d.items.length && page === 1) box.appendChild(el('p', 'bm-empty', 'Historia jest pusta.'));
				d.items.forEach(function (x) {
					var r = el('div', 'bm-logrow');
					r.appendChild(el('span', 'bm-logrow__when', x.when));
					var w = el('div', 'bm-logrow__what'); w.appendChild(el('strong', '', x.label));
					var det = x.details || {};
					var bits = [det.apartment || det.season, det.from && det.to ? range(det.from, det.to) : '', det.order ? 'zamówienie ' + det.order : '', det.reason ? 'powód: ' + det.reason : '', det.attempts ? det.attempts + ' prób' : ''].filter(Boolean);
					if (bits.length) w.appendChild(el('span', 'bm-muted', bits.join(' · ')));
					r.appendChild(w);
					var whoEl = el('span', 'bm-logrow__who', x.who);
					r.appendChild(whoEl);
					if (x.object && x.object.indexOf('booking') === 0) {
						var id = +x.object.split('#')[1];
						r.classList.add('is-link'); r.tabIndex = 0; r.setAttribute('role', 'button');
						r.onclick = function () { location.hash = 'rezerwacja/' + id; };
						r.onkeydown = function (e) { if (e.key === 'Enter') r.onclick(); };
					}
					box.appendChild(r);
				});
				more.hidden = d.items.length < 50;
			}).catch(fail);
		}
		load();
	}

	/* ================= konfiguracja (Właściciel) ================= */

	var META = null;
	function meta() { return META ? Promise.resolve(META) : api('/manage/meta').then(function (d) { META = d; return d; }); }
	function mapi(path, opts) { return api('/manage' + path, opts); }
	function setDirty(v) { dirty = v; if (saveBar) saveBar.classList.toggle('is-dirty', v); }
	var saveBar = null;

	// pola formularzy powiązane z obiektem stanu
	function inp(obj, key, type, attrs) {
		var i = el('input', 'bm-input'); i.type = type || 'text';
		var v = obj[key]; i.value = v === null || v === undefined ? '' : v;
		Object.keys(attrs || {}).forEach(function (k) { i.setAttribute(k, attrs[k]); });
		if (type === 'number') { i.inputMode = attrs && attrs.step && attrs.step !== '1' ? 'decimal' : 'numeric'; }
		i.oninput = function () { obj[key] = i.value; setDirty(true); };
		return i;
	}
	function moneyIn(obj, key, ph) { return inp(obj, key, 'number', { step: '0.01', min: '0', placeholder: ph == null ? '' : String(ph) }); }
	function num(obj, key, ph, min, max) { return inp(obj, key, 'number', { step: '1', min: String(min || 0), max: String(max || 999), placeholder: ph == null ? '' : String(ph) }); }
	function area(obj, key, rows, ph) {
		var t = el('textarea', 'bm-input bm-textarea'); t.rows = rows || 4; t.value = obj[key] || ''; if (ph) t.placeholder = ph;
		t.oninput = function () { obj[key] = t.value; setDirty(true); }; return t;
	}
	function toggle(obj, key, label, onChange) {
		var l = el('label', 'bm-toggle'), c = el('input', 'bm-check'); c.type = 'checkbox'; c.checked = !!obj[key];
		c.onchange = function () { obj[key] = c.checked; setDirty(true); if (onChange) onChange(c.checked); };
		l.appendChild(c); l.appendChild(el('span', '', label)); return l;
	}
	function select(obj, key, options, onChange) {
		var s = el('select', 'bm-select');
		options.forEach(function (o) { var op = el('option', '', o[1]); op.value = o[0]; if (String(obj[key]) === String(o[0])) op.selected = true; s.appendChild(op); });
		s.onchange = function () { obj[key] = s.value; setDirty(true); if (onChange) onChange(s.value); };
		return s;
	}
	function row() { var r = el('div', 'bm-form__row'); for (var i = 0; i < arguments.length; i++) if (arguments[i]) r.appendChild(arguments[i]); return r; }
	function card(title, help) { var c = el('section', 'bm-fcard'); if (title) c.appendChild(el('h3', 'bm-fcard__title', title)); if (help) c.appendChild(el('p', 'bm-hint bm-fcard__help', help)); return c; }
	function price(v) { return v === '' || v === null || v === undefined ? '—' : moneyFmt(v); }
	function moneyFmt(v) { return new Intl.NumberFormat('pl-PL', { style: 'currency', currency: CFG.currency || 'PLN' }).format(+v); }
	function locOptions(m, empty) {
		var o = [['', empty]];
		m.locations.forEach(function (l) { o.push([l.id, new Array(l.depth + 1).join('— ') + l.name + ' (' + l.type_label.toLowerCase() + ')']); });
		return o;
	}

	/* ---------- lista apartamentów ---------- */

	function viewApartments() {
		clear(main); setDirty(false);
		var head = el('div', 'bm-vhead');
		head.appendChild(el('h2', 'bm-ptitle', 'Apartamenty'));
		head.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Nowy apartament', newApartment));
		main.appendChild(head);
		var box = el('div', 'bm-agrid'); main.appendChild(box); loading(box);
		mapi('/apartments').then(function (list) {
			clear(box);
			if (!list.length) { box.appendChild(el('p', 'bm-empty', 'Nie masz jeszcze apartamentów. Dodaj pierwszy.')); return; }
			list.forEach(function (a) {
				var c = btn('bm-acard', '', function () { location.hash = 'apartament/' + a.id; });
				var img = el('div', 'bm-acard__img'); if (a.thumb) img.style.backgroundImage = 'url("' + a.thumb + '")'; else img.appendChild(el('span', '', 'brak zdjęcia'));
				c.appendChild(img);
				var b = el('div', 'bm-acard__body');
				var t = el('div', 'bm-acard__top'); t.appendChild(el('strong', '', a.name)); t.appendChild(chip(a.status === 'publish' ? 'confirmed' : 'block', a.status === 'publish' ? 'Opublikowany' : 'Szkic'));
				b.appendChild(t);
				if (a.where) b.appendChild(el('span', 'bm-muted', a.where));
				b.appendChild(el('span', '', [a.price, a.guests].filter(Boolean).join(' · ')));
				if (a.problems.length) b.appendChild(el('span', 'bm-acard__warn', 'Do uzupełnienia: ' + a.problems.join(', ')));
				c.appendChild(b); box.appendChild(c);
			});
		}).catch(function (e) { clear(box); fail(e); });
	}

	function newApartment() {
		var body = openDrawer('Nowy apartament');
		var f = { name: '', location: '' };
		meta().then(function (m) {
			var form = el('form', 'bm-form');
			var n = inp(f, 'name', 'text', { maxlength: '190', placeholder: 'np. Apartament Bursztynowy', required: 'required' });
			form.appendChild(field('Nazwa', n));
			form.appendChild(field('Lokalizacja', select(f, 'location', locOptions(m, 'wybierz później')), 'Obiekt / budynek / piętro — z niej biorą się udogodnienia, opcje i sezony.'));
			form.appendChild(el('p', 'bm-hint', 'Apartament powstanie jako szkic — goście go nie zobaczą, dopóki nie uzupełnisz ceny i miejsc i go nie opublikujesz.'));
			var go = btn('bm-btn bm-btn--primary bm-btn--block', 'Utwórz i uzupełnij'); go.type = 'submit'; form.appendChild(go);
			form.onsubmit = function (e) {
				e.preventDefault(); if (!f.name.trim()) { toast('Podaj nazwę.', true); return; }
				go.disabled = true; setDirty(false);
				mapi('/apartments', { method: 'POST', body: { name: f.name, location: f.location } }).then(function (a) {
					apartmentsCache = null; closeDrawer(); location.hash = 'apartament/' + a.id;
				}).catch(function (e2) { go.disabled = false; fail(e2); });
			};
			body.appendChild(form); n.focus();
		});
	}

	/* ---------- edycja apartamentu ---------- */

	var TABS = [['podstawowe', 'Podstawowe'], ['zdjecia', 'Zdjęcia'], ['cennik', 'Cennik'], ['pojemnosc', 'Pojemność'], ['opcje', 'Opcje dodatkowe'], ['sezony', 'Ceny sezonowe']];

	function editApartment(id) {
		clear(main); loading(main); setDirty(false);
		Promise.all([meta(), mapi('/apartments/' + id)]).then(function (r) { renderApartment(r[0], r[1], 'podstawowe'); }).catch(function (e) { clear(main); fail(e); });
	}

	function renderApartment(m, a, tab) {
		clear(main); setDirty(false);
		// stan formularza (kopia)
		var F = {
			name: a.name, short: a.short, description: a.description, location: a.location || '', layout: a.layout || '', gcal: a.gcal,
			config: JSON.parse(JSON.stringify(a.config)), images: a.images.map(function (i) { return i.id; }), imgs: a.images.slice(),
			extras: {}, season_rates: {}
		};
		a.extras.forEach(function (x) { F.extras[x.id] = { on: x.on, price: x.price_here, max: x.max_here }; });
		a.seasons.forEach(function (s) {
			var r = s.rates || {};
			F.season_rates[s.id] = { rate: r.rate == null ? '' : r.rate, adult_rate: r.adult_rate == null ? '' : r.adult_rate, child_prices: JSON.parse(JSON.stringify(r.child_prices || {})),
				eb_adult_price: r.eb_adult_price == null ? '' : r.eb_adult_price, eb_child_price: r.eb_child_price == null ? '' : r.eb_child_price, min_nights: r.min_nights == null ? '' : r.min_nights };
		});

		var head = el('div', 'bm-vhead');
		var back = el('a', 'bm-back', '← Apartamenty'); back.href = '#apartamenty'; head.appendChild(back);
		var title = el('h2', 'bm-ptitle', a.name); head.appendChild(title);
		head.appendChild(chip(a.status === 'publish' ? 'confirmed' : 'block', a.status === 'publish' ? 'Opublikowany' : 'Szkic'));
		var see = el('a', 'bm-link', a.status === 'publish' ? 'Zobacz stronę ↗' : 'Podgląd ↗'); see.href = a.url; see.target = '_blank'; head.appendChild(see);
		main.appendChild(head);
		if (a.problems.length) main.appendChild(el('div', 'bm-warn', 'Do uzupełnienia: ' + a.problems.join(', ') + '.'));

		var tabs = el('div', 'bm-seg bm-seg--tabs'); var pane = el('div', 'bm-apane');
		var paint = function (t) {
			tab = t;
			tabs.querySelectorAll('.bm-seg__btn').forEach(function (b) { b.classList.toggle('is-active', b.getAttribute('data-t') === t); });
			clear(pane);
			({ podstawowe: tabBasic, zdjecia: tabImages, cennik: tabPricing, pojemnosc: tabCapacity, opcje: tabExtras, sezony: tabSeasons })[t](pane, F, a, m);
		};
		TABS.forEach(function (t) { var b = btn('bm-seg__btn', t[1], function () { paint(t[0]); }); b.setAttribute('data-t', t[0]); tabs.appendChild(b); });
		main.appendChild(tabs); main.appendChild(pane);

		// pasek zapisu
		saveBar = el('div', 'bm-savebar');
		var info = el('span', 'bm-savebar__info', 'Zmiany zapiszą się po kliknięciu „Zapisz”.');
		var pub = btn('bm-btn bm-btn--ghost', a.status === 'publish' ? 'Ukryj (szkic)' : 'Opublikuj', function () { save(a.status === 'publish' ? 'draft' : 'publish'); });
		var sv = btn('bm-btn bm-btn--primary', 'Zapisz', function () { save(null); });
		saveBar.appendChild(info); saveBar.appendChild(pub); saveBar.appendChild(sv);
		main.appendChild(saveBar);

		function save(status) {
			var body = { name: F.name, short: F.short, description: F.description, location: F.location, layout: F.layout, gcal: F.gcal,
				config: F.config, images: F.images, extras: F.extras, season_rates: F.season_rates };
			if (status) body.status = status;
			sv.disabled = pub.disabled = true;
			mapi('/apartments/' + a.id, { method: 'POST', body: body }).then(function (na) {
				apartmentsCache = null; toast(status === 'publish' ? 'Opublikowano.' : status === 'draft' ? 'Apartament ukryty (szkic).' : 'Zapisano.');
				renderApartment(m, na, tab);
			}).catch(function (e) { sv.disabled = pub.disabled = false; fail(e); });
		}
		paint(tab);
	}

	function tabBasic(p, F, a, m) {
		var c = card('Opis');
		c.appendChild(field('Nazwa', inp(F, 'name', 'text', { maxlength: '190' })));
		c.appendChild(field('Krótki opis', area(F, 'short', 3, 'Jedno–dwa zdania na górze strony apartamentu.')));
		c.appendChild(field('Opis', area(F, 'description', 9), 'Akapity oddziel pustą linią. Możesz wkleić też HTML (np. listę <ul>).'));
		p.appendChild(c);
		var c2 = card('Położenie i wygląd');
		c2.appendChild(field('Lokalizacja', select(F, 'location', locOptions(m, 'nieprzypisany')), 'Zmiana obiektu zmienia dostępne opcje dodatkowe i sezony — zapisz, żeby je zobaczyć.'));
		var lo = [['', 'Domyślny (' + (m.layouts.filter(function (l) { return l.id === m.defaults.layout; })[0] || {}).name + ')']].concat(m.layouts.map(function (l) { return [l.id, l.name]; }));
		c2.appendChild(field('Układ strony', select(F, 'layout', lo)));
		p.appendChild(c2);
		var c3 = card('Kalendarz Google', m.google ? 'Rezerwacje tego apartamentu będą kopiowane do kalendarza (tylko w jedną stronę).' : 'Połączenie z Google nie jest skonfigurowane (kokpit → BookManager → Google). ID możesz wpisać już teraz.');
		c3.appendChild(field('ID kalendarza', inp(F, 'gcal', 'text', { placeholder: 'np. abc123@group.calendar.google.com' })));
		p.appendChild(c3);
	}

	function tabImages(p, F, a) {
		var c = card('Zdjęcia', 'Pierwsze zdjęcie jest główne. Przeciągnij, aby zmienić kolejność (na telefonie użyj strzałek). Nowe zdjęcia zapisują się od razu; kolejność i usunięcia — po „Zapisz”.');
		var grid = el('div', 'bm-imgs'); c.appendChild(grid);
		var byId = {}; F.imgs.forEach(function (i) { byId[i.id] = i; });
		var drag = null;
		function draw() {
			clear(grid);
			F.images.forEach(function (id, idx) {
				var it = el('div', 'bm-img' + (idx === 0 ? ' is-main' : '')); it.draggable = true;
				it.style.backgroundImage = 'url("' + (byId[id] ? byId[id].thumb : '') + '")';
				if (idx === 0) it.appendChild(el('span', 'bm-img__badge', 'Główne'));
				var tools = el('div', 'bm-img__tools');
				if (idx > 0) tools.appendChild(btn('bm-img__btn', '←', function () { move(idx, idx - 1); }, 'Wcześniej'));
				if (idx > 0) tools.appendChild(btn('bm-img__btn', '★', function () { move(idx, 0); }, 'Ustaw jako główne'));
				if (idx < F.images.length - 1) tools.appendChild(btn('bm-img__btn', '→', function () { move(idx, idx + 1); }, 'Później'));
				tools.appendChild(btn('bm-img__btn bm-img__btn--del', '×', function () { F.images.splice(idx, 1); setDirty(true); draw(); }, 'Usuń z galerii'));
				it.appendChild(tools);
				it.ondragstart = function () { drag = idx; it.classList.add('is-drag'); };
				it.ondragend = function () { it.classList.remove('is-drag'); };
				it.ondragover = function (e) { e.preventDefault(); };
				it.ondrop = function (e) { e.preventDefault(); if (drag !== null && drag !== idx) move(drag, idx); drag = null; };
				grid.appendChild(it);
			});
			var add = el('label', 'bm-img bm-img--add');
			add.appendChild(el('span', '', '+ Dodaj zdjęcia'));
			var fi = el('input'); fi.type = 'file'; fi.accept = 'image/jpeg,image/png,image/webp,image/avif'; fi.multiple = true; fi.hidden = true;
			fi.onchange = function () { upload(Array.prototype.slice.call(fi.files)); };
			add.appendChild(fi); grid.appendChild(add);
		}
		function move(from, to) { var x = F.images.splice(from, 1)[0]; F.images.splice(to, 0, x); setDirty(true); draw(); }
		function upload(files) {
			if (!files.length) return;
			var f = files.shift(), fd = new FormData(); fd.append('file', f);
			toast('Wysyłam: ' + f.name + '…');
			fetch(CFG.api + '/manage/apartments/' + a.id + '/images', { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': CFG.nonce }, body: fd })
				.then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.message || 'Nie udało się wysłać zdjęcia.'); return d; }); })
				.then(function (d) { d.images.forEach(function (i) { byId[i.id] = i; }); F.imgs = d.images; if (F.images.indexOf(d.id) === -1) F.images.push(d.id); draw(); upload(files); })
				.catch(function (e) { fail(e); upload(files); });
		}
		draw(); p.appendChild(c);
	}

	function tabPricing(p, F, a, m) {
		var C = F.config;
		var c = card('Cena noclegu');
		var flat = el('div'), pp = el('div');
		var sync = function () { flat.hidden = C.price_mode !== 'flat'; pp.hidden = C.price_mode === 'flat'; };
		c.appendChild(field('Sposób liczenia', select(C, 'price_mode', [['flat', 'Cena stała za noc'], ['per_person', 'Cena za osobę']], sync), 'Stała — ta sama cena bez względu na liczbę osób. Za osobę — dorośli i dzieci (wg wieku) liczeni osobno.'));
		flat.appendChild(field('Stawka za noc (zł)', moneyIn(C, 'rate')));
		pp.appendChild(field('Dorosły za noc (zł)', moneyIn(C, 'adult_rate')));
		var bands = el('div', 'bm-bands'); pp.appendChild(el('span', 'bm-field__label', 'Dzieci za noc — przedziały wieku')); pp.appendChild(bands);
		var drawBands = function () {
			clear(bands);
			C.child_bands.forEach(function (b, i) {
				var r = el('div', 'bm-bandrow');
				r.appendChild(field('od (lat)', num(b, 'from', '', 0, 17)));
				r.appendChild(field('do (lat)', num(b, 'to', '', 0, 17)));
				r.appendChild(field('cena (zł)', moneyIn(b, 'price')));
				r.appendChild(btn('bm-round bm-bandrow__del', '×', function () { C.child_bands.splice(i, 1); setDirty(true); drawBands(); }, 'Usuń przedział'));
				bands.appendChild(r);
			});
			bands.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', '+ przedział wieku', function () { C.child_bands.push({ from: '', to: '', price: '' }); setDirty(true); drawBands(); }));
			bands.appendChild(el('p', 'bm-hint', 'Dziecko starsze niż ostatni przedział płaci jak dorosły. Cena 0 = bezpłatnie. Zmiana przedziałów kasuje ich ceny sezonowe.'));
		};
		drawBands();
		pp.appendChild(field('Minimum płatnych osób', num(C, 'min_paying', 'bez minimum', 0, 50), 'Za noc liczymy co najmniej tyle osób dorosłych.'));
		c.appendChild(flat); c.appendChild(pp); sync();
		c.appendChild(field('Opłata serwisowa (zł)', moneyIn(C, 'service_fee'), 'Jednorazowo za pobyt.'));
		p.appendChild(c);

		var c2 = card('Długość pobytu');
		c2.appendChild(field('Minimalny pobyt (nocy)', num(C, 'min_nights', 'domyślnie ' + m.defaults.min_nights, 1, 60), 'Puste = wartość z ustawień. W sezonie może być inny (zakładka „Ceny sezonowe”).'));
		c2.appendChild(toggle(C, 'fill_gaps', 'Pozwól na krótszy pobyt, jeśli dokładnie wypełnia lukę między rezerwacjami'));
		p.appendChild(c2);

		var c3 = card('Opłata miejscowa', 'Informacja dla gościa — płatna na miejscu, nie wchodzi do zaliczki.');
		var city = el('div');
		c3.appendChild(toggle(C, 'city_tax', 'Pobierana', function (on) { city.hidden = !on; }));
		city.appendChild(row(field('Za osobę za noc (zł)', moneyIn(C, 'city_tax_amount')), field('Dzieci zwolnione do (lat)', num(C, 'city_tax_exempt_age', '', 0, 17))));
		city.hidden = !C.city_tax; c3.appendChild(city);
		p.appendChild(c3);
	}

	function tabCapacity(p, F) {
		var C = F.config;
		var c = card('Miejsca');
		c.appendChild(field('Stałe miejsca do spania', num(C, 'beds', '', 1, 50)));
		c.appendChild(row(
			field('Dzieci nie zajmują miejsca do (lat)', num(C, 'infant_age', 'każde zajmuje', 0, 17), 'Np. 3 — maluch śpi z rodzicami.'),
			field('Maks. dzieci bez miejsca', num(C, 'infant_max', '1', 0, 10), 'Kolejne zajmują normalne miejsce albo dostawkę.')
		));
		p.appendChild(c);
		var c2 = card('Dostawki', 'Dostawka zwiększa liczbę osób o jedną. Osoba śpiąca na dostawce płaci tylko za dostawkę.');
		[['eb_adult', 'Dostawka dla dorosłego'], ['eb_child', 'Dostawka dla dziecka']].forEach(function (t) {
			var box = el('div', 'bm-subbox');
			box.appendChild(toggle(C, t[0], t[1] + ' — dostępna', function (on) { opts.hidden = !on; }));
			var opts = row(field('Maks. liczba', num(C, t[0] + '_max', '1', 1, 10)), field('Cena za noc (zł)', moneyIn(C, t[0] + '_price')));
			opts.hidden = !C[t[0]]; box.appendChild(opts); c2.appendChild(box);
		});
		c2.appendChild(field('Maks. dostawek łącznie', num(C, 'eb_max_total', 'suma limitów', 0, 20), 'Np. 1 — gość wybierze dorosłą albo dziecięcą, nie obie.'));
		p.appendChild(c2);
	}

	function tabExtras(p, F, a) {
		var c = card('Opcje dodatkowe', 'Zaznacz opcje dostępne w tym apartamencie. Cena i limit „tutaj” — puste = z definicji opcji. Nieprzypisane opcje gość nie widzi.');
		if (!a.extras.length) { c.appendChild(el('p', 'bm-empty', 'Brak opcji dla obiektu tego apartamentu. Definicje opcji dodasz w kokpicie (BookManager → Opcje dodatkowe) — w panelu w kolejnym etapie.')); p.appendChild(c); return; }
		a.extras.forEach(function (x) {
			var st = F.extras[x.id], r = el('div', 'bm-xrow' + (x.active ? '' : ' is-off'));
			var main2 = el('div', 'bm-xrow__main');
			main2.appendChild(toggle(st, 'on', x.name + (x.active ? '' : ' (nieaktywna)')));
			main2.appendChild(el('span', 'bm-muted', x.price > 0 ? moneyFmt(x.price) + ' ' + x.charge : 'bezpłatna'));
			r.appendChild(main2);
			r.appendChild(row(field('Cena tutaj (zł)', moneyIn(st, 'price', x.price)), x.allow_qty ? field('Limit tutaj', num(st, 'max', x.max_qty, 1, 99)) : null));
			c.appendChild(r);
		});
		p.appendChild(c);
	}

	function tabSeasons(p, F, a, m) {
		var C = F.config;
		var c = card('Ceny sezonowe', 'Puste pole = cena bazowa. Sezon bez żadnej ceny nie zmienia ceny tego apartamentu (zasady pobytu sezonu nadal obowiązują). Sezony dodajesz w zakładce „Sezony”.');
		if (!a.seasons.length) { c.appendChild(el('p', 'bm-empty', 'Brak nadchodzących sezonów dla obiektu tego apartamentu.')); var l = el('a', 'bm-btn bm-btn--ghost bm-btn--sm', 'Przejdź do sezonów'); l.href = '#sezony'; c.appendChild(l); p.appendChild(c); return; }
		a.seasons.forEach(function (s) {
			var R = F.season_rates[s.id], box = el('div', 'bm-sbox');
			var h = el('div', 'bm-sbox__head'); var dot = el('i', 'bm-sdot'); if (s.color) dot.style.background = s.color; h.appendChild(dot);
			h.appendChild(el('strong', '', s.name)); h.appendChild(el('span', 'bm-muted', range(s.date_from, s.date_to) + (s.min_nights ? ' · min. ' + s.min_nights + ' nocy' : '') + (s.arrival_days.length ? ' · przyjazd: ' + s.arrival_days.map(function (d) { return DOW[d]; }).join(', ') : '')));
			box.appendChild(h);
			if (C.price_mode === 'flat') box.appendChild(row(field('Stawka za noc (zł)', moneyIn(R, 'rate', C.rate)), field('Min. pobyt (nocy)', num(R, 'min_nights', s.min_nights || effMin(C, m), 1, 60))));
			else {
				var r1 = row(field('Dorosły za noc (zł)', moneyIn(R, 'adult_rate', C.adult_rate)));
				C.child_bands.forEach(function (b) { var k = b.from + '-' + b.to; r1.appendChild(field('Dziecko ' + b.from + '–' + b.to + ' l.', moneyIn(R.child_prices, k, b.price))); });
				r1.appendChild(field('Min. pobyt (nocy)', num(R, 'min_nights', s.min_nights || effMin(C, m), 1, 60)));
				box.appendChild(r1);
			}
			var r2 = row(C.eb_adult ? field('Dostawka dorosła (zł)', moneyIn(R, 'eb_adult_price', C.eb_adult_price)) : null, C.eb_child ? field('Dostawka dziecięca (zł)', moneyIn(R, 'eb_child_price', C.eb_child_price)) : null);
			if (r2.childNodes.length) box.appendChild(r2);
			c.appendChild(box);
		});
		p.appendChild(c);
	}
	function effMin(C, m) { return C.min_nights || m.defaults.min_nights; }

	/* ---------- sezony ---------- */

	function viewSeasons() {
		clear(main); setDirty(false);
		var head = el('div', 'bm-vhead');
		head.appendChild(el('h2', 'bm-ptitle', 'Sezony'));
		head.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Nowy sezon', function () { location.hash = 'sezon/nowy'; }));
		main.appendChild(head);
		main.appendChild(el('p', 'bm-hint', 'Sezon to zakres nocy z innymi cenami i zasadami (minimalny pobyt, dni przyjazdu). Gdy sezony się nakładają, obowiązuje krótszy — np. Sylwester w Zimie. Nazwę sezonu widzi gość na rozbiciu ceny.'));
		var box = el('div', 'bm-list'); main.appendChild(box); loading(box);
		mapi('/seasons').then(function (list) {
			clear(box);
			if (!list.length) { box.appendChild(el('p', 'bm-empty', 'Brak sezonów. Wszystkie noce liczone są po cenach bazowych apartamentów.')); return; }
			list.sort(function (x, y) { return (x.past - y.past) || (x.date_from < y.date_from ? -1 : 1); });
			list.forEach(function (s) {
				var r = el('div', 'bm-srow' + (s.past ? ' is-past' : ''));
				var dot = el('i', 'bm-sdot'); if (s.color) dot.style.background = s.color; r.appendChild(dot);
				var t = el('div', 'bm-srow__main');
				t.appendChild(el('strong', '', s.name));
				var rules = [s.object, s.min_nights ? 'min. ' + s.min_nights + ' ' + pl(s.min_nights, 'noc', 'noce', 'nocy') : '', s.arrival_txt ? 'przyjazd: ' + s.arrival_txt : '', s.apartments + ' ' + pl(s.apartments, 'apartament', 'apartamenty', 'apartamentów') + ' z cenami'].filter(Boolean);
				t.appendChild(el('span', 'bm-muted', range(s.date_from, s.date_to) + ' · ' + rules.join(' · ')));
				r.appendChild(t);
				var acts = el('div', 'bm-srow__acts');
				acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Edytuj', function () { location.hash = 'sezon/' + s.id; }));
				acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Kopiuj na następny rok', function () {
					mapi('/seasons/' + s.id + '/copy', { method: 'POST' }).then(function (n) { toast('Skopiowano: ' + n.name + '. Sprawdź daty — święta ruchome trzeba poprawić.'); location.hash = 'sezon/' + n.id; }).catch(fail);
				}));
				acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm bm-txt-danger', 'Usuń', function () {
					if (!window.confirm('Usunąć sezon „' + s.name + '” razem z cenami? Istniejące rezerwacje zachowają swoje kwoty.')) return;
					mapi('/seasons/' + s.id, { method: 'DELETE' }).then(function () { toast('Sezon usunięty.'); viewSeasons(); }).catch(fail);
				}));
				r.appendChild(acts); box.appendChild(r);
			});
		}).catch(function (e) { clear(box); fail(e); });
	}

	function editSeason(id) {
		clear(main); loading(main); setDirty(false);
		Promise.all([meta(), id ? mapi('/seasons/' + id) : Promise.resolve(null)]).then(function (r) { renderSeason(r[0], r[1]); }).catch(function (e) { clear(main); fail(e); });
	}

	function renderSeason(m, s) {
		clear(main); setDirty(false);
		var S = s ? { name: s.name, object_id: s.object_id, date_from: s.date_from, date_to: s.date_to, min_nights: s.min_nights == null ? '' : s.min_nights, arrival_days: s.arrival_days.slice(), color: s.color || '#d97706' }
			: { name: '', object_id: m.objects.length === 1 ? m.objects[0].id : 0, date_from: '', date_to: '', min_nights: '', arrival_days: [], color: '#d97706' };
		var RATES = {};
		var head = el('div', 'bm-vhead');
		var back = el('a', 'bm-back', '← Sezony'); back.href = '#sezony'; head.appendChild(back);
		head.appendChild(el('h2', 'bm-ptitle', s ? s.name : 'Nowy sezon'));
		main.appendChild(head);

		var c = card('Sezon');
		c.appendChild(row(field('Nazwa (widzi ją gość)', inp(S, 'name', 'text', { maxlength: '100', placeholder: 'np. Wakacje, Sylwester, Majówka' })),
			field('Obiekt', select(S, 'object_id', [[0, 'Wszystkie obiekty']].concat(m.objects.map(function (o) { return [o.id, o.name]; }))))));
		c.appendChild(row(field('Pierwsza noc', inp(S, 'date_from', 'date')), field('Ostatnia noc', inp(S, 'date_to', 'date'), 'włącznie')));
		c.appendChild(row(field('Minimalny pobyt (nocy)', num(S, 'min_nights', 'bez zmian', 1, 60), 'Dla przyjazdów w tym sezonie.'), field('Kolor w kalendarzu', inp(S, 'color', 'color'))));
		var days = el('div', 'bm-days');
		[1, 2, 3, 4, 5, 6, 7].forEach(function (d) {
			var l = el('label', 'bm-day'), cb = el('input'); cb.type = 'checkbox'; cb.checked = S.arrival_days.indexOf(d) !== -1;
			cb.onchange = function () { S.arrival_days = S.arrival_days.filter(function (x) { return x !== d; }); if (cb.checked) S.arrival_days.push(d); setDirty(true); };
			l.appendChild(cb); l.appendChild(el('span', '', DOW[d])); days.appendChild(l);
		});
		c.appendChild(field('Dni przyjazdu', days, 'Nic nie zaznaczone = przyjazd w dowolny dzień. Np. tylko sobota dla turnusów sobota–sobota. Nie dotyczy wypełniania luk.'));
		main.appendChild(c);

		if (s) {
			var c2 = card('Ceny apartamentów w tym sezonie', 'Puste pole = cena bazowa (podana szarym). Apartament bez żadnej ceny liczy się w tym sezonie normalnie.');
			if (!s.apartments.length) c2.appendChild(el('p', 'bm-empty', 'Brak apartamentów w tym obiekcie.'));
			var tbl = el('div', 'bm-rtable');
			s.apartments.forEach(function (ap) {
				var r = ap.rates || {}, R = RATES[ap.id] = { rate: r.rate == null ? '' : r.rate, adult_rate: r.adult_rate == null ? '' : r.adult_rate, child_prices: JSON.parse(JSON.stringify(r.child_prices || {})),
					eb_adult_price: r.eb_adult_price == null ? '' : r.eb_adult_price, eb_child_price: r.eb_child_price == null ? '' : r.eb_child_price, min_nights: r.min_nights == null ? '' : r.min_nights };
				var line = el('div', 'bm-rrow');
				line.appendChild(el('strong', 'bm-rrow__name', ap.name));
				var f = el('div', 'bm-rrow__fields');
				if (ap.mode === 'flat') f.appendChild(field('Za noc (zł)', moneyIn(R, 'rate', ap.base.rate)));
				else {
					f.appendChild(field('Dorosły (zł)', moneyIn(R, 'adult_rate', ap.base.adult_rate)));
					ap.base.bands.forEach(function (b) { f.appendChild(field('Dziecko ' + b.label, moneyIn(R.child_prices, b.key, b.price))); });
				}
				if (ap.base.eb_adult !== null) f.appendChild(field('Dostawka dor. (zł)', moneyIn(R, 'eb_adult_price', ap.base.eb_adult)));
				if (ap.base.eb_child !== null) f.appendChild(field('Dostawka dz. (zł)', moneyIn(R, 'eb_child_price', ap.base.eb_child)));
				f.appendChild(field('Min. nocy', num(R, 'min_nights', S.min_nights || ap.base.min_nights, 1, 60)));
				line.appendChild(f); tbl.appendChild(line);
			});
			c2.appendChild(tbl); main.appendChild(c2);
		} else {
			main.appendChild(el('p', 'bm-hint', 'Po zapisaniu sezonu wpiszesz ceny wszystkich apartamentów obiektu w jednej tabeli.'));
		}

		saveBar = el('div', 'bm-savebar');
		saveBar.appendChild(el('span', 'bm-savebar__info', s ? 'Zmiany zapiszą się po kliknięciu „Zapisz”.' : ''));
		var sv = btn('bm-btn bm-btn--primary', s ? 'Zapisz' : 'Zapisz i wpisz ceny', function () {
			if (!S.name.trim() || !S.date_from || !S.date_to) { toast('Uzupełnij nazwę i daty sezonu.', true); return; }
			if (S.date_to < S.date_from) { toast('Ostatnia noc nie może być przed pierwszą.', true); return; }
			sv.disabled = true;
			var body = { name: S.name, object_id: +S.object_id, date_from: S.date_from, date_to: S.date_to, min_nights: S.min_nights, arrival_days: S.arrival_days, color: S.color };
			if (s) body.rates = RATES;
			mapi('/seasons' + (s ? '/' + s.id : ''), { method: 'POST', body: body }).then(function (ns) {
				setDirty(false); toast('Sezon zapisany.');
				if (!s) location.hash = 'sezon/' + ns.id; else renderSeason(m, ns);
			}).catch(function (e) { sv.disabled = false; fail(e); });
		});
		saveBar.appendChild(sv); main.appendChild(saveBar);
	}


	/* ================= ręczna rezerwacja ================= */

	var COUNTRIES = [['PL', 'Polska'], ['DE', 'Niemcy'], ['CZ', 'Czechy'], ['SK', 'Słowacja'], ['LT', 'Litwa'], ['UA', 'Ukraina'], ['GB', 'Wielka Brytania'], ['NL', 'Holandia'], ['NO', 'Norwegia'], ['SE', 'Szwecja'], ['DK', 'Dania'], ['FR', 'Francja'], ['IT', 'Włochy'], ['ES', 'Hiszpania'], ['AT', 'Austria'], ['US', 'USA']];

	function manualBooking() {
		clear(main); setDirty(false);
		var head = el('div', 'bm-vhead');
		var back = el('a', 'bm-back', '← Rezerwacje'); back.href = '#rezerwacje'; head.appendChild(back);
		head.appendChild(el('h2', 'bm-ptitle', 'Nowa rezerwacja'));
		main.appendChild(head);
		main.appendChild(el('p', 'bm-hint', 'Rezerwacja telefoniczna, mailowa albo osobista. Obowiązują te same zasady co na stronie (minimalny pobyt, sezony, pojemność). Gość dostanie powiadomienia zgodnie z ustawieniami.'));

		var steps = el('ol', 'bm-msteps'); main.appendChild(steps);
		var s1 = el('section', 'bm-fcard bm-mstep'), s2 = el('section', 'bm-fcard bm-mstep'), s3 = el('section', 'bm-fcard bm-mstep');
		[['1. Apartament, termin i goście', s1], ['2. Dane gościa', s2], ['3. Cena i płatność', s3]].forEach(function (x) { var li = el('li', '', x[0]); steps.appendChild(li); x[1].insertBefore(el('h3', 'bm-fcard__title', x[0]), x[1].firstChild); main.appendChild(x[1]); });
		var mark = function (n) { Array.prototype.forEach.call(steps.children, function (li, i) { li.classList.toggle('is-current', i === n); li.classList.toggle('is-done', i < n); }); };
		s2.hidden = s3.hidden = true; mark(0);

		var pick = null; // wybór z widżetu
		var G = { first_name: '', last_name: '', phone: '', email: '', address_1: '', postcode: '', city: '', country: 'PL', no_email: false, arrival_time: '', note: '', internal_note: '' };
		var P = { change: false, price: '', reason: '', mode: 'paid', amount: '', method: 'cash', due: addDays(new Date().toISOString().slice(0, 10), 3) };

		// krok 1: apartament + widżet
		var aptSel = el('select', 'bm-select'); var o0 = el('option', '', 'wybierz apartament'); o0.value = ''; aptSel.appendChild(o0);
		apartments().then(function (list) { list.forEach(function (a) { var o = el('option', '', a.name + (a.group ? ' · ' + a.group : '')); o.value = a.id; aptSel.appendChild(o); }); });
		s1.appendChild(field('Apartament', aptSel));
		var wbox = el('div', 'bm-mwidget'); s1.appendChild(wbox);
		var picked = el('div', 'bm-mpicked'); picked.hidden = true; s1.appendChild(picked);
		aptSel.onchange = function () {
			clear(wbox); pick = null; picked.hidden = true; s2.hidden = s3.hidden = true; mark(0);
			if (!aptSel.value) return;
			loading(wbox);
			api('/widget/' + aptSel.value).then(function (cfg) {
				clear(wbox);
				var w = el('div', 'bm-booking bm-booking--split'); w.setAttribute('data-bm-config', JSON.stringify(cfg));
				wbox.appendChild(w); window.BookManagerWidget(w);
			}).catch(function (e) { clear(wbox); fail(e); });
		};
		wbox.addEventListener('bm:pick', function (e) {
			pick = e.detail; setDirty(true);
			wbox.hidden = true; picked.hidden = false; clear(picked);
			var q = pick.quote;
			picked.appendChild(el('strong', '', aptSel.options[aptSel.selectedIndex].text));
			picked.appendChild(el('span', '', range(pick.check_in, pick.check_out) + ' · ' + q.nights + ' ' + pl(q.nights, 'noc', 'noce', 'nocy') + ' · ' + people({ adults: q.party.adults, children: q.party.children_ages.length }) + ' · ' + money.format(q.total)));
			picked.appendChild(btn('bm-link', 'Zmień', function () { wbox.hidden = false; picked.hidden = true; s2.hidden = s3.hidden = true; mark(0); }));
			s2.hidden = false; mark(1); renderPay();
			s2.scrollIntoView({ behavior: 'smooth', block: 'start' });
		});

		// krok 2: dane gościa
		s2.appendChild(row(field('Imię *', inp(G, 'first_name', 'text', { autocomplete: 'off' })), field('Nazwisko *', inp(G, 'last_name', 'text'))));
		var emailIn = inp(G, 'email', 'email', { placeholder: 'adres@przyklad.pl' });
		s2.appendChild(row(field('Telefon *', inp(G, 'phone', 'tel', { placeholder: '+48 …' })), field('E-mail *', emailIn)));
		var noMailWarn = el('div', 'bm-warn', 'Bez adresu e-mail gość nie dostanie żadnych powiadomień (potwierdzenia, przypomnień, informacji przed przyjazdem). Przekaż mu najważniejsze informacje telefonicznie.'); noMailWarn.hidden = true;
		s2.appendChild(toggle(G, 'no_email', 'Gość nie ma (lub nie chce podać) adresu e-mail', function (on) { emailIn.disabled = on; if (on) { emailIn.value = ''; G.email = ''; } noMailWarn.hidden = !on; renderPay(); }));
		s2.appendChild(noMailWarn);
		s2.appendChild(field('Ulica i numer *', inp(G, 'address_1', 'text')));
		s2.appendChild(row(field('Kod pocztowy *', inp(G, 'postcode', 'text')), field('Miejscowość *', inp(G, 'city', 'text')), field('Kraj *', select(G, 'country', COUNTRIES))));
		var hours = [['', 'nie podano']]; for (var h = 12; h <= 22; h++) hours.push([(h < 10 ? '0' : '') + h + ':00', h + ':00']); hours.push(['23:00', 'po 22:00']);
		s2.appendChild(field('Planowana godzina przyjazdu', select(G, 'arrival_time', hours)));
		s2.appendChild(field('Uwagi gościa (trafią do zamówienia)', area(G, 'note', 2)));
		s2.appendChild(field('Notatka obsługi (widzi tylko obsługa)', area(G, 'internal_note', 2)));
		s2.appendChild(btn('bm-btn bm-btn--primary', 'Dalej: cena i płatność', function () {
			var miss = [['first_name', 'imię'], ['last_name', 'nazwisko'], ['phone', 'telefon'], ['address_1', 'ulica'], ['postcode', 'kod'], ['city', 'miejscowość']].filter(function (x) { return !String(G[x[0]]).trim(); }).map(function (x) { return x[1]; });
			if (!G.no_email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(G.email)) miss.push('e-mail (albo zaznacz „brak e-maila”)');
			if (miss.length) { toast('Uzupełnij: ' + miss.join(', ') + '.', true); return; }
			s3.hidden = false; mark(2); renderPay(); s3.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}));

		// krok 3: cena i płatność
		var payBox = el('div', 'bm-form'); s3.appendChild(payBox);
		function renderPay() {
			clear(payBox);
			if (!pick) return;
			var q = pick.quote, calc = q.total;
			if (P.amount === '') P.amount = q.deposit_min;
			var ul = el('ul', 'bm-lines');
			q.lines.forEach(function (l) { var li = el('li'); li.appendChild(el('span', '', l.label)); li.appendChild(el('span', '', money.format(l.amount))); ul.appendChild(li); });
			var tot = el('li', 'is-total'); tot.appendChild(el('span', '', 'Cena wg cennika')); tot.appendChild(el('span', '', money.format(calc))); ul.appendChild(tot);
			payBox.appendChild(ul);
			var chg = el('div', 'bm-subbox'); chg.hidden = !P.change;
			payBox.appendChild(toggle(P, 'change', 'Zmień cenę (rabat lub korekta)', function (on) { chg.hidden = !on; if (!on) { P.price = ''; P.reason = ''; } }));
			chg.appendChild(row(field('Cena końcowa (zł)', moneyIn(P, 'price', calc)), field('Powód zmiany *', inp(P, 'reason', 'text', { maxlength: '200', placeholder: 'np. stały gość, dłuższy pobyt, reklamacja' }))));
			chg.appendChild(el('p', 'bm-hint', 'Powód zobaczy właściciel w historii zmian i w zamówieniu.'));
			payBox.appendChild(chg);

			var modes = el('div', 'bm-radios');
			[['paid', 'Zaliczka wpłacona'], ['awaiting', 'Czeka na wpłatę zaliczki'], ['none', 'Bez zaliczki (płatność na miejscu)']].forEach(function (m) {
				var l = el('label', 'bm-radio'), r = el('input'); r.type = 'radio'; r.name = 'bm-paymode'; r.checked = P.mode === m[0];
				r.onchange = function () { P.mode = m[0]; setDirty(true); renderPay(); };
				l.appendChild(r); l.appendChild(el('span', '', m[1])); modes.appendChild(l);
			});
			payBox.appendChild(field('Płatność', modes));
			if (P.mode === 'paid') payBox.appendChild(row(field('Kwota zaliczki (zł)', moneyIn(P, 'amount'), 'Minimum wg ustawień: ' + money.format(q.deposit_min)), field('Sposób', select(P, 'method', [['cash', 'Gotówka'], ['transfer', 'Przelew'], ['card', 'Karta'], ['blik', 'BLIK'], ['other', 'Inna']]))));
			if (P.mode === 'awaiting') {
				payBox.appendChild(row(field('Kwota zaliczki (zł)', moneyIn(P, 'amount')), field('Termin wpłaty', inp(P, 'due', 'date', { min: new Date().toISOString().slice(0, 10) }))));
				payBox.appendChild(el('p', 'bm-hint', 'Termin jest od razu zablokowany. Gość dostanie informację o rezerwacji wstępnej i przypomnienie. Po terminie rezerwacja zaświeci się na czerwono — nic nie anuluje się samo.'));
			}
			if (G.no_email) payBox.appendChild(el('div', 'bm-warn', 'Gość bez e-maila — powiadomienia do niego nie pójdą.'));
			var go = btn('bm-btn bm-btn--primary bm-btn--block', 'Zapisz rezerwację', function () {
				if (P.change && P.price !== '' && Math.abs(+P.price - calc) > 0.004 && !String(P.reason).trim()) { toast('Podaj powód zmiany ceny.', true); return; }
				go.disabled = true;
				var body = {
					apartment_id: pick.apartment_id, check_in: pick.check_in, check_out: pick.check_out, party: pick.party,
					guest: { first_name: G.first_name, last_name: G.last_name, phone: G.phone, email: G.email, address_1: G.address_1, postcode: G.postcode, city: G.city, country: G.country },
					no_email: G.no_email, arrival_time: G.arrival_time, note: G.note, internal_note: G.internal_note,
					price: P.change ? P.price : '', price_reason: P.change ? P.reason : '',
					payment: { mode: P.mode, amount: P.amount, method: P.method, due: P.due }
				};
				api('/manual', { method: 'POST', body: body }).then(function (b) {
					setDirty(false); apartmentsCache = apartmentsCache; toast('Rezerwacja zapisana.');
					history.replaceState(null, '', '#rezerwacje'); curHash = '#rezerwacje'; state.view = 'rezerwacje'; state.scope = 'all'; viewBookings();
					location.hash = 'rezerwacja/' + b.id;
				}).catch(function (e) { go.disabled = false; fail(e); });
			});
			payBox.appendChild(go);
		}
	}

	/* ================= powiadomienia (Właściciel) ================= */

	var NDATA = null;
	function ndata(force) { return NDATA && !force ? Promise.resolve(NDATA) : mapi('/notifications').then(function (d) { NDATA = d; return d; }); }
	var RCPT = { guest: 'gość', staff: 'obsługa', custom: 'inny adres' };

	function viewNotifications() {
		clear(main); setDirty(false); loading(main);
		ndata(true).then(function (d) {
			clear(main);
			var head = el('div', 'bm-vhead');
			head.appendChild(el('h2', 'bm-ptitle', 'Powiadomienia'));
			head.appendChild(btn('bm-btn bm-btn--primary bm-btn--sm', '+ Nowe powiadomienie', function () { location.hash = 'powiadomienie/nowe'; }));
			main.appendChild(head);
			main.appendChild(el('p', 'bm-hint', 'E-maile do gości i obsługi: po zdarzeniu (potwierdzenie, anulowanie…) albo w wybranym dniu względem terminu pobytu. Każde powiadomienie idzie do rezerwacji najwyżej raz — co i kiedy wysłano, widać w szczegółach rezerwacji.'));

			var S = { staff_email: d.settings.staff_email, replace: d.settings.replace_wc_emails };
			var sc = card('Ustawienia wysyłki');
			sc.appendChild(field('E-mail obsługi', inp(S, 'staff_email', 'email', { placeholder: d.settings.admin_email }), 'Tu trafiają powiadomienia „do obsługi”. Puste = ' + d.settings.admin_email + '.'));
			sc.appendChild(toggle(S, 'replace', 'Zastępuj e-maile WooCommerce dla rezerwacji apartamentów (gość i obsługa dostają tylko powiadomienia BookManagera)'));
			sc.appendChild(el('p', 'bm-hint', 'Wskazówka: żeby e-maile nie trafiały do spamu, zainstaluj wtyczkę SMTP (np. WP Mail SMTP) i podłącz skrzynkę w swojej domenie.'));
			sc.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Zapisz ustawienia', function () {
				mapi('/notifications/settings', { method: 'POST', body: { staff_email: S.staff_email, replace_wc_emails: S.replace } }).then(function () { setDirty(false); toast('Zapisano.'); }).catch(fail);
			}));
			main.appendChild(sc);

			var list = el('div', 'bm-list');
			d.items.forEach(function (n) {
				var r = el('div', 'bm-srow' + (n.active ? '' : ' is-past'));
				var sw = el('input', 'bm-check'); sw.type = 'checkbox'; sw.checked = n.active; sw.title = 'Włączone';
				sw.onchange = function () { mapi('/notifications/' + n.id, { method: 'POST', body: { active: sw.checked } }).then(function () { r.classList.toggle('is-past', !sw.checked); toast(sw.checked ? 'Włączono.' : 'Wyłączono.'); }).catch(fail); };
				r.appendChild(sw);
				var t = el('div', 'bm-srow__main'); t.appendChild(el('strong', '', n.name));
				t.appendChild(el('span', 'bm-muted', n.when + ' · do: ' + (n.recipient === 'custom' ? n.recipient_email : RCPT[n.recipient])));
				r.appendChild(t);
				var acts = el('div', 'bm-srow__acts');
				acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Edytuj', function () { location.hash = 'powiadomienie/' + n.id; }));
				r.appendChild(acts); list.appendChild(r);
			});
			main.appendChild(list);
		}).catch(function (e) { clear(main); fail(e); });
	}

	function editNotification(id) {
		clear(main); loading(main); setDirty(false);
		ndata(true).then(function (d) { Promise.all([meta(), Promise.resolve(d)]).then(function (r) { renderNotification(r[0], r[1], id); }); }).catch(function (e) { clear(main); fail(e); });
	}

	function renderNotification(m, d, id) {
		clear(main); setDirty(false);
		var src = d.items.filter(function (x) { return x.id === id; })[0];
		var N = src ? JSON.parse(JSON.stringify(src)) : { name: '', active: true, recipient: 'guest', recipient_email: '', trigger: 'confirmed', offset_days: 1, send_hour: 9, conditions: { objects: [], channel: 'any', only_balance: false }, subject: '', body: 'Dzień dobry {imie},\n\n\n\nPozdrawiamy,\n{nazwa_strony}' };
		var head = el('div', 'bm-vhead');
		var back = el('a', 'bm-back', '← Powiadomienia'); back.href = '#powiadomienia'; head.appendChild(back);
		head.appendChild(el('h2', 'bm-ptitle', src ? src.name : 'Nowe powiadomienie'));
		main.appendChild(head);
		var cols = el('div', 'bm-ncols'); var left = el('div', 'bm-ncol'), right = el('div', 'bm-ncol bm-ncol--preview');
		cols.appendChild(left); cols.appendChild(right); main.appendChild(cols);

		var c1 = card('Komu i kiedy');
		c1.appendChild(row(field('Nazwa (widzisz tylko Ty)', inp(N, 'name', 'text', { maxlength: '120' })), field('Komu', select(N, 'recipient', [['guest', 'Gość'], ['staff', 'Obsługa (e-mail obsługi)'], ['custom', 'Inny adres']], function () { cust.hidden = N.recipient !== 'custom'; }))));
		var cust = field('Adres e-mail', inp(N, 'recipient_email', 'email')); cust.hidden = N.recipient !== 'custom'; c1.appendChild(cust);
		var timeBox = el('div', 'bm-form__row');
		var isTime = function () { return (d.triggers.filter(function (t) { return t.id === N.trigger; })[0] || {}).kind === 'time'; };
		c1.appendChild(field('Kiedy', select(N, 'trigger', d.triggers.map(function (t) { return [t.id, t.name]; }), function () { timeBox.hidden = !isTime(); })));
		var hrs = []; for (var h = 0; h < 24; h++) hrs.push([h, (h < 10 ? '0' : '') + h + ':00']);
		timeBox.appendChild(field('Ile dni', num(N, 'offset_days', '', 0, 365)));
		timeBox.appendChild(field('Wysyłka od godziny', select(N, 'send_hour', hrs)));
		timeBox.hidden = !isTime(); c1.appendChild(timeBox);
		c1.appendChild(toggle(N, 'active', 'Włączone'));
		left.appendChild(c1);

		var c2 = card('Warunki (opcjonalnie)');
		var C = N.conditions;
		c2.appendChild(field('Skąd rezerwacja', select(C, 'channel', [['any', 'Wszystkie'], ['www', 'Tylko ze strony'], ['phone', 'Tylko wprowadzone przez obsługę']])));
		c2.appendChild(toggle(C, 'only_balance', 'Tylko gdy jest kwota do dopłaty'));
		if (m.objects.length > 1) {
			var ob = el('div', 'bm-days');
			m.objects.forEach(function (o) {
				var l = el('label', 'bm-day'), cb = el('input'); cb.type = 'checkbox'; cb.checked = C.objects.indexOf(o.id) !== -1;
				cb.onchange = function () { C.objects = C.objects.filter(function (x) { return x !== o.id; }); if (cb.checked) C.objects.push(o.id); setDirty(true); };
				l.appendChild(cb); l.appendChild(el('span', '', o.name)); ob.appendChild(l);
			});
			c2.appendChild(field('Tylko obiekty', ob, 'Nic nie zaznaczone = wszystkie.'));
		}
		left.appendChild(c2);

		var c3 = card('Treść');
		var subj = inp(N, 'subject', 'text', { maxlength: '255' });
		c3.appendChild(field('Temat', subj));
		var body = area(N, 'body', 16);
		var lastFocus = body;
		subj.onfocus = function () { lastFocus = subj; }; body.onfocus = function () { lastFocus = body; };
		var insert = function (txt) {
			var t = lastFocus, a = t.selectionStart || t.value.length, b2 = t.selectionEnd || a;
			t.value = t.value.slice(0, a) + txt + t.value.slice(b2); t.focus(); t.selectionStart = t.selectionEnd = a + txt.length;
			N[t === subj ? 'subject' : 'body'] = t.value; setDirty(true);
		};
		var chips = el('div', 'bm-chips');
		Object.keys(d.fields).forEach(function (k) { chips.appendChild(btn('bm-tag', '{' + k + '}', function () { insert('{' + k + '}'); }, d.fields[k])); });
		c3.appendChild(field('Pola (kliknij, aby wstawić)', chips));
		var bl = el('div', 'bm-chips');
		Object.keys(d.blocks).forEach(function (k) { bl.appendChild(btn('bm-tag bm-tag--block', '{' + k + '}', function () { insert('\n{' + k + '}\n'); }, d.blocks[k])); });
		bl.appendChild(btn('bm-tag bm-tag--block', 'przycisk', function () { insert('[[Tekst przycisku|https://]]'); }, 'Przycisk z linkiem'));
		bl.appendChild(btn('bm-tag bm-tag--block', 'link', function () { insert('[tekst linku](https://)'); }, 'Link w tekście'));
		c3.appendChild(field('Bloki i linki', bl));
		c3.appendChild(field('Treść', body, 'Pusta linia = nowy akapit. **tekst** = pogrubienie. [tekst](adres) = link. [[Tekst|adres]] = przycisk.'));
		left.appendChild(c3);

		// podgląd
		var pc = card('Podgląd');
		var bsel = el('select', 'bm-select'); d.bookings.forEach(function (b) { var o = el('option', '', b.label); o.value = b.id; bsel.appendChild(o); });
		pc.appendChild(field('Na przykładzie rezerwacji', bsel));
		var psub = el('p', 'bm-psubject'); pc.appendChild(psub);
		var frame = el('iframe', 'bm-pframe'); frame.title = 'Podgląd e-maila'; pc.appendChild(frame);
		var prev = function () {
			if (!d.bookings.length) { psub.textContent = 'Podgląd będzie dostępny po pierwszej potwierdzonej rezerwacji.'; return; }
			mapi('/notifications/preview', { method: 'POST', body: { subject: N.subject, body: N.body, booking_id: +bsel.value } }).then(function (r) { psub.textContent = 'Temat: ' + r.subject; frame.srcdoc = r.html; }).catch(fail);
		};
		var pt;
		[subj, body].forEach(function (x) { x.addEventListener('input', function () { clearTimeout(pt); pt = setTimeout(prev, 600); }); });
		bsel.onchange = prev;
		var acts = el('div', 'bm-form__row bm-form__row--inline');
		acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Odśwież podgląd', prev));
		acts.appendChild(btn('bm-btn bm-btn--ghost bm-btn--sm', 'Wyślij test do mnie (' + d.me + ')', function () {
			mapi('/notifications/test', { method: 'POST', body: { subject: N.subject, body: N.body, booking_id: +bsel.value } }).then(function (r) { toast('Wysłano test na ' + r.to + '.'); }).catch(fail);
		}));
		pc.appendChild(acts);
		right.appendChild(pc);
		prev();

		saveBar = el('div', 'bm-savebar');
		saveBar.appendChild(el('span', 'bm-savebar__info', ''));
		if (src) saveBar.appendChild(btn('bm-btn bm-btn--ghost bm-txt-danger', 'Usuń', function () {
			if (!window.confirm('Usunąć powiadomienie „' + src.name + '”? Lepiej je wyłączyć, jeśli możesz chcieć do niego wrócić.')) return;
			mapi('/notifications/' + src.id, { method: 'DELETE' }).then(function () { setDirty(false); toast('Usunięto.'); location.hash = 'powiadomienia'; }).catch(fail);
		}));
		var sv = btn('bm-btn bm-btn--primary', 'Zapisz', function () {
			sv.disabled = true;
			var bodyD = { name: N.name, active: N.active, recipient: N.recipient, recipient_email: N.recipient_email, trigger: N.trigger, offset_days: +N.offset_days || 0, send_hour: +N.send_hour, conditions: N.conditions, subject: N.subject, body: N.body };
			mapi('/notifications' + (src ? '/' + src.id : ''), { method: 'POST', body: bodyD }).then(function (n) {
				setDirty(false); toast('Zapisano.'); sv.disabled = false;
				if (!src) location.hash = 'powiadomienie/' + n.id;
			}).catch(function (e) { sv.disabled = false; fail(e); });
		});
		saveBar.appendChild(sv); main.appendChild(saveBar);
	}


	route();
})();
