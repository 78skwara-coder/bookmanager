<?php
/**
 * Plugin Name:       BookManager
 * Description:       Rezerwacje apartamentów dla WooCommerce.
 * Version:           0.6.0
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Requires Plugins:  woocommerce
 * Text Domain:       bookmanager
 */

defined( 'ABSPATH' ) || exit;

define( 'BM_VERSION', '0.6.0' );
define( 'BM_DB_VERSION', '6' );
define( 'BM_FILE', __FILE__ );
define( 'BM_PATH', plugin_dir_path( __FILE__ ) );

// Manifest aktualizacji (generuje go GitHub Actions). Można nadpisać w wp-config.php.
defined( 'BM_UPDATE_MANIFEST_URL' ) || define( 'BM_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/78skwara-coder/bookmanager/main/update.json' );

require_once BM_PATH . 'includes/class-bm-settings.php';
require_once BM_PATH . 'includes/class-bm-site.php';
require_once BM_PATH . 'includes/class-bm-installer.php';
require_once BM_PATH . 'includes/class-bm-locations.php';
require_once BM_PATH . 'includes/class-bm-availability.php';
require_once BM_PATH . 'includes/class-bm-apartment.php';
require_once BM_PATH . 'includes/class-bm-extras.php';
require_once BM_PATH . 'includes/class-bm-features.php';
require_once BM_PATH . 'includes/class-bm-seasons.php';
require_once BM_PATH . 'includes/class-bm-pricing.php';
require_once BM_PATH . 'includes/class-bm-product-type.php';
require_once BM_PATH . 'includes/class-bm-rest.php';
require_once BM_PATH . 'includes/class-bm-updater.php';
require_once BM_PATH . 'includes/class-bm-appearance.php';
require_once BM_PATH . 'includes/class-bm-frontend.php';
require_once BM_PATH . 'includes/class-bm-page.php';
require_once BM_PATH . 'includes/class-bm-roles.php';
require_once BM_PATH . 'includes/class-bm-log.php';
require_once BM_PATH . 'includes/class-bm-security.php';
require_once BM_PATH . 'includes/class-bm-panel.php';
require_once BM_PATH . 'includes/class-bm-panel-api.php';
require_once BM_PATH . 'includes/class-bm-panel-manage-api.php';
require_once BM_PATH . 'includes/class-bm-notify.php';
require_once BM_PATH . 'includes/class-bm-manual.php';
require_once BM_PATH . 'includes/class-bm-cart.php';
require_once BM_PATH . 'includes/class-bm-checkout-fields.php';
require_once BM_PATH . 'includes/class-bm-checkout.php';
require_once BM_PATH . 'includes/class-bm-listing.php';
require_once BM_PATH . 'includes/class-bm-contact.php';
require_once BM_PATH . 'includes/class-bm-google.php';

BM_Locations::init();
BM_REST::init();
BM_Updater::init();
BM_Frontend::init();
BM_Page::init();
BM_Appearance::init();
BM_Roles::init();
BM_Log::init();
BM_Security::init();
BM_Panel::init();
BM_Panel_API::init();
BM_Panel_Manage_API::init();
BM_Notify::init();
BM_Cart::init();
BM_Checkout_Fields::init();
BM_Checkout::init();
BM_Listing::init();
BM_Contact::init();
BM_Google::init();

if ( is_admin() ) {
	require_once BM_PATH . 'includes/class-bm-admin.php';
	require_once BM_PATH . 'includes/class-bm-bookings-table.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-locations.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-extras.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-features.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-calendar.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-google.php';
	require_once BM_PATH . 'includes/admin/class-bm-admin-appearance.php';
	BM_Admin::init();
}

// Typ produktu „Apartament” — dopiero gdy WooCommerce jest załadowany.
add_action( 'woocommerce_loaded', [ 'BM_Product_Type', 'init' ] );

register_activation_hook( BM_FILE, [ 'BM_Installer', 'install' ] );

register_deactivation_hook( BM_FILE, function () {
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( 'bm_purge_expired_holds' );
		as_unschedule_all_actions( 'bm_purge_id_numbers' );
	}
} );

// Sprzątanie wygasłych blokad co 5 minut (Action Scheduler z WooCommerce).
add_action( 'bm_purge_expired_holds', function () {
	BM_Availability::purge_expired();
} );
add_action( 'init', function () {
	if ( function_exists( 'as_has_scheduled_action' ) && ! as_has_scheduled_action( 'bm_purge_expired_holds' ) ) {
		as_schedule_recurring_action( time() + 300, 300, 'bm_purge_expired_holds', [], 'bookmanager' );
	}
} );

// Migracja schematu po aktualizacji pluginu (bez ponownej aktywacji).
add_action( 'plugins_loaded', [ 'BM_Installer', 'maybe_upgrade' ] );

// Deklaracja zgodności z HPOS (tabele zamówień WooCommerce).
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', BM_FILE, true );
	}
} );
