<?php
defined( 'ABSPATH' ) || exit;

/**
 * BookManager → Wygląd: układ strony apartamentu i styl widżetu, z podglądem na żywo.
 * Podgląd = prawdziwa strona apartamentu w ramce, z ustawieniami przekazanymi w adresie (tylko dla administratora).
 */
class BM_Admin_Appearance {

	const PAGE = 'bookmanager-appearance';

	public static function init(): void {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 20 );
		add_action( 'admin_init', [ __CLASS__, 'register' ] );
	}

	public static function menu(): void {
		add_submenu_page( BM_Admin::SLUG, __( 'Wygląd', 'bookmanager' ), __( 'Wygląd', 'bookmanager' ), BM_Admin::CAP, self::PAGE, [ __CLASS__, 'page' ], 7 );
	}

	public static function register(): void {
		register_setting( 'bm_appearance_group', BM_Appearance::OPTION, [
			'type'              => 'array',
			'sanitize_callback' => [ 'BM_Appearance', 'sanitize' ],
			'default'           => BM_Appearance::defaults(),
		] );
	}

	/** Miniatury układów (proste szkice SVG). */
	private static function thumb( string $layout ): string {
		$i = 'fill="#c3c4c7"'; // zdjęcie
		$t = 'fill="#dcdcde"'; // tekst
		$w = 'fill="#fff" stroke="#2271b1" stroke-width="1.5"'; // widżet
		$a = 'fill="#2271b1"';
		$svg = [
			'mosaic'  => "<rect x='8' y='8' width='60' height='6' $t/><rect x='8' y='18' width='64' height='34' rx='3' $i/><rect x='74' y='18' width='28' height='16' rx='2' $i/><rect x='104' y='18' width='28' height='16' rx='2' $i/><rect x='74' y='36' width='28' height='16' rx='2' $i/><rect x='104' y='36' width='28' height='16' rx='2' $i/><rect x='8' y='58' width='76' height='4' $t/><rect x='8' y='66' width='70' height='4' $t/><rect x='8' y='74' width='74' height='4' $t/><rect x='92' y='58' width='40' height='30' rx='3' $w/><rect x='97' y='80' width='30' height='4' rx='1' $a/>",
			'classic' => "<rect x='8' y='8' width='66' height='50' rx='3' $i/><rect x='8' y='61' width='15' height='10' $i/><rect x='25' y='61' width='15' height='10' $i/><rect x='42' y='61' width='15' height='10' $i/><rect x='59' y='61' width='15' height='10' $i/><rect x='80' y='8' width='40' height='6' $t/><rect x='80' y='18' width='52' height='60' rx='3' $w/><rect x='86' y='68' width='40' height='5' rx='1' $a/><rect x='8' y='80' width='66' height='4' $t/>",
			'hero'    => "<rect x='0' y='0' width='140' height='46' $i/><rect x='10' y='30' width='50' height='7' fill='#fff'/><rect x='14' y='42' width='112' height='12' rx='3' $w/><rect x='104' y='45' width='18' height='6' rx='1' $a/><rect x='10' y='62' width='54' height='4' $t/><rect x='10' y='70' width='50' height='4' $t/><rect x='76' y='60' width='54' height='28' rx='3' $i/>",
			'wizard'  => "<rect x='25' y='6' width='90' height='36' rx='3' $i/><circle cx='45' cy='50' r='4' $a/><circle cx='62' cy='50' r='4' $t/><circle cx='79' cy='50' r='4' $t/><circle cx='96' cy='50' r='4' $t/><rect x='25' y='58' width='90' height='30' rx='3' $w/><rect x='92' y='80' width='18' height='5' rx='1' $a/>",
		];
		return '<svg viewBox="0 0 140 92" width="140" height="92" aria-hidden="true" style="display:block;background:#f6f7f7;border-radius:4px">' . $svg[ $layout ] . '</svg>';
	}

	public static function page(): void {
		$a    = BM_Appearance::all();
		$apts = wc_get_products( [ 'type' => 'bm_apartment', 'status' => 'publish', 'limit' => 50, 'orderby' => 'title', 'order' => 'ASC' ] );
		$name = BM_Appearance::OPTION;
		?>
		<div class="wrap bm-look">
			<h1><?php esc_html_e( 'Wygląd strony apartamentu', 'bookmanager' ); ?></h1>
			<?php settings_errors(); ?>
			<div class="bm-look__cols">
				<form method="post" action="options.php" class="bm-look__form" id="bm-look-form">
					<?php settings_fields( 'bm_appearance_group' ); ?>

					<h2><?php esc_html_e( 'Układ', 'bookmanager' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Domyślny dla wszystkich apartamentów. Na karcie apartamentu (ramka „Wygląd strony apartamentu”) można wybrać inny.', 'bookmanager' ); ?></p>
					<div class="bm-look__layouts">
						<?php foreach ( BM_Appearance::layouts() as $k => [ $label, $desc ] ) : ?>
							<label class="bm-look__layout">
								<input type="radio" name="<?php echo esc_attr( $name ); ?>[layout]" value="<?php echo esc_attr( $k ); ?>" <?php checked( $a['layout'], $k ); ?>>
								<span class="bm-look__card"><?php echo self::thumb( $k ); // phpcs:ignore -- stały SVG ?>
									<strong><?php echo esc_html( $label ); ?></strong><span><?php echo esc_html( $desc ); ?></span></span>
							</label>
						<?php endforeach; ?>
					</div>

					<h2><?php esc_html_e( 'Styl', 'bookmanager' ); ?></h2>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Kolor akcentu', 'bookmanager' ); ?></th>
							<td>
								<label><input type="checkbox" id="bm-accent-theme" <?php checked( '' === $a['accent'] ); ?>> <?php esc_html_e( 'z motywu', 'bookmanager' ); ?></label>
								<input type="color" id="bm-accent-pick" value="<?php echo esc_attr( $a['accent'] ?: '#1f1f1f' ); ?>" style="vertical-align:middle;margin-left:12px">
								<input type="hidden" name="<?php echo esc_attr( $name ); ?>[accent]" id="bm-accent" value="<?php echo esc_attr( $a['accent'] ); ?>">
								<p class="description"><?php esc_html_e( 'Przycisk „Rezerwuj”, wybrane dni w kalendarzu, zaznaczenia. Kolor tekstu na przycisku dobiera się sam.', 'bookmanager' ); ?></p>
							</td>
						</tr>
						<?php
						self::radios( __( 'Kształt', 'bookmanager' ), 'shape', $a['shape'], [ 'square' => __( 'kwadratowe rogi', 'bookmanager' ), 'rounded' => __( 'zaokrąglone', 'bookmanager' ), 'pill' => __( 'mocno zaokrąglone (pigułki)', 'bookmanager' ) ] );
						self::radios( __( 'Przyciski −/+ przy gościach', 'bookmanager' ), 'stepper', $a['stepper'], [ 'round' => __( 'okrągłe', 'bookmanager' ), 'square' => __( 'kwadratowe', 'bookmanager' ) ] );
						self::radios( __( 'Kalendarz', 'bookmanager' ), 'months', (string) $a['months'], [ '1' => __( '1 miesiąc', 'bookmanager' ), '2' => __( '2 miesiące, gdy jest miejsce', 'bookmanager' ) ],
							__( 'Dwa miesiące mieszczą się w układach Hero i Kreator; w wąskiej kolumnie i na telefonie zawsze jeden.', 'bookmanager' ) );
						self::radios( __( 'Gęstość', 'bookmanager' ), 'density', $a['density'], [ 'comfortable' => __( 'przestronna', 'bookmanager' ), 'compact' => __( 'zwarta', 'bookmanager' ) ] );
						?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Telefon', 'bookmanager' ); ?></th>
							<td><label><input type="hidden" name="<?php echo esc_attr( $name ); ?>[bar]" value="no"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[bar]" value="yes" <?php checked( 'yes', $a['bar'] ); ?>>
								<?php esc_html_e( 'Pasek na dole ekranu z ceną i przyciskiem „Sprawdź termin”', 'bookmanager' ); ?></label></td>
						</tr>
					</table>
					<?php submit_button(); ?>
				</form>

				<div class="bm-look__preview">
					<?php if ( $apts ) : ?>
						<div class="bm-look__bar">
							<select id="bm-look-apt">
								<?php foreach ( $apts as $p ) : ?>
									<option value="<?php echo esc_url( get_permalink( $p->get_id() ) ); ?>"><?php echo esc_html( $p->get_name() ); ?></option>
								<?php endforeach; ?>
							</select>
							<span class="bm-look__devices">
								<button type="button" class="button is-active" data-w="1280"><?php esc_html_e( 'Komputer', 'bookmanager' ); ?></button>
								<button type="button" class="button" data-w="390"><?php esc_html_e( 'Telefon', 'bookmanager' ); ?></button>
							</span>
							<a class="button-link" id="bm-look-open" href="#" target="_blank"><?php esc_html_e( 'Otwórz w nowej karcie', 'bookmanager' ); ?></a>
						</div>
						<div class="bm-look__frame"><iframe id="bm-look-iframe" title="<?php esc_attr_e( 'Podgląd strony apartamentu', 'bookmanager' ); ?>"></iframe></div>
						<p class="description"><?php esc_html_e( 'Podgląd pokazuje niezapisane zmiany. Goście zobaczą je po kliknięciu „Zapisz zmiany”.', 'bookmanager' ); ?></p>
					<?php else : ?>
						<p><?php esc_html_e( 'Dodaj i opublikuj apartament, aby zobaczyć podgląd.', 'bookmanager' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<style>
			.bm-look__cols{display:grid;grid-template-columns:minmax(380px,520px) minmax(0,1fr);gap:28px;align-items:start}
			.bm-look__layouts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:12px 0 8px}
			.bm-look__layout input{position:absolute;opacity:0}
			.bm-look__card{display:flex;flex-direction:column;gap:6px;padding:12px;border:1px solid #dcdcde;border-radius:6px;background:#fff;cursor:pointer;height:100%;box-sizing:border-box}
			.bm-look__card span{color:#646970;font-size:12px;line-height:1.45}
			.bm-look__layout input:checked + .bm-look__card{border-color:#2271b1;box-shadow:0 0 0 1px #2271b1}
			.bm-look__layout input:focus-visible + .bm-look__card{outline:2px solid #2271b1;outline-offset:2px}
			.bm-look__preview{position:sticky;top:46px}
			.bm-look__bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:20px 0 10px}
			.bm-look__devices .button.is-active{background:#f0f6fc;border-color:#2271b1;color:#2271b1}
			.bm-look__frame{background:#e9e9ea;border:1px solid #dcdcde;border-radius:6px;padding:0;height:calc(100vh - 190px);min-height:520px;overflow:hidden;position:relative}
			.bm-look__frame iframe{position:absolute;top:0;left:50%;border:0;background:#fff;transform-origin:top center}
			.bm-look .form-table th{width:170px}
			@media (max-width:1100px){.bm-look__cols{grid-template-columns:1fr}.bm-look__preview{position:static}}
		</style>
		<script>
		(function () {
			var form = document.getElementById('bm-look-form'), frame = document.getElementById('bm-look-iframe');
			var accent = document.getElementById('bm-accent'), pick = document.getElementById('bm-accent-pick'), theme = document.getElementById('bm-accent-theme');
			var syncAccent = function () { accent.value = theme.checked ? '' : pick.value; pick.disabled = theme.checked; };
			theme.onchange = function () { syncAccent(); refresh(); };
			pick.oninput = function () { theme.checked = false; syncAccent(); };
			pick.onchange = refresh;
			syncAccent();
			if (!frame) return;
			var apt = document.getElementById('bm-look-apt'), open = document.getElementById('bm-look-open');
			function url() {
				var data = new FormData(form), q = ['bm_preview=1'];
				['layout', 'accent', 'shape', 'stepper', 'months', 'density', 'bar'].forEach(function (k) {
					var all = data.getAll('<?php echo esc_js( $name ); ?>[' + k + ']'), v = all.length ? all[all.length - 1] : '';
					q.push('bm_' + k + '=' + encodeURIComponent(v));
				});
				var base = apt.value;
				return base + (base.indexOf('?') === -1 ? '?' : '&') + q.join('&');
			}
			function refresh() { var u = url(); frame.src = u; open.href = u; }
			form.addEventListener('change', refresh);
			apt.addEventListener('change', refresh);
			// Podgląd w prawdziwej szerokości (komputer 1280 px, telefon 390 px), pomniejszony do ramki.
			var box = frame.parentNode, width = 1280;
			function fit() {
				var s = Math.min(1, box.clientWidth / width);
				frame.style.width = width + 'px';
				frame.style.height = (box.clientHeight / s) + 'px';
				frame.style.transform = 'translateX(-50%) scale(' + s + ')';
			}
			document.querySelectorAll('.bm-look__devices .button').forEach(function (b) {
				b.onclick = function () {
					document.querySelectorAll('.bm-look__devices .button').forEach(function (x) { x.classList.remove('is-active'); });
					b.classList.add('is-active'); width = +b.getAttribute('data-w'); fit();
				};
			});
			window.addEventListener('resize', fit);
			fit(); refresh();
		})();
		</script>
		<?php
	}

	private static function radios( string $label, string $key, string $current, array $options, string $help = '' ): void {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td><fieldset style="display:flex;flex-wrap:wrap;gap:6px 22px">';
		foreach ( $options as $v => $text ) {
			printf(
				'<label><input type="radio" name="%s[%s]" value="%s" %s> %s</label>',
				esc_attr( BM_Appearance::OPTION ), esc_attr( $key ), esc_attr( $v ), checked( $current, (string) $v, false ), esc_html( $text )
			);
		}
		echo '</fieldset>' . ( $help ? '<p class="description">' . esc_html( $help ) . '</p>' : '' ) . '</td></tr>';
	}
}
