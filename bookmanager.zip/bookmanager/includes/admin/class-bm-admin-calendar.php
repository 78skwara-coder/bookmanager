<?php
defined( 'ABSPATH' ) || exit;

/**
 * Kalendarz w kokpicie: oś czasu miesiąca.
 * Wiersze = apartamenty pogrupowane wg drzewa lokalizacji, kolumny = noce.
 * Klik w rezerwację → szczegóły; zaznaczenie wolnych nocy (dwa kliknięcia) → ręczna blokada z notatką.
 */
class BM_Admin_Calendar {

	const PAGE = 'bookmanager-calendar';

	public static function init(): void {
		add_action( 'admin_post_bm_block_create', [ __CLASS__, 'handle_create' ] );
		add_action( 'admin_post_bm_block_delete', [ __CLASS__, 'handle_delete' ] );
	}

	private static function month(): DateTimeImmutable {
		$tz = wp_timezone();
		$m  = sanitize_text_field( $_GET['month'] ?? '' ); // phpcs:ignore
		$d  = preg_match( '/^\d{4}-\d{2}$/', $m ) ? DateTimeImmutable::createFromFormat( '!Y-m-d', $m . '-01', $tz ) : null;
		return $d ?: new DateTimeImmutable( 'first day of this month midnight', $tz );
	}

	/** Grupy wierszy: [{title, depth, apartments: [WC_Product]}] wg drzewa lokalizacji. */
	private static function groups(): array {
		$all      = BM_Admin::apartments();
		$by_term  = [];
		$unsorted = [];
		foreach ( $all as $apt ) {
			$t = BM_Locations::of_apartment( $apt->get_id() );
			if ( $t ) {
				$by_term[ $t ][] = $apt;
			} else {
				$unsorted[] = $apt;
			}
		}
		$groups = [];
		$ids    = array_map( fn( $a ) => $a->get_id(), $all );
		$walk   = function ( int $parent, int $depth ) use ( &$walk, &$groups, $by_term, $ids ) {
			foreach ( get_terms( [ 'taxonomy' => BM_Locations::TAX, 'parent' => $parent, 'hide_empty' => false, 'orderby' => 'name' ] ) as $t ) {
				if ( ! array_intersect( BM_Locations::apartments_in( $t->term_id ), $ids ) ) {
					continue; // gałąź bez apartamentów
				}
				$groups[] = [ 'title' => $t->name, 'type' => BM_Locations::type_of( $t->term_id ), 'depth' => $depth, 'apartments' => $by_term[ $t->term_id ] ?? [] ];
				$walk( $t->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		if ( $unsorted ) {
			$groups[] = [ 'title' => __( 'Bez lokalizacji', 'bookmanager' ), 'type' => '', 'depth' => 0, 'apartments' => $unsorted ];
		}
		return $groups;
	}

	public static function page(): void {
		global $wpdb;
		$m0    = self::month();
		$m1    = $m0->modify( 'first day of next month' );
		$days  = (int) $m0->format( 't' );
		$today = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );
		$now   = gmdate( 'Y-m-d H:i:s' );

		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . BM_Installer::table( 'bookings' ) . "
			 WHERE check_in < %s AND check_out > %s
			   AND ( status IN ('confirmed','block','conflict') OR ( status = 'hold' AND hold_expires >= %s ) )
			 ORDER BY check_in",
			$m1->format( 'Y-m-d' ), $m0->format( 'Y-m-d' ), $now
		) );
		$by_apt = [];
		foreach ( $rows as $r ) {
			$by_apt[ (int) $r->apartment_id ][] = $r;
		}

		$url = fn( DateTimeImmutable $d ) => admin_url( 'admin.php?page=' . self::PAGE . '&month=' . $d->format( 'Y-m' ) );
		echo '<div class="wrap bm-calendar-wrap"><h1 class="wp-heading-inline">' . esc_html__( 'Kalendarz', 'bookmanager' ) . '</h1>';
		self::notice();
		printf(
			'<div class="bm-cal-nav"><a class="button" href="%s">‹</a> <strong>%s</strong> <a class="button" href="%s">›</a> <a class="button" href="%s">%s</a>'
			. '<span class="bm-legend"><i class="bm-st-confirmed"></i>potwierdzona <i class="bm-st-hold"></i>w trakcie płatności <i class="bm-st-block"></i>blokada <i class="bm-st-conflict"></i>konflikt</span></div>',
			esc_url( $url( $m0->modify( '-1 month' ) ) ), esc_html( wp_date( 'F Y', $m0->getTimestamp() ) ), esc_url( $url( $m1 ) ),
			esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ), esc_html__( 'Dziś', 'bookmanager' )
		);
		echo '<p class="description">' . esc_html__( 'Kliknij rezerwację, aby zobaczyć szczegóły. Aby zablokować termin, kliknij pierwszą i ostatnią wolną noc w wierszu apartamentu.', 'bookmanager' ) . '</p>';

		$groups = self::groups();
		if ( ! $groups ) {
			echo '<p>' . esc_html__( 'Brak apartamentów.', 'bookmanager' ) . '</p></div>';
			return;
		}

		echo '<div class="bm-tl-scroll"><table class="bm-tl"><thead><tr><th class="bm-tl-name"></th>';
		for ( $i = 1; $i <= $days; $i++ ) {
			$d   = $m0->setDate( (int) $m0->format( 'Y' ), (int) $m0->format( 'm' ), $i );
			$dow = (int) $d->format( 'N' );
			printf( '<th class="%s"><span>%s</span>%d</th>', esc_attr( trim( ( $dow >= 6 ? 'is-we ' : '' ) . ( $d->format( 'Y-m-d' ) === $today ? 'is-today' : '' ) ) ),
				esc_html( [ 1 => 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd' ][ $dow ] ), $i );
		}
		echo '</tr></thead><tbody>';

		$types = BM_Locations::types();
		foreach ( $groups as $g ) {
			printf( '<tr class="bm-tl-group bm-tl-group--%s"><th colspan="%d" style="padding-left:%dpx">%s <small>%s</small></th></tr>',
				esc_attr( $g['type'] ), $days + 1, 8 + $g['depth'] * 16, esc_html( $g['title'] ), esc_html( $types[ $g['type'] ] ?? '' ) );
			foreach ( $g['apartments'] as $apt ) {
				self::apartment_row( $apt, $by_apt[ $apt->get_id() ] ?? [], $m0, $days, $today, $g['depth'] );
			}
		}
		echo '</tbody></table></div>';
		self::panel();
		self::assets();
		echo '</div>';
	}

	private static function apartment_row( WC_Product $apt, array $bookings, DateTimeImmutable $m0, int $days, string $today, int $depth ): void {
		$ym = $m0->format( 'Y-m-' );
		printf( '<tr class="bm-tl-row" data-apt="%d" data-name="%s"><th class="bm-tl-name" style="padding-left:%dpx"><a href="%s">%s</a></th>',
			$apt->get_id(), esc_attr( $apt->get_name() ), 20 + $depth * 16, esc_url( get_edit_post_link( $apt->get_id() ) ), esc_html( $apt->get_name() ) );

		// Mapa: dzień miesiąca → rezerwacja zaczynająca się (w obrębie miesiąca) tego dnia.
		$starts = [];
		foreach ( $bookings as $b ) {
			$first = max( $b->check_in, $m0->format( 'Y-m-d' ) );
			$last  = min( gmdate( 'Y-m-d', strtotime( $b->check_out . ' -1 day' ) ), $ym . sprintf( '%02d', $days ) );
			$starts[ (int) substr( $first, 8, 2 ) ] = [ $b, (int) substr( $last, 8, 2 ) - (int) substr( $first, 8, 2 ) + 1 ];
		}

		for ( $i = 1; $i <= $days; $i++ ) {
			$date = $ym . sprintf( '%02d', $i );
			if ( isset( $starts[ $i ] ) ) {
				[ $b, $span ] = $starts[ $i ];
				$info = self::booking_info( $b );
				printf( '<td colspan="%d" class="bm-tl-bar bm-st-%s" data-info="%s" title="%s"><span>%s</span></td>',
					$span, esc_attr( $b->status ), esc_attr( wp_json_encode( $info ) ), esc_attr( $info['title'] ), esc_html( $info['label'] ) );
				$i += $span - 1;
				continue;
			}
			$cls = [ 'bm-tl-free' ];
			if ( $date < $today ) {
				$cls[] = 'is-past';
			}
			if ( (int) gmdate( 'N', strtotime( $date ) ) >= 6 ) {
				$cls[] = 'is-we';
			}
			if ( $date === $today ) {
				$cls[] = 'is-today';
			}
			printf( '<td class="%s" data-date="%s"></td>', esc_attr( implode( ' ', $cls ) ), esc_attr( $date ) );
		}
		echo '</tr>';
	}

	/** Dane rezerwacji do panelu szczegółów (tylko dla obsługi). */
	private static function booking_info( $b ): array {
		$o     = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		$guest = $o ? trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) : '';
		$n     = (int) ( ( strtotime( $b->check_out ) - strtotime( $b->check_in ) ) / DAY_IN_SECONDS );
		$label = 'block' === $b->status ? ( $b->note ?: 'Blokada' ) : ( $guest ?: 'Rezerwacja #' . $b->id );
		$st    = BM_Bookings_Table::statuses()[ $b->status ] ?? $b->status;
		$df    = get_option( 'date_format' );
		return [
			'id'      => (int) $b->id,
			'status'  => $b->status,
			'label'   => $label,
			'title'   => sprintf( '%s · %s – %s · %s', $label, $b->check_in, $b->check_out, $st ),
			'rows'    => array_filter( [
				'Status'      => $st,
				'Termin'      => wp_date( $df, strtotime( $b->check_in . ' 12:00' ) ) . ' – ' . wp_date( $df, strtotime( $b->check_out . ' 12:00' ) ) . " ($n " . BM_Pricing::pl( $n, 'noc', 'noce', 'nocy' ) . ')',
				'Gość'        => $guest,
				'Telefon'     => $o ? $o->get_billing_phone() : '',
				'E-mail'      => $o ? $o->get_billing_email() : '',
				'Osoby'       => 'block' === $b->status ? '' : $b->adults . ' dor.' . ( $b->children ? ', ' . $b->children . ' dz. (' . $b->children_ages . ' l.)' : '' ),
				'Przyjazd ok.' => $b->arrival_time ? substr( $b->arrival_time, 0, 5 ) : '',
				'Cena'        => (float) $b->total ? html_entity_decode( wp_strip_all_tags( wc_price( $b->total ) ) ) : '',
				'Do dopłaty'  => 'confirmed' === $b->status && (float) $b->balance_due ? html_entity_decode( wp_strip_all_tags( wc_price( $b->balance_due ) ) ) . ( $b->balance_due_date ? ' (do ' . $b->balance_due_date . ')' : '' ) : '',
				'Notatka'     => (string) $b->note,
			] ),
			'order'   => $o ? $o->get_edit_order_url() : '',
			'delete'  => 'block' === $b->status ? wp_nonce_url( admin_url( 'admin-post.php?action=bm_block_delete&id=' . $b->id ), 'bm_block_delete_' . $b->id ) : '',
		];
	}

	private static function notice(): void {
		$msg = sanitize_text_field( wp_unslash( $_GET['bm_msg'] ?? '' ) ); // phpcs:ignore
		$err = sanitize_text_field( wp_unslash( $_GET['bm_err'] ?? '' ) ); // phpcs:ignore
		if ( 'created' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Termin zablokowany.', 'bookmanager' ) . '</p></div>';
		} elseif ( 'deleted' === $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Blokada usunięta — termin wrócił do sprzedaży.', 'bookmanager' ) . '</p></div>';
		}
		if ( $err ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $err ) . '</p></div>';
		}
	}

	/** Panel szczegółów i formularz blokady (wypełniane przez JS). */
	private static function panel(): void {
		echo '<div id="bm-tl-panel" class="bm-tl-panel" hidden><button type="button" class="bm-tl-close" aria-label="Zamknij">×</button><div class="bm-tl-panel__body"></div></div>';
		echo '<form id="bm-tl-block" class="bm-tl-panel" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" hidden>';
		wp_nonce_field( 'bm_block_create' );
		echo '<input type="hidden" name="action" value="bm_block_create"><input type="hidden" name="apartment_id"><input type="hidden" name="check_in"><input type="hidden" name="check_out"><input type="hidden" name="month">';
		echo '<button type="button" class="bm-tl-close" aria-label="Zamknij">×</button><h3>' . esc_html__( 'Zablokuj termin', 'bookmanager' ) . '</h3><p class="bm-tl-block-summary"></p>';
		echo '<p><label>' . esc_html__( 'Notatka (np. remont, pobyt własny)', 'bookmanager' ) . '<br><input type="text" name="note" class="regular-text" maxlength="250"></label></p>';
		submit_button( __( 'Zablokuj', 'bookmanager' ), 'primary', 'submit', false );
		echo '</form>';
	}

	private static function assets(): void {
		?>
		<style>
			.bm-cal-nav{display:flex;gap:6px;align-items:center;margin:12px 0}
			.bm-cal-nav strong{min-width:150px;text-align:center;font-size:15px}
			.bm-legend{margin-left:auto;font-size:12px;color:#50575e}
			.bm-legend i{display:inline-block;width:12px;height:12px;border-radius:3px;margin:0 4px 0 12px;vertical-align:-1px}
			.bm-tl-scroll{overflow-x:auto;background:#fff;border:1px solid #dcdcde}
			.bm-tl{border-collapse:collapse;table-layout:fixed;min-width:100%}
			.bm-tl th,.bm-tl td{border:1px solid #f0f0f1;height:34px;padding:0;text-align:center;font-size:11px}
			.bm-tl thead th{width:34px;min-width:34px;font-weight:400;color:#50575e;background:#f6f7f7}
			.bm-tl thead th span{display:block;font-size:10px;color:#8c8f94}
			.bm-tl .bm-tl-name{width:190px;min-width:190px;text-align:left;font-weight:500;padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;position:sticky;left:0;background:#fff;z-index:1}
			.bm-tl-group th{background:#f6f7f7;text-align:left;font-weight:600;font-size:12px}
			.bm-tl-group th small{font-weight:400;color:#8c8f94;margin-left:4px}
			.bm-tl .is-we{background:#fafafa}.bm-tl .is-today{box-shadow:inset 0 0 0 2px #2271b1}
			.bm-tl-free{cursor:pointer}.bm-tl-free:hover{background:#e7f0f8}.bm-tl-free.is-past{cursor:default;background:#fbfbfb}
			.bm-tl-free.is-sel{background:#2271b1!important}
			.bm-tl-bar{cursor:pointer;text-align:left!important;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 6px!important;border-radius:4px}
			.bm-tl-bar span{font-size:12px}
			.bm-st-confirmed{background:#2e8540}.bm-st-hold{background:#dba617}.bm-st-block{background:#6c6fa8}.bm-st-conflict{background:#d63638}
			.bm-tl-panel{position:fixed;right:24px;top:90px;width:340px;background:#fff;border:1px solid #c3c4c7;box-shadow:0 6px 24px rgba(0,0,0,.15);padding:16px;z-index:100000}
			.bm-tl-panel table{width:100%}.bm-tl-panel td{padding:3px 0;vertical-align:top}.bm-tl-panel td:first-child{color:#646970;width:40%}
			.bm-tl-close{position:absolute;right:8px;top:4px;border:0;background:none;font-size:20px;cursor:pointer}
		</style>
		<script>
		(function () {
			var panel = document.getElementById('bm-tl-panel'), form = document.getElementById('bm-tl-block'), sel = null;
			function close() { panel.hidden = true; form.hidden = true; clearSel(); }
			function clearSel() { document.querySelectorAll('.bm-tl-free.is-sel').forEach(function (c) { c.classList.remove('is-sel'); }); sel = null; }
			document.querySelectorAll('.bm-tl-close').forEach(function (b) { b.onclick = close; });
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
			function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

			document.querySelectorAll('.bm-tl-bar').forEach(function (td) {
				td.onclick = function () {
					var i = JSON.parse(td.getAttribute('data-info')), h = '<h3>' + esc(i.label) + '</h3><table>';
					Object.keys(i.rows).forEach(function (k) { h += '<tr><td>' + esc(k) + '</td><td>' + esc(i.rows[k]) + '</td></tr>'; });
					h += '</table><p>';
					if (i.order) h += '<a class="button" href="' + i.order + '">Zamówienie</a> ';
					if (i.delete) h += '<a class="button button-link-delete" href="' + i.delete + '" onclick="return confirm(\'Usunąć blokadę i przywrócić termin do sprzedaży?\')">Usuń blokadę</a>';
					panel.querySelector('.bm-tl-panel__body').innerHTML = h + '</p>';
					form.hidden = true; clearSel(); panel.hidden = false;
				};
			});

			document.querySelectorAll('.bm-tl-free:not(.is-past)').forEach(function (td) {
				td.onclick = function () {
					var row = td.parentNode, date = td.getAttribute('data-date');
					if (!sel || sel.row !== row) { clearSel(); sel = { row: row, from: date }; td.classList.add('is-sel'); return; }
					var a = sel.from < date ? sel.from : date, b = sel.from < date ? date : sel.from, ok = true, cells = [];
					row.querySelectorAll('td[data-date]').forEach(function (c) {
						var d = c.getAttribute('data-date');
						if (d >= a && d <= b) cells.push(c);
					});
					// czy między a i b nie ma zajętych nocy
					var all = Array.prototype.slice.call(row.children), inRange = false;
					all.forEach(function (c) {
						var d = c.getAttribute('data-date');
						if (d === a) inRange = true;
						if (inRange && c.classList.contains('bm-tl-bar')) ok = false;
						if (d === b) inRange = false;
					});
					if (!ok) { alert('W zaznaczonym zakresie jest już rezerwacja.'); clearSel(); return; }
					cells.forEach(function (c) { c.classList.add('is-sel'); });
					var out = new Date(b + 'T12:00:00Z'); out.setUTCDate(out.getUTCDate() + 1); out = out.toISOString().slice(0, 10);
					var n = cells.length;
					form.apartment_id.value = row.getAttribute('data-apt'); form.check_in.value = a; form.check_out.value = out;
					form.month.value = a.slice(0, 7);
					form.querySelector('.bm-tl-block-summary').textContent = row.getAttribute('data-name') + ': noce od ' + a + ' do ' + b + ' (' + n + '), wolne od ' + out + '.';
					panel.hidden = true; form.hidden = false; form.note.focus();
					sel = null;
				};
			});
		})();
		</script>
		<?php
	}

	/* ---------- akcje ---------- */

	private static function back( array $args ): void {
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . self::PAGE ) ) );
		exit;
	}

	public static function handle_create(): void {
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( 'bm_block_create' );
		$p     = wp_unslash( $_POST );
		$month = preg_match( '/^\d{4}-\d{2}$/', $p['month'] ?? '' ) ? $p['month'] : '';
		$res   = BM_Availability::create_block( absint( $p['apartment_id'] ?? 0 ), sanitize_text_field( $p['check_in'] ?? '' ),
			sanitize_text_field( $p['check_out'] ?? '' ), sanitize_text_field( $p['note'] ?? '' ) );
		if ( is_wp_error( $res ) ) {
			self::back( [ 'month' => $month, 'bm_err' => rawurlencode( $res->get_error_message() ) ] );
		}
		do_action( 'bm_block_created', $res );
		self::back( [ 'month' => $month, 'bm_msg' => 'created' ] );
	}

	public static function handle_delete(): void {
		$id = absint( $_GET['id'] ?? 0 );
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( 'bm_block_delete_' . $id );
		$b = BM_Availability::get( $id );
		if ( $b && 'block' === $b->status ) {
			BM_Availability::release( $id, 'cancelled' );
			do_action( 'bm_booking_cancelled', $id );
		}
		self::back( [ 'month' => $b ? substr( $b->check_in, 0, 7 ) : '', 'bm_msg' => 'deleted' ] );
	}
}
