<?php
defined( 'ABSPATH' ) || exit;

/**
 * Opcje dodatkowe: definicje (ekran BookManager → Opcje dodatkowe)
 * i przypisanie do apartamentu (zakładka na karcie apartamentu).
 */
class BM_Admin_Extras {

	const PAGE = 'bookmanager-extras';

	public static function init(): void {
		add_action( 'admin_post_bm_extra_save', [ __CLASS__, 'handle_save' ] );
		add_action( 'admin_post_bm_extra_delete', [ __CLASS__, 'handle_delete' ] );
		add_filter( 'woocommerce_product_data_tabs', [ __CLASS__, 'product_tab' ] );
		add_action( 'woocommerce_product_data_panels', [ __CLASS__, 'product_panel' ] );
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'product_save' ] );
	}

	private static function t( string $n ): string {
		return BM_Installer::table( $n );
	}

	/** Obiekty (węzły typu „obiekt”) do list wyboru. */
	public static function objects(): array {
		$out = [];
		foreach ( get_terms( [ 'taxonomy' => BM_Locations::TAX, 'hide_empty' => false ] ) as $t ) {
			if ( 'object' === BM_Locations::type_of( $t->term_id ) ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	/* ---------- Ekran ---------- */

	public static function page(): void {
		$id = absint( $_GET['edit'] ?? 0 ); // phpcs:ignore
		echo '<div class="wrap">';
		if ( isset( $_GET['edit'] ) ) { // phpcs:ignore
			self::form( $id );
		} else {
			self::list();
		}
		echo '</div>';
	}

	private static function notice(): void {
		$msg = [ 'saved' => __( 'Zapisano opcję.', 'bookmanager' ), 'deleted' => __( 'Usunięto opcję.', 'bookmanager' ) ][ $_GET['bm_msg'] ?? '' ] ?? ''; // phpcs:ignore
		if ( $msg ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
	}

	private static function list(): void {
		global $wpdb;
		$rows    = $wpdb->get_results( 'SELECT e.*, (SELECT COUNT(*) FROM ' . self::t( 'apartment_extras' ) . ' ae WHERE ae.extra_id = e.id) AS apts FROM ' . self::t( 'extras' ) . ' e ORDER BY e.sort, e.name' );
		$objects = self::objects();

		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Opcje dodatkowe', 'bookmanager' ) . '</h1> ';
		printf( '<a href="%s" class="page-title-action">%s</a><hr class="wp-header-end">', esc_url( admin_url( 'admin.php?page=' . self::PAGE . '&edit=0' ) ), esc_html__( 'Dodaj opcję', 'bookmanager' ) );
		self::notice();
		echo '<p>' . esc_html__( 'Opcje, które gość świadomie wybiera przy rezerwacji — płatne lub darmowe (łóżeczko, pies, parking…). Po zdefiniowaniu przypisz je do apartamentów na karcie apartamentu, w zakładce „Opcje dodatkowe”.', 'bookmanager' ) . '</p>';

		if ( ! $rows ) {
			echo '<p><em>' . esc_html__( 'Nie ma jeszcze żadnych opcji.', 'bookmanager' ) . '</em></p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr>';
		foreach ( [ 'Nazwa', 'Cena', 'Ilość', 'Obiekt', 'Pula w obiekcie', 'Apartamenty', 'Aktywna', '' ] as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$edit = admin_url( 'admin.php?page=' . self::PAGE . '&edit=' . (int) $r->id );
			$del  = wp_nonce_url( admin_url( 'admin-post.php?action=bm_extra_delete&id=' . (int) $r->id ), 'bm_extra_delete_' . (int) $r->id );
			$pool = $r->pool_qty && $r->pool_location_id && get_term( (int) $r->pool_location_id )
				? sprintf( '%d szt. — %s', $r->pool_qty, get_term( (int) $r->pool_location_id )->name ) : '—';
			echo '<tr>';
			printf( '<td><strong><a href="%s">%s</a></strong></td>', esc_url( $edit ), esc_html( $r->name ) );
			printf( '<td>%s %s</td>', (float) $r->price > 0 ? wp_kses_post( wc_price( $r->price ) ) : esc_html__( 'bezpłatna', 'bookmanager' ),
				(float) $r->price > 0 ? esc_html( BM_Extras::charge_types()[ $r->charge_type ] ?? '' ) : '' );
			echo '<td>' . ( $r->allow_qty ? esc_html( sprintf( __( 'do %d', 'bookmanager' ), $r->max_qty ) ) : '1' ) . '</td>';
			echo '<td>' . esc_html( $r->object_id ? ( $objects[ $r->object_id ] ?? '?' ) : __( 'wszystkie', 'bookmanager' ) ) . '</td>';
			echo '<td>' . esc_html( $pool ) . '</td>';
			echo '<td>' . (int) $r->apts . '</td>';
			echo '<td>' . esc_html( $r->active ? __( 'tak', 'bookmanager' ) : __( 'nie', 'bookmanager' ) ) . '</td>';
			printf( '<td><a href="%s">%s</a> | <a href="%s" class="bm-del" onclick="return confirm(\'%s\')">%s</a></td>',
				esc_url( $edit ), esc_html__( 'Edytuj', 'bookmanager' ), esc_url( $del ),
				esc_js( __( 'Usunąć opcję? Zostanie odpięta od apartamentów. Dotychczasowe rezerwacje zachowają jej nazwę i cenę.', 'bookmanager' ) ),
				esc_html__( 'Usuń', 'bookmanager' ) );
			echo '</tr>';
		}
		echo '</tbody></table>';
	}

	private static function form( int $id ): void {
		global $wpdb;
		$r = $id ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'extras' ) . ' WHERE id = %d', $id ) ) : null;
		$v = fn( $k, $d = '' ) => $r ? $r->$k : $d;

		echo '<h1>' . esc_html( $r ? __( 'Edytuj opcję', 'bookmanager' ) : __( 'Nowa opcja dodatkowa', 'bookmanager' ) ) . '</h1>';
		printf( '<p><a href="%s">← %s</a></p>', esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ), esc_html__( 'Wszystkie opcje', 'bookmanager' ) );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'bm_extra_save' );
		echo '<input type="hidden" name="action" value="bm_extra_save"><input type="hidden" name="id" value="' . (int) $id . '">';
		echo '<table class="form-table">';

		printf( '<tr><th><label for="name">%s</label></th><td><input name="name" id="name" class="regular-text" required value="%s" placeholder="%s"></td></tr>',
			esc_html__( 'Nazwa', 'bookmanager' ), esc_attr( $v( 'name' ) ), esc_attr__( 'np. Łóżeczko dziecięce', 'bookmanager' ) );
		printf( '<tr><th><label for="description">%s</label></th><td><textarea name="description" id="description" class="large-text" rows="2">%s</textarea><p class="description">%s</p></td></tr>',
			esc_html__( 'Opis dla gościa', 'bookmanager' ), esc_textarea( $v( 'description' ) ), esc_html__( 'Krótko, co gość dostaje — widoczne przy wyborze opcji.', 'bookmanager' ) );

		$types = '';
		foreach ( BM_Extras::charge_types() as $k => $label ) {
			$types .= sprintf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $v( 'charge_type', 'stay' ), $k, false ), esc_html( $label ) );
		}
		printf( '<tr><th><label for="price">%s</label></th><td><input name="price" id="price" class="small-text wc_input_price" value="%s"> zł <select name="charge_type">%s</select><p class="description">%s</p></td></tr>',
			esc_html__( 'Cena', 'bookmanager' ), esc_attr( wc_format_localized_price( (string) $v( 'price', '0' ) ) ), $types, // phpcs:ignore
			esc_html__( '0 = opcja bezpłatna. „Za noc” mnoży cenę przez liczbę nocy.', 'bookmanager' ) );

		printf( '<tr><th>%s</th><td><label><input type="checkbox" name="allow_qty" value="1"%s> %s</label> <input type="number" name="max_qty" min="1" max="99" class="small-text" value="%d"> <p class="description">%s</p></td></tr>',
			esc_html__( 'Ilość', 'bookmanager' ), checked( (int) $v( 'allow_qty', 0 ), 1, false ), esc_html__( 'gość wybiera ilość, maksymalnie', 'bookmanager' ),
			(int) $v( 'max_qty', 1 ), esc_html__( 'Np. pies: maks. 2. Bez zaznaczenia — opcja jest pojedyncza.', 'bookmanager' ) );

		$obj_opts = '<option value="0">' . esc_html__( 'Wszystkie obiekty', 'bookmanager' ) . '</option>';
		foreach ( self::objects() as $oid => $name ) {
			$obj_opts .= sprintf( '<option value="%d"%s>%s</option>', $oid, selected( (int) $v( 'object_id', 0 ), $oid, false ), esc_html( $name ) );
		}
		printf( '<tr><th><label for="object_id">%s</label></th><td><select name="object_id" id="object_id">%s</select><p class="description">%s</p></td></tr>',
			esc_html__( 'Obiekt', 'bookmanager' ), $obj_opts, esc_html__( 'Opcja pojawi się do przypisania tylko w apartamentach tego obiektu.', 'bookmanager' ) ); // phpcs:ignore

		echo '<tr><th>' . esc_html__( 'Pula sztuk', 'bookmanager' ) . '</th><td>';
		printf( '<input type="number" name="pool_qty" min="0" max="999" class="small-text" value="%d"> %s ', (int) $v( 'pool_qty', 0 ), esc_html__( 'szt. na', 'bookmanager' ) );
		wp_dropdown_categories( [
			'taxonomy' => BM_Locations::TAX, 'name' => 'pool_location_id', 'hierarchical' => true, 'hide_empty' => false,
			'selected' => (int) $v( 'pool_location_id', 0 ), 'show_option_none' => __( '— wybierz miejsce —', 'bookmanager' ), 'option_none_value' => 0,
		] );
		echo '<p class="description">' . esc_html__( 'Np. 2 łóżeczka na cały Budynek A — w tych samych nocach nie da się wybrać trzeciego, w żadnym apartamencie budynku. 0 = bez limitu. (Pilnowanie puli włączy się razem z rezerwacją ze strony.)', 'bookmanager' ) . '</p></td></tr>';

		printf( '<tr><th>%s</th><td><label><input type="checkbox" name="active" value="1"%s> %s</label></td></tr>',
			esc_html__( 'Aktywna', 'bookmanager' ), checked( (int) $v( 'active', 1 ), 1, false ), esc_html__( 'dostępna do wyboru', 'bookmanager' ) );
		printf( '<tr><th><label for="sort">%s</label></th><td><input type="number" name="sort" id="sort" class="small-text" value="%d"></td></tr>',
			esc_html__( 'Kolejność', 'bookmanager' ), (int) $v( 'sort', 0 ) );

		echo '</table>';
		submit_button( $r ? __( 'Zapisz', 'bookmanager' ) : __( 'Dodaj opcję', 'bookmanager' ) );
		echo '</form>';
	}

	public static function handle_save(): void {
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( 'bm_extra_save' );
		global $wpdb;
		$p   = wp_unslash( $_POST );
		$id  = absint( $p['id'] ?? 0 );
		$now = gmdate( 'Y-m-d H:i:s' );
		$row = [
			'name'             => sanitize_text_field( $p['name'] ?? '' ),
			'description'      => sanitize_textarea_field( $p['description'] ?? '' ),
			'price'            => max( 0, (float) wc_format_decimal( $p['price'] ?? 0 ) ),
			'charge_type'      => isset( BM_Extras::charge_types()[ $p['charge_type'] ?? '' ] ) ? $p['charge_type'] : BM_Extras::CHARGE_STAY,
			'allow_qty'        => empty( $p['allow_qty'] ) ? 0 : 1,
			'max_qty'          => max( 1, min( 99, absint( $p['max_qty'] ?? 1 ) ) ),
			'object_id'        => absint( $p['object_id'] ?? 0 ),
			'pool_location_id' => absint( $p['pool_location_id'] ?? 0 ),
			'pool_qty'         => min( 999, absint( $p['pool_qty'] ?? 0 ) ),
			'active'           => empty( $p['active'] ) ? 0 : 1,
			'sort'             => (int) ( $p['sort'] ?? 0 ),
			'updated_at'       => $now,
		];
		if ( '' === $row['name'] ) {
			wp_die( esc_html__( 'Podaj nazwę opcji.', 'bookmanager' ), '', [ 'back_link' => true ] );
		}
		if ( $id ) {
			$wpdb->update( self::t( 'extras' ), $row, [ 'id' => $id ] );
		} else {
			$row['created_at'] = $now;
			$wpdb->insert( self::t( 'extras' ), $row );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&bm_msg=saved' ) );
		exit;
	}

	public static function handle_delete(): void {
		$id = absint( $_GET['id'] ?? 0 );
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( 'bm_extra_delete_' . $id );
		global $wpdb;
		$wpdb->delete( self::t( 'apartment_extras' ), [ 'extra_id' => $id ] );
		$wpdb->delete( self::t( 'extras' ), [ 'id' => $id ] );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&bm_msg=deleted' ) );
		exit;
	}

	/* ---------- Karta apartamentu ---------- */

	public static function product_tab( array $tabs ): array {
		$tabs['bm_extras'] = [ 'label' => __( 'Opcje dodatkowe', 'bookmanager' ), 'target' => 'bm_extras_data', 'class' => [ 'show_if_bm_apartment' ], 'priority' => 17 ];
		return $tabs;
	}

	public static function product_panel(): void {
		global $post, $wpdb;
		$apt_id = $post ? (int) $post->ID : 0;
		$object = BM_Locations::object_of_apartment( $apt_id );

		$extras = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . self::t( 'extras' ) . ' WHERE object_id IN (0, %d) ORDER BY sort, name', $object
		) );
		$linked = [];
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'apartment_extras' ) . ' WHERE apartment_id = %d', $apt_id ) ) as $l ) {
			$linked[ (int) $l->extra_id ] = $l;
		}

		echo '<div id="bm_extras_data" class="panel woocommerce_options_panel hidden"><div class="bm-extras-wrap">';
		wp_nonce_field( 'bm_apartment_extras', 'bm_apartment_extras_nonce' );

		if ( ! $extras ) {
			printf( '<p>%s <a href="%s">%s</a></p>', esc_html__( 'Brak zdefiniowanych opcji dla obiektu tego apartamentu.', 'bookmanager' ),
				esc_url( admin_url( 'admin.php?page=' . self::PAGE . '&edit=0' ) ), esc_html__( 'Dodaj opcję', 'bookmanager' ) );
			echo '</div></div>';
			return;
		}
		echo '<p class="description">' . esc_html__( 'Zaznacz opcje dostępne w tym apartamencie. Cenę i limit można tu nadpisać — puste pole = wartość z definicji opcji.', 'bookmanager' ) . '</p>';
		echo '<table class="widefat bm-extras-table"><thead><tr><th></th><th>' . esc_html__( 'Opcja', 'bookmanager' ) . '</th><th>' . esc_html__( 'Cena', 'bookmanager' ) . '</th><th>' . esc_html__( 'Cena tutaj', 'bookmanager' ) . '</th><th>' . esc_html__( 'Limit tutaj', 'bookmanager' ) . '</th></tr></thead><tbody>';
		foreach ( $extras as $e ) {
			$l   = $linked[ (int) $e->id ] ?? null;
			$pfx = 'bm_extras[' . (int) $e->id . ']';
			printf(
				'<tr%s><td><input type="checkbox" name="%s[on]" value="1"%s></td><td><strong>%s</strong>%s</td><td>%s</td>'
				. '<td><input type="text" class="wc_input_price short" name="%s[price]" value="%s" placeholder="%s"></td>'
				. '<td>%s</td></tr>',
				$e->active ? '' : ' class="bm-inactive"',
				esc_attr( $pfx ), checked( (bool) $l, true, false ), esc_html( $e->name ),
				$e->active ? '' : ' <em>(' . esc_html__( 'nieaktywna', 'bookmanager' ) . ')</em>',
				(float) $e->price > 0 ? wp_kses_post( wc_price( $e->price ) ) . ' ' . esc_html( BM_Extras::charge_types()[ $e->charge_type ] ?? '' ) : esc_html__( 'bezpłatna', 'bookmanager' ),
				esc_attr( $pfx ), esc_attr( $l && null !== $l->price_override ? wc_format_localized_price( $l->price_override ) : '' ),
				esc_attr( wc_format_localized_price( $e->price ) ),
				$e->allow_qty
					? sprintf( '<input type="number" min="1" max="99" class="short" name="%s[max]" value="%s" placeholder="%d">', esc_attr( $pfx ), esc_attr( $l && null !== $l->max_qty_override ? (string) $l->max_qty_override : '' ), (int) $e->max_qty )
					: '—'
			);
		}
		echo '</tbody></table></div></div>';
		echo '<style>.bm-extras-wrap{padding:8px 12px}.bm-extras-table td,.bm-extras-table th{vertical-align:middle}.bm-extras-table input.short{width:90px!important;float:none!important}.bm-inactive{opacity:.6}</style>';
	}

	public static function product_save( int $post_id ): void {
		if ( ! isset( $_POST['bm_apartment_extras_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bm_apartment_extras_nonce'] ), 'bm_apartment_extras' ) ) {
			return;
		}
		BM_Extras::set_for_apartment( $post_id, (array) wp_unslash( $_POST['bm_extras'] ?? [] ) ); // phpcs:ignore -- czyszczone w set_for_apartment
	}
}
