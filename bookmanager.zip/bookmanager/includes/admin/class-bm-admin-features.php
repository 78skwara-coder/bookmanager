<?php
defined( 'ABSPATH' ) || exit;

/**
 * Udogodnienia i zasady obiektu: lista, podpowiedzi z branży, edycja z przypisaniem
 * do budynków, pięter i apartamentów obiektu oraz miejscami wyświetlania.
 */
class BM_Admin_Features {

	const PAGE = 'bookmanager-features';

	public static function init(): void {
		add_action( 'admin_post_bm_feature_save', [ __CLASS__, 'handle_save' ] );
		add_action( 'admin_post_bm_feature_delete', [ __CLASS__, 'handle_delete' ] );
		add_action( 'admin_post_bm_feature_presets', [ __CLASS__, 'handle_presets' ] );
	}

	private static function url( array $args = [] ): string {
		return admin_url( add_query_arg( $args, 'admin.php?page=' . self::PAGE ) );
	}

	/* ---------- Ekran ---------- */

	public static function page(): void {
		// phpcs:disable WordPress.Security.NonceVerification
		$objects = BM_Admin_Extras::objects();
		echo '<div class="wrap">';
		if ( ! $objects ) {
			echo '<h1>' . esc_html__( 'Udogodnienia i zasady', 'bookmanager' ) . '</h1>';
			printf( '<p>%s <a href="%s">%s</a></p></div>', esc_html__( 'Udogodnienia i zasady definiuje się w obiekcie. Najpierw dodaj obiekt w lokalizacjach.', 'bookmanager' ),
				esc_url( admin_url( BM_Admin_Locations::url() ) ), esc_html__( 'Przejdź do lokalizacji', 'bookmanager' ) );
			return;
		}
		$object = absint( $_GET['object'] ?? 0 );
		if ( ! isset( $objects[ $object ] ) ) {
			$object = (int) array_key_first( $objects );
		}

		if ( isset( $_GET['edit'] ) ) {
			self::form( $object, absint( $_GET['edit'] ), sanitize_key( $_GET['kind'] ?? BM_Features::AMENITY ) );
		} elseif ( isset( $_GET['presets'] ) ) {
			self::presets_form( $object );
		} else {
			self::list( $object, $objects );
		}
		echo '</div>';
		// phpcs:enable
	}

	private static function notice(): void {
		$m = [
			'saved'   => __( 'Zapisano.', 'bookmanager' ),
			'deleted' => __( 'Usunięto.', 'bookmanager' ),
			'added'   => __( 'Dodano pozycje z podpowiedzi. Teraz przypisz je do miejsc w obiekcie.', 'bookmanager' ),
		][ $_GET['bm_msg'] ?? '' ] ?? ''; // phpcs:ignore
		if ( $m ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $m ) . '</p></div>';
		}
	}

	private static function list( int $object, array $objects ): void {
		global $wpdb;
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Udogodnienia i zasady', 'bookmanager' ) . '</h1>';
		self::notice();

		echo '<form method="get" class="bm-object-pick"><input type="hidden" name="page" value="' . esc_attr( self::PAGE ) . '">';
		echo '<label>' . esc_html__( 'Obiekt:', 'bookmanager' ) . ' <select name="object" onchange="this.form.submit()">';
		foreach ( $objects as $id => $name ) {
			printf( '<option value="%d"%s>%s</option>', $id, selected( $object, $id, false ), esc_html( $name ) );
		}
		echo '</select></label> ';
		printf( '<a href="%s" class="button">%s</a></form>', esc_url( self::url( [ 'object' => $object, 'presets' => 1 ] ) ), esc_html__( 'Dodaj z podpowiedzi', 'bookmanager' ) );

		$items = BM_Features::for_object( $object );
		$links = [];
		if ( $items ) {
			$ids = implode( ',', array_map( 'intval', array_column( $items, 'id' ) ) );
			foreach ( $wpdb->get_results( 'SELECT feature_id, COUNT(*) n FROM ' . BM_Installer::table( 'feature_links' ) . " WHERE feature_id IN ($ids) GROUP BY feature_id" ) as $r ) {
				$links[ (int) $r->feature_id ] = (int) $r->n;
			}
		}
		$ctx = BM_Features::contexts();

		foreach ( BM_Features::kinds() as $kind => $label ) {
			$title = BM_Features::AMENITY === $kind ? __( 'Udogodnienia', 'bookmanager' ) : __( 'Zasady obiektu', 'bookmanager' );
			printf( '<h2>%s <a href="%s" class="page-title-action">%s</a></h2>', esc_html( $title ),
				esc_url( self::url( [ 'object' => $object, 'edit' => 0, 'kind' => $kind ] ) ),
				esc_html( BM_Features::AMENITY === $kind ? __( 'Dodaj udogodnienie', 'bookmanager' ) : __( 'Dodaj zasadę', 'bookmanager' ) ) );

			$rows = array_filter( $items, fn( $f ) => $f['kind'] === $kind );
			if ( ! $rows ) {
				echo '<p><em>' . esc_html__( 'Brak pozycji.', 'bookmanager' ) . '</em></p>';
				continue;
			}
			echo '<table class="widefat striped bm-features"><thead><tr>';
			foreach ( [ 'Nazwa', 'Kategoria', 'Akceptacja klienta', 'Gdzie widoczne', 'Przypisane do', 'Aktywne', '' ] as $h ) {
				echo '<th>' . esc_html( $h ) . '</th>';
			}
			echo '</tr></thead><tbody>';
			foreach ( $rows as $f ) {
				$edit = self::url( [ 'object' => $object, 'edit' => $f['id'] ] );
				$del  = wp_nonce_url( admin_url( 'admin-post.php?action=bm_feature_delete&id=' . $f['id'] . '&object=' . $object ), 'bm_feature_delete_' . $f['id'] );
				$n    = $links[ $f['id'] ] ?? 0;
				echo '<tr>';
				printf( '<td><strong><a href="%s">%s</a></strong></td>', esc_url( $edit ), esc_html( $f['name'] ) );
				echo '<td>' . esc_html( BM_Features::categories( $kind )[ $f['category'] ] ?? '' ) . '</td>';
				echo '<td>' . ( $f['requires_acceptance'] ? '<span class="bm-status bm-status--hold">' . esc_html__( 'wymagana', 'bookmanager' ) . '</span>' : '—' ) . '</td>';
				echo '<td class="bm-ctx">' . esc_html( implode( ', ', array_map( fn( $c ) => explode( ' (', $ctx[ $c ] ?? $c )[0], $f['display'] ) ) ?: '—' ) . '</td>';
				echo '<td>' . ( $n ? esc_html( $n . ' ' . BM_Pricing::pl( $n, 'miejsce', 'miejsca', 'miejsc' ) ) : '<span class="bm-warn">' . esc_html__( 'nigdzie', 'bookmanager' ) . '</span>' ) . '</td>';
				echo '<td>' . esc_html( $f['active'] ? __( 'tak', 'bookmanager' ) : __( 'nie', 'bookmanager' ) ) . '</td>';
				printf( '<td><a href="%s">%s</a> | <a href="%s" onclick="return confirm(\'%s\')">%s</a></td>', esc_url( $edit ), esc_html__( 'Edytuj', 'bookmanager' ),
					esc_url( $del ), esc_js( __( 'Usunąć pozycję i jej przypisania?', 'bookmanager' ) ), esc_html__( 'Usuń', 'bookmanager' ) );
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
	}

	/* ---------- Podpowiedzi z branży ---------- */

	private static function presets_form( int $object ): void {
		$existing = array_map( fn( $f ) => mb_strtolower( $f['name'] ), BM_Features::for_object( $object ) );
		echo '<h1>' . esc_html__( 'Dodaj z podpowiedzi', 'bookmanager' ) . ' — ' . esc_html( get_term( $object )->name ) . '</h1>';
		printf( '<p><a href="%s">← %s</a></p>', esc_url( self::url( [ 'object' => $object ] ) ), esc_html__( 'Wróć', 'bookmanager' ) );
		echo '<p>' . esc_html__( 'Zaznacz to, co jest w obiekcie. Pozycje skopiują się do obiektu — potem możesz je dowolnie zmieniać i przypisać do budynków, pięter i apartamentów.', 'bookmanager' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'bm_feature_presets' );
		echo '<input type="hidden" name="action" value="bm_feature_presets"><input type="hidden" name="object" value="' . (int) $object . '">';

		$group = null;
		foreach ( BM_Features::presets() as $i => [ $kind, $cat, $name, $acc ] ) {
			$g = $kind . '/' . $cat;
			if ( $g !== $group ) {
				echo null === $group ? '' : '</fieldset>';
				printf( '<fieldset class="bm-preset"><legend>%s — %s</legend>', esc_html( BM_Features::kinds()[ $kind ] ), esc_html( BM_Features::categories( $kind )[ $cat ] ) );
				$group = $g;
			}
			$has = in_array( mb_strtolower( $name ), $existing, true );
			printf( '<label><input type="checkbox" name="presets[]" value="%d"%s> %s%s</label>', $i, disabled( $has, true, false ), esc_html( $name ),
				$has ? ' <em>(' . esc_html__( 'już jest', 'bookmanager' ) . ')</em>' : ( $acc ? ' <span class="bm-status bm-status--hold">' . esc_html__( 'akceptacja', 'bookmanager' ) . '</span>' : '' ) );
		}
		echo '</fieldset>';
		submit_button( __( 'Dodaj zaznaczone', 'bookmanager' ) );
		echo '</form>';
	}

	public static function handle_presets(): void {
		self::guard( 'bm_feature_presets' );
		$object  = absint( $_POST['object'] ?? 0 );
		$presets = BM_Features::presets();
		foreach ( array_map( 'absint', (array) ( $_POST['presets'] ?? [] ) ) as $i ) {
			if ( ! isset( $presets[ $i ] ) ) {
				continue;
			}
			[ $kind, $cat, $name, $acc ] = $presets[ $i ];
			BM_Features::save( [
				'object_id' => $object, 'kind' => $kind, 'category' => $cat, 'name' => $name, 'active' => 1,
				'requires_acceptance' => $acc, 'display' => BM_Features::default_display( $kind, $acc ),
			] );
		}
		wp_safe_redirect( self::url( [ 'object' => $object, 'bm_msg' => 'added' ] ) );
		exit;
	}

	/* ---------- Edycja pozycji ---------- */

	private static function form( int $object, int $id, string $kind ): void {
		$f = $id ? BM_Features::get( $id ) : null;
		if ( $f ) {
			$object = $f['object_id'];
			$kind   = $f['kind'];
		}
		$kind  = BM_Features::RULE === $kind ? BM_Features::RULE : BM_Features::AMENITY;
		$links = $f ? BM_Features::links( $id ) : [];
		$v     = fn( $k, $d = '' ) => $f[ $k ] ?? $d;

		$title = $f ? sprintf( __( 'Edytuj: %s', 'bookmanager' ), $f['name'] )
			: ( BM_Features::AMENITY === $kind ? __( 'Nowe udogodnienie', 'bookmanager' ) : __( 'Nowa zasada', 'bookmanager' ) );
		echo '<h1>' . esc_html( $title ) . ' <small>— ' . esc_html( get_term( $object )->name ) . '</small></h1>';
		printf( '<p><a href="%s">← %s</a></p>', esc_url( self::url( [ 'object' => $object ] ) ), esc_html__( 'Wróć do listy', 'bookmanager' ) );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'bm_feature_save' );
		printf( '<input type="hidden" name="action" value="bm_feature_save"><input type="hidden" name="id" value="%d"><input type="hidden" name="object_id" value="%d"><input type="hidden" name="kind" value="%s">',
			$id, $object, esc_attr( $kind ) );

		echo '<table class="form-table">';
		printf( '<tr><th><label for="name">%s</label></th><td><input name="name" id="name" class="regular-text" required value="%s"></td></tr>',
			esc_html__( 'Nazwa', 'bookmanager' ), esc_attr( $v( 'name' ) ) );
		printf( '<tr><th><label for="description">%s</label></th><td><textarea name="description" id="description" class="large-text" rows="3">%s</textarea><p class="description">%s</p></td></tr>',
			esc_html__( 'Opis dla gościa', 'bookmanager' ), esc_textarea( $v( 'description' ) ),
			esc_html__( 'Sformułuj wprost, np. „Łazienka na korytarzu, wspólna dla 3 pokoi na piętrze”. Ten tekst gość akceptuje przed zapłatą.', 'bookmanager' ) );

		$cats = '';
		foreach ( BM_Features::categories( $kind ) as $k => $label ) {
			$cats .= sprintf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $v( 'category', 'other' ), $k, false ), esc_html( $label ) );
		}
		printf( '<tr><th><label for="category">%s</label></th><td><select name="category" id="category">%s</select></td></tr>', esc_html__( 'Kategoria', 'bookmanager' ), $cats ); // phpcs:ignore

		printf( '<tr><th>%s</th><td><label><input type="checkbox" name="requires_acceptance" value="1"%s> %s</label></td></tr>',
			esc_html__( 'Akceptacja klienta', 'bookmanager' ), checked( (bool) $v( 'requires_acceptance', false ), true, false ),
			esc_html__( 'gość musi to świadomie zaakceptować przed zapłatą (zapisujemy zaakceptowany tekst z datą)', 'bookmanager' ) );

		$display = $f ? $f['display'] : BM_Features::default_display( $kind, false );
		echo '<tr><th>' . esc_html__( 'Gdzie widoczne', 'bookmanager' ) . '</th><td><fieldset>';
		foreach ( BM_Features::contexts() as $k => $label ) {
			printf( '<label class="bm-block"><input type="checkbox" name="display[]" value="%s"%s> %s</label>', esc_attr( $k ), checked( in_array( $k, $display, true ), true, false ), esc_html( $label ) );
		}
		echo '</fieldset></td></tr>';

		printf( '<tr><th>%s</th><td><label><input type="checkbox" name="active" value="1"%s> %s</label> &nbsp; %s <input type="number" name="sort" class="small-text" value="%d"></td></tr>',
			esc_html__( 'Aktywne', 'bookmanager' ), checked( (bool) $v( 'active', true ), true, false ), esc_html__( 'tak', 'bookmanager' ),
			esc_html__( 'kolejność', 'bookmanager' ), (int) $v( 'sort', 0 ) );
		echo '</table>';

		echo '<h2>' . esc_html__( 'Gdzie w obiekcie', 'bookmanager' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Zaznacz miejsce, do którego należy pozycja. Apartamenty dziedziczą wszystko z poziomów nad nimi — np. grill przypisany do obiektu widzą wszystkie apartamenty, łazienkę przypisaną do piętra — tylko apartamenty na tym piętrze (jako wspólną).', 'bookmanager' ) . '</p>';
		echo '<table class="widefat bm-tree"><thead><tr><th>' . esc_html__( 'Miejsce', 'bookmanager' ) . '</th><th>' . esc_html__( 'Ilość', 'bookmanager' ) . '</th><th>' . esc_html__( 'Uwaga (np. godziny, położenie)', 'bookmanager' ) . '</th></tr></thead><tbody>';
		self::tree_rows( $object, 0, $links );
		echo '</tbody></table>';

		submit_button( $f ? __( 'Zapisz', 'bookmanager' ) : __( 'Dodaj', 'bookmanager' ) );
		echo '</form>';
	}

	/** Wiersze drzewa: węzeł, jego apartamenty, potem dzieci (rekurencyjnie). */
	private static function tree_rows( int $term_id, int $depth, array $links ): void {
		$term = get_term( $term_id );
		self::target_row( 'location', $term_id, $term->name, BM_Locations::types()[ BM_Locations::type_of( $term_id ) ] ?? '', $depth, $links );

		$apartments = get_posts( [
			'post_type' => 'product', 'post_status' => [ 'publish', 'draft', 'private', 'pending' ], 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC',
			'tax_query' => [ [ 'taxonomy' => BM_Locations::TAX, 'terms' => $term_id, 'include_children' => false ] ], // phpcs:ignore
		] );
		foreach ( $apartments as $p ) {
			self::target_row( 'apartment', $p->ID, $p->post_title, __( 'Apartament', 'bookmanager' ), $depth + 1, $links );
		}
		foreach ( get_terms( [ 'taxonomy' => BM_Locations::TAX, 'parent' => $term_id, 'hide_empty' => false, 'orderby' => 'name' ] ) as $child ) {
			self::tree_rows( $child->term_id, $depth + 1, $links );
		}
	}

	private static function target_row( string $type, int $id, string $name, string $label, int $depth, array $links ): void {
		$key = "$type:$id";
		$l   = $links[ $key ] ?? null;
		$pfx = 'links[' . $key . ']';
		printf(
			'<tr class="bm-tree-%s"><td style="padding-left:%dpx"><label><input type="checkbox" name="%s[on]" value="1"%s> <strong>%s</strong> <span class="bm-muted">%s</span></label></td>'
			. '<td><input type="number" min="1" max="999" class="small-text" name="%s[qty]" value="%d"></td>'
			. '<td><input type="text" class="regular-text" name="%s[note]" value="%s"></td></tr>',
			esc_attr( $type ), 10 + $depth * 22, esc_attr( $pfx ), checked( (bool) $l, true, false ), esc_html( $name ), esc_html( $label ),
			esc_attr( $pfx ), $l ? (int) $l['qty'] : 1, esc_attr( $pfx ), esc_attr( $l['note'] ?? '' )
		);
	}

	public static function handle_save(): void {
		self::guard( 'bm_feature_save' );
		$d = wp_unslash( $_POST );
		if ( '' === trim( (string) ( $d['name'] ?? '' ) ) ) {
			wp_die( esc_html__( 'Podaj nazwę.', 'bookmanager' ), '', [ 'back_link' => true ] );
		}
		$object = absint( $d['object_id'] ?? 0 );
		$id     = BM_Features::save( [
			'id' => absint( $d['id'] ?? 0 ), 'object_id' => $object, 'kind' => $d['kind'] ?? '', 'name' => $d['name'],
			'description' => $d['description'] ?? '', 'category' => $d['category'] ?? '', 'requires_acceptance' => ! empty( $d['requires_acceptance'] ),
			'display' => (array) ( $d['display'] ?? [] ), 'active' => ! empty( $d['active'] ), 'sort' => $d['sort'] ?? 0,
		] );
		BM_Features::set_links( $id, $object, (array) ( $d['links'] ?? [] ) );
		wp_safe_redirect( self::url( [ 'object' => $object, 'bm_msg' => 'saved' ] ) );
		exit;
	}

	public static function handle_delete(): void {
		$id = absint( $_GET['id'] ?? 0 );
		self::guard( 'bm_feature_delete_' . $id );
		BM_Features::delete( $id );
		wp_safe_redirect( self::url( [ 'object' => absint( $_GET['object'] ?? 0 ), 'bm_msg' => 'deleted' ] ) );
		exit;
	}

	private static function guard( string $action ): void {
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( $action );
	}
}
