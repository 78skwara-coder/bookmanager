<?php
defined( 'ABSPATH' ) || exit;

/**
 * Google Calendar w kokpicie: klucz konta serwisowego (Ustawienia),
 * zakładka „Kalendarz Google” na karcie apartamentu, test połączenia.
 */
class BM_Admin_Google {

	public static function init(): void {
		add_action( 'admin_init', [ __CLASS__, 'register_setting' ] );
		add_filter( 'woocommerce_product_data_tabs', [ __CLASS__, 'tab' ] );
		add_action( 'woocommerce_product_data_panels', [ __CLASS__, 'panel' ] );
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'save' ] );
		add_action( 'admin_post_bm_gcal_test', [ __CLASS__, 'handle_test' ] );
		add_action( 'admin_notices', [ __CLASS__, 'test_notice' ] );
	}

	/* ---------- Ustawienia ---------- */

	public static function register_setting(): void {
		register_setting( 'bm_settings_group', BM_Google::OPTION, [ 'type' => 'string', 'sanitize_callback' => [ __CLASS__, 'sanitize_key' ], 'default' => '' ] );
		$page = BM_Admin::SLUG . '-settings';
		add_settings_section( 'bm_google', __( 'Google Calendar', 'bookmanager' ), function () {
			echo '<p>' . esc_html__( 'Rezerwacje i blokady trafiają do kalendarzy Google apartamentów (tylko w jedną stronę — zmiany w Google nie wpływają na stronę). ID kalendarza ustawiasz na karcie apartamentu.', 'bookmanager' ) . '</p>';
		}, $page );
		add_settings_field( 'bm_google_sa', __( 'Klucz konta serwisowego', 'bookmanager' ), [ __CLASS__, 'field' ], $page, 'bm_google' );
	}

	public static function field(): void {
		$cred = BM_Google::credentials();
		if ( 'wp-config' === BM_Google::source() ) {
			echo '<p>' . esc_html__( 'Ustawiony w wp-config.php (BM_GOOGLE_SA_JSON).', 'bookmanager' ) . '</p>';
		} else {
			printf( '<textarea name="%s" rows="4" class="large-text code" placeholder="%s"></textarea>', esc_attr( BM_Google::OPTION ),
				esc_attr( $cred ? __( 'Klucz zapisany. Wklej nowy JSON, aby go zmienić.', 'bookmanager' ) : __( 'Wklej zawartość pliku JSON klucza konta serwisowego', 'bookmanager' ) ) );
			if ( $cred ) {
				printf( '<label class="bm-block"><input type="checkbox" name="%s" value="__delete__"> %s</label>', esc_attr( BM_Google::OPTION ), esc_html__( 'Usuń zapisany klucz', 'bookmanager' ) );
			}
			echo '<p class="description">' . esc_html__( 'Bezpieczniej: zapisz plik JSON poza katalogiem strony i dodaj w wp-config.php: define( \'BM_GOOGLE_SA_JSON\', \'/ścieżka/do/klucza.json\' ); — wtedy klucz nie trafia do bazy ani kopii zapasowych bazy.', 'bookmanager' ) . '</p>';
		}
		if ( $cred ) {
			printf( '<p><strong>%s</strong> <code>%s</code><br>%s</p>', esc_html__( 'Konto:', 'bookmanager' ), esc_html( $cred['client_email'] ),
				esc_html__( 'Udostępnij każdy kalendarz apartamentu temu adresowi z uprawnieniem „Wprowadzanie zmian w wydarzeniach”.', 'bookmanager' ) );
		}
	}

	/** Puste pole = zostaw stary klucz; zły JSON = błąd i stary klucz. Klucza nigdy nie pokazujemy z powrotem. */
	public static function sanitize_key( $value ) {
		$old = (string) get_option( BM_Google::OPTION, '' );
		if ( is_array( $value ) ) {
			$value = in_array( '__delete__', $value, true ) ? '__delete__' : (string) reset( $value );
		}
		$value = trim( (string) $value );
		if ( '__delete__' === $value ) {
			return '';
		}
		if ( '' === $value ) {
			return $old;
		}
		$j = json_decode( wp_unslash( $value ), true );
		if ( ! is_array( $j ) || empty( $j['client_email'] ) || empty( $j['private_key'] ) || ! openssl_pkey_get_private( $j['private_key'] ) ) {
			add_settings_error( BM_Google::OPTION, 'bm_gcal', __( 'To nie jest poprawny klucz konta serwisowego Google (JSON z client_email i private_key). Zachowano poprzedni.', 'bookmanager' ) );
			return $old;
		}
		return wp_json_encode( [ 'client_email' => $j['client_email'], 'private_key' => $j['private_key'] ] );
	}

	/* ---------- Karta apartamentu ---------- */

	public static function tab( array $tabs ): array {
		$tabs['bm_gcal'] = [ 'label' => __( 'Kalendarz Google', 'bookmanager' ), 'target' => 'bm_gcal_data', 'class' => [ 'show_if_bm_apartment' ], 'priority' => 18 ];
		return $tabs;
	}

	public static function panel(): void {
		global $post;
		$id = $post ? (int) $post->ID : 0;
		echo '<div id="bm_gcal_data" class="panel woocommerce_options_panel hidden">';
		wp_nonce_field( 'bm_gcal_product', 'bm_gcal_nonce' );
		woocommerce_wp_text_input( [
			'id' => '_bm_gcal_id', 'label' => __( 'ID kalendarza', 'bookmanager' ), 'placeholder' => 'abc123@group.calendar.google.com',
			'desc_tip' => true, 'description' => __( 'Google Calendar → ustawienia kalendarza → „Integrowanie kalendarza” → Identyfikator kalendarza.', 'bookmanager' ),
		] );
		woocommerce_wp_checkbox( [ 'id' => '_bm_gcal_resync', 'label' => __( 'Wyślij ponownie', 'bookmanager' ), 'value' => 'no',
			'description' => __( 'po zapisie wyślij do kalendarza wszystkie przyszłe rezerwacje i blokady', 'bookmanager' ) ] );

		echo '<p class="form-field"><label>' . esc_html__( 'Stan', 'bookmanager' ) . '</label>';
		echo wp_kses_post( self::status_html( $id ) );
		if ( BM_Google::calendar_of( $id ) && BM_Google::credentials() ) {
			printf( ' &nbsp; <a href="%s">%s</a>', esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bm_gcal_test&apt=' . $id ), 'bm_gcal_test_' . $id ) ), esc_html__( 'Sprawdź połączenie', 'bookmanager' ) );
		}
		echo '</p>';
		if ( ! BM_Google::credentials() ) {
			printf( '<p class="form-field"><label></label><a href="%s">%s</a></p>', esc_url( admin_url( 'admin.php?page=bookmanager-settings' ) ), esc_html__( 'Najpierw dodaj klucz konta serwisowego w Ustawieniach BookManagera.', 'bookmanager' ) );
		}
		echo '</div>';
	}

	public static function status_html( int $apartment_id ): string {
		if ( ! BM_Google::calendar_of( $apartment_id ) ) {
			return '—';
		}
		if ( ! BM_Google::credentials() ) {
			return '<span class="bm-warn">' . esc_html__( 'brak klucza Google', 'bookmanager' ) . '</span>';
		}
		$s = BM_Google::status( $apartment_id );
		if ( ! $s ) {
			return esc_html__( 'ustawiony, jeszcze bez synchronizacji', 'bookmanager' );
		}
		$when = wp_date( 'j.m H:i', $s['time'] );
		return $s['ok']
			? '<span style="color:#2e8540">✓ ' . esc_html( sprintf( __( 'połączony (%s)', 'bookmanager' ), $when ) ) . '</span>'
			: '<span class="bm-warn" title="' . esc_attr( $s['message'] ) . '">✕ ' . esc_html( sprintf( __( 'błąd (%s): %s', 'bookmanager' ), $when, mb_strimwidth( $s['message'], 0, 80, '…' ) ) ) . '</span>';
	}

	public static function save( int $post_id ): void {
		if ( ! isset( $_POST['bm_gcal_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bm_gcal_nonce'] ), 'bm_gcal_product' ) ) {
			return;
		}
		$old = BM_Google::calendar_of( $post_id );
		$new = sanitize_text_field( wp_unslash( $_POST['_bm_gcal_id'] ?? '' ) );
		update_post_meta( $post_id, '_bm_gcal_id', $new );
		if ( $new !== $old ) {
			delete_post_meta( $post_id, '_bm_gcal_status' );
		}
		// Nowy kalendarz albo prośba o ponowne wysłanie → kolejka.
		if ( $new && ( $new !== $old || isset( $_POST['_bm_gcal_resync'] ) ) ) {
			BM_Google::resync_apartment( $post_id );
		}
	}

	public static function handle_test(): void {
		$id = absint( $_GET['apt'] ?? 0 );
		if ( ! current_user_can( BM_Admin::CAP ) ) {
			wp_die( 'Brak uprawnień.' );
		}
		check_admin_referer( 'bm_gcal_test_' . $id );
		[ $ok, $msg ] = BM_Google::test( $id );
		set_transient( 'bm_gcal_test_' . get_current_user_id(), [ $ok, $msg ], 60 );
		wp_safe_redirect( get_edit_post_link( $id, 'url' ) );
		exit;
	}

	public static function test_notice(): void {
		$r = get_transient( 'bm_gcal_test_' . get_current_user_id() );
		if ( $r ) {
			delete_transient( 'bm_gcal_test_' . get_current_user_id() );
			printf( '<div class="notice notice-%s is-dismissible"><p>Google Calendar: %s</p></div>', $r[0] ? 'success' : 'error', esc_html( $r[1] ) );
		}
	}
}
