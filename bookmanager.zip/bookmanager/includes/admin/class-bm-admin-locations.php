<?php
defined( 'ABSPATH' ) || exit;

/**
 * Lokalizacje w kokpicie: typ poziomu przy węźle drzewa, kolumna „Typ”,
 * wybór JEDNEJ lokalizacji na karcie apartamentu (zamiast wielokrotnych checkboxów).
 */
class BM_Admin_Locations {

	const TAX = BM_Locations::TAX;

	public static function init(): void {
		add_action( self::TAX . '_add_form_fields', [ __CLASS__, 'add_fields' ] );
		add_action( self::TAX . '_edit_form_fields', [ __CLASS__, 'edit_fields' ] );
		add_action( 'created_' . self::TAX, [ __CLASS__, 'save_type' ] );
		add_action( 'edited_' . self::TAX, [ __CLASS__, 'save_type' ] );
		add_filter( 'manage_edit-' . self::TAX . '_columns', [ __CLASS__, 'columns' ] );
		add_filter( 'manage_' . self::TAX . '_custom_column', [ __CLASS__, 'column' ], 10, 3 );
		add_filter( 'parent_file', [ __CLASS__, 'parent_file' ] );
		add_filter( 'submenu_file', [ __CLASS__, 'submenu_file' ] );
		add_action( 'add_meta_boxes_product', [ __CLASS__, 'meta_box' ], 20 );
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'save_product' ] );
		add_action( 'admin_footer-edit-tags.php', [ __CLASS__, 'type_suggest_script' ] );
	}

	public static function url(): string {
		return 'edit-tags.php?taxonomy=' . self::TAX . '&post_type=product';
	}

	/* ---------- Formularz węzła ---------- */

	private static function type_select( string $current ): string {
		$html = '<select name="bm_level" id="bm_level">';
		foreach ( BM_Locations::types() as $k => $label ) {
			$html .= sprintf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $current, $k, false ), esc_html( $label ) );
		}
		return $html . '</select>';
	}

	public static function add_fields(): void {
		wp_nonce_field( 'bm_level', 'bm_level_nonce' );
		echo '<div class="form-field"><label for="bm_level">' . esc_html__( 'Typ', 'bookmanager' ) . '</label>'
			. self::type_select( 'object' ) // phpcs:ignore
			. '<p>' . esc_html__( 'Obiekt to najwyższy poziom: ma własne udogodnienia i zasady. Pod nim budynki, pod budynkami piętra.', 'bookmanager' ) . '</p></div>';
	}

	public static function edit_fields( WP_Term $term ): void {
		wp_nonce_field( 'bm_level', 'bm_level_nonce' );
		echo '<tr class="form-field"><th scope="row"><label for="bm_level">' . esc_html__( 'Typ', 'bookmanager' ) . '</label></th><td>'
			. self::type_select( BM_Locations::type_of( $term->term_id ) ) // phpcs:ignore
			. '</td></tr>';
	}

	public static function save_type( int $term_id ): void {
		if ( ! isset( $_POST['bm_level_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bm_level_nonce'] ), 'bm_level' ) ) {
			return;
		}
		$level = sanitize_key( $_POST['bm_level'] ?? 'object' );
		update_term_meta( $term_id, BM_Locations::META_TYPE, isset( BM_Locations::types()[ $level ] ) ? $level : 'object' );
	}

	/** Po wyborze rodzica podpowiadamy typ o poziom niżej. */
	public static function type_suggest_script(): void {
		if ( ( $_GET['taxonomy'] ?? '' ) !== self::TAX ) { // phpcs:ignore
			return;
		}
		$types = [];
		foreach ( get_terms( [ 'taxonomy' => self::TAX, 'hide_empty' => false ] ) as $t ) {
			$types[ $t->term_id ] = BM_Locations::type_of( $t->term_id );
		}
		?>
		<script>
		jQuery(function ($) {
			var types = <?php echo wp_json_encode( $types ); ?>, order = <?php echo wp_json_encode( array_keys( BM_Locations::types() ) ); ?>;
			$('#parent').on('change', function () {
				var t = types[this.value], i = t ? order.indexOf(t) + 1 : 0;
				$('#bm_level').val(order[Math.min(i, order.length - 1)]);
			});
		});
		</script>
		<?php
	}

	/* ---------- Lista ---------- */

	public static function columns( array $cols ): array {
		$out = [];
		foreach ( $cols as $k => $v ) {
			$out[ $k ] = $v;
			if ( 'name' === $k ) {
				$out['bm_level'] = __( 'Typ', 'bookmanager' );
			}
		}
		if ( isset( $out['posts'] ) ) {
			$out['posts'] = __( 'Apartamenty', 'bookmanager' );
		}
		unset( $out['slug'] );
		return $out;
	}

	public static function column( $content, string $column, int $term_id ) {
		return 'bm_level' === $column ? esc_html( BM_Locations::types()[ BM_Locations::type_of( $term_id ) ] ?? '' ) : $content;
	}

	/* Podświetlenie menu BookManager na ekranie lokalizacji. */
	public static function parent_file( $file ) {
		return ( $_GET['taxonomy'] ?? '' ) === self::TAX ? BM_Admin::SLUG : $file; // phpcs:ignore
	}

	public static function submenu_file( $file ) {
		return ( $_GET['taxonomy'] ?? '' ) === self::TAX ? self::url() : $file; // phpcs:ignore
	}

	/* ---------- Karta apartamentu: jedna lokalizacja ---------- */

	public static function meta_box(): void {
		remove_meta_box( self::TAX . 'div', 'product', 'side' );
		add_meta_box( 'bm_location_box', __( 'Lokalizacja apartamentu', 'bookmanager' ), [ __CLASS__, 'render_box' ], 'product', 'side', 'default' );
	}

	public static function render_box( WP_Post $post ): void {
		wp_nonce_field( 'bm_location_box', 'bm_location_box_nonce' );
		$current = BM_Locations::of_apartment( $post->ID );
		$has     = (bool) get_terms( [ 'taxonomy' => self::TAX, 'hide_empty' => false, 'number' => 1, 'fields' => 'ids' ] );
		if ( ! $has ) {
			printf( '<p>%s <a href="%s">%s</a></p>', esc_html__( 'Brak lokalizacji.', 'bookmanager' ), esc_url( admin_url( self::url() ) ), esc_html__( 'Dodaj obiekt', 'bookmanager' ) );
			return;
		}
		wp_dropdown_categories( [
			'taxonomy'          => self::TAX,
			'name'              => 'bm_location_id',
			'id'                => 'bm_location_id',
			'hierarchical'      => true,
			'hide_empty'        => false,
			'selected'          => $current,
			'show_option_none'  => __( '— nieprzypisany —', 'bookmanager' ),
			'option_none_value' => 0,
			'class'             => 'widefat',
		] );
		echo '<p class="description">' . esc_html__( 'Apartament dziedziczy udogodnienia, zasady i pule opcji z wybranego miejsca i wszystkich poziomów nad nim.', 'bookmanager' ) . '</p>';
	}

	public static function save_product( int $post_id ): void {
		if ( ! isset( $_POST['bm_location_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bm_location_box_nonce'] ), 'bm_location_box' ) ) {
			return;
		}
		$term = absint( $_POST['bm_location_id'] ?? 0 );
		wp_set_object_terms( $post_id, $term ? [ $term ] : [], self::TAX );
	}
}
