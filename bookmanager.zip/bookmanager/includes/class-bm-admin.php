<?php
defined( 'ABSPATH' ) || exit;

/**
 * Menu BookManager w kokpicie: Rezerwacje, Apartamenty, Ustawienia.
 * Dostęp: administrator i Kierownik sklepu (uprawnienie manage_woocommerce).
 */
class BM_Admin {

	const CAP  = 'manage_woocommerce';
	const SLUG = 'bookmanager';

	public static function init(): void {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
		add_action( 'admin_head', [ __CLASS__, 'styles' ] );
		BM_Admin_Locations::init();
		BM_Admin_Extras::init();
		BM_Admin_Features::init();
		BM_Admin_Calendar::init();
		BM_Admin_Google::init();
		BM_Admin_Appearance::init();
	}

	public static function menu(): void {
		add_menu_page( 'BookManager', 'BookManager', self::CAP, self::SLUG, [ __CLASS__, 'page_bookings' ], 'dashicons-calendar-alt', 56 );
		add_submenu_page( self::SLUG, __( 'Rezerwacje', 'bookmanager' ), __( 'Rezerwacje', 'bookmanager' ), self::CAP, self::SLUG, [ __CLASS__, 'page_bookings' ] );
		add_submenu_page( self::SLUG, __( 'Kalendarz', 'bookmanager' ), __( 'Kalendarz', 'bookmanager' ), self::CAP, BM_Admin_Calendar::PAGE, [ 'BM_Admin_Calendar', 'page' ] );
		add_submenu_page( self::SLUG, __( 'Apartamenty', 'bookmanager' ), __( 'Apartamenty', 'bookmanager' ), self::CAP, self::SLUG . '-apartments', [ __CLASS__, 'page_apartments' ] );
		add_submenu_page( self::SLUG, __( 'Lokalizacje', 'bookmanager' ), __( 'Lokalizacje', 'bookmanager' ), self::CAP, BM_Admin_Locations::url() );
		add_submenu_page( self::SLUG, __( 'Udogodnienia i zasady', 'bookmanager' ), __( 'Udogodnienia i zasady', 'bookmanager' ), self::CAP, BM_Admin_Features::PAGE, [ 'BM_Admin_Features', 'page' ] );
		add_submenu_page( self::SLUG, __( 'Opcje dodatkowe', 'bookmanager' ), __( 'Opcje dodatkowe', 'bookmanager' ), self::CAP, BM_Admin_Extras::PAGE, [ 'BM_Admin_Extras', 'page' ] );
		add_submenu_page( self::SLUG, __( 'Ustawienia', 'bookmanager' ), __( 'Ustawienia', 'bookmanager' ), self::CAP, self::SLUG . '-settings', [ __CLASS__, 'page_settings' ] );
	}

	/** Wszystkie apartamenty (także szkice), alfabetycznie. */
	public static function apartments(): array {
		return wc_get_products( [
			'type'    => 'bm_apartment',
			'status'  => [ 'publish', 'draft', 'pending', 'private' ],
			'limit'   => -1,
			'orderby' => 'title',
			'order'   => 'ASC',
		] );
	}

	/* ---------- Rezerwacje ---------- */

	public static function page_bookings(): void {
		$table = new BM_Bookings_Table();
		$table->prepare_items();
		echo '<div class="wrap"><h1>' . esc_html__( 'Rezerwacje', 'bookmanager' ) . '</h1>';
		echo '<form method="get"><input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '">';
		$table->display();
		echo '</form></div>';
	}

	/* ---------- Apartamenty ---------- */

	public static function page_apartments(): void {
		global $wpdb;
		$apartments = self::apartments();
		$today      = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );

		// Nadchodzące potwierdzone rezerwacje — jedno zapytanie dla wszystkich apartamentów.
		$upcoming = [];
		foreach ( $wpdb->get_results( $wpdb->prepare(
			"SELECT apartment_id, COUNT(*) AS n FROM {$wpdb->prefix}bm_bookings
			 WHERE status = 'confirmed' AND check_out > %s GROUP BY apartment_id",
			$today
		) ) as $row ) {
			$upcoming[ (int) $row->apartment_id ] = (int) $row->n;
		}

		$default_min = (int) BM_Settings::get( 'min_nights' );

		echo '<div class="wrap"><h1 class="wp-heading-inline">' . esc_html__( 'Apartamenty', 'bookmanager' ) . '</h1> ';
		printf( '<a href="%s" class="page-title-action">%s</a><hr class="wp-header-end">',
			esc_url( admin_url( 'post-new.php?post_type=product' ) ), esc_html__( 'Dodaj apartament', 'bookmanager' ) );

		if ( ! $apartments ) {
			echo '<p>' . esc_html__( 'Nie ma jeszcze apartamentów. Dodaj produkt i wybierz typ „Apartament”.', 'bookmanager' ) . '</p></div>';
			return;
		}

		echo '<table class="widefat striped bm-apartments"><thead><tr>';
		foreach ( [ 'Apartament', 'Status', 'Cena', 'Opłata serwisowa', 'Miejsca', 'Min. nocy', 'Luki', 'Kalendarz Google', 'Nadchodzące rezerwacje' ] as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';

		foreach ( $apartments as $apt ) {
			$id       = $apt->get_id();
			$cfg      = BM_Apartment::config( $apt );
			$from     = BM_Apartment::from_price( $apt );
			$fee      = $cfg['service_fee'];
			$own_min  = (int) $apt->get_meta( '_bm_min_nights' );
			$statuses = get_post_statuses();
			$n        = $upcoming[ $id ] ?? 0;

			echo '<tr>';
			printf( '<td><strong><a href="%s">%s</a></strong></td>', esc_url( get_edit_post_link( $id ) ), esc_html( $apt->get_name() ) );
			echo '<td>' . esc_html( $statuses[ $apt->get_status() ] ?? $apt->get_status() ) . '</td>';
			echo '<td>' . ( $from['amount'] > 0
				? wp_kses_post( wc_price( $from['amount'] ) ) . ' / ' . esc_html( $from['unit'] )
				: '<span class="bm-warn">' . esc_html__( 'brak', 'bookmanager' ) . '</span>' ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $fee ) ) . '</td>';
			$eb = ( $cfg['eb_adult']['enabled'] ? $cfg['eb_adult']['max'] : 0 ) + ( $cfg['eb_child']['enabled'] ? $cfg['eb_child']['max'] : 0 );
			if ( null !== $cfg['eb_max_total'] ) {
				$eb = min( $eb, $cfg['eb_max_total'] );
			}
			echo '<td>' . ( $cfg['beds'] > 0
				? (int) $cfg['beds'] . ( $eb ? ' + ' . (int) $eb . ' ' . esc_html__( 'dost.', 'bookmanager' ) : '' )
				: '<span class="bm-warn">' . esc_html__( 'brak', 'bookmanager' ) . '</span>' ) . '</td>';
			echo '<td>' . ( $own_min ? (int) $own_min : esc_html( sprintf( __( '%d (domyślnie)', 'bookmanager' ), $default_min ) ) ) . '</td>';
			echo '<td>' . esc_html( BM_Pricing::gaps_allowed( $apt ) ? __( 'tak', 'bookmanager' ) : __( 'nie', 'bookmanager' ) ) . '</td>';
			echo '<td>' . wp_kses_post( BM_Admin_Google::status_html( $id ) ) . '</td>';
			printf( '<td>%s</td>', $n
				? sprintf( '<a href="%s">%d</a>', esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&bm_apartment=' . $id . '&bm_status=confirmed' ) ), $n )
				: '0' );
			echo '</tr>';
		}
		echo '</tbody></table></div>';
	}

	/* ---------- Ustawienia ---------- */

	public static function register_settings(): void {
		register_setting( 'bm_settings_group', BM_Settings::OPTION, [
			'type'              => 'array',
			'sanitize_callback' => [ 'BM_Settings', 'sanitize' ],
			'default'           => BM_Settings::defaults(),
		] );

		$page = self::SLUG . '-settings';
		add_settings_section( 'bm_booking', __( 'Rezerwacje', 'bookmanager' ), '__return_null', $page );
		add_settings_section( 'bm_payment', __( 'Płatności', 'bookmanager' ), '__return_null', $page );
		add_settings_section( 'bm_guest', __( 'Dane gościa', 'bookmanager' ), '__return_null', $page );
		add_settings_section( 'bm_panel', __( 'Panel i logowanie', 'bookmanager' ), [ __CLASS__, 'panel_section_intro' ], $page );
		add_settings_section( 'bm_data', __( 'Dane', 'bookmanager' ), '__return_null', $page );

		$number = function ( array $a ) {
			printf(
				'<input type="number" name="%s[%s]" value="%d" min="%d" max="%d" class="small-text"> %s<p class="description">%s</p>',
				esc_attr( BM_Settings::OPTION ), esc_attr( $a['key'] ), (int) BM_Settings::get( $a['key'] ),
				(int) $a['min'], (int) $a['max'], esc_html( $a['unit'] ), esc_html( $a['desc'] )
			);
		};

		add_settings_field( 'min_nights', __( 'Minimalny pobyt', 'bookmanager' ), $number, $page, 'bm_booking', [
			'key' => 'min_nights', 'min' => 1, 'max' => 60, 'unit' => __( 'nocy', 'bookmanager' ),
			'desc' => __( 'Domyślnie dla wszystkich apartamentów. Na karcie apartamentu można ustawić inaczej.', 'bookmanager' ),
		] );
		add_settings_field( 'hold_minutes', __( 'Blokada tymczasowa', 'bookmanager' ), $number, $page, 'bm_booking', [
			'key' => 'hold_minutes', 'min' => 5, 'max' => 240, 'unit' => __( 'minut', 'bookmanager' ),
			'desc' => __( 'Jak długo termin czeka na klienta w trakcie rezerwacji, zanim wróci do sprzedaży.', 'bookmanager' ),
		] );
		add_settings_field( 'min_deposit_percent', __( 'Minimalna zaliczka', 'bookmanager' ), $number, $page, 'bm_booking', [
			'key' => 'min_deposit_percent', 'min' => 1, 'max' => 100, 'unit' => '%',
			'desc' => __( 'Najmniejsza część ceny pobytu, jaką klient płaci online. Może zapłacić więcej.', 'bookmanager' ),
		] );
		add_settings_field( 'transfer_hold_hours', __( 'Czas na przelew', 'bookmanager' ), $number, $page, 'bm_payment', [
			'key' => 'transfer_hold_hours', 'min' => 1, 'max' => 240, 'unit' => __( 'godzin', 'bookmanager' ),
			'desc' => __( 'Przy płatności przelewem tradycyjnym (zamówienie „wstrzymane”) termin czeka tyle godzin na wpłatę, potem wraca do sprzedaży.', 'bookmanager' ),
		] );
		add_settings_field( 'balance_due_days', __( 'Termin dopłaty', 'bookmanager' ), $number, $page, 'bm_payment', [
			'key' => 'balance_due_days', 'min' => 0, 'max' => 365, 'unit' => __( 'dni przed przyjazdem', 'bookmanager' ),
			'desc' => __( '0 = reszta płatna w dniu przyjazdu.', 'bookmanager' ),
		] );
		add_settings_field( 'balance_label', __( 'Opis pozostałej kwoty', 'bookmanager' ), function () {
			printf( '<input type="text" class="regular-text" name="%s[balance_label]" value="%s"><p class="description">%s</p>',
				esc_attr( BM_Settings::OPTION ), esc_attr( BM_Settings::get( 'balance_label' ) ),
				esc_html__( 'Pozycja w koszyku i zamówieniu, która odejmuje od ceny pobytu część płatną później.', 'bookmanager' ) );
		}, $page, 'bm_payment' );
		add_settings_field( 'collect_id_number', __( 'Numer dowodu', 'bookmanager' ), function () {
			$o = esc_attr( BM_Settings::OPTION );
			printf( '<label class="bm-block"><input type="checkbox" name="%s[collect_id_number]" value="1"%s> %s</label>', $o, checked( BM_Settings::get( 'collect_id_number' ), 'yes', false ), esc_html__( 'Pytaj o numer dowodu przy zamówieniu', 'bookmanager' ) );
			printf( '<label class="bm-block"><input type="checkbox" name="%s[id_number_required]" value="1"%s> %s</label>', $o, checked( BM_Settings::get( 'id_number_required' ), 'yes', false ), esc_html__( 'Pole obowiązkowe', 'bookmanager' ) );
			printf( '<p>%s <input type="number" min="0" max="3650" class="small-text" name="%s[id_retention_days]" value="%d"> %s</p><p class="description">%s</p>',
				esc_html__( 'Usuń numer dowodu', 'bookmanager' ), $o, (int) BM_Settings::get( 'id_retention_days' ), esc_html__( 'dni po wyjeździe (0 = nie usuwaj)', 'bookmanager' ),
				esc_html__( 'Zbieranie numeru dowodu wymaga podstawy prawnej (RODO) — włącz po konsultacji. Usuwanie po wyjeździe ogranicza przechowywanie do minimum.', 'bookmanager' ) );
		}, $page, 'bm_guest' );
		add_settings_field( 'turnstile', __( 'Nie jestem robotem', 'bookmanager' ), function () {
			$o      = esc_attr( BM_Settings::OPTION );
			$secret = (string) BM_Settings::get( 'turnstile_secret' );
			printf( '<p><label>%s<br><input type="text" class="regular-text code" name="%s[turnstile_site]" value="%s" autocomplete="off"%s></label></p>',
				esc_html__( 'Klucz witryny (Site Key)', 'bookmanager' ), $o, esc_attr( BM_Settings::get( 'turnstile_site' ) ), defined( 'BM_TURNSTILE_SITE_KEY' ) ? ' disabled' : '' );
			printf( '<p><label>%s<br><input type="password" class="regular-text code" name="%s[turnstile_secret]" value="" autocomplete="new-password" placeholder="%s"%s></label></p>',
				esc_html__( 'Klucz tajny (Secret Key)', 'bookmanager' ), $o,
				esc_attr( $secret ? __( 'zapisany — wpisz nowy, aby zmienić; „-” usuwa', 'bookmanager' ) : '' ), defined( 'BM_TURNSTILE_SECRET' ) ? ' disabled' : '' );
			printf( '<label class="bm-block"><input type="checkbox" name="%s[turnstile_wp_login]" value="1"%s> %s</label>', $o, checked( BM_Settings::get( 'turnstile_wp_login' ), 'yes', false ),
				esc_html__( 'Także na stronie logowania WordPressa (wp-login.php)', 'bookmanager' ) );
			$state = BM_Security::turnstile_on() ? __( 'Włączone.', 'bookmanager' ) : __( 'Wyłączone — brak kluczy. Logowanie chroni tylko limit prób.', 'bookmanager' );
			printf( '<p class="description"><strong>%s</strong> %s</p>', esc_html( $state ),
				esc_html__( 'Klucze: dash.cloudflare.com → Turnstile → Add widget (darmowe), domena strony. Awaryjnie wyłączysz ochronę stałą BM_TURNSTILE_OFF w wp-config.php.', 'bookmanager' ) );
		}, $page, 'bm_panel' );
		add_settings_field( 'login_limits', __( 'Limit prób logowania', 'bookmanager' ), function () {
			$o = esc_attr( BM_Settings::OPTION );
			printf( '<input type="number" min="3" max="20" class="small-text" name="%s[login_max_attempts]" value="%d"> %s <input type="number" min="5" max="1440" class="small-text" name="%s[login_lock_minutes]" value="%d"> %s<p class="description">%s</p>',
				$o, (int) BM_Settings::get( 'login_max_attempts' ), esc_html__( 'nieudanych prób z jednego adresu → blokada na', 'bookmanager' ),
				$o, (int) BM_Settings::get( 'login_lock_minutes' ), esc_html__( 'minut', 'bookmanager' ),
				esc_html__( 'Dotyczy każdego logowania do WordPressa (panel, wp-login.php, XML-RPC).', 'bookmanager' ) );
		}, $page, 'bm_panel' );
		add_settings_field( 'delete_data', __( 'Odinstalowanie', 'bookmanager' ), function () {
			printf(
				'<label><input type="checkbox" name="%s[delete_data]" value="1"%s> %s</label><p class="description">%s</p>',
				esc_attr( BM_Settings::OPTION ), checked( BM_Settings::get( 'delete_data' ), 'yes', false ),
				esc_html__( 'Usuń wszystkie rezerwacje i ustawienia przy usuwaniu wtyczki', 'bookmanager' ),
				esc_html__( 'Zostaw wyłączone, jeśli nie chcesz stracić historii rezerwacji przy przypadkowym usunięciu.', 'bookmanager' )
			);
		}, $page, 'bm_data' );
	}

	public static function page_settings(): void {
		echo '<div class="wrap"><h1>' . esc_html__( 'Ustawienia BookManagera', 'bookmanager' ) . '</h1>';
		settings_errors(); // komunikat „Ustawienia zapisane” na własnej stronie menu
		echo '<form method="post" action="options.php">';
		settings_fields( 'bm_settings_group' );
		do_settings_sections( self::SLUG . '-settings' );
		submit_button();
		echo '</form></div>';
	}

	public static function panel_section_intro(): void {
		$url = BM_Panel::url();
		echo '<p>' . ( $url
			? sprintf( esc_html__( 'Panel działa pod adresem: %s', 'bookmanager' ), '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $url ) . '</a>' )
			: esc_html__( 'Aby uruchomić panel, wstaw shortcode [bookmanager_panel] na nową stronę (np. „Panel”) i opublikuj ją.', 'bookmanager' ) ) . '</p>';
		echo '<p class="description">' . esc_html__( 'Konta dla obsługi: Użytkownicy → Dodaj nowego → rola „Recepcja (BookManager)” albo „Właściciel (BookManager)”.', 'bookmanager' ) . '</p>';
	}

	public static function styles(): void {
		$screen = get_current_screen();
		if ( ! $screen || ( ! str_contains( $screen->id, self::SLUG ) && ! str_contains( $screen->id, BM_Locations::TAX ) ) ) {
			return;
		}
		echo '<style>
			.bm-status{display:inline-block;padding:2px 8px;border-radius:10px;font-size:12px;background:#f0f0f1}
			.bm-status--confirmed{background:#d7f0dd;color:#0a5c22}
			.bm-status--hold{background:#fcf0c3;color:#6b5000}
			.bm-status--block{background:#e5e5f5;color:#3a3a7a}
			.bm-status--cancelled,.bm-status--expired{color:#787c82}
			.bm-warn{color:#b32d2e;font-weight:600}
			.bm-apartments td,.bm-apartments th{vertical-align:middle}
			.bm-object-pick{margin:12px 0 4px}
			.bm-preset{border:1px solid #dcdcde;background:#fff;padding:8px 14px 10px;margin:0 0 12px}
			.bm-preset legend{font-weight:600;padding:0 4px}
			.bm-preset label{display:inline-block;min-width:260px;margin:3px 0}
			.bm-block{display:block!important;margin:3px 0!important}
			.bm-muted{color:#787c82;font-weight:400}
			.bm-tree td{vertical-align:middle}
			.bm-tree-location td:first-child strong{color:#1d2327}
			.bm-tree-apartment td:first-child strong{font-weight:400}
			.bm-ctx{color:#50575e;font-size:12px}
		</style>';
	}
}
