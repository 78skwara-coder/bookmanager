<?php
defined( 'ABSPATH' ) || exit;

/**
 * Konfiguracja apartamentu (cennik i pojemność) — jedno miejsce odczytu metadanych,
 * z wartościami domyślnymi. Korzystają z niej wycena, panel i REST.
 */
class BM_Apartment {

	const MODE_FLAT       = 'flat';
	const MODE_PER_PERSON = 'per_person';
	const MAX_CHILD_AGE   = 17;

	public static function config( WC_Product $apt ): array {
		$m     = fn( string $k ) => $apt->get_meta( '_bm_' . $k );
		$num   = fn( string $k ) => (float) wc_format_decimal( $m( $k ) );
		$int   = fn( string $k ) => '' === $m( $k ) ? null : (int) $m( $k );
		$on    = fn( string $k ) => 'yes' === $m( $k );
		$bands = json_decode( (string) $m( 'child_bands' ), true );

		$mode = $m( 'price_mode' );

		return [
			'mode'         => self::MODE_PER_PERSON === $mode ? self::MODE_PER_PERSON : self::MODE_FLAT,
			'rate'         => $num( 'rate' ),
			'adult_rate'   => $num( 'adult_rate' ),
			'child_bands'  => self::sanitize_bands( is_array( $bands ) ? $bands : [] ),
			'min_paying'   => max( 0, (int) $m( 'min_paying' ) ),
			'service_fee'  => $num( 'service_fee' ),
			'min_nights'   => (int) $m( 'min_nights' ) ?: (int) BM_Settings::get( 'min_nights' ),
			'fill_gaps'    => 'no' !== $m( 'fill_gaps' ),
			'beds'         => max( 0, (int) $m( 'beds' ) ),
			'infant_age'   => $int( 'infant_age' ), // dzieci w wieku ≤ X nie zajmują miejsca; null = każde zajmuje
			// …ale najwyżej tyle maluchów bez miejsca (puste = 1); kolejne zajmują normalne miejsce.
			'infant_max'   => null === $int( 'infant_age' ) ? 0 : ( null === $int( 'infant_max' ) ? 1 : max( 0, $int( 'infant_max' ) ) ),
			'eb_adult'     => [ 'enabled' => $on( 'eb_adult' ), 'max' => max( 0, (int) $m( 'eb_adult_max' ) ), 'price' => $num( 'eb_adult_price' ) ],
			'eb_child'     => [ 'enabled' => $on( 'eb_child' ), 'max' => max( 0, (int) $m( 'eb_child_max' ) ), 'price' => $num( 'eb_child_price' ) ],
			'eb_max_total' => $int( 'eb_max_total' ), // null = suma limitów obu typów
			'city_tax'     => [ 'enabled' => $on( 'city_tax' ), 'amount' => $num( 'city_tax_amount' ), 'exempt_age' => $int( 'city_tax_exempt_age' ) ],
		];
	}

	/** Przedziały wieku dzieci: [{from, to, price}], posortowane, w zakresie 0–17. */
	public static function sanitize_bands( array $bands ): array {
		$out = [];
		foreach ( $bands as $b ) {
			if ( ! is_array( $b ) || ! isset( $b['from'], $b['to'] ) || '' === $b['from'] || '' === $b['to'] ) {
				continue;
			}
			$from = max( 0, min( self::MAX_CHILD_AGE, (int) $b['from'] ) );
			$to   = max( 0, min( self::MAX_CHILD_AGE, (int) $b['to'] ) );
			if ( $to < $from ) {
				[ $from, $to ] = [ $to, $from ];
			}
			$out[] = [ 'from' => $from, 'to' => $to, 'price' => max( 0, (float) wc_format_decimal( $b['price'] ?? 0 ) ) ];
		}
		usort( $out, fn( $a, $b ) => $a['from'] <=> $b['from'] );
		return $out;
	}

	/**
	 * Wiek dzieci, które zajmują miejsce: starsze niż próg oraz maluchy ponad limit „bez miejsca”.
	 * Bez miejsca śpią najmłodsze — do limitu.
	 */
	public static function sleepers( array $cfg, array $ages ): array {
		if ( null === $cfg['infant_age'] ) {
			return array_values( $ages );
		}
		$infants = array_values( array_filter( $ages, fn( $a ) => $a <= $cfg['infant_age'] ) );
		$older   = array_values( array_filter( $ages, fn( $a ) => $a > $cfg['infant_age'] ) );
		sort( $infants );
		return array_merge( $older, array_slice( $infants, $cfg['infant_max'] ) );
	}

	/** Cena dziecka w danym wieku za noc; poza przedziałami — jak dorosły. */
	public static function child_price( array $cfg, int $age ): float {
		foreach ( $cfg['child_bands'] as $b ) {
			if ( $age >= $b['from'] && $age <= $b['to'] ) {
				return $b['price'];
			}
		}
		return $cfg['adult_rate'];
	}

	/** Cena „od” do list produktów. */
	public static function from_price( WC_Product $apt ): array {
		$cfg = self::config( $apt );
		return self::MODE_PER_PERSON === $cfg['mode']
			? [ 'amount' => $cfg['adult_rate'], 'unit' => __( 'os. / noc', 'bookmanager' ) ]
			: [ 'amount' => $cfg['rate'], 'unit' => __( 'noc', 'bookmanager' ) ];
	}

	/* ================= zapis (wspólny dla kokpitu i panelu) ================= */

	/** Pola karty apartamentu: klucz => typ. Meta = '_bm_' . klucz. */
	public static function fields(): array {
		return [
			'price_mode' => 'mode', 'rate' => 'money', 'adult_rate' => 'money', 'child_bands' => 'bands', 'min_paying' => 'int',
			'service_fee' => 'money', 'min_nights' => 'int', 'fill_gaps' => 'flag',
			'city_tax' => 'flag', 'city_tax_amount' => 'money', 'city_tax_exempt_age' => 'int',
			'beds' => 'int', 'infant_age' => 'int', 'infant_max' => 'int',
			'eb_adult' => 'flag', 'eb_adult_max' => 'int', 'eb_adult_price' => 'money',
			'eb_child' => 'flag', 'eb_child_max' => 'int', 'eb_child_price' => 'money', 'eb_max_total' => 'int',
		];
	}

	/** Surowe wartości do edycji (puste pola zostają puste — „domyślne”). */
	public static function editable( WC_Product $apt ): array {
		$out = [];
		foreach ( self::fields() as $k => $type ) {
			$v = $apt->get_meta( '_bm_' . $k );
			switch ( $type ) {
				case 'flag':
					$out[ $k ] = 'fill_gaps' === $k ? 'no' !== $v : 'yes' === $v;
					break;
				case 'bands':
					$b         = json_decode( (string) $v, true );
					$out[ $k ] = self::sanitize_bands( is_array( $b ) ? $b : [] );
					break;
				case 'mode':
					$out[ $k ] = self::MODE_PER_PERSON === $v ? self::MODE_PER_PERSON : self::MODE_FLAT;
					break;
				default:
					$out[ $k ] = '' === (string) $v ? '' : ( 'money' === $type ? (float) $v : (int) $v );
			}
		}
		return $out;
	}

	/**
	 * Zapisuje konfigurację apartamentu z tablicy (klucze z fields(), bez przedrostka).
	 * Brakujące klucze zostają bez zmian; flagi: true/false/'yes'/'no'/'1'.
	 */
	public static function save_config( WC_Product $apt, array $d ): void {
		$money = fn( $v ) => '' === trim( (string) $v ) ? '' : (string) max( 0, (float) wc_format_decimal( $v ) );
		$int   = fn( $v ) => '' === trim( (string) $v ) ? '' : absint( $v );
		$flag  = fn( $v ) => in_array( $v, [ true, 1, '1', 'yes', 'on', 'true' ], true ) ? 'yes' : 'no';

		foreach ( self::fields() as $k => $type ) {
			if ( ! array_key_exists( $k, $d ) ) {
				continue;
			}
			$v = $d[ $k ];
			switch ( $type ) {
				case 'mode':
					$v = self::MODE_PER_PERSON === $v ? self::MODE_PER_PERSON : self::MODE_FLAT;
					break;
				case 'money':
					$v = $money( $v );
					break;
				case 'int':
					$v = $int( $v );
					break;
				case 'flag':
					$v = $flag( $v );
					break;
				case 'bands':
					$v = wp_json_encode( self::sanitize_bands( (array) $v ) );
					break;
			}
			if ( 'min_nights' === $k && ! $v ) {
				$v = '';
			}
			$apt->update_meta_data( '_bm_' . $k, $v );
		}
		// Włączona dostawka bez limitu = 1 sztuka.
		foreach ( [ 'adult', 'child' ] as $t ) {
			if ( 'yes' === $apt->get_meta( "_bm_eb_$t" ) && ! $apt->get_meta( "_bm_eb_{$t}_max" ) ) {
				$apt->update_meta_data( "_bm_eb_{$t}_max", 1 );
			}
		}
		// Cena „od” do sortowania i list WooCommerce.
		$from = self::from_price( $apt );
		$apt->set_regular_price( $from['amount'] ?: '' );
		$apt->set_price( $from['amount'] ?: '' );
	}
}
