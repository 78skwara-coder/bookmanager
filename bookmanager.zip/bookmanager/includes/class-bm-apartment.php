<?php
defined( 'ABSPATH' ) || exit;

/**
 * Konfiguracja apartamentu (cennik i pojemność) — jedno miejsce odczytu metadanych,
 * z wartościami domyślnymi. Korzystają z niej wycena, panel i REST.
 */
class BM_Apartment {

	const MODE_FLAT       = 'flat';
	const MODE_PER_PERSON = 'per_person';
	const MAX_CHILD_AGE   = 17;

	public static function config( WC_Product $apt ): array {
		$m     = fn( string $k ) => $apt->get_meta( '_bm_' . $k );
		$num   = fn( string $k ) => (float) wc_format_decimal( $m( $k ) );
		$int   = fn( string $k ) => '' === $m( $k ) ? null : (int) $m( $k );
		$on    = fn( string $k ) => 'yes' === $m( $k );
		$bands = json_decode( (string) $m( 'child_bands' ), true );

		$mode = $m( 'price_mode' );

		return [
			'mode'         => self::MODE_PER_PERSON === $mode ? self::MODE_PER_PERSON : self::MODE_FLAT,
			'rate'         => $num( 'rate' ),
			'adult_rate'   => $num( 'adult_rate' ),
			'child_bands'  => self::sanitize_bands( is_array( $bands ) ? $bands : [] ),
			'min_paying'   => max( 0, (int) $m( 'min_paying' ) ),
			'service_fee'  => $num( 'service_fee' ),
			'min_nights'   => (int) $m( 'min_nights' ) ?: (int) BM_Settings::get( 'min_nights' ),
			'fill_gaps'    => 'no' !== $m( 'fill_gaps' ),
			'beds'         => max( 0, (int) $m( 'beds' ) ),
			'infant_age'   => $int( 'infant_age' ), // dzieci w wieku ≤ X nie zajmują miejsca; null = każde zajmuje
			'eb_adult'     => [ 'enabled' => $on( 'eb_adult' ), 'max' => max( 0, (int) $m( 'eb_adult_max' ) ), 'price' => $num( 'eb_adult_price' ) ],
			'eb_child'     => [ 'enabled' => $on( 'eb_child' ), 'max' => max( 0, (int) $m( 'eb_child_max' ) ), 'price' => $num( 'eb_child_price' ) ],
			'eb_max_total' => $int( 'eb_max_total' ), // null = suma limitów obu typów
			'city_tax'     => [ 'enabled' => $on( 'city_tax' ), 'amount' => $num( 'city_tax_amount' ), 'exempt_age' => $int( 'city_tax_exempt_age' ) ],
		];
	}

	/** Przedziały wieku dzieci: [{from, to, price}], posortowane, w zakresie 0–17. */
	public static function sanitize_bands( array $bands ): array {
		$out = [];
		foreach ( $bands as $b ) {
			if ( ! is_array( $b ) || ! isset( $b['from'], $b['to'] ) || '' === $b['from'] || '' === $b['to'] ) {
				continue;
			}
			$from = max( 0, min( self::MAX_CHILD_AGE, (int) $b['from'] ) );
			$to   = max( 0, min( self::MAX_CHILD_AGE, (int) $b['to'] ) );
			if ( $to < $from ) {
				[ $from, $to ] = [ $to, $from ];
			}
			$out[] = [ 'from' => $from, 'to' => $to, 'price' => max( 0, (float) wc_format_decimal( $b['price'] ?? 0 ) ) ];
		}
		usort( $out, fn( $a, $b ) => $a['from'] <=> $b['from'] );
		return $out;
	}

	/** Cena dziecka w danym wieku za noc; poza przedziałami — jak dorosły. */
	public static function child_price( array $cfg, int $age ): float {
		foreach ( $cfg['child_bands'] as $b ) {
			if ( $age >= $b['from'] && $age <= $b['to'] ) {
				return $b['price'];
			}
		}
		return $cfg['adult_rate'];
	}

	/** Cena „od” do list produktów. */
	public static function from_price( WC_Product $apt ): array {
		$cfg = self::config( $apt );
		return self::MODE_PER_PERSON === $cfg['mode']
			? [ 'amount' => $cfg['adult_rate'], 'unit' => __( 'os. / noc', 'bookmanager' ) ]
			: [ 'amount' => $cfg['rate'], 'unit' => __( 'noc', 'bookmanager' ) ];
	}
}
