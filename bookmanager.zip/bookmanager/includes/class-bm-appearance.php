<?php
defined( 'ABSPATH' ) || exit;

/**
 * Wygląd strony apartamentu — jedna opcja `bm_appearance` (tablica) + nadpisanie układu na apartamencie.
 *
 * Podgląd: administrator może dopisać do adresu apartamentu parametry bm_layout, bm_accent, bm_shape,
 * bm_stepper, bm_months, bm_density, bm_bar — tak działa podgląd na żywo w BookManager → Wygląd.
 */
class BM_Appearance {

	const OPTION     = 'bm_appearance';
	const META       = '_bm_layout';
	const PREVIEW    = [ 'layout', 'accent', 'shape', 'stepper', 'months', 'density', 'bar' ];

	public static function layouts(): array {
		return [
			'mosaic'  => [ __( 'Mozaika', 'bookmanager' ), __( 'Mozaika zdjęć na górze, treść po lewej, rezerwacja przyklejona po prawej. Wzorzec: Airbnb.', 'bookmanager' ) ],
			'classic' => [ __( 'Klasyczny', 'bookmanager' ), __( 'Galeria z miniaturami obok rezerwacji, opis i udogodnienia pod spodem. Wzorzec: Booking.', 'bookmanager' ) ],
			'hero'    => [ __( 'Hero', 'bookmanager' ), __( 'Zdjęcie na całą szerokość z nazwą, pasek dostępności, sekcje zdjęcie / tekst. Wzorzec: butikowe hotele.', 'bookmanager' ) ],
			'wizard'  => [ __( 'Kreator', 'bookmanager' ), __( 'Slider zdjęć i rezerwacja krok po kroku: termin → goście → opcje → podsumowanie. Najwygodniejszy na telefonie.', 'bookmanager' ) ],
		];
	}

	public static function defaults(): array {
		return [
			'layout'  => 'mosaic',
			'accent'  => '',        // pusty = kolor z motywu
			'shape'   => 'rounded', // square | rounded | pill
			'stepper' => 'round',   // round | square
			'months'  => 2,         // 1 | 2 (na telefonie zawsze 1)
			'density' => 'comfortable', // compact | comfortable
			'bar'     => 'yes',     // dolny pasek na telefonie
		];
	}

	public static function sanitize( $in ): array {
		$in  = is_array( $in ) ? $in : [];
		$d   = self::defaults();
		$pick = fn( $v, array $allowed, $def ) => in_array( $v, $allowed, true ) ? $v : $def;

		return [
			'layout'  => $pick( $in['layout'] ?? '', array_keys( self::layouts() ), $d['layout'] ),
			'accent'  => (string) sanitize_hex_color( $in['accent'] ?? '' ),
			'shape'   => $pick( $in['shape'] ?? '', [ 'square', 'rounded', 'pill' ], $d['shape'] ),
			'stepper' => $pick( $in['stepper'] ?? '', [ 'round', 'square' ], $d['stepper'] ),
			'months'  => 1 === (int) ( $in['months'] ?? 2 ) ? 1 : 2,
			'density' => $pick( $in['density'] ?? '', [ 'compact', 'comfortable' ], $d['density'] ),
			'bar'     => in_array( $in['bar'] ?? 'no', [ 'yes', '1', 1, true ], true ) ? 'yes' : 'no',
		];
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		return self::sanitize( array_merge( self::defaults(), is_array( $saved ) ? $saved : [] ) );
	}

	/** Ustawienia dla konkretnego apartamentu: globalne → układ z apartamentu → parametry podglądu (tylko administrator). */
	public static function for_apartment( int $apartment_id = 0 ): array {
		$a = self::all();
		if ( $apartment_id ) {
			$own = get_post_meta( $apartment_id, self::META, true );
			if ( isset( self::layouts()[ $own ] ) ) {
				$a['layout'] = $own;
			}
		}
		if ( self::is_preview() ) {
			$over = [];
			foreach ( self::PREVIEW as $k ) {
				if ( isset( $_GET[ 'bm_' . $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- tylko podgląd dla zalogowanego administratora
					$over[ $k ] = sanitize_text_field( wp_unslash( $_GET[ 'bm_' . $k ] ) ); // phpcs:ignore
				}
			}
			if ( $over ) {
				$a = self::sanitize( array_merge( $a, $over ) );
			}
		}
		return $a;
	}

	public static function is_preview(): bool {
		return isset( $_GET['bm_preview'] ) && current_user_can( 'manage_woocommerce' ); // phpcs:ignore
	}

	/** Klasy CSS opisujące styl (na stronę i na sam widżet z shortcode'u). */
	public static function classes( array $a ): string {
		return sprintf( 'bm-ui bm-shape--%s bm-stepper--%s bm-density--%s', $a['shape'], $a['stepper'], $a['density'] );
	}

	/** Zmienne CSS: kolor akcentu i czytelny kolor tekstu na nim. */
	public static function style_vars( array $a ): string {
		if ( ! $a['accent'] ) {
			return '';
		}
		return sprintf( '--bm-accent:%s;--bm-on-accent:%s;', $a['accent'], self::readable_on( $a['accent'] ) );
	}

	/** Biały albo prawie czarny — co lepiej czytelne na danym kolorze (WCAG, luminancja względna). */
	public static function readable_on( string $hex ): string {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$lin = function ( string $c ): float {
			$v = hexdec( $c ) / 255;
			return $v <= 0.03928 ? $v / 12.92 : ( ( $v + 0.055 ) / 1.055 ) ** 2.4;
		};
		$l = 0.2126 * $lin( substr( $hex, 0, 2 ) ) + 0.7152 * $lin( substr( $hex, 2, 2 ) ) + 0.0722 * $lin( substr( $hex, 4, 2 ) );
		return ( 1.05 / ( $l + 0.05 ) ) >= ( ( $l + 0.05 ) / 0.05 ) ? '#ffffff' : '#111111';
	}

	/* ---------- nadpisanie układu na apartamencie ---------- */

	public static function init(): void {
		add_action( 'add_meta_boxes_product', [ __CLASS__, 'meta_box' ] );
		// W ramce podglądu bez paska administratora — ma wyglądać jak u gościa.
		add_filter( 'show_admin_bar', fn( $show ) => self::is_preview() ? false : $show );
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'save_meta' ] );
	}

	public static function meta_box(): void {
		add_meta_box( 'bm-layout', __( 'Wygląd strony apartamentu', 'bookmanager' ), [ __CLASS__, 'render_meta_box' ], 'product', 'side', 'low' );
	}

	public static function render_meta_box( WP_Post $post ): void {
		$cur = get_post_meta( $post->ID, self::META, true );
		echo '<p><label for="bm_layout">' . esc_html__( 'Układ', 'bookmanager' ) . '</label><br><select name="bm_layout" id="bm_layout" style="width:100%">';
		$def = self::layouts()[ self::all()['layout'] ][0];
		printf( '<option value="">%s</option>', esc_html( sprintf( __( 'Domyślny (%s)', 'bookmanager' ), $def ) ) );
		foreach ( self::layouts() as $k => [ $label ] ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $k ), selected( $cur, $k, false ), esc_html( $label ) );
		}
		echo '</select></p><p class="description">' . esc_html__( 'Dotyczy tylko apartamentów. Pozostałe ustawienia: BookManager → Wygląd.', 'bookmanager' ) . '</p>';
	}

	public static function save_meta( int $post_id ): void {
		if ( ! isset( $_POST['bm_layout'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- nonce sprawdza WooCommerce przed tym hookiem
			return;
		}
		$v = sanitize_key( wp_unslash( $_POST['bm_layout'] ) ); // phpcs:ignore
		if ( isset( self::layouts()[ $v ] ) ) {
			update_post_meta( $post_id, self::META, $v );
		} else {
			delete_post_meta( $post_id, self::META );
		}
	}
}
