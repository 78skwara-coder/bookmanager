<?php
defined( 'ABSPATH' ) || exit;

/**
 * Dostępność apartamentów.
 * Noc = data zameldowania; check_out jest wyłączny (DATE, bez strefy czasowej).
 * Znaczniki czasu (hold_expires, created_at, updated_at) w UTC.
 */
class BM_Availability {

	const MAX_NIGHTS   = 90;

	private static function tb(): string { global $wpdb; return $wpdb->prefix . 'bm_bookings'; }
	private static function tn(): string { global $wpdb; return $wpdb->prefix . 'bm_nights'; }
	private static function now(): string { return gmdate( 'Y-m-d H:i:s' ); }

	/** Walidacja zakresu dat. Zwraca [check_in, check_out] lub WP_Error. */
	public static function parse_range( string $in, string $out ) {
		$tz = wp_timezone();
		$ci = DateTimeImmutable::createFromFormat( '!Y-m-d', $in, $tz );
		$co = DateTimeImmutable::createFromFormat( '!Y-m-d', $out, $tz );

		if ( ! $ci || ! $co || $ci->format( 'Y-m-d' ) !== $in || $co->format( 'Y-m-d' ) !== $out ) {
			return new WP_Error( 'bm_bad_date', 'Nieprawidłowa data.' );
		}
		if ( $co <= $ci ) {
			return new WP_Error( 'bm_bad_range', 'Wymeldowanie musi być po zameldowaniu.' );
		}
		if ( $ci < new DateTimeImmutable( 'today', $tz ) ) {
			return new WP_Error( 'bm_past', 'Data zameldowania już minęła.' );
		}
		if ( $ci->diff( $co )->days > self::MAX_NIGHTS ) {
			return new WP_Error( 'bm_too_long', 'Za długi pobyt.' );
		}
		return [ $ci, $co ];
	}

	/** Lista nocy (Y-m-d) od zameldowania do dnia przed wymeldowaniem. */
	public static function nights( DateTimeImmutable $ci, DateTimeImmutable $co ): array {
		$list = [];
		foreach ( new DatePeriod( $ci, new DateInterval( 'P1D' ), $co ) as $d ) {
			$list[] = $d->format( 'Y-m-d' );
		}
		return $list;
	}

	/** Zajęte noce w zakresie [from, to) — dla kalendarza na froncie. Wygasłe blokady pomijane. */
	public static function get_booked_dates( int $apt, string $from, string $to ): array {
		global $wpdb;
		return $wpdb->get_col( $wpdb->prepare(
			'SELECT n.night_date FROM ' . self::tn() . ' n
			 JOIN ' . self::tb() . " b ON b.id = n.booking_id
			 WHERE n.apartment_id = %d AND n.night_date >= %s AND n.night_date < %s
			   AND NOT ( b.status = 'hold' AND b.hold_expires < %s )
			 ORDER BY n.night_date",
			$apt, $from, $to, self::now()
		) );
	}

	/**
	 * Czy pobyt dokładnie wypełnia lukę: noc przed przyjazdem zajęta (albo przyjazd dziś)
	 * i noc w dniu wyjazdu zajęta. Granicami są tylko trwałe rezerwacje i blokady ręczne —
	 * blokada tymczasowa może wygasnąć, a wtedy „luka” przestałaby nią być.
	 */
	public static function is_gap( int $apt, string $in, string $out ): bool {
		global $wpdb;

		$range = self::parse_range( $in, $out );
		if ( is_wp_error( $range ) ) {
			return false;
		}
		[ $ci, $co ] = $range;
		$before      = $ci->modify( '-1 day' )->format( 'Y-m-d' );
		$today       = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );

		$taken = $wpdb->get_col( $wpdb->prepare(
			'SELECT n.night_date FROM ' . self::tn() . ' n
			 JOIN ' . self::tb() . " b ON b.id = n.booking_id
			 WHERE n.apartment_id = %d AND n.night_date IN (%s, %s)
			   AND b.status IN ('confirmed', 'block')",
			$apt, $before, $out
		) );

		$left_closed  = $in === $today || in_array( $before, $taken, true );
		$right_closed = in_array( $out, $taken, true );

		return $left_closed && $right_closed;
	}

	/**
	 * Noce zajęte w zakresie [from, to) z podziałem dla kalendarza:
	 * 'booked' — wszystkie niedostępne (także aktywne blokady tymczasowe),
	 * 'firm'   — tylko trwałe (confirmed/block), czyli granice luk.
	 * Zwraca wyłącznie daty, bez danych gości.
	 */
	public static function get_calendar( int $apt, string $from, string $to ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT n.night_date, b.status FROM ' . self::tn() . ' n
			 JOIN ' . self::tb() . " b ON b.id = n.booking_id
			 WHERE n.apartment_id = %d AND n.night_date >= %s AND n.night_date < %s
			   AND NOT ( b.status = 'hold' AND b.hold_expires < %s )
			 ORDER BY n.night_date",
			$apt, $from, $to, self::now()
		) );

		$booked = [];
		$firm   = [];
		foreach ( $rows as $r ) {
			$booked[] = $r->night_date;
			if ( in_array( $r->status, [ 'confirmed', 'block' ], true ) ) {
				$firm[] = $r->night_date;
			}
		}
		return [ 'booked' => $booked, 'firm' => $firm ];
	}

	public static function is_available( int $apt, string $in, string $out ): bool {
		if ( is_wp_error( self::parse_range( $in, $out ) ) ) {
			return false;
		}
		return empty( self::get_booked_dates( $apt, $in, $out ) );
	}

	/** Zakłada tymczasową blokadę. Zwraca ID rezerwacji lub WP_Error. */
	public static function create_hold( int $apt, string $in, string $out, int $guests = 1, ?int $minutes = null ) {
		$minutes = $minutes ?? (int) BM_Settings::get( 'hold_minutes' );
		return self::insert_with_nights( $apt, $in, $out, [
			'guests'       => $guests,
			'adults'       => $guests,
			'status'       => 'hold',
			'source'       => 'www',
			'channel'      => 'www',
			'hold_expires' => gmdate( 'Y-m-d H:i:s', time() + $minutes * MINUTE_IN_SECONDS ),
		] );
	}

	/** Ręczna blokada terminu z kokpitu (remont, pobyt własny…). */
	public static function create_block( int $apt, string $in, string $out, string $note = '' ) {
		return self::insert_with_nights( $apt, $in, $out, [
			'guests'  => 0,
			'adults'  => 0,
			'status'  => 'block',
			'source'  => 'admin',
			'channel' => 'owner',
			'note'    => $note,
		], false );
	}

	/**
	 * Wspólny zapis: rezerwacja + jej noce w jednej transakcji.
	 * Duplikat klucza (apartament, noc) = termin zajęty → wycofanie całości.
	 */
	private static function insert_with_nights( int $apt, string $in, string $out, array $fields, bool $future_only = true ) {
		global $wpdb;
		$range = self::parse_range( $in, $out );
		if ( is_wp_error( $range ) && ! ( ! $future_only && 'bm_past' === $range->get_error_code() ) ) {
			return $range;
		}
		if ( is_wp_error( $range ) ) { // blokada w przeszłości z kokpitu — dozwolona
			$tz    = wp_timezone();
			$range = [ DateTimeImmutable::createFromFormat( '!Y-m-d', $in, $tz ), DateTimeImmutable::createFromFormat( '!Y-m-d', $out, $tz ) ];
		}
		$nights = self::nights( ...$range );
		$now    = self::now();

		$wpdb->query( 'START TRANSACTION' );
		self::purge_expired( $apt, $in, $out ); // wygasłe blokady kolidujące z tym terminem

		$ok = $wpdb->insert( self::tb(), array_merge( [
			'apartment_id' => $apt,
			'check_in'     => $in,
			'check_out'    => $out,
			'created_at'   => $now,
			'updated_at'   => $now,
		], $fields ) );
		if ( ! $ok ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'bm_db', 'Nie udało się zapisać rezerwacji.' );
		}
		$id = (int) $wpdb->insert_id;

		if ( ! self::insert_nights( $apt, $nights, $id ) ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'bm_unavailable', 'Ten termin jest już zajęty.' );
		}
		$wpdb->query( 'COMMIT' );
		return $id;
	}

	/** Wszystkie noce jednym zapytaniem. false = któraś noc zajęta. */
	private static function insert_nights( int $apt, array $nights, int $booking_id ): bool {
		global $wpdb;
		$rows = implode( ',', array_fill( 0, count( $nights ), '(%d,%s,%d)' ) );
		$vals = [];
		foreach ( $nights as $n ) {
			array_push( $vals, $apt, $n, $booking_id );
		}
		$prev = $wpdb->suppress_errors( true );
		$ok   = $wpdb->query( $wpdb->prepare( 'INSERT INTO ' . self::tn() . " (apartment_id, night_date, booking_id) VALUES $rows", $vals ) );
		$wpdb->suppress_errors( $prev );
		return false !== $ok;
	}

	/**
	 * Przywraca noce rezerwacji, której blokada wygasła i została posprzątana
	 * (np. płatność przyszła po czasie). Udaje się tylko, jeśli termin nadal jest wolny.
	 */
	public static function restore( int $booking_id, int $minutes = 60 ): bool {
		global $wpdb;
		$b = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tb() . ' WHERE id = %d', $booking_id ) );
		if ( ! $b ) {
			return false;
		}
		$has = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::tn() . ' WHERE booking_id = %d', $booking_id ) );
		if ( ! $has ) {
			$tz = wp_timezone();
			$nights = self::nights( DateTimeImmutable::createFromFormat( '!Y-m-d', $b->check_in, $tz ), DateTimeImmutable::createFromFormat( '!Y-m-d', $b->check_out, $tz ) );
			$wpdb->query( 'START TRANSACTION' );
			self::purge_expired( (int) $b->apartment_id, $b->check_in, $b->check_out );
			if ( ! self::insert_nights( (int) $b->apartment_id, $nights, $booking_id ) ) {
				$wpdb->query( 'ROLLBACK' );
				return false;
			}
			$wpdb->query( 'COMMIT' );
		}
		$wpdb->update( self::tb(), [
			'status'       => 'hold',
			'hold_expires' => gmdate( 'Y-m-d H:i:s', time() + $minutes * MINUTE_IN_SECONDS ),
			'updated_at'   => self::now(),
		], [ 'id' => $booking_id ] );
		return true;
	}

	/** Rezerwacja jako wiersz (obiekt) albo null. */
	public static function get( int $booking_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tb() . ' WHERE id = %d', $booking_id ) ) ?: null;
	}

	/** Czy blokada nadal trzyma noce (nie wygasła ani nie została zwolniona). */
	public static function hold_active( int $booking_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare(
			'SELECT 1 FROM ' . self::tb() . " b WHERE b.id = %d AND b.status = 'hold' AND b.hold_expires >= %s
			   AND EXISTS ( SELECT 1 FROM " . self::tn() . ' n WHERE n.booking_id = b.id )',
			$booking_id, self::now()
		) );
	}

	/** Zapis składu gości, cen i opcji z wyceny w rezerwacji (stan z chwili rezerwacji). */
	public static function save_quote( int $booking_id, array $quote, float $deposit ): void {
		global $wpdb;
		$p     = $quote['party'];
		$ages  = $p['children_ages'];
		$total = (float) $quote['total'];
		$wpdb->update( self::tb(), [
			'guests'           => $p['adults'] + count( $ages ),
			'adults'           => $p['adults'],
			'children'         => count( $ages ),
			'children_ages'    => implode( ',', $ages ),
			'extra_beds_adult' => $p['eb_adult'],
			'extra_beds_child' => $p['eb_child'],
			'currency'         => get_woocommerce_currency(),
			'price_nights'     => $quote['price_nights'],
			'price_extra_beds' => $quote['price_extra_beds'],
			'price_extras'     => $quote['price_extras'],
			'service_fee'      => $quote['service_fee'],
			'total'            => $total,
			'city_tax'         => $quote['city_tax']['amount'],
			'balance_due'      => round( $total - $deposit, 2 ),
			'price_breakdown'  => wp_json_encode( [ 'lines' => $quote['lines'], 'deposit' => $deposit, 'mode' => $quote['mode'], 'is_gap' => $quote['is_gap'] ] ),
			'updated_at'       => self::now(),
		], [ 'id' => $booking_id ] );

		$be = BM_Installer::table( 'booking_extras' );
		$wpdb->delete( $be, [ 'booking_id' => $booking_id ] );
		foreach ( $quote['extras'] as $x ) {
			$wpdb->insert( $be, [
				'booking_id' => $booking_id, 'extra_id' => $x['id'], 'name' => $x['name'], 'charge_type' => $x['charge_type'],
				'qty' => $x['qty'], 'unit_price' => $x['unit_price'], 'total' => $x['total'],
			] );
		}
	}

	/** Przedłuża blokadę (np. po utworzeniu zamówienia, na czas płatności). */
	public static function extend_hold( int $booking_id, int $minutes ): bool {
		global $wpdb;
		return 1 === $wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::tb() . " SET hold_expires = %s, updated_at = %s
			 WHERE id = %d AND status = 'hold'
			   AND EXISTS ( SELECT 1 FROM " . self::tn() . ' WHERE booking_id = %d )',
			gmdate( 'Y-m-d H:i:s', time() + $minutes * MINUTE_IN_SECONDS ), self::now(), $booking_id, $booking_id
		) );
	}

	/** Potwierdza blokadę po płatności. false = noce już przepadły (konflikt do obsłużenia). */
	public static function confirm( int $booking_id, int $order_id ): bool {
		global $wpdb;
		return 1 === $wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::tb() . " SET status = 'confirmed', order_id = %d, hold_expires = NULL, updated_at = %s
			 WHERE id = %d AND status = 'hold'
			   AND EXISTS ( SELECT 1 FROM " . self::tn() . ' WHERE booking_id = %d )',
			$order_id, self::now(), $booking_id, $booking_id
		) );
	}

	/** Zwalnia noce rezerwacji (anulowanie, zwrot, nieudana płatność). */
	public static function release( int $booking_id, string $status = 'cancelled' ): void {
		global $wpdb;
		$wpdb->query( 'START TRANSACTION' );
		$wpdb->delete( self::tn(), [ 'booking_id' => $booking_id ] );
		$wpdb->update( self::tb(), [ 'status' => $status, 'updated_at' => self::now() ], [ 'id' => $booking_id ] );
		$wpdb->query( 'COMMIT' );
	}

	/** Sprząta wygasłe blokady. Bez argumentów — wszystkie (cron), z argumentami — tylko kolidujące. */
	public static function purge_expired( ?int $apt = null, ?string $from = null, ?string $to = null ): int {
		global $wpdb;

		$sql  = 'SELECT id FROM ' . self::tb() . " WHERE status = 'hold' AND hold_expires < %s";
		$args = [ self::now() ];
		if ( $apt && $from && $to ) {
			$sql .= ' AND apartment_id = %d AND check_in < %s AND check_out > %s';
			array_push( $args, $apt, $to, $from );
		}
		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $args ) ) );
		if ( ! $ids ) {
			return 0;
		}

		$in = implode( ',', $ids ); // same liczby całkowite — bezpieczne
		$wpdb->query( 'DELETE FROM ' . self::tn() . " WHERE booking_id IN ($in)" );
		$wpdb->query( $wpdb->prepare(
			'UPDATE ' . self::tb() . " SET status = 'expired', updated_at = %s WHERE id IN ($in)",
			self::now()
		) );
		return count( $ids );
	}
}
