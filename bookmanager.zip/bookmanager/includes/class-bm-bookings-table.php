<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Lista rezerwacji w kokpicie: filtry po apartamencie, statusie i datach.
 */
class BM_Bookings_Table extends WP_List_Table {

	const PER_PAGE = 20;

	public static function statuses(): array {
		return [
			'hold'      => __( 'Blokada tymczasowa', 'bookmanager' ),
			'confirmed' => __( 'Potwierdzona', 'bookmanager' ),
			'block'     => __( 'Blokada ręczna', 'bookmanager' ),
			'cancelled' => __( 'Anulowana', 'bookmanager' ),
			'expired'   => __( 'Wygasła', 'bookmanager' ),
			'conflict'  => __( 'Konflikt — do wyjaśnienia', 'bookmanager' ),
		];
	}

	public function __construct() {
		parent::__construct( [ 'singular' => 'rezerwacja', 'plural' => 'rezerwacje', 'ajax' => false ] );
	}

	public function get_columns() {
		return [
			'id'         => 'ID',
			'apartment'  => __( 'Apartament', 'bookmanager' ),
			'check_in'   => __( 'Przyjazd', 'bookmanager' ),
			'check_out'  => __( 'Wyjazd', 'bookmanager' ),
			'nights'     => __( 'Noce', 'bookmanager' ),
			'guest'      => __( 'Gość', 'bookmanager' ),
			'guests'     => __( 'Osoby', 'bookmanager' ),
			'status'     => __( 'Status', 'bookmanager' ),
			'source'     => __( 'Źródło', 'bookmanager' ),
			'money'      => __( 'Cena / saldo', 'bookmanager' ),
			'order'      => __( 'Zamówienie', 'bookmanager' ),
			'created_at' => __( 'Utworzono', 'bookmanager' ),
		];
	}

	protected function get_sortable_columns() {
		return [
			'id'         => [ 'id', true ],
			'check_in'   => [ 'check_in', false ],
			'created_at' => [ 'created_at', true ],
		];
	}

	/** Filtry z adresu, oczyszczone. */
	private function filters(): array {
		// phpcs:disable WordPress.Security.NonceVerification -- tylko odczyt.
		$date = fn( $k ) => isset( $_GET[ $k ] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_GET[ $k ] ) ? $_GET[ $k ] : '';
		$status = sanitize_key( $_GET['bm_status'] ?? '' );
		$f = [
			'apartment' => absint( $_GET['bm_apartment'] ?? 0 ),
			'status'    => isset( self::statuses()[ $status ] ) || 'all' === $status ? $status : '',
			'from'      => $date( 'bm_from' ),
			'to'        => $date( 'bm_to' ),
		];
		// phpcs:enable
		return $f;
	}

	public function prepare_items() {
		global $wpdb;
		$table = $wpdb->prefix . 'bm_bookings';
		$f     = $this->filters();

		$where = [ '1=1' ];
		$args  = [];
		if ( $f['apartment'] ) {
			$where[] = 'apartment_id = %d';
			$args[]  = $f['apartment'];
		}
		if ( '' === $f['status'] ) {
			$where[] = "status IN ('hold','confirmed','block','conflict')"; // domyślnie tylko aktywne
		} elseif ( 'all' !== $f['status'] ) {
			$where[] = 'status = %s';
			$args[]  = $f['status'];
		}
		if ( $f['from'] ) { // pobyty zahaczające o zakres
			$where[] = 'check_out > %s';
			$args[]  = $f['from'];
		}
		if ( $f['to'] ) {
			$where[] = 'check_in <= %s';
			$args[]  = $f['to'];
		}
		$where_sql = implode( ' AND ', $where );

		// phpcs:disable WordPress.Security.NonceVerification
		$orderby = in_array( $_GET['orderby'] ?? '', [ 'id', 'check_in', 'created_at' ], true ) ? $_GET['orderby'] : 'check_in';
		$order   = 'desc' === strtolower( $_GET['order'] ?? '' ) ? 'DESC' : 'ASC';
		// phpcs:enable

		$page   = $this->get_pagenum();
		$offset = ( $page - 1 ) * self::PER_PAGE;

		$count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
		$total     = (int) $wpdb->get_var( $args ? $wpdb->prepare( $count_sql, $args ) : $count_sql );

		$sql         = "SELECT * FROM $table WHERE $where_sql ORDER BY $orderby $order, id DESC LIMIT %d OFFSET %d";
		$this->items = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, [ self::PER_PAGE, $offset ] ) ) );

		$this->_column_headers = [ $this->get_columns(), [], $this->get_sortable_columns() ];
		$this->set_pagination_args( [ 'total_items' => $total, 'per_page' => self::PER_PAGE ] );
	}

	protected function extra_tablenav( $which ) {
		if ( 'top' !== $which ) {
			return;
		}
		$f = $this->filters();
		echo '<div class="alignleft actions">';

		echo '<select name="bm_apartment"><option value="">' . esc_html__( 'Wszystkie apartamenty', 'bookmanager' ) . '</option>';
		foreach ( BM_Admin::apartments() as $apt ) {
			printf( '<option value="%d"%s>%s</option>', $apt->get_id(), selected( $f['apartment'], $apt->get_id(), false ), esc_html( $apt->get_name() ) );
		}
		echo '</select>';

		echo '<select name="bm_status"><option value="">' . esc_html__( 'Aktywne', 'bookmanager' ) . '</option>';
		printf( '<option value="all"%s>%s</option>', selected( $f['status'], 'all', false ), esc_html__( 'Wszystkie', 'bookmanager' ) );
		foreach ( self::statuses() as $key => $label ) {
			printf( '<option value="%s"%s>%s</option>', esc_attr( $key ), selected( $f['status'], $key, false ), esc_html( $label ) );
		}
		echo '</select>';

		printf( '<label>%s <input type="date" name="bm_from" value="%s"></label> ', esc_html__( 'od', 'bookmanager' ), esc_attr( $f['from'] ) );
		printf( '<label>%s <input type="date" name="bm_to" value="%s"></label> ', esc_html__( 'do', 'bookmanager' ), esc_attr( $f['to'] ) );
		submit_button( __( 'Filtruj', 'bookmanager' ), '', 'bm_filter', false );
		echo '</div>';
	}

	public function no_items() {
		esc_html_e( 'Brak rezerwacji dla wybranych filtrów.', 'bookmanager' );
	}

	protected function column_default( $item, $column ) {
		$df = get_option( 'date_format' );
		switch ( $column ) {
			case 'id':
				return (int) $item->id;
			case 'apartment':
				$apt = wc_get_product( $item->apartment_id );
				return $apt
					? sprintf( '<a href="%s">%s</a>', esc_url( get_edit_post_link( $apt->get_id() ) ), esc_html( $apt->get_name() ) )
					: '#' . (int) $item->apartment_id;
			case 'check_in':
			case 'check_out':
				return esc_html( wp_date( $df, strtotime( $item->$column . ' 12:00:00' ) ) );
			case 'nights':
				return (int) ( ( strtotime( $item->check_out ) - strtotime( $item->check_in ) ) / DAY_IN_SECONDS );
			case 'guests':
				return 'block' === $item->status ? '—' : esc_html( $item->adults . ( $item->children ? ' + ' . $item->children . ' dz.' : '' ) );
			case 'guest':
				if ( 'block' === $item->status ) {
					return '<em>' . esc_html( $item->note ?: __( 'blokada', 'bookmanager' ) ) . '</em>';
				}
				$o = $item->order_id ? wc_get_order( $item->order_id ) : null;
				return $o ? esc_html( trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) ) . '<br><small>' . esc_html( $o->get_billing_phone() ) . '</small>' : '—';
			case 'money':
				if ( (float) $item->total <= 0 ) {
					return '—';
				}
				$bal = (float) $item->balance_due;
				return wp_kses_post( wc_price( $item->total ) ) . '<br><small>' . ( 'confirmed' === $item->status && $bal > 0
					? esc_html__( 'do dopłaty: ', 'bookmanager' ) . wp_kses_post( wc_price( $bal ) )
					: ( 'confirmed' === $item->status ? esc_html__( 'opłacone', 'bookmanager' ) : '' ) ) . '</small>';
			case 'status':
				$label = self::statuses()[ $item->status ] ?? $item->status;
				$extra = 'hold' === $item->status && $item->hold_expires
					? ' <small>(' . esc_html( sprintf( __( 'do %s', 'bookmanager' ), wp_date( 'H:i', strtotime( $item->hold_expires . ' UTC' ) ) ) ) . ')</small>'
					: '';
				return sprintf( '<span class="bm-status bm-status--%s">%s</span>%s', esc_attr( $item->status ), esc_html( $label ), $extra );
			case 'source':
				return esc_html( [ 'www' => 'Strona', 'admin' => 'Panel', 'google' => 'Google' ][ $item->source ] ?? $item->source );
			case 'order':
				$order = $item->order_id ? wc_get_order( $item->order_id ) : null;
				return $order
					? sprintf( '<a href="%s">#%s</a>', esc_url( $order->get_edit_order_url() ), esc_html( $order->get_order_number() ) )
					: '—';
			case 'created_at':
				return esc_html( wp_date( $df . ' H:i', strtotime( $item->created_at . ' UTC' ) ) );
		}
		return '';
	}
}
