<?php
defined( 'ABSPATH' ) || exit;

/**
 * Rezerwacja → koszyk → zamówienie WooCommerce.
 *
 * 1. „Rezerwuj” w widżecie wysyła zwykły formularz add-to-cart (natywna ścieżka WooCommerce).
 * 2. Walidacja: wycena z serwera, dostępność, akceptacja warunków, zaliczka → blokada terminu.
 * 3. W koszyku cena = cena pobytu z wyceny; część płatna później odejmowana ujemną opłatą
 *    („Do zapłaty na miejscu”), więc zamówienie opiewa na zaliczkę.
 * 4. Statusy zamówienia sterują rezerwacją: opłacone → potwierdzona, wstrzymane (przelew) →
 *    blokada przedłużona, anulowane/nieudane/zwrócone → noce zwolnione.
 */
class BM_Cart {

	const MAX_ITEMS = 3; // ile apartamentów naraz w jednym koszyku

	/** Dane z walidacji przekazywane do woocommerce_add_cart_item_data (ten sam request). */
	private static $pending = null;

	public static function init(): void {
		add_filter( 'woocommerce_add_to_cart_validation', [ __CLASS__, 'validate' ], 10, 3 );
		add_filter( 'woocommerce_add_cart_item_data', [ __CLASS__, 'add_item_data' ], 10, 2 );
		add_filter( 'woocommerce_add_to_cart_redirect', [ __CLASS__, 'redirect' ], 10, 2 );
		add_action( 'woocommerce_before_calculate_totals', [ __CLASS__, 'set_prices' ], 20 );
		add_action( 'woocommerce_cart_calculate_fees', [ __CLASS__, 'fees' ] );
		add_filter( 'woocommerce_get_item_data', [ __CLASS__, 'item_data' ], 10, 2 );
		add_action( 'woocommerce_check_cart_items', [ __CLASS__, 'check_items' ] );
		add_action( 'woocommerce_store_api_cart_errors', [ __CLASS__, 'store_api_errors' ], 10, 2 );
		add_action( 'woocommerce_remove_cart_item', [ __CLASS__, 'removed' ], 10, 2 );
		add_filter( 'woocommerce_cart_item_quantity', [ __CLASS__, 'fixed_quantity' ], 10, 3 );

		add_action( 'woocommerce_checkout_create_order_line_item', [ __CLASS__, 'order_item_meta' ], 10, 4 );
		foreach ( [ 'woocommerce_checkout_order_created', 'woocommerce_checkout_order_processed', 'woocommerce_store_api_checkout_order_processed' ] as $h ) {
			add_action( $h, [ __CLASS__, 'link_order' ] );
		}
		add_action( 'woocommerce_order_status_changed', [ __CLASS__, 'status_changed' ], 10, 4 );
	}

	/* ================= dodanie do koszyka ================= */

	private static function is_apartment( $product_id ): bool {
		$p = wc_get_product( $product_id );
		return $p && 'bm_apartment' === $p->get_type();
	}

	public static function validate( $passed, $product_id, $qty ) {
		if ( ! $passed || ! self::is_apartment( $product_id ) ) {
			return $passed;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- natywny formularz add-to-cart WooCommerce (bez nonce).
		$r   = wp_unslash( $_POST );
		$in  = sanitize_text_field( $r['bm_check_in'] ?? '' );
		$out = sanitize_text_field( $r['bm_check_out'] ?? '' );
		$extras = [];
		foreach ( array_filter( explode( ',', (string) ( $r['bm_extras'] ?? '' ) ) ) as $pair ) {
			[ $id, $q ] = array_map( 'intval', array_pad( explode( ':', $pair ), 2, 0 ) );
			if ( $id > 0 && $q > 0 ) {
				$extras[ $id ] = $q;
			}
		}
		$party = [
			'adults'        => (int) ( $r['bm_adults'] ?? 1 ),
			'children_ages' => preg_match( '/^\d{1,2}(,\d{1,2})*$/', (string) ( $r['bm_children'] ?? '' ) ) ? (string) $r['bm_children'] : '',
			'eb_adult'      => (int) ( $r['bm_eb_adult'] ?? 0 ),
			'eb_child'      => (int) ( $r['bm_eb_child'] ?? 0 ),
			'extras'        => $extras,
		];
		$deposit = (float) wc_format_decimal( $r['bm_deposit'] ?? 0 );
		$accept  = ! empty( $r['bm_accept'] );
		// phpcs:enable

		// Ten sam apartament już w koszyku → zastępujemy poprzedni wybór.
		foreach ( WC()->cart->get_cart() as $key => $item ) {
			if ( ! empty( $item['bm'] ) && (int) $item['product_id'] === (int) $product_id ) {
				WC()->cart->remove_cart_item( $key ); // zwalnia też blokadę (hook removed)
			}
		}
		if ( count( self::cart_bookings() ) >= self::MAX_ITEMS ) {
			wc_add_notice( sprintf( 'W jednym zamówieniu można zarezerwować najwyżej %d apartamenty.', self::MAX_ITEMS ), 'error' );
			return false;
		}

		$quote = BM_Pricing::quote( (int) $product_id, $in, $out, $party );
		if ( is_wp_error( $quote ) ) {
			wc_add_notice( $quote->get_error_message(), 'error' );
			return false;
		}
		$terms = BM_Features::acceptance_text( (int) $product_id );
		if ( $terms && ! $accept ) {
			wc_add_notice( 'Zaakceptuj warunki pobytu, aby zarezerwować.', 'error' );
			return false;
		}
		$deposit = min( (float) $quote['total'], max( (float) $quote['deposit_min'], round( $deposit, 2 ) ) );

		$hold = BM_Availability::create_hold( (int) $product_id, $in, $out, $quote['occupants'] );
		if ( is_wp_error( $hold ) ) {
			wc_add_notice( $hold->get_error_message(), 'error' );
			return false;
		}
		BM_Availability::save_quote( $hold, $quote, $deposit );

		self::$pending = [
			'product_id' => (int) $product_id,
			'booking_id' => $hold,
			'quote'      => $quote,
			'deposit'    => $deposit,
			'terms'      => $terms ? [ 'text' => $terms, 'accepted_at' => gmdate( 'Y-m-d H:i:s' ) ] : null,
		];
		return true;
	}

	public static function add_item_data( array $data, $product_id ): array {
		if ( self::$pending && (int) $product_id === self::$pending['product_id'] ) {
			$data['bm']         = self::$pending;
			$data['unique_key'] = md5( 'bm' . self::$pending['booking_id'] );
			self::$pending      = null;
		}
		return $data;
	}

	public static function redirect( $url, $product = null ) {
		return $product && 'bm_apartment' === $product->get_type() ? wc_get_checkout_url() : $url;
	}

	/** Pozycje-rezerwacje w koszyku: klucz => element. */
	private static function cart_bookings(): array {
		if ( ! WC()->cart ) {
			return [];
		}
		return array_filter( WC()->cart->get_cart(), fn( $i ) => ! empty( $i['bm'] ) );
	}

	/* ================= koszyk ================= */

	public static function set_prices( $cart ): void {
		foreach ( $cart->get_cart() as $item ) {
			if ( ! empty( $item['bm'] ) ) {
				$item['data']->set_price( (float) $item['bm']['quote']['total'] );
			}
		}
	}

	/** Część płatna później — ujemna opłata, więc do zapłaty online zostaje zaliczka. */
	public static function fees( $cart ): void {
		$later = 0.0;
		foreach ( $cart->get_cart() as $item ) {
			if ( ! empty( $item['bm'] ) ) {
				$later += (float) $item['bm']['quote']['total'] - (float) $item['bm']['deposit'];
			}
		}
		if ( $later > 0.004 ) {
			$cart->add_fee( (string) BM_Settings::get( 'balance_label' ), -round( $later, 2 ), false );
		}
	}

	public static function fixed_quantity( $html, $key, $item ) {
		return ! empty( $item['bm'] ) ? '1' : $html;
	}

	/** Opis pozycji w koszyku i podsumowaniu zamówienia. */
	public static function item_data( array $data, array $item ): array {
		if ( empty( $item['bm'] ) ) {
			return $data;
		}
		foreach ( self::describe( $item['bm'] ) as $k => $v ) {
			$data[] = [ 'key' => $k, 'value' => $v ];
		}
		return $data;
	}

	/** Czytelny opis rezerwacji: etykieta => wartość (koszyk, zamówienie, maile). */
	public static function describe( array $bm ): array {
		$q     = $bm['quote'];
		$p     = $q['party'];
		$money = fn( $v ) => trim( str_replace( "\xC2\xA0", ' ', html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' ) ) );
		$date  = fn( $d ) => wp_date( 'j F Y', strtotime( $d . ' 12:00:00' ) );

		$guests = sprintf( '%d %s', $p['adults'], BM_Pricing::pl( $p['adults'], 'dorosły', 'dorosłych', 'dorosłych' ) );
		if ( $p['children_ages'] ) {
			$n       = count( $p['children_ages'] );
			$guests .= sprintf( ', %d %s (%s)', $n, BM_Pricing::pl( $n, 'dziecko', 'dzieci', 'dzieci' ),
				implode( ', ', array_map( fn( $a ) => $a . ' l.', $p['children_ages'] ) ) );
		}
		$out = [
			'Przyjazd' => $date( $q['check_in'] ),
			'Wyjazd'   => $date( $q['check_out'] ),
			'Noce'     => (string) $q['nights'],
			'Goście'   => $guests,
		];
		$beds = [];
		if ( $p['eb_adult'] ) {
			$beds[] = 'dorosła ×' . $p['eb_adult'];
		}
		if ( $p['eb_child'] ) {
			$beds[] = 'dziecięca ×' . $p['eb_child'];
		}
		if ( $beds ) {
			$out['Dostawki'] = implode( ', ', $beds );
		}
		if ( $q['extras'] ) {
			$out['Opcje'] = implode( ', ', array_map( fn( $x ) => $x['name'] . ( $x['qty'] > 1 ? ' ×' . $x['qty'] : '' ), $q['extras'] ) );
		}
		$out['Cena pobytu']       = $money( $q['total'] );
		$out['Zaliczka teraz']    = $money( $bm['deposit'] );
		$out['Pozostało do zapłaty'] = $money( $q['total'] - $bm['deposit'] );
		if ( $q['city_tax']['amount'] > 0 ) {
			$out['Opłata miejscowa'] = $money( $q['city_tax']['amount'] ) . ' — płatna na miejscu';
		}
		if ( ! empty( $bm['terms'] ) ) {
			$out['Warunki pobytu'] = 'zaakceptowane';
		}
		return $out;
	}

	/* ================= ważność blokad ================= */

	/** Upewnia się, że blokada pozycji trzyma termin; jeśli wygasła — próbuje ją odtworzyć. */
	private static function ensure_hold( array $item ): bool {
		$id = (int) $item['bm']['booking_id'];
		if ( BM_Availability::hold_active( $id ) ) {
			return true;
		}
		$b = BM_Availability::get( $id );
		if ( ! $b || ! in_array( $b->status, [ 'hold', 'expired' ], true ) || $b->order_id ) {
			return false;
		}
		return BM_Availability::restore( $id, (int) BM_Settings::get( 'hold_minutes' ) );
	}

	public static function check_items(): void {
		foreach ( self::cart_bookings() as $key => $item ) {
			if ( ! self::ensure_hold( $item ) ) {
				WC()->cart->remove_cart_item( $key );
				wc_add_notice( sprintf( 'Termin %s – %s w „%s” został w międzyczasie zarezerwowany przez kogoś innego. Wybierz inny termin.',
					$item['bm']['quote']['check_in'], $item['bm']['quote']['check_out'], $item['data']->get_name() ), 'error' );
			}
		}
	}

	/** To samo dla blokowego koszyka/checkoutu (Store API). */
	public static function store_api_errors( $errors, $cart ): void {
		foreach ( self::cart_bookings() as $item ) {
			if ( ! self::ensure_hold( $item ) ) {
				$errors->add( 'bm_hold_lost', sprintf( 'Termin w „%s” został w międzyczasie zarezerwowany. Usuń pozycję z koszyka i wybierz inny termin.', $item['data']->get_name() ) );
			}
		}
	}

	public static function removed( $key, $cart ): void {
		$item = $cart->removed_cart_contents[ $key ] ?? ( $cart->cart_contents[ $key ] ?? null );
		if ( ! empty( $item['bm']['booking_id'] ) ) {
			$b = BM_Availability::get( (int) $item['bm']['booking_id'] );
			if ( $b && 'hold' === $b->status && ! $b->order_id ) {
				BM_Availability::release( (int) $b->id, 'cancelled' );
			}
		}
	}

	/* ================= zamówienie ================= */

	public static function order_item_meta( $item, $key, $values, $order ): void {
		if ( empty( $values['bm'] ) ) {
			return;
		}
		$bm = $values['bm'];
		$item->add_meta_data( '_bm_booking_id', (int) $bm['booking_id'], true );
		$item->add_meta_data( '_bm_deposit', (float) $bm['deposit'], true );
		$item->add_meta_data( '_bm_total', (float) $bm['quote']['total'], true );
		if ( ! empty( $bm['terms'] ) ) {
			$item->add_meta_data( '_bm_terms', $bm['terms'], true );
		}
		foreach ( self::describe( $bm ) as $label => $value ) {
			$item->add_meta_data( $label, $value, true );
		}
	}

	/** Rezerwacje zamówienia: [booking_id => pozycja]. */
	private static function order_bookings( WC_Order $order ): array {
		$out = [];
		foreach ( $order->get_items() as $item ) {
			$id = (int) $item->get_meta( '_bm_booking_id' );
			if ( $id ) {
				$out[ $id ] = $item;
			}
		}
		return $out;
	}

	/** Powiązanie rezerwacji z zamówieniem (idempotentne — wywoływane z kilku hooków). */
	public static function link_order( $order ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! $order ) {
			return;
		}
		global $wpdb;
		$b = BM_Installer::table( 'bookings' );

		$stay = 0.0;
		$later = 0.0;
		foreach ( self::order_bookings( $order ) as $booking_id => $item ) {
			$row = BM_Availability::get( $booking_id );
			if ( ! $row ) {
				continue;
			}
			$stay  += (float) $item->get_meta( '_bm_total' );
			$later += (float) $item->get_meta( '_bm_total' ) - (float) $item->get_meta( '_bm_deposit' );
			if ( (int) $row->order_id === $order->get_id() ) {
				continue; // już powiązana
			}
			$arrival = BM_Checkout_Fields::get( $order, 'arrival-time' );
			$wpdb->update( $b, [
				'order_id'      => $order->get_id(),
				'guest_country' => substr( (string) $order->get_billing_country(), 0, 2 ),
				'arrival_time'  => preg_match( '/^\d{2}:\d{2}$/', (string) $arrival ) ? $arrival . ':00' : null,
				'updated_at'    => gmdate( 'Y-m-d H:i:s' ),
			], [ 'id' => $booking_id ] );

			// Na czas płatności blokada co najmniej tak długa jak „wstrzymanie stanu” WooCommerce.
			$minutes = max( (int) BM_Settings::get( 'hold_minutes' ), (int) get_option( 'woocommerce_hold_stock_minutes', 60 ) ?: 60 );
			if ( ! BM_Availability::extend_hold( $booking_id, $minutes ) ) {
				BM_Availability::restore( $booking_id, $minutes );
			}

			$terms = $item->get_meta( '_bm_terms' );
			if ( $terms && is_array( $terms ) && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . BM_Installer::table( 'acceptances' ) . ' WHERE booking_id = %d', $booking_id ) ) ) {
				$wpdb->insert( BM_Installer::table( 'acceptances' ), [
					'booking_id'   => $booking_id,
					'order_id'     => $order->get_id(),
					'context'      => 'booking',
					'content'      => $terms['text'],
					'content_hash' => hash( 'sha256', $terms['text'] ),
					'accepted_at'  => $terms['accepted_at'],
				] );
			}
		}
		if ( $stay > 0 && ! $order->get_meta( '_bm_stay_total' ) ) {
			$order->update_meta_data( '_bm_stay_total', round( $stay, 2 ) );
			$order->update_meta_data( '_bm_balance_due', round( $later, 2 ) );
			$order->save();
		}
	}

	public static function status_changed( $order_id, $from, $to, $order ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order || ! self::order_bookings( $order ) ) {
			return;
		}
		self::link_order( $order );

		foreach ( self::order_bookings( $order ) as $booking_id => $item ) {
			$row = BM_Availability::get( $booking_id );
			if ( ! $row ) {
				continue;
			}
			switch ( $to ) {
				case 'processing':
				case 'completed':
					if ( 'confirmed' === $row->status ) {
						break;
					}
					$ok = BM_Availability::confirm( $booking_id, $order_id )
						|| ( BM_Availability::restore( $booking_id ) && BM_Availability::confirm( $booking_id, $order_id ) );
					if ( $ok ) {
						self::after_confirm( $booking_id, $item );
					} else {
						self::conflict( $order, $row );
					}
					break;

				case 'on-hold': // przelew tradycyjny — termin czeka na wpłatę
					if ( 'confirmed' !== $row->status ) {
						$minutes = (int) BM_Settings::get( 'transfer_hold_hours' ) * 60;
						if ( ! BM_Availability::extend_hold( $booking_id, $minutes ) ) {
							BM_Availability::restore( $booking_id, $minutes );
						}
						do_action( 'bm_booking_pending', $booking_id );
					}
					break;

				case 'cancelled':
				case 'failed':
				case 'refunded':
					if ( 'cancelled' !== $row->status ) {
						BM_Availability::release( $booking_id, 'cancelled' );
						do_action( 'bm_booking_cancelled', $booking_id );
					}
					break;
			}
		}
	}

	public static function after_confirm( int $booking_id, $item ): void {
		global $wpdb;
		$row     = BM_Availability::get( $booking_id );
		$deposit = (float) $item->get_meta( '_bm_deposit' );
		$total   = (float) $item->get_meta( '_bm_total' );
		$days    = (int) BM_Settings::get( 'balance_due_days' );
		$wpdb->update( BM_Installer::table( 'bookings' ), [
			'deposit_paid'     => $deposit,
			'balance_due'      => round( $total - $deposit, 2 ),
			'balance_due_date' => gmdate( 'Y-m-d', strtotime( $row->check_in . " -$days days" ) ),
			'updated_at'       => gmdate( 'Y-m-d H:i:s' ),
		], [ 'id' => $booking_id ] );
		do_action( 'bm_booking_confirmed', $booking_id );
	}

	/** Płatność przyszła, a terminu nie da się już utrzymać — człowiek decyduje (zwrot / inny termin). */
	private static function conflict( WC_Order $order, $row ): void {
		global $wpdb;
		$wpdb->update( BM_Installer::table( 'bookings' ), [ 'status' => 'conflict', 'order_id' => $order->get_id(), 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ], [ 'id' => $row->id ] );
		$msg = sprintf( 'UWAGA: płatność przyszła, ale termin %s – %s w apartamencie #%d jest już zajęty (blokada wygasła przed wpłatą). Skontaktuj się z gościem: zwrot albo inny termin.',
			$row->check_in, $row->check_out, $row->apartment_id );
		$order->add_order_note( $msg );
		wp_mail( get_option( 'admin_email' ), sprintf( '[BookManager] Konflikt rezerwacji — zamówienie #%s', $order->get_order_number() ), $msg . "\n\n" . $order->get_edit_order_url() );
	}
}
