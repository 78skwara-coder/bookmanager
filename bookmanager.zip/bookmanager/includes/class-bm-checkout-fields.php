<?php
defined( 'ABSPATH' ) || exit;

/**
 * Dodatkowe pola zamówienia: planowana godzina przyjazdu i (opcjonalnie) numer dowodu.
 *
 * Blokowy checkout: API dodatkowych pól WooCommerce (woocommerce_register_additional_checkout_field).
 * Klasyczny checkout ([woocommerce_checkout]): własne pola zapisywane pod tymi samymi kluczami,
 * więc dalszy kod (rezerwacje, czyszczenie numeru dowodu) nie musi wiedzieć, skąd przyszły.
 */
class BM_Checkout_Fields {

	const NS = 'bookmanager/';

	public static function init(): void {
		add_action( 'woocommerce_init', [ __CLASS__, 'register_block_fields' ] );
		add_action( 'woocommerce_after_order_notes', [ __CLASS__, 'classic_render' ] );
		add_action( 'woocommerce_checkout_process', [ __CLASS__, 'classic_validate' ] );
		add_action( 'woocommerce_checkout_create_order', [ __CLASS__, 'classic_save' ], 10, 2 );
		add_action( 'bm_purge_id_numbers', [ __CLASS__, 'purge_id_numbers' ] );
		add_action( 'init', [ __CLASS__, 'schedule' ] );
	}

	/** Klucz meta, pod którym WooCommerce zapisuje pole z lokalizacji „order”. */
	public static function meta_key( string $field ): string {
		return '_wc_other/' . self::NS . $field;
	}

	public static function get( WC_Order $order, string $field ): string {
		return (string) $order->get_meta( self::meta_key( $field ) );
	}

	private static function arrival_options(): array {
		$o = [ [ 'value' => '', 'label' => 'nie wiem jeszcze' ] ];
		for ( $h = 12; $h <= 22; $h++ ) {
			$t   = sprintf( '%02d:00', $h );
			$o[] = [ 'value' => $t, 'label' => sprintf( 'ok. %s', $t ) ];
		}
		$o[] = [ 'value' => '23:00', 'label' => 'po 22:00' ];
		return $o;
	}

	private static function cart_has_booking(): bool {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['bm'] ) ) {
				return true;
			}
		}
		return false;
	}

	/* ---------- blokowy checkout ---------- */

	public static function register_block_fields(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field( [
			'id'       => self::NS . 'arrival-time',
			'label'    => 'Planowana godzina przyjazdu',
			'location' => 'order',
			'type'     => 'select',
			'options'  => self::arrival_options(),
			'required' => false,
		] );
		if ( 'yes' === BM_Settings::get( 'collect_id_number' ) ) {
			woocommerce_register_additional_checkout_field( [
				'id'                => self::NS . 'id-number',
				'label'             => 'Numer dowodu osobistego lub paszportu',
				'optionalLabel'     => 'Numer dowodu lub paszportu (opcjonalnie)',
				'location'          => 'order',
				'type'              => 'text',
				'required'          => 'yes' === BM_Settings::get( 'id_number_required' ),
				'sanitize_callback' => fn( $v ) => strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $v ) ),
				'validate_callback' => function ( $v ) {
					if ( '' !== $v && ( strlen( $v ) < 5 || strlen( $v ) > 20 ) ) {
						return new WP_Error( 'bm_id_number', 'Sprawdź numer dokumentu.' );
					}
				},
			] );
		}
	}

	/* ---------- klasyczny checkout ---------- */

	public static function classic_render( $checkout ): void {
		if ( ! self::cart_has_booking() ) {
			return;
		}
		$opts = [];
		foreach ( self::arrival_options() as $o ) {
			$opts[ $o['value'] ] = $o['label'];
		}
		woocommerce_form_field( 'bm_arrival_time', [ 'type' => 'select', 'label' => 'Planowana godzina przyjazdu', 'options' => $opts, 'class' => [ 'form-row-wide' ] ], $checkout->get_value( 'bm_arrival_time' ) );
		if ( 'yes' === BM_Settings::get( 'collect_id_number' ) ) {
			woocommerce_form_field( 'bm_id_number', [
				'type' => 'text', 'label' => 'Numer dowodu osobistego lub paszportu', 'class' => [ 'form-row-wide' ],
				'required' => 'yes' === BM_Settings::get( 'id_number_required' ),
			], $checkout->get_value( 'bm_id_number' ) );
		}
	}

	public static function classic_validate(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- nonce sprawdza WooCommerce.
		if ( ! self::cart_has_booking() || 'yes' !== BM_Settings::get( 'collect_id_number' ) ) {
			return;
		}
		$v = preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['bm_id_number'] ?? '' ) );
		if ( '' === $v && 'yes' === BM_Settings::get( 'id_number_required' ) ) {
			wc_add_notice( 'Podaj numer dowodu osobistego lub paszportu.', 'error' );
		} elseif ( '' !== $v && ( strlen( $v ) < 5 || strlen( $v ) > 20 ) ) {
			wc_add_notice( 'Sprawdź numer dokumentu.', 'error' );
		}
		// phpcs:enable
	}

	public static function classic_save( WC_Order $order, $data ): void {
		// phpcs:disable WordPress.Security.NonceVerification
		if ( isset( $_POST['bm_arrival_time'] ) ) {
			$t = sanitize_text_field( wp_unslash( $_POST['bm_arrival_time'] ) );
			$order->update_meta_data( self::meta_key( 'arrival-time' ), preg_match( '/^\d{2}:\d{2}$/', $t ) ? $t : '' );
		}
		if ( isset( $_POST['bm_id_number'] ) && 'yes' === BM_Settings::get( 'collect_id_number' ) ) {
			$order->update_meta_data( self::meta_key( 'id-number' ), strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['bm_id_number'] ) ) ) );
		}
		// phpcs:enable
	}

	/* ---------- RODO: usuwanie numerów dowodu po wyjeździe ---------- */

	public static function schedule(): void {
		if ( function_exists( 'as_has_scheduled_action' ) && ! as_has_scheduled_action( 'bm_purge_id_numbers' ) ) {
			as_schedule_recurring_action( time() + HOUR_IN_SECONDS, DAY_IN_SECONDS, 'bm_purge_id_numbers', [], 'bookmanager' );
		}
	}

	public static function purge_id_numbers(): int {
		$days = (int) BM_Settings::get( 'id_retention_days' );
		if ( $days < 1 ) {
			return 0;
		}
		global $wpdb;
		$before = gmdate( 'Y-m-d', strtotime( "-$days days" ) );
		$orders = $wpdb->get_col( $wpdb->prepare(
			'SELECT DISTINCT order_id FROM ' . BM_Installer::table( 'bookings' ) . ' WHERE order_id > 0 AND check_out < %s', $before
		) );
		$n = 0;
		foreach ( $orders as $id ) {
			$order = wc_get_order( (int) $id );
			if ( $order && '' !== self::get( $order, 'id-number' ) ) {
				$order->delete_meta_data( self::meta_key( 'id-number' ) );
				$order->add_order_note( 'Numer dowodu usunięty automatycznie po wyjeździe gościa (RODO).' );
				$order->save();
				$n++;
			}
		}
		return $n;
	}
}
