<?php
defined( 'ABSPATH' ) || exit;

/**
 * Zamówienie rezerwacji — bez koszyka, z podsumowaniem pobytu i akceptacją regulaminu.
 *
 * - Gdy w koszyku są apartamenty, strona zamówienia używa klasycznego formularza WooCommerce
 *   ([woocommerce_checkout]) w naszym układzie: pełna kontrola pól, zgód i przycisku, zgodność
 *   z bramkami płatności (Przelewy24 i inne) bez zależności od blokowego checkoutu.
 * - Koszyk nie jest pokazywany: /koszyk → zamówienie (albo lista apartamentów, gdy pusty).
 *   Jego rolę przejmuje podsumowanie obok formularza (zmień termin, usuń, dodaj kolejny apartament)
 *   i pływający pasek „Rozpoczęta rezerwacja” na pozostałych stronach.
 * - Akceptacja Regulaminu i Polityki prywatności na końcu procesu (wymóg operatorów płatności),
 *   zapisywana z datą, IP i odciskiem treści dokumentów.
 * - Przycisk „Rezerwuję z obowiązkiem zapłaty” (art. 17 ustawy o prawach konsumenta).
 */
class BM_Checkout {

	const BUTTON = 'Rezerwuję z obowiązkiem zapłaty';

	public static function init(): void {
		add_filter( 'render_block', [ __CLASS__, 'replace_block' ], 10, 2 );
		add_action( 'template_redirect', [ __CLASS__, 'skip_cart' ], 6 );
		add_filter( 'the_title', [ __CLASS__, 'title' ], 10, 2 );
		add_filter( 'body_class', [ __CLASS__, 'body_class' ] );

		add_filter( 'woocommerce_checkout_fields', [ __CLASS__, 'fields' ], 20 );
		add_filter( 'woocommerce_get_country_locale', [ __CLASS__, 'locale' ], 20 );
		add_filter( 'woocommerce_get_country_locale_default', [ __CLASS__, 'locale_default' ], 20 );
		add_filter( 'woocommerce_checkout_posted_data', [ __CLASS__, 'posted_data' ] );
		add_action( 'woocommerce_after_checkout_validation', [ __CLASS__, 'validate' ], 10, 2 );
		add_action( 'woocommerce_checkout_create_order', [ __CLASS__, 'save_invoice' ], 10, 2 );
		add_action( 'woocommerce_checkout_order_created', [ __CLASS__, 'save_acceptance' ] );

		add_action( 'woocommerce_checkout_before_customer_details', [ __CLASS__, 'summary' ] );
		add_action( 'woocommerce_before_checkout_billing_form', [ __CLASS__, 'heading_guest' ] );
		add_action( 'woocommerce_before_order_notes', [ __CLASS__, 'heading_stay' ] );
		add_action( 'woocommerce_review_order_before_payment', [ __CLASS__, 'heading_payment' ] );
		add_action( 'woocommerce_review_order_before_submit', [ __CLASS__, 'terms_checkbox' ] );
		add_filter( 'woocommerce_checkout_show_terms', [ __CLASS__, 'no_wc_terms' ] );
		add_filter( 'woocommerce_order_button_text', [ __CLASS__, 'button_text' ] );
		add_filter( 'woocommerce_available_payment_gateways', [ __CLASS__, 'gateway_buttons' ], 99 );
		add_action( 'wp', [ __CLASS__, 'unhook_wc' ] );
		add_filter( 'woocommerce_coupons_enabled', [ __CLASS__, 'coupons' ] );

		add_action( 'woocommerce_admin_order_data_after_billing_address', [ __CLASS__, 'admin_invoice' ] );

		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'assets' ], 20 );
		add_filter( 'template_include', [ __CLASS__, 'confirmation_template' ], 99 );
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	/* ================= skrypty i pasek „Rozpoczęta rezerwacja” ================= */

	public static function assets(): void {
		wp_register_script( 'bookmanager-checkout', plugins_url( 'assets/checkout.js', BM_FILE ), [ 'jquery' ], BM_VERSION, true );
		if ( is_admin() || ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) || ( is_page() && get_queried_object_id() === (int) get_option( 'bm_panel_page' ) ) ) {
			return;
		}
		// Mały skrypt na każdej stronie: odzywa się tylko, gdy w koszyku coś jest (ciasteczko WooCommerce), więc działa też z cache stron.
		wp_enqueue_script( 'bookmanager-cart', plugins_url( 'assets/cart.js', BM_FILE ), [], BM_VERSION, [ 'in_footer' => true, 'strategy' => 'defer' ] );
		$a = BM_Appearance::all();
		wp_add_inline_script( 'bookmanager-cart', 'window.BM_CART=' . wp_json_encode( [
			'api'    => rest_url( BM_REST::NS . '/cart' ),
			'accent' => $a['accent'] ?: '#1f1f1f',
			'on'     => BM_Appearance::readable_on( $a['accent'] ?: '#1f1f1f' ),
		] ) . ';', 'before' );
	}

	public static function routes(): void {
		register_rest_route( BM_REST::NS, '/cart', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'rest_cart' ],
			'permission_callback' => '__return_true',
		] );
	}

	/** Co gość ma rozpoczęte — bez danych osobowych, tylko apartament i termin. */
	public static function rest_cart() {
		if ( function_exists( 'wc_load_cart' ) && ! WC()->cart ) {
			wc_load_cart();
		}
		$items = [];
		$exp   = PHP_INT_MAX;
		foreach ( self::items() as $it ) {
			$q       = $it['bm']['quote'];
			$p       = wc_get_product( (int) $it['product_id'] );
			$items[] = [ 'name' => $p ? $p->get_name() : '', 'dates' => self::short_date( $q['check_in'] ) . ' – ' . self::short_date( $q['check_out'] ) ];
			$row     = BM_Availability::get( (int) $it['bm']['booking_id'] );
			if ( $row && 'hold' === $row->status && $row->hold_expires ) {
				$exp = min( $exp, strtotime( $row->hold_expires . ' UTC' ) );
			}
		}
		$res = new WP_REST_Response( [
			'items'    => $items,
			'checkout' => wc_get_checkout_url(),
			'left'     => PHP_INT_MAX === $exp ? null : max( 0, $exp - time() ),
		] );
		$res->header( 'Cache-Control', 'no-store, private' );
		return $res;
	}

	/* ================= kiedy działamy ================= */

	/** Rezerwacje w koszyku: klucz => pozycja. */
	public static function items(): array {
		if ( ! function_exists( 'WC' ) || ! did_action( 'wp_loaded' ) || ! WC()->cart ) {
			return [];
		}
		return array_filter( WC()->cart->get_cart(), fn( $i ) => ! empty( $i['bm'] ) );
	}

	/** Koszyk z apartamentami na stronie zamówienia (bez „zapłać za zamówienie” i „dziękujemy”). */
	public static function active(): bool {
		static $on = null;
		if ( null !== $on && did_action( 'wp' ) ) {
			return $on;
		}
		$v = (bool) self::items() && ( is_checkout() || wp_doing_ajax() || ( defined( 'WOOCOMMERCE_CHECKOUT' ) && WOOCOMMERCE_CHECKOUT ) )
			&& ! is_wc_endpoint_url( 'order-received' ) && ! is_wc_endpoint_url( 'order-pay' );
		if ( did_action( 'wp' ) ) {
			$on = $v;
		}
		return $v;
	}

	public static function unhook_wc(): void {
		if ( self::active() ) {
			// Link „Regulamin” ma otwierać stronę, a nie rozwijać treść pod formularzem.
			remove_action( 'woocommerce_checkout_terms_and_conditions', 'wc_terms_and_conditions_page_content', 30 );
			remove_action( 'woocommerce_checkout_terms_and_conditions', 'wc_checkout_privacy_policy_text', 20 );
			remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
		}
	}

	/* ================= bez koszyka ================= */

	public static function skip_cart(): void {
		if ( ! function_exists( 'is_cart' ) || ! is_cart() || ! WC()->cart ) {
			return;
		}
		if ( self::items() ) {
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		if ( WC()->cart->is_empty() ) {
			wp_safe_redirect( BM_Site::list_url() );
			exit;
		}
	}

	/** Blokowy checkout → klasyczny formularz w naszym układzie (tylko z rezerwacjami w koszyku). */
	public static function replace_block( $html, $block ) {
		if ( 'woocommerce/checkout' !== ( $block['blockName'] ?? '' ) || is_admin() || ! self::active() ) {
			return $html;
		}
		return self::page();
	}

	public static function page(): string {
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_script( 'bookmanager-checkout' );
		$a = BM_Appearance::all();
		return sprintf(
			'<div class="bm-ui bm-co alignwide %s" style="%s">%s%s<div class="bm-co__form">%s</div></div>',
			esc_attr( BM_Appearance::classes( $a ) ),
			esc_attr( BM_Appearance::style_vars( $a ) ),
			self::crumbs(),
			self::steps( 2 ),
			do_shortcode( '[woocommerce_checkout]' )
		);
	}

	public static function crumbs(): string {
		return '<nav class="bm-crumbs" aria-label="' . esc_attr__( 'Nawigacja', 'bookmanager' ) . '"><a class="bm-crumbs__back" href="' . esc_url( BM_Site::list_url( self::search_args() ) ) . '">'
			. BM_Page::icon( 'left' ) . esc_html__( 'Wróć do apartamentów', 'bookmanager' ) . '</a></nav>';
	}

	/** Kroki: 1 termin, 2 dane i płatność, 3 potwierdzenie. */
	public static function steps( int $current ): string {
		$names = [ 1 => __( 'Termin i goście', 'bookmanager' ), 2 => __( 'Dane i płatność', 'bookmanager' ), 3 => __( 'Potwierdzenie', 'bookmanager' ) ];
		$html  = '<ol class="bm-co-steps">';
		foreach ( $names as $i => $n ) {
			$html .= sprintf( '<li class="bm-co-steps__item%s"%s><span class="bm-co-steps__num">%s</span><span>%s</span></li>',
				$i < $current ? ' is-done' : ( $i === $current ? ' is-current' : '' ),
				$i === $current ? ' aria-current="step"' : '',
				$i < $current ? BM_Page::icon( 'check' ) : $i,
				esc_html( $n ) );
		}
		return $html . '</ol>';
	}

	/** Termin i goście pierwszej rezerwacji — do linków „wróć” i „dodaj kolejny”. */
	public static function search_args(): array {
		foreach ( self::items() as $item ) {
			$q = $item['bm']['quote'];
			return [ 'bm_in' => $q['check_in'], 'bm_out' => $q['check_out'], 'bm_adults' => $q['party']['adults'], 'bm_children' => implode( ',', $q['party']['children_ages'] ) ];
		}
		return [];
	}

	public static function title( $title, $id = 0 ) {
		if ( $id && (int) $id === wc_get_page_id( 'checkout' ) && ! is_admin() && in_the_loop() && self::items() && ! is_wc_endpoint_url() ) {
			return __( 'Dokończ rezerwację', 'bookmanager' );
		}
		return $title;
	}

	public static function body_class( array $c ): array {
		if ( function_exists( 'is_checkout' ) && is_checkout() && self::items() && ! is_wc_endpoint_url() ) {
			$c[] = 'bm-checkout-page';
		}
		return $c;
	}

	/* ================= podsumowanie (zamiast koszyka) ================= */

	public static function summary(): void {
		if ( ! self::active() ) {
			return;
		}
		$items   = self::items();
		$stay    = 0.0;
		$now     = 0.0;
		$tax     = 0.0;
		$expires = PHP_INT_MAX;
		$cards   = '';
		foreach ( $items as $key => $item ) {
			$bm      = $item['bm'];
			$q       = $bm['quote'];
			$p       = wc_get_product( (int) $item['product_id'] );
			$stay   += (float) $q['total'];
			$now    += (float) $bm['deposit'];
			$tax    += (float) ( $q['city_tax']['amount'] ?? 0 );
			$row     = BM_Availability::get( (int) $bm['booking_id'] );
			if ( $row && 'hold' === $row->status && $row->hold_expires ) {
				$expires = min( $expires, strtotime( $row->hold_expires . ' UTC' ) );
			}
			$cards .= self::summary_item( $key, $item, $p );
		}
		$later = $stay - $now;
		$left  = PHP_INT_MAX === $expires ? 0 : max( 0, $expires - time() );

		$add = count( $items ) < BM_Cart::MAX_ITEMS
			? '<a class="bm-co-sum__add" href="' . esc_url( BM_Site::list_url( self::search_args() ) ) . '">+ ' . esc_html__( 'Dodaj kolejny apartament', 'bookmanager' ) . '</a>'
			: '';

		$lines  = self::line( __( 'Cena pobytu', 'bookmanager' ), $stay );
		if ( $later > 0.004 ) {
			$lines .= self::line( (string) BM_Settings::get( 'balance_label' ), $later, 'is-muted' );
		}
		if ( $tax > 0 ) {
			$lines .= '<li class="bm-co-sum__line is-muted"><span>' . esc_html__( 'Opłata miejscowa', 'bookmanager' ) . '</span><span>' . wp_kses_post( wc_price( $tax ) ) . ' · ' . esc_html__( 'na miejscu', 'bookmanager' ) . '</span></li>';
		}
		$lines .= '<li class="bm-co-sum__line is-total"><span>' . esc_html( $later > 0.004 ? __( 'Do zapłaty teraz (zaliczka)', 'bookmanager' ) : __( 'Do zapłaty teraz', 'bookmanager' ) ) . '</span><span>' . wp_kses_post( wc_price( $now ) ) . '</span></li>';

		printf(
			'<aside class="bm-co-sum" aria-label="%1$s"><details class="bm-co-sum__box" open><summary class="bm-co-sum__head"><span class="bm-co-sum__title">%1$s</span><span class="bm-co-sum__toggle">%2$s</span></summary>%3$s<div class="bm-co-sum__items">%4$s</div>%5$s<ul class="bm-co-sum__lines">%6$s</ul></details>%7$s</aside>',
			esc_html__( 'Twoja rezerwacja', 'bookmanager' ),
			wp_kses_post( wc_price( $now ) ),
			$left ? '<p class="bm-co-sum__timer" data-bm-expires="' . (int) $left . '">' . BM_Page::icon( 'moon' ) . '<span>' . esc_html__( 'Termin czeka na Ciebie jeszcze', 'bookmanager' ) . ' <strong>' . esc_html( gmdate( 'i:s', $left ) ) . '</strong></span></p>' : '',
			$cards,
			$add,
			$lines,
			'<p class="bm-co-sum__safe">' . BM_Page::icon( 'check' ) . esc_html__( 'Potwierdzenie rezerwacji otrzymasz e-mailem zaraz po płatności.', 'bookmanager' ) . '</p>'
		);
	}

	private static function line( string $label, float $amount, string $cls = '' ): string {
		return '<li class="bm-co-sum__line ' . esc_attr( $cls ) . '"><span>' . esc_html( $label ) . '</span><span>' . wp_kses_post( wc_price( $amount ) ) . '</span></li>';
	}

	private static function summary_item( string $key, array $item, $p ): string {
		$bm   = $item['bm'];
		$q    = $bm['quote'];
		$pt   = $q['party'];
		$img  = $p && $p->get_image_id() ? wp_get_attachment_image( $p->get_image_id(), 'thumbnail', false, [ 'class' => 'bm-img', 'alt' => '' ] ) : '';
		$d    = [ __CLASS__, 'short_date' ];
		$who  = sprintf( '%d %s', $pt['adults'], BM_Pricing::pl( $pt['adults'], 'dorosły', 'dorosłych', 'dorosłych' ) );
		if ( $pt['children_ages'] ) {
			$n    = count( $pt['children_ages'] );
			$who .= sprintf( ', %d %s', $n, BM_Pricing::pl( $n, 'dziecko', 'dzieci', 'dzieci' ) );
		}
		$extra = array_map( fn( $x ) => $x['name'] . ( $x['qty'] > 1 ? ' ×' . $x['qty'] : '' ), (array) $q['extras'] );
		if ( $pt['eb_adult'] + $pt['eb_child'] ) {
			array_unshift( $extra, sprintf( 'dostawka ×%d', $pt['eb_adult'] + $pt['eb_child'] ) );
		}
		$edit = $p ? add_query_arg( array_map( 'rawurlencode', array_filter( [
			'bm_in' => $q['check_in'], 'bm_out' => $q['check_out'], 'bm_adults' => $pt['adults'], 'bm_children' => implode( ',', $pt['children_ages'] ),
		], 'strlen' ) ), $p->get_permalink() ) . '#bm-rezerwacja' : '';

		return sprintf(
			'<div class="bm-co-item"><div class="bm-co-item__img">%s</div><div class="bm-co-item__body"><strong class="bm-co-item__name">%s</strong>'
			. '<span class="bm-co-item__dates">%s → %s · %s</span><span class="bm-co-item__who">%s</span>%s'
			. '<span class="bm-co-item__acts"><a href="%s">%s</a><a href="%s" class="bm-co-item__rm" data-bm-confirm="%s">%s</a></span></div>'
			. '<span class="bm-co-item__price">%s</span></div>',
			$img,
			esc_html( $p ? $p->get_name() : '' ),
			esc_html( $d( $q['check_in'] ) ),
			esc_html( $d( $q['check_out'] ) ),
			esc_html( sprintf( '%d %s', $q['nights'], BM_Pricing::pl( $q['nights'], 'noc', 'noce', 'nocy' ) ) ),
			esc_html( $who ),
			$extra ? '<span class="bm-co-item__extra">' . esc_html( implode( ', ', $extra ) ) . '</span>' : '',
			esc_url( $edit ),
			esc_html__( 'Zmień termin lub gości', 'bookmanager' ),
			esc_url( wc_get_cart_remove_url( $key ) ),
			esc_attr__( 'Usunąć ten apartament z rezerwacji? Termin zostanie zwolniony.', 'bookmanager' ),
			esc_html__( 'Usuń', 'bookmanager' ),
			wp_kses_post( wc_price( (float) $q['total'] ) )
		);
	}

	/* ================= pola ================= */

	public static function fields( array $f ): array {
		if ( ! self::active() ) {
			return $f;
		}
		$b    = $f['billing'] ?? [];
		$keep = [];
		$set  = function ( string $k, array $def ) use ( &$keep, $b ) {
			$keep[ $k ] = array_merge( $b[ $k ] ?? [], $def );
		};
		$set( 'billing_first_name', [ 'label' => 'Imię', 'required' => true, 'class' => [ 'form-row-first' ], 'priority' => 10, 'autocomplete' => 'given-name' ] );
		$set( 'billing_last_name', [ 'label' => 'Nazwisko', 'required' => true, 'class' => [ 'form-row-last' ], 'priority' => 20, 'autocomplete' => 'family-name' ] );
		$set( 'billing_email', [ 'label' => 'E-mail', 'required' => true, 'class' => [ 'form-row-first' ], 'priority' => 30, 'description' => 'Na ten adres wyślemy potwierdzenie.' ] );
		$set( 'billing_phone', [ 'label' => 'Telefon', 'required' => true, 'class' => [ 'form-row-last' ], 'priority' => 40, 'description' => 'Na wypadek pytań przed przyjazdem.' ] );
		$set( 'billing_country', [ 'label' => 'Kraj zamieszkania', 'required' => true, 'class' => [ 'form-row-wide', 'address-field', 'update_totals_on_change' ], 'priority' => 50 ] );
		$keep['billing_bm_invoice'] = [ 'type' => 'checkbox', 'label' => 'Potrzebuję faktury', 'required' => false, 'class' => [ 'form-row-wide', 'bm-inv-toggle' ], 'priority' => 60 ];
		$inv = [ 'required' => false, 'class' => [ 'form-row-wide', 'bm-inv' ] ];
		$set( 'billing_company', array_merge( $inv, [ 'label' => 'Nazwa firmy', 'priority' => 61 ] ) );
		$keep['billing_nip'] = array_merge( $inv, [ 'type' => 'text', 'label' => 'NIP', 'priority' => 62, 'class' => [ 'form-row-first', 'bm-inv' ] ] );
		$set( 'billing_address_1', array_merge( $inv, [ 'label' => 'Ulica i numer', 'placeholder' => '', 'priority' => 63, 'class' => [ 'form-row-last', 'bm-inv' ] ] ) );
		$set( 'billing_postcode', array_merge( $inv, [ 'label' => 'Kod pocztowy', 'priority' => 64, 'class' => [ 'form-row-first', 'bm-inv' ] ] ) );
		$set( 'billing_city', array_merge( $inv, [ 'label' => 'Miejscowość', 'priority' => 65, 'class' => [ 'form-row-last', 'bm-inv' ] ] ) );
		$f['billing'] = $keep;
		$f['shipping'] = [];
		if ( isset( $f['order']['order_comments'] ) ) {
			$f['order']['order_comments']['label']       = 'Uwagi do pobytu (opcjonalnie)';
			$f['order']['order_comments']['placeholder'] = 'np. przyjedziemy z psem, prosimy o łóżeczko, późny przyjazd';
		}
		return $f;
	}

	/** Adres tylko przy fakturze — nie wymagamy go po kraju (inaczej WooCommerce oznacza pola jako obowiązkowe). */
	public static function locale( $locale ) {
		if ( ! self::active() || ! is_array( $locale ) ) {
			return $locale;
		}
		foreach ( $locale as $cc => $fields ) {
			foreach ( [ 'address_1', 'postcode', 'city', 'state' ] as $k ) {
				$locale[ $cc ][ $k ]['required'] = false;
			}
			$locale[ $cc ]['state']['hidden'] = true;
		}
		return $locale;
	}

	public static function locale_default( $d ) {
		if ( self::active() && is_array( $d ) ) {
			foreach ( [ 'address_1', 'postcode', 'city', 'state' ] as $k ) {
				$d[ $k ]['required'] = false;
			}
		}
		return $d;
	}

	/** Bez faktury adres nie jest potrzebny — czyścimy ukryte pola (stare wartości z sesji nie blokują rezerwacji). */
	public static function posted_data( $data ) {
		// phpcs:ignore WordPress.Security.NonceVerification -- nonce sprawdza WooCommerce
		if ( ! is_array( $data ) || ! self::active() ) {
			return $data;
		}
		if ( empty( $_POST['billing_bm_invoice'] ) ) {
			foreach ( [ 'billing_company', 'billing_address_1', 'billing_address_2', 'billing_postcode', 'billing_city', 'billing_state' ] as $k ) {
				unset( $data[ $k ] ); // pole pominięte = bez walidacji WooCommerce
			}
		} elseif ( isset( $data['billing_postcode'] ) && '' === trim( (string) $data['billing_postcode'] ) ) {
			unset( $data['billing_postcode'] ); // pusty kod PL WooCommerce zamienia na „-” i zgłasza błąd; brak kodu zgłaszamy sami
		}
		return $data;
	}

	/** Faktura: komplet danych. Regulamin: zaznaczony. */
	public static function validate( $data, $errors ): void {
		if ( ! self::active() ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- nonce sprawdza WooCommerce.
		if ( ! empty( $_POST['billing_bm_invoice'] ) ) {
			foreach ( [ 'billing_company' => 'nazwę firmy', 'billing_nip' => 'NIP', 'billing_address_1' => 'ulicę i numer', 'billing_postcode' => 'kod pocztowy', 'billing_city' => 'miejscowość' ] as $k => $name ) {
				if ( '' === trim( (string) wp_unslash( $_POST[ $k ] ?? '' ) ) ) {
					$errors->add( $k . '_required', sprintf( 'Do faktury podaj %s.', $name ), [ 'id' => $k ] );
				}
			}
			$nip = preg_replace( '/[^0-9A-Za-z]/', '', (string) wp_unslash( $_POST['billing_nip'] ?? '' ) );
			if ( $nip && 'PL' === ( $data['billing_country'] ?? 'PL' ) && ! self::nip_ok( $nip ) ) {
				$errors->add( 'billing_nip_invalid', 'Sprawdź NIP — ten numer jest nieprawidłowy.', [ 'id' => 'billing_nip' ] );
			}
		}
		if ( self::legal_links() && empty( $_POST['terms'] ) ) {
			$errors->add( 'terms', 'Zaakceptuj Regulamin i Politykę prywatności, aby złożyć rezerwację.', [ 'id' => 'terms' ] );
		}
		// phpcs:enable
	}

	public static function nip_ok( string $nip ): bool {
		$nip = preg_replace( '/^PL/i', '', $nip );
		if ( ! preg_match( '/^\d{10}$/', $nip ) ) {
			return false;
		}
		$w   = [ 6, 5, 7, 2, 3, 4, 5, 6, 7 ];
		$sum = 0;
		foreach ( $w as $i => $x ) {
			$sum += $x * (int) $nip[ $i ];
		}
		return $sum % 11 === (int) $nip[9];
	}

	public static function save_invoice( WC_Order $order, $data ): void {
		if ( ! self::items() ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification
		$want = ! empty( $_POST['billing_bm_invoice'] );
		$order->update_meta_data( '_bm_invoice', $want ? 'yes' : 'no' );
		$order->delete_meta_data( '_billing_bm_invoice' );
		if ( $want ) {
			$order->update_meta_data( '_billing_nip', strtoupper( preg_replace( '/[^0-9A-Za-z]/', '', (string) wp_unslash( $_POST['billing_nip'] ?? '' ) ) ) );
		} else {
			$order->delete_meta_data( '_billing_nip' );
		}
		// phpcs:enable
	}

	public static function admin_invoice( $order ): void {
		if ( 'yes' === $order->get_meta( '_bm_invoice' ) ) {
			printf( '<p><strong>%s</strong> NIP %s</p>', esc_html__( 'Faktura:', 'bookmanager' ), esc_html( (string) $order->get_meta( '_billing_nip' ) ) );
		}
	}

	/* ================= nagłówki sekcji ================= */

	public static function heading_guest(): void {
		if ( self::active() ) {
			echo '<h2 class="bm-co__h"><span class="bm-co__hn">1</span>' . esc_html__( 'Dane gościa', 'bookmanager' ) . '</h2>';
		}
	}

	public static function heading_stay(): void {
		if ( self::active() ) {
			echo '<h2 class="bm-co__h"><span class="bm-co__hn">2</span>' . esc_html__( 'Przyjazd i uwagi', 'bookmanager' ) . '</h2>';
		}
	}

	public static function heading_payment(): void {
		if ( self::active() ) {
			echo '<h2 class="bm-co__h"><span class="bm-co__hn">3</span>' . esc_html__( 'Płatność', 'bookmanager' ) . '</h2>';
		}
	}

	/* ================= regulamin i przycisk ================= */

	/** [klucz => [nazwa w zdaniu, adres]] dla opublikowanych stron. */
	public static function legal_links(): array {
		$out = [];
		if ( $u = BM_Site::page_url( 'terms_page' ) ) { // phpcs:ignore
			$out['terms'] = [ __( 'Regulamin', 'bookmanager' ), $u ];
		}
		if ( $u = BM_Site::page_url( 'privacy_page' ) ) { // phpcs:ignore
			$out['privacy'] = [ __( 'Politykę prywatności', 'bookmanager' ), $u ];
		}
		return $out;
	}

	/** Treść zgody (HTML z linkami albo zwykły tekst do zapisu). */
	public static function terms_text( bool $html = true ): string {
		$links = array_map( fn( $l ) => $html
			? '<a href="' . esc_url( $l[1] ) . '" target="_blank" rel="noopener">' . esc_html( $l[0] ) . '</a>'
			: $l[0] . ' (' . $l[1] . ')', self::legal_links() );
		return sprintf( 'Akceptuję %s.', implode( ' i ', $links ) );
	}

	public static function no_wc_terms( $show ) {
		return self::active() ? false : $show;
	}

	public static function terms_checkbox(): void {
		if ( ! self::active() || ! self::legal_links() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification -- zachowanie stanu po odświeżeniu fragmentu
		$checked = ! empty( $_POST['terms'] ) || ( isset( $_POST['post_data'] ) && str_contains( (string) wp_unslash( $_POST['post_data'] ), 'terms=on' ) );
		printf(
			'<div class="bm-co-terms"><p class="form-row validate-required" id="terms_field"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">'
			. '<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms" id="terms"%s> '
			. '<span class="bm-co-terms__text">%s&nbsp;<abbr class="required" title="%s">*</abbr></span></label></p>'
			. '<p class="bm-co-terms__note">%s</p></div>',
			$checked ? ' checked' : '',
			wp_kses( self::terms_text(), [ 'a' => [ 'href' => true, 'target' => true, 'rel' => true ] ] ),
			esc_attr__( 'wymagane', 'bookmanager' ),
			esc_html__( 'Rezerwacja noclegu na konkretny termin nie podlega 14-dniowemu prawu odstąpienia od umowy (art. 38 pkt 12 ustawy o prawach konsumenta). Zasady anulowania opisuje regulamin.', 'bookmanager' )
		);
	}

	public static function button_text( $text ) {
		return self::active() ? __( self::BUTTON, 'bookmanager' ) : $text; // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText
	}

	/** Bramki z własnym napisem na przycisku (np. „Przejdź do płatności”) — zostaje nasz, wymagany prawem. */
	public static function gateway_buttons( $gateways ) {
		if ( is_array( $gateways ) && self::active() ) {
			foreach ( $gateways as $g ) {
				if ( is_object( $g ) && property_exists( $g, 'order_button_text' ) ) {
					$g->order_button_text = null;
				}
			}
		}
		return $gateways;
	}

	/** Pole kodu rabatowego tylko wtedy, gdy jakiś kod istnieje — puste pole kusi do szukania kodów i porzucenia rezerwacji. */
	public static function coupons( $on ) {
		static $any = null;
		if ( ! $on || ! self::active() ) {
			return $on;
		}
		if ( null === $any ) {
			$any = (bool) get_posts( [ 'post_type' => 'shop_coupon', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids' ] );
		}
		return $any;
	}

	/** „sob., 12 gru 2026” — niezależnie od języka WordPressa. */
	public static function short_date( string $date ): string {
		$t   = strtotime( $date . ' 12:00:00 UTC' );
		$dow = [ 'nd.', 'pn.', 'wt.', 'śr.', 'czw.', 'pt.', 'sob.' ];
		$mon = [ 'sty', 'lut', 'mar', 'kwi', 'maj', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru' ];
		return $dow[ (int) gmdate( 'w', $t ) ] . ' ' . (int) gmdate( 'j', $t ) . ' ' . $mon[ (int) gmdate( 'n', $t ) - 1 ] . ' ' . gmdate( 'Y', $t );
	}

	/** Zapis zgody: treść z adresami, data, IP i odcisk aktualnej treści dokumentów (wersja). */
	public static function save_acceptance( $order ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! $order || ! self::legal_links() || $order->get_meta( '_bm_legal_accepted' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification
		if ( empty( $_POST['terms'] ) ) {
			return;
		}
		$docs = [];
		foreach ( [ 'terms_page', 'privacy_page' ] as $k ) {
			$id = (int) BM_Site::get( $k );
			$p  = $id ? get_post( $id ) : null;
			if ( $p ) {
				$docs[ $k ] = [ 'id' => $id, 'modified' => $p->post_modified_gmt, 'hash' => hash( 'sha256', (string) $p->post_content ) ];
			}
		}
		$text = self::terms_text( false );
		$when = gmdate( 'Y-m-d H:i:s' );
		$ip   = BM_Log::ip();
		$order->update_meta_data( '_bm_legal_accepted', [ 'text' => $text, 'at' => $when, 'ip' => $ip, 'docs' => $docs ] );
		$order->add_order_note( sprintf( 'Gość zaakceptował: %s (%s UTC, IP %s).', $text, $when, $ip ?: '—' ) );
		$order->save();

		global $wpdb;
		$content = $text . "\n" . wp_json_encode( $docs );
		$wpdb->insert( BM_Installer::table( 'acceptances' ), [
			'booking_id'   => 0,
			'order_id'     => $order->get_id(),
			'context'      => 'checkout',
			'content'      => $content,
			'content_hash' => hash( 'sha256', $content ),
			'accepted_at'  => $when,
			'ip'           => $ip,
		] );
	}

	/* ================= potwierdzenie (krok 3) ================= */

	/** Zamówienie z adresu „dziękujemy” — tylko z poprawnym kluczem. */
	public static function received_order(): ?WC_Order {
		static $o = false;
		if ( false !== $o ) {
			return $o;
		}
		$o = null;
		if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( 'order-received' ) ) {
			return null;
		}
		$id    = absint( get_query_var( 'order-received' ) );
		$order = $id ? wc_get_order( $id ) : null;
		// phpcs:ignore WordPress.Security.NonceVerification -- klucz zamówienia jak w WooCommerce
		$key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
		if ( $order && hash_equals( $order->get_order_key(), (string) $key ) && self::order_bookings( $order ) ) {
			$o = $order;
		}
		return $o;
	}

	public static function order_bookings( WC_Order $order ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . BM_Installer::table( 'bookings' ) . ' WHERE order_id = %d ORDER BY check_in', $order->get_id() ) );
	}

	public static function confirmation_template( $template ) {
		if ( self::received_order() ) {
			wp_enqueue_style( 'bookmanager' );
			return BM_PATH . 'templates/confirmation.php';
		}
		return $template;
	}

	public static function confirmation( ?WC_Order $order ): string {
		if ( ! $order ) {
			return '';
		}
		$bookings = self::order_bookings( $order );
		$status   = $order->get_status();
		$name     = $order->get_billing_first_name();
		$email    = $order->get_meta( '_bm_no_email' ) ? '' : $order->get_billing_email();
		$money    = fn( $v ) => wp_kses_post( wc_price( (float) $v ) );
		$paid     = in_array( $status, [ 'processing', 'completed' ], true );

		if ( $paid ) {
			$state = 'ok';
			$head  = $name ? sprintf( 'Dziękujemy, %s! Rezerwacja potwierdzona.', $name ) : 'Dziękujemy! Rezerwacja potwierdzona.';
			$sub   = $email ? sprintf( 'Potwierdzenie wysłaliśmy na adres %s.', $email ) : 'Szczegóły znajdziesz poniżej.';
		} elseif ( 'on-hold' === $status ) {
			$state = 'wait';
			$until = '';
			foreach ( $bookings as $b ) {
				if ( 'hold' === $b->status && $b->hold_expires ) {
					$until = wp_date( 'j.m.Y, H:i', strtotime( $b->hold_expires . ' UTC' ) );
					break;
				}
			}
			$head = $name ? sprintf( 'Dziękujemy, %s! Termin czeka na Twoją wpłatę.', $name ) : 'Dziękujemy! Termin czeka na Twoją wpłatę.';
			$sub  = sprintf( 'Rezerwację potwierdzimy po zaksięgowaniu %s%s.', wp_strip_all_tags( wc_price( (float) $order->get_total() ) ), $until ? ' — wpłać do ' . $until : '' );
		} elseif ( in_array( $status, [ 'pending', 'failed' ], true ) ) {
			$state = 'fail';
			$head  = 'Płatność nie została zakończona';
			$sub   = 'Termin jest jeszcze chwilę zarezerwowany dla Ciebie — dokończ płatność, aby potwierdzić pobyt.';
		} else {
			$state = 'wait';
			$head  = 'Rezerwacja przyjęta';
			$sub   = 'Szczegóły znajdziesz poniżej.';
		}

		$stays = '';
		$total = 0.0;
		foreach ( $bookings as $b ) {
			$p      = wc_get_product( (int) $b->apartment_id );
			$total += (float) $b->total;
			$who    = sprintf( '%d %s', $b->adults, BM_Pricing::pl( (int) $b->adults, 'dorosły', 'dorosłych', 'dorosłych' ) );
			if ( (int) $b->children ) {
				$who .= sprintf( ', %d %s', $b->children, BM_Pricing::pl( (int) $b->children, 'dziecko', 'dzieci', 'dzieci' ) );
			}
			$nights = (int) round( ( strtotime( $b->check_out ) - strtotime( $b->check_in ) ) / DAY_IN_SECONDS );
			$stays .= sprintf(
				'<div class="bm-conf__stay">%s<div><strong>%s</strong><dl class="bm-conf__dl"><div><dt>Przyjazd</dt><dd>%s</dd></div><div><dt>Wyjazd</dt><dd>%s</dd></div><div><dt>Pobyt</dt><dd>%s · %s</dd></div></dl></div></div>',
				$p && $p->get_image_id() ? wp_get_attachment_image( $p->get_image_id(), 'medium', false, [ 'class' => 'bm-img bm-conf__img', 'alt' => '' ] ) : '',
				esc_html( $p ? $p->get_name() : '' ),
				esc_html( BM_Notify::date_long( $b->check_in ) ),
				esc_html( BM_Notify::date_long( $b->check_out ) ),
				esc_html( sprintf( '%d %s', $nights, BM_Pricing::pl( $nights, 'noc', 'noce', 'nocy' ) ) ),
				esc_html( $who )
			);
		}
		$later = (float) $order->get_meta( '_bm_balance_due' );
		$lines = '<li><span>Cena pobytu</span><span>' . $money( $total ) . '</span></li>'
			. '<li><span>' . ( $paid ? 'Wpłacono' : 'Do wpłaty teraz' ) . '</span><span>' . $money( $order->get_total() ) . '</span></li>';
		if ( $later > 0.004 ) {
			$due    = $bookings[0]->balance_due_date ?? '';
			$lines .= '<li class="is-muted"><span>' . esc_html( (string) BM_Settings::get( 'balance_label' ) ) . ( $due ? ' · do ' . esc_html( BM_Notify::date_long( $due ) ) : '' ) . '</span><span>' . $money( $later ) . '</span></li>';
		}

		// Bramki płatności i statystyki (np. Przelewy24, dane przelewu, Google Analytics) dopisują się tutaj.
		remove_action( 'woocommerce_thankyou', 'woocommerce_order_details_table', 10 ); // szczegóły pokazujemy sami
		ob_start();
		do_action( 'woocommerce_before_thankyou', $order->get_id() );
		do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() );
		do_action( 'woocommerce_thankyou', $order->get_id() );
		$gw = trim( (string) ob_get_clean() );

		$site    = BM_Site::all();
		$contact = '';
		if ( $site['phone'] ) {
			$contact .= '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $site['phone'] ) ) . '">' . BM_Page::icon( 'phone' ) . esc_html( $site['phone'] ) . '</a>';
		}
		$mail = $site['email'] ?: '';
		if ( $mail ) {
			$contact .= '<a href="mailto:' . esc_attr( $mail ) . '">' . BM_Page::icon( 'mail' ) . esc_html( $mail ) . '</a>';
		}
		$next = [];
		if ( 'wait' === $state ) {
			$next[] = 'Po zaksięgowaniu wpłaty wyślemy e-mail z potwierdzeniem rezerwacji.';
		}
		if ( $email ) {
			$next[] = 'Przed przyjazdem przypomnimy o terminie i prześlemy informacje o zameldowaniu.';
		}
		if ( $later > 0.004 ) {
			$next[] = 'Pozostałą kwotę zapłacisz zgodnie z regulaminem — przypomnimy o niej.';
		}
		$next[] = 'Masz pytania lub chcesz coś zmienić? Napisz albo zadzwoń — podaj numer rezerwacji.';

		$a = BM_Appearance::all();
		return sprintf(
			'<div class="bm-ui bm-co bm-conf alignwide %1$s" style="%2$s">%3$s<section class="bm-conf__card bm-conf--%4$s"><span class="bm-conf__badge">%5$s</span><h1 class="bm-conf__title">%6$s</h1><p class="bm-conf__sub">%7$s</p>'
			. '<p class="bm-conf__no">Numer rezerwacji: <strong>%8$s</strong></p>%9$s</section>'
			. '<div class="bm-conf__grid"><section class="bm-conf__box"><h2 class="bm-co__h">Twój pobyt</h2>%10$s<ul class="bm-conf__lines">%11$s</ul></section>'
			. '<section class="bm-conf__box"><h2 class="bm-co__h">Co dalej?</h2><ul class="bm-conf__next">%12$s</ul>%13$s%14$s</section></div>'
			. '<p class="bm-conf__home"><a class="bm-btn bm-btn--ghost" href="%15$s">Wróć na stronę główną</a></p></div>',
			esc_attr( BM_Appearance::classes( $a ) ),
			esc_attr( BM_Appearance::style_vars( $a ) ),
			self::steps( 'ok' === $state ? 4 : 3 ),
			esc_attr( $state ),
			'ok' === $state ? BM_Page::icon( 'check' ) : ( 'fail' === $state ? BM_Page::icon( 'info' ) : BM_Page::icon( 'clock' ) ),
			esc_html( $head ),
			esc_html( $sub ),
			esc_html( $order->get_order_number() ),
			'fail' === $state && $order->needs_payment() ? '<p><a class="bm-btn bm-btn--primary" href="' . esc_url( $order->get_checkout_payment_url() ) . '">Zapłać teraz</a></p>' : '',
			$stays,
			$lines,
			implode( '', array_map( fn( $t ) => '<li>' . BM_Page::icon( 'check' ) . '<span>' . esc_html( $t ) . '</span></li>', $next ) ),
			$contact ? '<p class="bm-conf__contact">' . $contact . '</p>' : '',
			$gw ? '<div class="bm-conf__gw">' . $gw . '</div>' : '',
			esc_url( home_url( '/' ) )
		);
	}
}
