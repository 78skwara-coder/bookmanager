<?php
defined( 'ABSPATH' ) || exit;

/**
 * Strona kontaktu: dane obiektu + formularz.
 *
 * [bookmanager_kontakt] — atrybuty: mapa="nie", dane="nie" (sam formularz).
 * Wiadomość trafia e-mailem do obsługi (odpowiedz → gość), gość dostaje automatyczne potwierdzenie.
 * Nic nie zapisujemy w bazie poza wpisem w historii (bez danych osobowych).
 * Ochrona: ukryte pole, minimalny czas wypełnienia, limit wiadomości z jednego adresu IP, Turnstile (gdy włączony).
 * Formularz działa bez JavaScriptu (zwykły POST na tę samą stronę).
 */
class BM_Contact {

	const LIMIT  = 5;   // wiadomości z jednego IP na godzinę
	const MIN_S  = 3;   // minimalny czas wypełniania (boty wysyłają od razu)
	const MAX_MSG = 5000;

	/** @var array{errors: array, values: array, sent: bool}|null */
	private static $state = null;

	public static function init(): void {
		add_shortcode( 'bookmanager_kontakt', [ __CLASS__, 'shortcode' ] );
		add_action( 'template_redirect', [ __CLASS__, 'handle' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'assets' ] );
	}

	public static function assets(): void {
		wp_register_script( 'bookmanager-contact', plugins_url( 'assets/contact.js', BM_FILE ), [], BM_VERSION, [ 'in_footer' => true, 'strategy' => 'defer' ] );
	}

	/* ================= wysyłka ================= */

	private static function token( int $t ): string {
		return $t . '.' . substr( hash_hmac( 'sha256', 'bm_contact|' . $t, wp_salt( 'nonce' ) ), 0, 20 );
	}

	private static function token_age( string $tok ): ?int {
		[ $t ] = explode( '.', $tok . '.' );
		$t     = (int) $t;
		return $t && hash_equals( self::token( $t ), $tok ) ? time() - $t : null;
	}

	public static function fields(): array {
		return [ 'name', 'email', 'phone', 'apartment', 'from', 'to', 'message' ];
	}

	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- publiczny formularz; ochrona: token czasowy, ukryte pole, limit, Turnstile
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || empty( $_POST['bm_contact'] ) ) {
			return;
		}
		$p = wp_unslash( $_POST );
		// phpcs:enable
		$v = [
			'name'      => mb_substr( sanitize_text_field( (string) ( $p['bm_name'] ?? '' ) ), 0, 100 ),
			'email'     => sanitize_email( (string) ( $p['bm_email'] ?? '' ) ),
			'phone'     => mb_substr( preg_replace( '/[^0-9+ ()\-]/', '', (string) ( $p['bm_phone'] ?? '' ) ), 0, 30 ),
			'apartment' => absint( $p['bm_apartment'] ?? 0 ),
			'from'      => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['bm_from'] ?? '' ) ) ? (string) $p['bm_from'] : '',
			'to'        => preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $p['bm_to'] ?? '' ) ) ? (string) $p['bm_to'] : '',
			'message'   => mb_substr( trim( sanitize_textarea_field( (string) ( $p['bm_message'] ?? '' ) ) ), 0, self::MAX_MSG ),
			'consent'   => ! empty( $p['bm_consent'] ),
		];
		$e = [];

		// Boty: ukryte pole wypełnione albo za szybko / bez tokenu — udajemy sukces, nic nie wysyłamy.
		$age = self::token_age( (string) ( $p['bm_t'] ?? '' ) );
		if ( '' !== (string) ( $p['bm_website'] ?? '' ) || null === $age || $age < self::MIN_S ) {
			self::done( false );
			return;
		}
		if ( mb_strlen( $v['name'] ) < 2 ) {
			$e['name'] = __( 'Podaj imię.', 'bookmanager' );
		}
		if ( ! is_email( $v['email'] ) ) {
			$e['email'] = __( 'Podaj poprawny adres e-mail — na niego odpowiemy.', 'bookmanager' );
		}
		if ( mb_strlen( $v['message'] ) < 5 ) {
			$e['message'] = __( 'Napisz, w czym możemy pomóc.', 'bookmanager' );
		}
		if ( $v['from'] && $v['to'] && $v['to'] <= $v['from'] ) {
			$e['to'] = __( 'Wyjazd musi być po przyjeździe.', 'bookmanager' );
		}
		if ( $v['apartment'] && ( ! ( $ap = wc_get_product( $v['apartment'] ) ) || 'bm_apartment' !== $ap->get_type() ) ) { // phpcs:ignore
			$v['apartment'] = 0;
		}
		if ( BM_Site::page_url( 'privacy_page' ) && ! $v['consent'] ) {
			$e['consent'] = __( 'Potrzebujemy zgody, żeby odpowiedzieć na wiadomość.', 'bookmanager' );
		}
		if ( ! $e && ! BM_Security::verify() ) {
			$e['form'] = __( 'Potwierdź, że nie jesteś robotem.', 'bookmanager' );
		}
		$key = 'bm_ct_' . md5( BM_Log::ip() ?: 'none' );
		if ( ! $e && (int) get_transient( $key ) >= self::LIMIT ) {
			$e['form'] = __( 'Wysłano już kilka wiadomości — spróbuj za godzinę albo zadzwoń.', 'bookmanager' );
		}

		if ( $e ) {
			self::$state = [ 'errors' => $e, 'values' => $v, 'sent' => false ];
			return;
		}
		set_transient( $key, (int) get_transient( $key ) + 1, HOUR_IN_SECONDS );

		if ( ! self::send( $v ) ) {
			self::$state = [ 'errors' => [ 'form' => __( 'Nie udało się wysłać wiadomości. Spróbuj ponownie albo napisz bezpośrednio na nasz adres e-mail.', 'bookmanager' ) ], 'values' => $v, 'sent' => false ];
			return;
		}
		BM_Log::add( 'contact_message', 'contact', 0, $v['apartment'] ? [ 'apartment' => get_the_title( $v['apartment'] ) ] : [], 0 );
		self::done( true );
	}

	/** Po wysłaniu — przekierowanie (odświeżenie nie wyśle drugi raz). */
	private static function done( bool $real ): void {
		$url = add_query_arg( 'bm_wyslano', 1, remove_query_arg( 'bm_wyslano' ) ) . '#bm-kontakt';
		if ( headers_sent() ) {
			self::$state = [ 'errors' => [], 'values' => [], 'sent' => true ];
			return;
		}
		wp_safe_redirect( $url, 303 );
		exit;
	}

	public static function recipient(): string {
		return (string) ( BM_Site::get( 'contact_to' ) ?: BM_Settings::get( 'staff_email' ) ?: get_option( 'admin_email' ) );
	}

	private static function send( array $v ): bool {
		$site  = BM_Site::vars();
		$apt   = $v['apartment'] ? get_the_title( $v['apartment'] ) : '';
		$dates = $v['from'] ? BM_Notify::date_long( $v['from'] ) . ( $v['to'] ? ' – ' . BM_Notify::date_long( $v['to'] ) : '' ) : '';
		$rows  = [
			__( 'Imię', 'bookmanager' )        => $v['name'],
			__( 'E-mail', 'bookmanager' )      => $v['email'],
			__( 'Telefon', 'bookmanager' )     => $v['phone'],
			__( 'Apartament', 'bookmanager' )  => $apt,
			__( 'Termin', 'bookmanager' )      => $dates,
		];
		$table = '';
		foreach ( array_filter( $rows ) as $k => $val ) {
			$table .= '<tr><td style="padding:6px 16px 6px 0;color:#777;white-space:nowrap;vertical-align:top;">' . esc_html( $k ) . '</td><td style="padding:6px 0;">' . esc_html( $val ) . '</td></tr>';
		}
		$subject = sprintf( __( 'Wiadomość ze strony: %s', 'bookmanager' ), $v['name'] );
		$body    = '<p>' . esc_html__( 'Nowa wiadomość z formularza kontaktowego. Odpowiedz na tego maila — trafi prosto do gościa.', 'bookmanager' ) . '</p>'
			. '<table role="presentation" style="border-collapse:collapse;margin:0 0 16px;">' . $table . '</table>'
			. '<div style="padding:16px 18px;border-radius:8px;background:#f6f5f2;white-space:pre-wrap;">' . esc_html( $v['message'] ) . '</div>';
		$headers = [ 'Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . self::header_name( $v['name'] ) . ' <' . $v['email'] . '>' ];
		$ok      = wp_mail( self::recipient(), $subject, BM_Notify::wrap( $subject, $body, [ 'preheader' => mb_substr( $v['message'], 0, 120 ) ] ), $headers );
		if ( ! $ok ) {
			return false;
		}

		if ( 'yes' === BM_Site::get( 'contact_autoreply' ) ) {
			$vars  = array_merge( $site, [ 'imie' => $v['name'], 'wiadomosc' => $v['message'], 'apartament' => $apt, 'termin' => $dates ] );
			$subj  = strtr( (string) BM_Site::get( 'contact_subject' ), self::braces( $vars ) );
			$html  = BM_Notify::format_text( (string) BM_Site::get( 'contact_body' ), $vars );
			$reply = BM_Site::get( 'email' ) ?: self::recipient();
			wp_mail( $v['email'], $subj, BM_Notify::wrap( $subj, $html ), [ 'Content-Type: text/html; charset=UTF-8', 'Reply-To: ' . $reply ] );
		}
		return true;
	}

	private static function braces( array $vars ): array {
		$out = [];
		foreach ( $vars as $k => $v ) {
			$out[ '{' . $k . '}' ] = (string) $v;
		}
		return $out;
	}

	private static function header_name( string $n ): string {
		return '"' . str_replace( [ '"', "\r", "\n" ], '', $n ) . '"';
	}

	/* ================= HTML ================= */

	public static function shortcode( $atts = [] ): string {
		$atts = shortcode_atts( [ 'mapa' => 'tak', 'dane' => 'tak' ], $atts, 'bookmanager_kontakt' );
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_script( 'bookmanager-contact' );
		$a    = BM_Appearance::all();
		$info = 'nie' !== $atts['dane'] ? self::info( 'nie' !== $atts['mapa'] ) : '';
		return sprintf( '<div class="bm-ui bm-contact alignwide %s%s" id="bm-kontakt" style="%s">%s<div class="bm-contact__form">%s</div></div>',
			esc_attr( BM_Appearance::classes( $a ) ), $info ? '' : ' is-solo', esc_attr( BM_Appearance::style_vars( $a ) ), $info, self::form() );
	}

	private static function info( bool $map ): string {
		$s     = BM_Site::all();
		$addr  = BM_Site::address_line();
		$rows  = '';
		$row   = fn( $icon, $label, $html ) => '<li class="bm-contact__row">' . BM_Page::icon( $icon ) . '<div><span class="bm-contact__label">' . esc_html( $label ) . '</span>' . $html . '</div></li>';
		if ( $s['phone'] ) {
			$rows .= $row( 'phone', __( 'Telefon', 'bookmanager' ), '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $s['phone'] ) ) . '">' . esc_html( $s['phone'] ) . '</a>' );
		}
		if ( $s['email'] ) {
			$rows .= $row( 'mail', __( 'E-mail', 'bookmanager' ), '<a href="mailto:' . esc_attr( $s['email'] ) . '">' . esc_html( $s['email'] ) . '</a>' );
		}
		if ( $addr ) {
			$rows .= $row( 'pin', __( 'Adres', 'bookmanager' ), '<a href="' . esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $addr ) ) . '" target="_blank" rel="noopener">' . esc_html( $addr ) . '</a>' );
		}
		if ( $s['hours'] ) {
			$rows .= $row( 'clock', __( 'Recepcja', 'bookmanager' ), '<span>' . esc_html( $s['hours'] ) . '</span>' );
		}
		if ( ! $rows && ! $s['company'] ) {
			return '';
		}
		$firm = $s['company'] ? '<p class="bm-contact__firm"><strong>' . esc_html( $s['company'] ) . '</strong>' . ( $s['nip'] ? '<span>NIP ' . esc_html( $s['nip'] ) . '</span>' : '' ) . '</p>' : '';

		// Mapa Google ładuje się dopiero po kliknięciu — bez ciasteczek Google przed zgodą gościa.
		$mapbox = '';
		if ( $map && 'yes' === $s['map'] && $addr ) {
			$src    = 'https://maps.google.com/maps?q=' . rawurlencode( ( $s['company'] ? $s['company'] . ', ' : '' ) . $addr ) . '&z=15&output=embed';
			$mapbox = '<div class="bm-contact__map" data-bm-map="' . esc_attr( $src ) . '"><button type="button" class="bm-contact__mapbtn">' . BM_Page::icon( 'pin' )
				. '<span><strong>' . esc_html__( 'Pokaż mapę', 'bookmanager' ) . '</strong><small>' . esc_html__( 'Mapa Google — po kliknięciu Google może zapisać ciasteczka.', 'bookmanager' ) . '</small></span></button></div>';
		}
		return '<aside class="bm-contact__info"><h2 class="bm-contact__h">' . esc_html__( 'Dane kontaktowe', 'bookmanager' ) . '</h2>' . $firm . '<ul class="bm-contact__rows">' . $rows . '</ul>' . $mapbox . '</aside>';
	}

	private static function form(): string {
		// phpcs:ignore WordPress.Security.NonceVerification -- tylko wyświetlenie komunikatu
		if ( ( self::$state['sent'] ?? false ) || isset( $_GET['bm_wyslano'] ) ) {
			return '<div class="bm-contact__ok" role="status" tabindex="-1">' . BM_Page::icon( 'check' ) . '<div><h2 class="bm-contact__h">' . esc_html__( 'Dziękujemy, wiadomość wysłana!', 'bookmanager' ) . '</h2><p>'
				. esc_html__( 'Odpowiemy najszybciej, jak to możliwe. Kopię potwierdzenia wysłaliśmy na Twój adres e-mail.', 'bookmanager' ) . '</p><p><a class="bm-btn bm-btn--ghost" href="' . esc_url( remove_query_arg( 'bm_wyslano' ) ) . '#bm-kontakt">'
				. esc_html__( 'Napisz kolejną wiadomość', 'bookmanager' ) . '</a></p></div></div>';
		}
		$st  = self::$state ?? [ 'errors' => [], 'values' => [] ];
		$err = $st['errors'];
		$v   = $st['values'] + [ 'name' => '', 'email' => '', 'phone' => '', 'apartment' => 0, 'from' => '', 'to' => '', 'message' => '', 'consent' => false ];
		// phpcs:ignore WordPress.Security.NonceVerification -- wstępny wybór apartamentu z linku
		if ( ! $v['apartment'] && isset( $_GET['apartament'] ) ) {
			$v['apartment'] = absint( $_GET['apartament'] ); // phpcs:ignore
		}

		$field = function ( string $k, string $label, string $input, bool $req = false, string $hint = '' ) use ( $err ) {
			return sprintf( '<div class="bm-field%s"><label class="bm-field__label" for="bm-c-%s">%s%s</label>%s%s%s</div>',
				isset( $err[ $k ] ) ? ' is-error' : '', esc_attr( $k ), esc_html( $label ),
				$req ? ' <span class="bm-field__req" aria-hidden="true">*</span>' : ' <span class="bm-field__opt">' . esc_html__( '(opcjonalnie)', 'bookmanager' ) . '</span>',
				$input,
				$hint ? '<span class="bm-field__hint">' . esc_html( $hint ) . '</span>' : '',
				isset( $err[ $k ] ) ? '<span class="bm-field__err" id="bm-c-' . esc_attr( $k ) . '-err">' . esc_html( $err[ $k ] ) . '</span>' : '' );
		};
		$attrs = fn( $k ) => 'id="bm-c-' . $k . '" class="bm-input"' . ( isset( $err[ $k ] ) ? ' aria-invalid="true" aria-describedby="bm-c-' . $k . '-err"' : '' );

		$apts = wc_get_products( [ 'type' => 'bm_apartment', 'status' => 'publish', 'limit' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
		$aptf = '';
		if ( $apts ) {
			$o = '<option value="">' . esc_html__( '— dowolny / nie wiem —', 'bookmanager' ) . '</option>';
			foreach ( $apts as $ap ) {
				$o .= '<option value="' . (int) $ap->get_id() . '"' . selected( (int) $v['apartment'], $ap->get_id(), false ) . '>' . esc_html( $ap->get_name() ) . '</option>';
			}
			$aptf = $field( 'apartment', __( 'Apartament', 'bookmanager' ), '<select name="bm_apartment" ' . $attrs( 'apartment' ) . '>' . $o . '</select>' );
		}
		$today = wp_date( 'Y-m-d' );

		$consent = '';
		if ( $priv = BM_Site::page_url( 'privacy_page' ) ) { // phpcs:ignore
			$consent = sprintf( '<div class="bm-field bm-field--check%s"><label class="bm-ccheck"><input type="checkbox" name="bm_consent" value="1"%s%s> <span>%s <a href="%s" target="_blank" rel="noopener">%s</a>. <span class="bm-field__req" aria-hidden="true">*</span></span></label>%s</div>',
				isset( $err['consent'] ) ? ' is-error' : '',
				checked( $v['consent'], true, false ),
				isset( $err['consent'] ) ? ' aria-invalid="true"' : '',
				esc_html__( 'Zgadzam się na przetwarzanie moich danych w celu odpowiedzi na wiadomość, zgodnie z', 'bookmanager' ),
				esc_url( $priv ),
				esc_html__( 'Polityką prywatności', 'bookmanager' ),
				isset( $err['consent'] ) ? '<span class="bm-field__err">' . esc_html( $err['consent'] ) . '</span>' : '' );
		}

		return '<form class="bm-cform" method="post" action="' . esc_url( remove_query_arg( 'bm_wyslano' ) ) . '#bm-kontakt" novalidate>'
			. '<h2 class="bm-contact__h">' . esc_html__( 'Napisz do nas', 'bookmanager' ) . '</h2>'
			. '<p class="bm-contact__lead">' . esc_html__( 'Pytanie o termin, dojazd albo pobyt z psem? Odpiszemy zwykle w ciągu jednego dnia.', 'bookmanager' ) . '</p>'
			. ( isset( $err['form'] ) ? '<p class="bm-cform__alert" role="alert">' . esc_html( $err['form'] ) . '</p>' : ( $err ? '<p class="bm-cform__alert" role="alert">' . esc_html__( 'Popraw zaznaczone pola.', 'bookmanager' ) . '</p>' : '' ) )
			. '<div class="bm-cform__grid">'
			. $field( 'name', __( 'Imię', 'bookmanager' ), '<input type="text" name="bm_name" autocomplete="given-name" required maxlength="100" value="' . esc_attr( $v['name'] ) . '" ' . $attrs( 'name' ) . '>', true )
			. $field( 'email', __( 'E-mail', 'bookmanager' ), '<input type="email" name="bm_email" autocomplete="email" required value="' . esc_attr( $v['email'] ) . '" ' . $attrs( 'email' ) . '>', true )
			. $field( 'phone', __( 'Telefon', 'bookmanager' ), '<input type="tel" name="bm_phone" autocomplete="tel" value="' . esc_attr( $v['phone'] ) . '" ' . $attrs( 'phone' ) . '>' )
			. $aptf
			. $field( 'from', __( 'Przyjazd', 'bookmanager' ), '<input type="date" name="bm_from" min="' . esc_attr( $today ) . '" value="' . esc_attr( $v['from'] ) . '" ' . $attrs( 'from' ) . '>' )
			. $field( 'to', __( 'Wyjazd', 'bookmanager' ), '<input type="date" name="bm_to" min="' . esc_attr( $today ) . '" value="' . esc_attr( $v['to'] ) . '" ' . $attrs( 'to' ) . '>' )
			. '</div>'
			. $field( 'message', __( 'Wiadomość', 'bookmanager' ), '<textarea name="bm_message" rows="6" required maxlength="' . self::MAX_MSG . '" ' . $attrs( 'message' ) . '>' . esc_textarea( $v['message'] ) . '</textarea>', true )
			. $consent
			. '<div class="bm-cform__hp" aria-hidden="true"><label>' . esc_html__( 'Zostaw to pole puste', 'bookmanager' ) . ' <input type="text" name="bm_website" tabindex="-1" autocomplete="off"></label></div>'
			. '<input type="hidden" name="bm_contact" value="1"><input type="hidden" name="bm_t" value="' . esc_attr( self::token( time() ) ) . '">'
			. BM_Security::widget()
			. '<div class="bm-cform__foot"><button type="submit" class="bm-btn bm-btn--primary">' . BM_Page::icon( 'mail' ) . esc_html__( 'Wyślij wiadomość', 'bookmanager' ) . '</button>'
			. '<span class="bm-cform__note">' . esc_html__( 'Pola oznaczone * są wymagane.', 'bookmanager' ) . '</span></div>'
			. '</form>';
	}
}
