<?php
defined( 'ABSPATH' ) || exit;

/**
 * Opcje dodatkowe (łóżeczko, pies, …): definicje i przypisanie do apartamentów.
 * Ekran zarządzania — BM_Admin (część 3). Pilnowanie pul sztuk — przy rezerwacji ze strony.
 */
class BM_Extras {

	const CHARGE_STAY  = 'stay';  // za pobyt (× ilość)
	const CHARGE_NIGHT = 'night'; // za noc (× ilość × noce)

	public static function charge_types(): array {
		return [
			self::CHARGE_STAY  => __( 'za pobyt', 'bookmanager' ),
			self::CHARGE_NIGHT => __( 'za noc', 'bookmanager' ),
		];
	}

	/**
	 * Pula sztuk: czy w nocach [in, out) starczy sztuk opcji w całym miejscu drzewa
	 * (np. 2 łóżeczka na Budynek A). Liczą się potwierdzone rezerwacje i aktywne blokady.
	 * Zwraca true albo WP_Error z nazwą opcji.
	 */
	public static function check_pools( int $apartment_id, string $in, string $out, array $wanted, int $exclude_booking = 0 ) {
		global $wpdb;
		$available = self::for_apartment( $apartment_id );
		$b         = BM_Installer::table( 'bookings' );
		$be        = BM_Installer::table( 'booking_extras' );
		$now       = gmdate( 'Y-m-d H:i:s' );

		foreach ( $wanted as $extra_id => $qty ) {
			$x = $available[ $extra_id ] ?? null;
			if ( ! $x || ! $x['pool']['qty'] || ! $x['pool']['location_id'] ) {
				continue;
			}
			$apartments = BM_Locations::apartments_in( $x['pool']['location_id'] );
			if ( ! in_array( $apartment_id, $apartments, true ) ) {
				continue; // apartament poza miejscem puli — pula go nie dotyczy
			}
			$ids  = implode( ',', array_map( 'intval', $apartments ) );
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT b.check_in, b.check_out, be.qty FROM $be be JOIN $b b ON b.id = be.booking_id
				 WHERE be.extra_id = %d AND b.apartment_id IN ($ids) AND b.id <> %d
				   AND b.check_in < %s AND b.check_out > %s
				   AND ( b.status = 'confirmed' OR ( b.status = 'hold' AND b.hold_expires >= %s ) )",
				$extra_id, $exclude_booking, $out, $in, $now
			) );
			// Najgorsza noc w zakresie.
			$peak = 0;
			for ( $d = $in; $d < $out; $d = gmdate( 'Y-m-d', strtotime( $d . ' +1 day' ) ) ) {
				$used = 0;
				foreach ( $rows as $r ) {
					if ( $r->check_in <= $d && $r->check_out > $d ) {
						$used += (int) $r->qty;
					}
				}
				$peak = max( $peak, $used );
			}
			if ( $peak + $qty > $x['pool']['qty'] ) {
				$left = max( 0, $x['pool']['qty'] - $peak );
				return new WP_Error( 'bm_pool', $left
					? sprintf( '%s: w tym terminie zostało %d szt.', $x['name'], $left )
					: sprintf( '%s: w tym terminie wszystkie sztuki są już zarezerwowane.', $x['name'] ) );
			}
		}
		return true;
	}

	/**
	 * Opcje dostępne w apartamencie, z ceną i limitem po uwzględnieniu nadpisań.
	 * Klucz tablicy = ID opcji.
	 */
	public static function for_apartment( int $apartment_id ): array {
		global $wpdb;
		$e  = BM_Installer::table( 'extras' );
		$ae = BM_Installer::table( 'apartment_extras' );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT e.*, ae.price_override, ae.max_qty_override
			 FROM $ae ae JOIN $e e ON e.id = ae.extra_id
			 WHERE ae.apartment_id = %d AND e.active = 1
			 ORDER BY e.sort, e.name",
			$apartment_id
		) );

		$out = [];
		foreach ( $rows as $r ) {
			$out[ (int) $r->id ] = [
				'id'          => (int) $r->id,
				'name'        => $r->name,
				'description' => (string) $r->description,
				'price'       => null !== $r->price_override ? (float) $r->price_override : (float) $r->price,
				'charge_type' => isset( self::charge_types()[ $r->charge_type ] ) ? $r->charge_type : self::CHARGE_STAY,
				'allow_qty'   => (bool) $r->allow_qty,
				'max_qty'     => $r->allow_qty ? max( 1, (int) ( $r->max_qty_override ?? $r->max_qty ) ) : 1,
				'pool'        => [ 'location_id' => (int) $r->pool_location_id, 'qty' => (int) $r->pool_qty ],
			];
		}
		return $out;
	}
}
