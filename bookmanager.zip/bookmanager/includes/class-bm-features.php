<?php
defined( 'ABSPATH' ) || exit;

/**
 * Udogodnienia i zasady — definiowane w obiekcie, przypisywane do jego budynków,
 * pięter i apartamentów, dziedziczone w dół drzewa.
 *
 * „Gdzie klient to zobaczy” to konfiguracja (contexts), a nie kod na sztywno:
 * nowe miejsce wyświetlania = nowa pozycja w filtrze bm_feature_contexts.
 */
class BM_Features {

	const AMENITY = 'amenity';
	const RULE    = 'rule';

	public static function kinds(): array {
		return [ self::AMENITY => __( 'Udogodnienie', 'bookmanager' ), self::RULE => __( 'Zasada', 'bookmanager' ) ];
	}

	/** Miejsca wyświetlania. Część obsłużymy z frontem; lista jest gotowa na przyszłe. */
	public static function contexts(): array {
		return apply_filters( 'bm_feature_contexts', [
			'apartment_page' => __( 'Strona apartamentu („O obiekcie”)', 'bookmanager' ),
			'checkout'       => __( 'Podsumowanie przed zapłatą', 'bookmanager' ),
			'email'          => __( 'Mail z potwierdzeniem', 'bookmanager' ),
			'filters'        => __( 'Filtry wyszukiwarki', 'bookmanager' ),
			'terms'          => __( 'Regulamin', 'bookmanager' ),
		] );
	}

	public static function categories( string $kind ): array {
		return self::RULE === $kind
			? [
				'checkin' => __( 'Zameldowanie i wymeldowanie', 'bookmanager' ),
				'quiet'   => __( 'Cisza nocna', 'bookmanager' ),
				'smoking' => __( 'Palenie', 'bookmanager' ),
				'pets'    => __( 'Zwierzęta', 'bookmanager' ),
				'other'   => __( 'Inne', 'bookmanager' ),
			]
			: [
				'bathroom'      => __( 'Łazienka', 'bookmanager' ),
				'kitchen'       => __( 'Kuchnia', 'bookmanager' ),
				'laundry'       => __( 'Pranie', 'bookmanager' ),
				'recreation'    => __( 'Rekreacja', 'bookmanager' ),
				'parking'       => __( 'Parking i dojazd', 'bookmanager' ),
				'rooms'         => __( 'Pomieszczenia wspólne', 'bookmanager' ),
				'accessibility' => __( 'Dostępność', 'bookmanager' ),
				'other'         => __( 'Inne', 'bookmanager' ),
			];
	}

	/** Podpowiedzi z branży: [kind, category, name, wymaga akceptacji]. */
	public static function presets(): array {
		$a = self::AMENITY;
		$r = self::RULE;
		return [
			[ $a, 'bathroom', 'Łazienka wspólna', true ],
			[ $a, 'bathroom', 'WC wspólne', true ],
			[ $a, 'bathroom', 'Prysznice wspólne', true ],
			[ $a, 'kitchen', 'Kuchnia wspólna', true ],
			[ $a, 'kitchen', 'Jadalnia', false ],
			[ $a, 'kitchen', 'Lodówka wspólna', false ],
			[ $a, 'laundry', 'Pralka', false ],
			[ $a, 'laundry', 'Suszarnia', false ],
			[ $a, 'laundry', 'Żelazko', false ],
			[ $a, 'recreation', 'Grill', false ],
			[ $a, 'recreation', 'Miejsce na ognisko', false ],
			[ $a, 'recreation', 'Altana', false ],
			[ $a, 'recreation', 'Ogród', false ],
			[ $a, 'recreation', 'Plac zabaw', false ],
			[ $a, 'recreation', 'Basen', false ],
			[ $a, 'recreation', 'Sauna', false ],
			[ $a, 'recreation', 'Jacuzzi', false ],
			[ $a, 'recreation', 'Sala gier', false ],
			[ $a, 'recreation', 'Rowery', false ],
			[ $a, 'recreation', 'Kajaki', false ],
			[ $a, 'parking', 'Parking', false ],
			[ $a, 'parking', 'Parking zadaszony', false ],
			[ $a, 'parking', 'Garaż', false ],
			[ $a, 'parking', 'Ładowarka do aut elektrycznych', false ],
			[ $a, 'parking', 'Wiata na rowery', false ],
			[ $a, 'rooms', 'Świetlica', false ],
			[ $a, 'rooms', 'Sala konferencyjna', false ],
			[ $a, 'rooms', 'Taras wspólny', false ],
			[ $a, 'accessibility', 'Winda', false ],
			[ $a, 'accessibility', 'Podjazd dla wózków', false ],
			[ $a, 'accessibility', 'Apartament przystosowany dla osób z niepełnosprawnością', false ],
			[ $r, 'checkin', 'Zameldowanie od 15:00, wymeldowanie do 11:00', true ],
			[ $r, 'quiet', 'Cisza nocna 22:00–6:00', true ],
			[ $r, 'smoking', 'Zakaz palenia w budynkach', true ],
			[ $r, 'pets', 'Zwierzęta tylko po wcześniejszym uzgodnieniu', true ],
			[ $r, 'other', 'Zakaz organizowania imprez', true ],
		];
	}

	/** Domyślne miejsca wyświetlania dla nowej pozycji. */
	public static function default_display( string $kind, bool $requires_acceptance ): array {
		$base = [ 'apartment_page', 'email' ];
		if ( self::AMENITY === $kind ) {
			$base[] = 'filters';
		}
		if ( $requires_acceptance || self::RULE === $kind ) {
			array_push( $base, 'checkout', 'terms' );
		}
		return array_values( array_intersect( array_keys( self::contexts() ), $base ) );
	}

	/* ---------- Dane ---------- */

	private static function t( string $n ): string {
		return BM_Installer::table( $n );
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'features' ) . ' WHERE id = %d', $id ), ARRAY_A );
		return $row ? self::hydrate( $row ) : null;
	}

	public static function for_object( int $object_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . self::t( 'features' ) . ' WHERE object_id = %d ORDER BY kind, sort, name', $object_id
		), ARRAY_A );
		return array_map( [ __CLASS__, 'hydrate' ], $rows );
	}

	private static function hydrate( array $r ): array {
		$r['id']                  = (int) $r['id'];
		$r['object_id']           = (int) $r['object_id'];
		$r['requires_acceptance'] = (bool) $r['requires_acceptance'];
		$r['active']              = (bool) $r['active'];
		$r['display']             = array_values( array_filter( explode( ',', (string) $r['display'] ) ) );
		return $r;
	}

	/** Zapis (nowa pozycja gdy brak id). Zwraca id. */
	public static function save( array $d ): int {
		global $wpdb;
		$kind = self::RULE === ( $d['kind'] ?? '' ) ? self::RULE : self::AMENITY;
		$now  = gmdate( 'Y-m-d H:i:s' );
		$row  = [
			'object_id'           => (int) $d['object_id'],
			'kind'                => $kind,
			'name'                => sanitize_text_field( $d['name'] ?? '' ),
			'description'         => sanitize_textarea_field( $d['description'] ?? '' ),
			'category'            => isset( self::categories( $kind )[ $d['category'] ?? '' ] ) ? $d['category'] : 'other',
			'requires_acceptance' => empty( $d['requires_acceptance'] ) ? 0 : 1,
			'display'             => implode( ',', array_intersect( (array) ( $d['display'] ?? [] ), array_keys( self::contexts() ) ) ),
			'active'              => empty( $d['active'] ) ? 0 : 1,
			'sort'                => (int) ( $d['sort'] ?? 0 ),
			'updated_at'          => $now,
		];
		if ( ! empty( $d['id'] ) ) {
			$wpdb->update( self::t( 'features' ), $row, [ 'id' => (int) $d['id'] ] );
			return (int) $d['id'];
		}
		$row['created_at'] = $now;
		$wpdb->insert( self::t( 'features' ), $row );
		return (int) $wpdb->insert_id;
	}

	public static function delete( int $id ): void {
		global $wpdb;
		$wpdb->delete( self::t( 'feature_links' ), [ 'feature_id' => $id ] );
		$wpdb->delete( self::t( 'features' ), [ 'id' => $id ] );
	}

	/** Przypisania pozycji: klucz "location:12" / "apartment:34" => [qty, note]. */
	public static function links( int $feature_id ): array {
		global $wpdb;
		$out = [];
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'feature_links' ) . ' WHERE feature_id = %d', $feature_id ) ) as $l ) {
			$out[ $l->target_type . ':' . $l->target_id ] = [ 'qty' => (int) $l->qty, 'note' => $l->note ];
		}
		return $out;
	}

	/** Podmienia przypisania pozycji — tylko na cele z jej obiektu. */
	public static function set_links( int $feature_id, int $object_id, array $links ): void {
		global $wpdb;
		$allowed_loc = BM_Locations::subtree( $object_id );
		$allowed_apt = BM_Locations::apartments_in( $object_id );

		$wpdb->delete( self::t( 'feature_links' ), [ 'feature_id' => $feature_id ] );
		foreach ( $links as $key => $l ) {
			[ $type, $id ] = array_pad( explode( ':', (string) $key ), 2, 0 );
			$id            = (int) $id;
			$ok            = ( 'location' === $type && in_array( $id, $allowed_loc, true ) )
				|| ( 'apartment' === $type && in_array( $id, $allowed_apt, true ) );
			if ( ! $ok || empty( $l['on'] ) ) {
				continue;
			}
			$wpdb->insert( self::t( 'feature_links' ), [
				'feature_id'  => $feature_id,
				'target_type' => $type,
				'target_id'   => $id,
				'qty'         => max( 1, (int) ( $l['qty'] ?? 1 ) ),
				'note'        => sanitize_text_field( $l['note'] ?? '' ),
			] );
		}
	}

	/**
	 * Wszystko, co „widzi” apartament: własne pozycje + odziedziczone z piętra, budynku i obiektu.
	 * Zwraca listę poziomów od apartamentu w górę: [{level, label, items:[…]}].
	 * Opcjonalnie tylko pozycje wyświetlane w danym miejscu ($context).
	 */
	public static function for_apartment( int $apartment_id, ?string $context = null ): array {
		global $wpdb;
		$path    = BM_Locations::path( BM_Locations::of_apartment( $apartment_id ) );
		$targets = array_merge( [ [ 'apartment', $apartment_id ] ], array_map( fn( $id ) => [ 'location', $id ], $path ) );

		$levels = [];
		foreach ( $targets as [ $type, $id ] ) {
			$rows = $wpdb->get_results( $wpdb->prepare(
				'SELECT f.*, l.qty AS link_qty, l.note AS link_note FROM ' . self::t( 'feature_links' ) . ' l
				 JOIN ' . self::t( 'features' ) . ' f ON f.id = l.feature_id
				 WHERE l.target_type = %s AND l.target_id = %d AND f.active = 1
				 ORDER BY f.kind, f.sort, f.name',
				$type, $id
			), ARRAY_A );

			$items = [];
			foreach ( $rows as $r ) {
				$f = self::hydrate( $r );
				if ( $context && ! in_array( $context, $f['display'], true ) ) {
					continue;
				}
				$f['qty']  = (int) $r['link_qty'];
				$f['note'] = (string) $r['link_note'];
				$items[]   = $f;
			}
			if ( ! $items ) {
				continue;
			}
			$level    = 'apartment' === $type ? 'apartment' : BM_Locations::type_of( $id );
			$levels[] = [
				'level'  => $level,
				'shared' => 'apartment' !== $type, // wszystko powyżej apartamentu jest wspólne z innymi gośćmi
				'label'  => 'apartment' === $type ? __( 'W apartamencie', 'bookmanager' ) : get_term( $id )->name,
				'items'  => $items,
			];
		}
		return $levels;
	}

	/** Pozycje wymagające akceptacji przed zapłatą, jako jeden tekst do zapisania. */
	public static function acceptance_text( int $apartment_id ): string {
		$lines = [];
		foreach ( self::for_apartment( $apartment_id, 'checkout' ) as $lvl ) {
			foreach ( $lvl['items'] as $f ) {
				if ( ! $f['requires_acceptance'] ) {
					continue;
				}
				// „Wspólne” dotyczy udogodnień; zasady po prostu obowiązują.
				$where   = $lvl['shared'] && self::AMENITY === $f['kind'] ? sprintf( ' (wspólne: %s)', $lvl['label'] ) : '';
				$lines[] = '• ' . $f['name'] . ( $f['qty'] > 1 ? ' ×' . $f['qty'] : '' ) . $where
					. ( $f['note'] ? ' — ' . $f['note'] : '' ) . ( $f['description'] ? "\n  " . $f['description'] : '' );
			}
		}
		return implode( "\n", $lines );
	}
}
