<?php
defined( 'ABSPATH' ) || exit;

/**
 * Front: shortcode'y (silnik) i bloki Gutenberga (nakładka na shortcode'y).
 *
 *   [bookmanager_o_obiekcie]                  — na stronie apartamentu
 *   [bookmanager_o_obiekcie id="123"]         — wskazany apartament
 *   [bookmanager_o_obiekcie obiekt="Nazwa"]   — cały obiekt (nazwa, slug lub ID)
 *   [bookmanager_rezerwacja]  /  [bookmanager_rezerwacja id="123"]
 *
 * Na stronie produktu-apartamentu widżet rezerwacji wstawia się sam w miejsce „Dodaj do koszyka”.
 * Wygląd: BM_Appearance (BookManager → Wygląd); strona apartamentu: BM_Page.
 */
class BM_Frontend {

	public static function init(): void {
		add_shortcode( 'bookmanager_o_obiekcie', [ __CLASS__, 'about' ] );
		add_shortcode( 'bookmanager_rezerwacja', [ __CLASS__, 'booking' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'register_assets' ] );
		add_action( 'woocommerce_bm_apartment_add_to_cart', [ __CLASS__, 'product_page_widget' ] );
		add_action( 'init', [ __CLASS__, 'register_blocks' ] );
	}

	public static function register_assets(): void {
		wp_register_style( 'bookmanager', plugins_url( 'assets/bookmanager.css', BM_FILE ), [], BM_VERSION );
		wp_register_script( 'bookmanager-booking', plugins_url( 'assets/booking.js', BM_FILE ), [], BM_VERSION, true );
		wp_register_script( 'bookmanager-page', plugins_url( 'assets/page.js', BM_FILE ), [], BM_VERSION, true );
	}

	/** Apartament z atrybutu id albo bieżąca strona produktu. */
	private static function apartment( $id ): ?WC_Product {
		$id  = absint( $id ) ?: get_the_ID();
		$apt = $id ? wc_get_product( $id ) : null;
		return $apt && 'bm_apartment' === $apt->get_type() && 'publish' === $apt->get_status() ? $apt : null;
	}

	/* ================= O obiekcie ================= */

	public static function about( $atts ): string {
		$atts = shortcode_atts( [ 'id' => 0, 'obiekt' => '' ], $atts, 'bookmanager_o_obiekcie' );
		wp_enqueue_style( 'bookmanager' );

		if ( '' !== $atts['obiekt'] ) {
			$term = self::find_location( (string) $atts['obiekt'] );
			return $term ? self::about_location( $term ) : '';
		}
		$apt = self::apartment( $atts['id'] );
		return $apt ? self::about_apartment( $apt ) : '';
	}

	private static function find_location( string $ref ): ?WP_Term {
		foreach ( [ 'id', 'slug', 'name' ] as $field ) {
			if ( 'id' === $field && ! ctype_digit( $ref ) ) {
				continue;
			}
			$t = get_term_by( $field, 'id' === $field ? (int) $ref : $ref, BM_Locations::TAX );
			if ( $t ) {
				return $t;
			}
		}
		return null;
	}

	private static function about_apartment( WC_Product $apt ): string {
		$path   = BM_Locations::path( BM_Locations::of_apartment( $apt->get_id() ) );
		$levels = [];
		foreach ( BM_Features::for_apartment( $apt->get_id(), 'apartment_page' ) as $lvl ) {
			$levels[ $lvl['label'] ] = $lvl;
		}

		$amen  = '';
		$rules = [];
		// Od apartamentu w górę: W apartamencie → piętro → budynek → obiekt.
		$own = $levels[ __( 'W apartamencie', 'bookmanager' ) ] ?? null;
		$amen .= self::level_block( __( 'W apartamencie', 'bookmanager' ), '', false, $own['items'] ?? [], $rules );
		foreach ( $path as $term_id ) {
			$term   = get_term( $term_id );
			$lvl    = $levels[ $term->name ] ?? null;
			$amen  .= self::level_block( self::level_title( $term ), $term->description, true, $lvl['items'] ?? [], $rules );
		}
		return self::wrap( $amen, $rules );
	}

	private static function about_location( WP_Term $term ): string {
		global $wpdb;
		$rows  = $wpdb->get_results( $wpdb->prepare(
			'SELECT f.*, l.qty AS link_qty, l.note AS link_note FROM ' . BM_Installer::table( 'feature_links' ) . ' l
			 JOIN ' . BM_Installer::table( 'features' ) . " f ON f.id = l.feature_id
			 WHERE l.target_type = 'location' AND l.target_id = %d AND f.active = 1 ORDER BY f.kind, f.sort, f.name",
			$term->term_id
		), ARRAY_A );
		$items = [];
		foreach ( $rows as $r ) {
			$display = explode( ',', (string) $r['display'] );
			if ( in_array( 'apartment_page', $display, true ) ) {
				$items[] = [ 'kind' => $r['kind'], 'name' => $r['name'], 'description' => (string) $r['description'],
					'qty' => (int) $r['link_qty'], 'note' => (string) $r['link_note'], 'requires_acceptance' => (bool) $r['requires_acceptance'] ];
			}
		}
		$rules = [];
		$amen  = self::level_block( $term->name, $term->description, false, $items, $rules );
		return self::wrap( $amen, $rules );
	}

	private static function level_title( WP_Term $term ): string {
		$type = BM_Locations::type_of( $term->term_id );
		$map  = [
			'floor'    => __( 'Wspólne na piętrze: %s', 'bookmanager' ),
			'building' => __( 'Wspólne w budynku: %s', 'bookmanager' ),
			'object'   => __( 'Na terenie obiektu: %s', 'bookmanager' ),
		];
		return sprintf( $map[ $type ] ?? '%s', $term->name );
	}

	/** Blok poziomu: tytuł, opis, udogodnienia. Zasady odkładamy do wspólnej listy. */
	private static function level_block( string $title, string $desc, bool $shared, array $items, array &$rules ): string {
		$li = '';
		foreach ( $items as $f ) {
			if ( BM_Features::RULE === $f['kind'] ) {
				$rules[] = $f;
				continue;
			}
			$li .= self::item( $f );
		}
		if ( '' === $li && '' === trim( $desc ) ) {
			return '';
		}
		return sprintf(
			'<div class="bm-about__level%s"><h3 class="bm-about__title">%s%s</h3>%s%s</div>',
			$shared ? ' bm-about__level--shared' : '',
			esc_html( $title ),
			$shared ? ' <span class="bm-badge bm-badge--shared">' . esc_html__( 'wspólne z innymi gośćmi', 'bookmanager' ) . '</span>' : '',
			trim( $desc ) ? '<div class="bm-about__desc">' . wp_kses_post( wpautop( $desc ) ) . '</div>' : '',
			$li ? '<ul class="bm-about__list">' . $li . '</ul>' : ''
		);
	}

	private static function item( array $f ): string {
		return sprintf(
			'<li class="bm-about__item"><span class="bm-about__name">%s%s</span>%s%s</li>',
			esc_html( $f['name'] ),
			$f['qty'] > 1 ? ' <span class="bm-about__qty">×' . (int) $f['qty'] . '</span>' : '',
			$f['note'] ? ' <span class="bm-about__note">' . esc_html( $f['note'] ) . '</span>' : '',
			$f['description'] ? '<span class="bm-about__fdesc">' . esc_html( $f['description'] ) . '</span>' : ''
		);
	}

	private static function wrap( string $amen, array $rules ): string {
		if ( '' === $amen && ! $rules ) {
			return '';
		}
		$html = '<section class="bm-about"><h2 class="bm-about__heading">' . esc_html__( 'O obiekcie', 'bookmanager' ) . '</h2>' . $amen;
		if ( $rules ) {
			$html .= '<div class="bm-about__rules"><h3 class="bm-about__title">' . esc_html__( 'Zasady pobytu', 'bookmanager' ) . '</h3><ul class="bm-about__list">';
			foreach ( $rules as $r ) {
				$html .= self::item( $r );
			}
			$html .= '</ul></div>';
		}
		return $html . '</section>';
	}

	/* ================= Widżet rezerwacji ================= */

	/** Konfiguracja widżetu — tylko to, co potrzebne w przeglądarce. Ceny i tak liczy serwer. */
	public static function widget_config( WC_Product $apt ): array {
		$cfg    = BM_Apartment::config( $apt );
		$extras = array_values( array_map( fn( $x ) => [
			'id' => $x['id'], 'name' => $x['name'], 'description' => $x['description'], 'price' => $x['price'],
			'charge_type' => $x['charge_type'], 'allow_qty' => $x['allow_qty'], 'max_qty' => $x['max_qty'],
		], BM_Extras::for_apartment( $apt->get_id() ) ) );

		$eb_total = null !== $cfg['eb_max_total'] ? $cfg['eb_max_total'] : 99;

		return [
			'apartment_id' => $apt->get_id(),
			'api'          => esc_url_raw( rest_url( BM_REST::NS . '/apartments/' . $apt->get_id() ) ),
			'currency'     => get_woocommerce_currency(),
			'mode'         => $cfg['mode'],
			'min_nights'   => $cfg['min_nights'],
			'fill_gaps'    => $cfg['fill_gaps'],
			'beds'         => $cfg['beds'],
			'infant_age'   => $cfg['infant_age'],
			'infant_max'   => $cfg['infant_max'],
			'max_child'    => BM_Apartment::MAX_CHILD_AGE,
			'eb_adult'     => $cfg['eb_adult']['enabled'] ? [ 'max' => $cfg['eb_adult']['max'], 'price' => $cfg['eb_adult']['price'] ] : null,
			'eb_child'     => $cfg['eb_child']['enabled'] ? [ 'max' => $cfg['eb_child']['max'], 'price' => $cfg['eb_child']['price'] ] : null,
			'eb_max_total' => $eb_total,
			'extras'       => $extras,
			'booking_open' => true,
			'cart_url'     => get_permalink( $apt->get_id() ),
			'acceptance'   => BM_Features::acceptance_text( $apt->get_id() ),
		];
	}

	public static function booking( $atts ): string {
		$atts = shortcode_atts( [ 'id' => 0 ], $atts, 'bookmanager_rezerwacja' );
		$apt  = self::apartment( $atts['id'] );
		if ( ! $apt ) {
			return '';
		}
		$a = BM_Appearance::for_apartment( $apt->get_id() );
		return self::widget_html( $apt, $a, [ 'standalone' => true, 'wizard' => 'wizard' === $a['layout'] ] );
	}

	/**
	 * Widżet rezerwacji. $opts: show_price (cena „od” na górze), wizard (kroki), split (kalendarz obok reszty),
	 * standalone (poza stroną BookManagera — dostaje własne klasy stylu).
	 */
	public static function widget_html( WC_Product $apt, array $a, array $opts = [] ): string {
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_script( 'bookmanager-booking' );

		$cfg = self::widget_config( $apt ) + [
			'months'     => (int) $a['months'],
			'wizard'     => ! empty( $opts['wizard'] ),
			'show_price' => ! empty( $opts['show_price'] ),
			'from'       => BM_Page::price_from_text( $apt ),
		];
		$cls = 'bm-booking' . ( ! empty( $opts['wizard'] ) ? ' bm-booking--wizard' : '' ) . ( ! empty( $opts['split'] ) ? ' bm-booking--split' : '' );
		$style = '';
		if ( ! empty( $opts['standalone'] ) ) {
			$cls  .= ' ' . BM_Appearance::classes( $a );
			$style = BM_Appearance::style_vars( $a );
		}

		return sprintf(
			'<div class="%s"%s data-bm-config="%s"><noscript>%s</noscript><p class="bm-booking__loading">%s</p></div>',
			esc_attr( $cls ),
			$style ? ' style="' . esc_attr( $style ) . '"' : '',
			esc_attr( wp_json_encode( $cfg ) ),
			esc_html__( 'Rezerwacja wymaga włączonej obsługi JavaScript.', 'bookmanager' ),
			esc_html__( 'Ładowanie kalendarza…', 'bookmanager' )
		);
	}

	public static function product_page_widget(): void {
		echo self::booking( [] ); // phpcs:ignore -- zbudowane z escapowanych części
	}

	/* ================= Bloki ================= */

	public static function register_blocks(): void {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		wp_register_script( 'bookmanager-blocks', plugins_url( 'assets/blocks.js', BM_FILE ),
			[ 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n' ], BM_VERSION, true );

		register_block_type( 'bookmanager/o-obiekcie', [
			'editor_script'   => 'bookmanager-blocks',
			'attributes'      => [ 'id' => [ 'type' => 'number', 'default' => 0 ], 'obiekt' => [ 'type' => 'string', 'default' => '' ] ],
			'render_callback' => fn( $a ) => self::about( [ 'id' => $a['id'] ?? 0, 'obiekt' => $a['obiekt'] ?? '' ] ),
		] );
		register_block_type( 'bookmanager/rezerwacja', [
			'editor_script'   => 'bookmanager-blocks',
			'attributes'      => [ 'id' => [ 'type' => 'number', 'default' => 0 ] ],
			'render_callback' => fn( $a ) => self::booking( [ 'id' => $a['id'] ?? 0 ] ),
		] );
	}
}
