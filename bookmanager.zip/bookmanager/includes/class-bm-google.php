<?php
defined( 'ABSPATH' ) || exit;

/**
 * Synchronizacja z Google Calendar — JEDNOKIERUNKOWO: BookManager → Google.
 * Kalendarz Google to podgląd dla właściciela; zmiany w Google nie wpływają na stronę.
 *
 * Konto serwisowe (service account) + osobny kalendarz na apartament (ID na karcie apartamentu).
 * Kalendarz trzeba udostępnić adresowi e-mail konta serwisowego z prawem „Wprowadzanie zmian w wydarzeniach”.
 * Klucz: stała BM_GOOGLE_SA_JSON w wp-config.php (zalecane; ścieżka do pliku albo sam JSON)
 *        albo pole w Ustawieniach (zapisywane w bazie).
 *
 * Bez biblioteki google/apiclient: token JWT podpisany openssl_sign + wp_remote_*.
 * Operacje idą w tle (Action Scheduler) z ponawianiem, więc awaria Google nie blokuje zamówień.
 */
class BM_Google {

	const SCOPE     = 'https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.readonly';
	const TOKEN_URL = 'https://oauth2.googleapis.com/token';
	const API       = 'https://www.googleapis.com/calendar/v3';
	const OPTION    = 'bm_google_sa';
	const RETRIES   = 5;

	public static function init(): void {
		add_action( 'bm_booking_confirmed', [ __CLASS__, 'queue_sync' ] );
		add_action( 'bm_block_created', [ __CLASS__, 'queue_sync' ] );
		add_action( 'bm_booking_cancelled', [ __CLASS__, 'queue_delete' ] );
		add_action( 'bm_gcal_sync', [ __CLASS__, 'run_sync' ], 10, 2 );
		add_action( 'bm_gcal_delete', [ __CLASS__, 'run_delete' ], 10, 4 );
	}

	/* ================= konfiguracja ================= */

	/** Dane konta serwisowego albo null. */
	public static function credentials(): ?array {
		$raw = defined( 'BM_GOOGLE_SA_JSON' ) ? (string) BM_GOOGLE_SA_JSON : (string) get_option( self::OPTION, '' );
		if ( '' === trim( $raw ) ) {
			return null;
		}
		if ( '{' !== ltrim( $raw )[0] && is_readable( $raw ) ) {
			$raw = (string) file_get_contents( $raw ); // phpcs:ignore
		}
		$j = json_decode( $raw, true );
		return is_array( $j ) && ! empty( $j['client_email'] ) && ! empty( $j['private_key'] ) ? $j : null;
	}

	public static function source(): string {
		return defined( 'BM_GOOGLE_SA_JSON' ) ? 'wp-config' : ( get_option( self::OPTION ) ? 'option' : '' );
	}

	public static function calendar_of( int $apartment_id ): string {
		return trim( (string) get_post_meta( $apartment_id, '_bm_gcal_id', true ) );
	}

	public static function enabled_for( int $apartment_id ): bool {
		return self::credentials() && '' !== self::calendar_of( $apartment_id );
	}

	/** Stan synchronizacji apartamentu (do kolumny w „Apartamenty”). */
	public static function set_status( int $apartment_id, bool $ok, string $message = '' ): void {
		update_post_meta( $apartment_id, '_bm_gcal_status', [ 'ok' => $ok, 'message' => $message, 'time' => time() ] );
	}

	public static function status( int $apartment_id ): ?array {
		$s = get_post_meta( $apartment_id, '_bm_gcal_status', true );
		return is_array( $s ) ? $s : null;
	}

	/* ================= token ================= */

	private static function b64( string $s ): string {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
	}

	/** JWT podpisany kluczem konta serwisowego (RS256). */
	public static function jwt( array $cred, int $now ): ?string {
		$head  = self::b64( wp_json_encode( [ 'alg' => 'RS256', 'typ' => 'JWT' ] ) );
		$claim = self::b64( wp_json_encode( [
			'iss' => $cred['client_email'], 'scope' => self::SCOPE, 'aud' => self::TOKEN_URL, 'iat' => $now, 'exp' => $now + 3600,
		] ) );
		$sig = '';
		if ( ! openssl_sign( "$head.$claim", $sig, $cred['private_key'], OPENSSL_ALGO_SHA256 ) ) {
			return null;
		}
		return "$head.$claim." . self::b64( $sig );
	}

	/** Token dostępu (cache w transiencie do wygaśnięcia) albo WP_Error. */
	public static function token() {
		$cred = self::credentials();
		if ( ! $cred ) {
			return new WP_Error( 'bm_gcal_cred', 'Brak klucza konta serwisowego Google.' );
		}
		$key    = 'bm_gcal_token_' . md5( $cred['client_email'] );
		$cached = get_transient( $key );
		if ( $cached ) {
			return $cached;
		}
		$jwt = self::jwt( $cred, time() );
		if ( ! $jwt ) {
			return new WP_Error( 'bm_gcal_sign', 'Nie udało się podpisać tokenu — sprawdź klucz prywatny w JSON-ie.' );
		}
		$res = wp_remote_post( self::TOKEN_URL, [
			'timeout' => 15,
			'body'    => [ 'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt ],
		] );
		$body = is_wp_error( $res ) ? null : json_decode( wp_remote_retrieve_body( $res ), true );
		if ( empty( $body['access_token'] ) ) {
			return new WP_Error( 'bm_gcal_token', 'Google odrzucił logowanie: ' . ( is_wp_error( $res ) ? $res->get_error_message() : ( $body['error_description'] ?? $body['error'] ?? 'nieznany błąd' ) ) );
		}
		set_transient( $key, $body['access_token'], max( 60, (int) ( $body['expires_in'] ?? 3600 ) - 120 ) );
		return $body['access_token'];
	}

	/** Zapytanie do API kalendarza. Zwraca [kod, dane] albo WP_Error (sieć/logowanie). */
	private static function api( string $method, string $path, ?array $body = null ) {
		$token = self::token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$res = wp_remote_request( self::API . $path, [
			'method'  => $method,
			'timeout' => 15,
			'headers' => [ 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ],
			'body'    => null === $body ? null : wp_json_encode( $body ),
		] );
		if ( is_wp_error( $res ) ) {
			return $res;
		}
		return [ (int) wp_remote_retrieve_response_code( $res ), json_decode( wp_remote_retrieve_body( $res ), true ) ];
	}

	private static function cal_path( string $calendar_id ): string {
		return '/calendars/' . rawurlencode( $calendar_id ) . '/events';
	}

	/* ================= kolejka ================= */

	public static function queue_sync( int $booking_id ): void {
		$b = BM_Availability::get( $booking_id );
		if ( $b && self::enabled_for( (int) $b->apartment_id ) && function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( 'bm_gcal_sync', [ $booking_id, 1 ], 'bookmanager' );
		}
	}

	public static function queue_delete( int $booking_id ): void {
		$b = BM_Availability::get( $booking_id );
		if ( $b && $b->google_event_id && function_exists( 'as_enqueue_async_action' ) ) {
			$cal = self::calendar_of( (int) $b->apartment_id );
			as_enqueue_async_action( 'bm_gcal_delete', [ $booking_id, $cal, $b->google_event_id, 1 ], 'bookmanager' );
		}
	}

	private static function retry( string $hook, array $args, int $attempt ): void {
		if ( $attempt < self::RETRIES && function_exists( 'as_schedule_single_action' ) ) {
			$args[ count( $args ) - 1 ] = $attempt + 1;
			as_schedule_single_action( time() + 300 * $attempt, $hook, $args, 'bookmanager' ); // 5, 10, 15… min
		}
	}

	/* ================= operacje ================= */

	/** Treść wydarzenia: minimum danych osobowych (imię i inicjał nazwiska). */
	public static function event_body( $b ): array {
		$o = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		if ( 'block' === $b->status ) {
			$summary = 'Blokada' . ( $b->note ? ': ' . $b->note : '' );
			$desc    = 'Blokada ręczna z BookManagera.';
		} else {
			$name    = $o ? trim( $o->get_billing_first_name() . ' ' . mb_substr( $o->get_billing_last_name(), 0, 1 ) . ( $o->get_billing_last_name() ? '.' : '' ) ) : 'Gość';
			$people  = $b->adults + $b->children;
			$summary = sprintf( '%s · %d %s', $name, $people, BM_Pricing::pl( $people, 'osoba', 'osoby', 'osób' ) );
			$lines   = [ 'Rezerwacja #' . $b->id . ( $o ? ', zamówienie #' . $o->get_order_number() : '' ) ];
			if ( $b->arrival_time ) {
				$lines[] = 'Przyjazd ok. ' . substr( $b->arrival_time, 0, 5 );
			}
			if ( (float) $b->balance_due > 0 ) {
				$lines[] = 'Do dopłaty: ' . html_entity_decode( wp_strip_all_tags( wc_price( $b->balance_due ) ) );
			}
			$desc = implode( "\n", $lines );
		}
		return [
			'summary'            => $summary,
			'description'        => $desc,
			'start'              => [ 'date' => $b->check_in ],
			'end'                => [ 'date' => $b->check_out ], // całodniowe: data końca wyłączna — jak wymeldowanie
			'transparency'       => 'opaque',
			'extendedProperties' => [ 'private' => [ 'bm_booking_id' => (string) $b->id, 'bm_site' => home_url() ] ],
		];
	}

	public static function run_sync( int $booking_id, int $attempt = 1 ): void {
		$b = BM_Availability::get( $booking_id );
		if ( ! $b || ! in_array( $b->status, [ 'confirmed', 'block' ], true ) ) {
			return;
		}
		$apt = (int) $b->apartment_id;
		$cal = self::calendar_of( $apt );
		if ( ! $cal || ! self::credentials() ) {
			return;
		}
		$body = self::event_body( $b );
		$res  = $b->google_event_id
			? self::api( 'PUT', self::cal_path( $cal ) . '/' . rawurlencode( $b->google_event_id ), $body )
			: self::api( 'POST', self::cal_path( $cal ), $body );

		if ( ! is_wp_error( $res ) && 404 === $res[0] && $b->google_event_id ) { // ktoś usunął wydarzenie w Google — tworzymy od nowa
			$res = self::api( 'POST', self::cal_path( $cal ), $body );
		}
		if ( is_wp_error( $res ) || $res[0] >= 300 ) {
			$msg = is_wp_error( $res ) ? $res->get_error_message() : ( $res[1]['error']['message'] ?? 'HTTP ' . $res[0] );
			self::set_status( $apt, false, $msg );
			self::retry( 'bm_gcal_sync', [ $booking_id, $attempt ], $attempt );
			return;
		}
		global $wpdb;
		$wpdb->update( BM_Installer::table( 'bookings' ), [ 'google_event_id' => $res[1]['id'] ?? $b->google_event_id ], [ 'id' => $booking_id ] );
		self::set_status( $apt, true );
	}

	public static function run_delete( int $booking_id, string $calendar_id, string $event_id, int $attempt = 1 ): void {
		if ( ! $calendar_id || ! $event_id ) {
			return;
		}
		$res = self::api( 'DELETE', self::cal_path( $calendar_id ) . '/' . rawurlencode( $event_id ) );
		if ( is_wp_error( $res ) || ( $res[0] >= 300 && ! in_array( $res[0], [ 404, 410 ], true ) ) ) {
			self::retry( 'bm_gcal_delete', [ $booking_id, $calendar_id, $event_id, $attempt ], $attempt );
			return;
		}
		global $wpdb;
		$wpdb->update( BM_Installer::table( 'bookings' ), [ 'google_event_id' => null ], [ 'id' => $booking_id ] );
	}

	/** Sprawdzenie dostępu do kalendarza apartamentu (przycisk na karcie). */
	public static function test( int $apartment_id ): array {
		$cal = self::calendar_of( $apartment_id );
		if ( ! $cal ) {
			return [ false, 'Brak ID kalendarza.' ];
		}
		$res = self::api( 'GET', '/calendars/' . rawurlencode( $cal ) );
		if ( is_wp_error( $res ) ) {
			$r = [ false, $res->get_error_message() ];
		} elseif ( 200 === $res[0] ) {
			$r = [ true, 'Połączono z kalendarzem „' . ( $res[1]['summary'] ?? $cal ) . '”.' ];
		} elseif ( 404 === $res[0] ) {
			$r = [ false, 'Kalendarz nie istnieje albo nie został udostępniony kontu ' . ( self::credentials()['client_email'] ?? '' ) . '.' ];
		} else {
			$r = [ false, $res[1]['error']['message'] ?? 'HTTP ' . $res[0] ];
		}
		self::set_status( $apartment_id, $r[0], $r[1] );
		return $r;
	}

	/** Wysyła do Google wszystkie przyszłe potwierdzone rezerwacje i blokady apartamentu. */
	public static function resync_apartment( int $apartment_id ): int {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare(
			'SELECT id FROM ' . BM_Installer::table( 'bookings' ) . " WHERE apartment_id = %d AND status IN ('confirmed','block') AND check_out >= %s",
			$apartment_id, gmdate( 'Y-m-d' )
		) );
		foreach ( $ids as $id ) {
			self::queue_sync( (int) $id );
		}
		return count( $ids );
	}
}
