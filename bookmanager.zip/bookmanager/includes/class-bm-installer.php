<?php
defined( 'ABSPATH' ) || exit;

/**
 * Schemat bazy BookManagera.
 *
 * Zasada: liczby i statusy w tabelach BookManagera (szybkie raporty),
 * dane osobowe gościa wyłącznie w zamówieniu WooCommerce (jedno miejsce do usunięcia — RODO).
 *
 * Zmiana schematu = edycja CREATE TABLE poniżej + podbicie BM_DB_VERSION.
 * dbDelta sama dokłada brakujące kolumny i indeksy, nie ruszając danych.
 * Przekształcenia danych między wersjami — w migrate().
 */
class BM_Installer {

	public static function maybe_upgrade(): void {
		if ( get_option( 'bm_db_version' ) !== BM_DB_VERSION ) {
			self::install();
		}
	}

	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$from = (int) get_option( 'bm_db_version', 0 );
		$c    = $wpdb->get_charset_collate();
		$p    = $wpdb->prefix . 'bm_';

		// Uwaga: dbDelta wymaga dwóch spacji po "PRIMARY KEY" i każdej kolumny w osobnej linii.
		$sql = "CREATE TABLE {$p}bookings (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			apartment_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned DEFAULT NULL,
			check_in date NOT NULL,
			check_out date NOT NULL,
			guests smallint(5) unsigned NOT NULL DEFAULT 1,
			adults smallint(5) unsigned NOT NULL DEFAULT 1,
			children smallint(5) unsigned NOT NULL DEFAULT 0,
			children_ages varchar(100) NOT NULL DEFAULT '',
			extra_beds_adult tinyint(3) unsigned NOT NULL DEFAULT 0,
			extra_beds_child tinyint(3) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'hold',
			source varchar(20) NOT NULL DEFAULT 'www',
			channel varchar(30) NOT NULL DEFAULT 'www',
			currency char(3) NOT NULL DEFAULT 'PLN',
			price_nights decimal(12,2) NOT NULL DEFAULT 0,
			price_guests decimal(12,2) NOT NULL DEFAULT 0,
			price_extra_beds decimal(12,2) NOT NULL DEFAULT 0,
			price_extras decimal(12,2) NOT NULL DEFAULT 0,
			service_fee decimal(12,2) NOT NULL DEFAULT 0,
			discount decimal(12,2) NOT NULL DEFAULT 0,
			total decimal(12,2) NOT NULL DEFAULT 0,
			city_tax decimal(12,2) NOT NULL DEFAULT 0,
			deposit_paid decimal(12,2) NOT NULL DEFAULT 0,
			balance_due decimal(12,2) NOT NULL DEFAULT 0,
			balance_due_date date DEFAULT NULL,
			price_breakdown longtext,
			security_deposit decimal(12,2) NOT NULL DEFAULT 0,
			security_deposit_status varchar(20) NOT NULL DEFAULT 'none',
			stay_status varchar(20) NOT NULL DEFAULT 'pending',
			checked_in_at datetime DEFAULT NULL,
			checked_out_at datetime DEFAULT NULL,
			arrival_time time DEFAULT NULL,
			guest_country char(2) NOT NULL DEFAULT '',
			note text,
			google_event_id varchar(255) DEFAULT NULL,
			hold_expires datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY apartment_dates (apartment_id,check_in,check_out),
			KEY order_id (order_id),
			KEY status_hold (status,hold_expires),
			KEY check_in (check_in),
			KEY stay_status (stay_status)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}nights (
			apartment_id bigint(20) unsigned NOT NULL,
			night_date date NOT NULL,
			booking_id bigint(20) unsigned NOT NULL,
			PRIMARY KEY  (apartment_id,night_date),
			KEY booking_id (booking_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}payments (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			booking_id bigint(20) unsigned NOT NULL,
			kind varchar(20) NOT NULL DEFAULT 'balance',
			amount decimal(12,2) NOT NULL,
			method varchar(20) NOT NULL DEFAULT 'cash',
			paid_at datetime NOT NULL,
			note varchar(255) NOT NULL DEFAULT '',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY booking_id (booking_id),
			KEY paid_at (paid_at)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}extras (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(190) NOT NULL,
			description text,
			price decimal(12,2) NOT NULL DEFAULT 0,
			charge_type varchar(20) NOT NULL DEFAULT 'stay',
			allow_qty tinyint(1) unsigned NOT NULL DEFAULT 0,
			max_qty smallint(5) unsigned NOT NULL DEFAULT 1,
			pool_location_id bigint(20) unsigned NOT NULL DEFAULT 0,
			pool_qty smallint(5) unsigned NOT NULL DEFAULT 0,
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			sort int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY object_id (object_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}apartment_extras (
			apartment_id bigint(20) unsigned NOT NULL,
			extra_id bigint(20) unsigned NOT NULL,
			price_override decimal(12,2) DEFAULT NULL,
			max_qty_override smallint(5) unsigned DEFAULT NULL,
			PRIMARY KEY  (apartment_id,extra_id),
			KEY extra_id (extra_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}booking_extras (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			booking_id bigint(20) unsigned NOT NULL,
			extra_id bigint(20) unsigned NOT NULL,
			name varchar(190) NOT NULL,
			charge_type varchar(20) NOT NULL,
			qty smallint(5) unsigned NOT NULL DEFAULT 1,
			unit_price decimal(12,2) NOT NULL DEFAULT 0,
			total decimal(12,2) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY booking_id (booking_id),
			KEY extra_id (extra_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}features (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			object_id bigint(20) unsigned NOT NULL,
			kind varchar(10) NOT NULL DEFAULT 'amenity',
			name varchar(190) NOT NULL,
			description text,
			category varchar(30) NOT NULL DEFAULT '',
			icon varchar(50) NOT NULL DEFAULT '',
			requires_acceptance tinyint(1) unsigned NOT NULL DEFAULT 0,
			display varchar(255) NOT NULL DEFAULT '',
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			sort int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY object_kind (object_id,kind)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}feature_links (
			feature_id bigint(20) unsigned NOT NULL,
			target_type varchar(10) NOT NULL,
			target_id bigint(20) unsigned NOT NULL,
			qty smallint(5) unsigned NOT NULL DEFAULT 1,
			note varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (feature_id,target_type,target_id),
			KEY target (target_type,target_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}acceptances (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			booking_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			context varchar(30) NOT NULL DEFAULT 'checkout',
			content longtext NOT NULL,
			content_hash char(64) NOT NULL,
			accepted_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY booking_id (booking_id),
			KEY order_id (order_id)
		) ENGINE=InnoDB $c;
		CREATE TABLE {$p}log (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(40) NOT NULL,
			object_type varchar(20) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			details text,
			ip varchar(45) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY object (object_type,object_id)
		) ENGINE=InnoDB $c;";

		dbDelta( $sql );
		self::migrate( $from );
		update_option( 'bm_db_version', BM_DB_VERSION, false );
	}

	/** Przekształcenia danych przy przejściu między wersjami schematu. */
	private static function migrate( int $from ): void {
		global $wpdb;
		$t = $wpdb->prefix . 'bm_bookings';

		if ( $from > 0 && $from < 2 ) {
			// v1 znała tylko łączną liczbę gości — traktujemy ich jako dorosłych.
			$wpdb->query( "UPDATE $t SET adults = guests, children = 0 WHERE children = 0" );
			$wpdb->query( "UPDATE $t SET channel = 'phone' WHERE source = 'admin'" );
		}
	}

	/** Nazwy tabel w jednym miejscu. */
	public static function table( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . 'bm_' . $name;
	}
}
