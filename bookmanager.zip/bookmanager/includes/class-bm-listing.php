<?php
defined( 'ABSPATH' ) || exit;

/**
 * Lista apartamentów z wyszukiwarką — zamiast sklepowej listy produktów.
 *
 * [bookmanager_lista] — na dowolnej stronie (zwykle „Apartamenty”, wskazanej w panelu → Strona).
 * Atrybuty: obiekt="slug lub ID lokalizacji" (zawęża listę), wyszukiwarka="nie" (bez paska wyszukiwania).
 *
 * Bez dat: wszystkie apartamenty z ceną „od”. Z datami: wolne apartamenty z ceną za cały pobyt
 * (ta sama wycena co w widżecie), pod nimi niedostępne — z powodem (zajęte, minimalny pobyt, za mało miejsc).
 * Wyszukiwanie działa zwykłym formularzem GET — adres można wysłać gościowi albo zapisać.
 */
class BM_Listing {

	const MAX_KIDS = 6;

	public static function init(): void {
		add_shortcode( 'bookmanager_lista', [ __CLASS__, 'shortcode' ] );
		add_shortcode( 'bookmanager_apartamenty', [ __CLASS__, 'shortcode' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'assets' ] );
		add_filter( 'bm_feature_contexts', [ __CLASS__, 'context' ] );
	}

	public static function assets(): void {
		wp_register_script( 'bookmanager-list', plugins_url( 'assets/list.js', BM_FILE ), [], BM_VERSION, true );
	}

	public static function context( array $c ): array {
		$c['listing'] = __( 'Karta na liście apartamentów', 'bookmanager' );
		return $c;
	}

	/* ================= zapytanie ================= */

	/** Parametry wyszukiwania z adresu (bm_in, bm_out, bm_adults, bm_children, bm_loc, bm_sort, bm_f[]). */
	public static function query(): array {
		// phpcs:disable WordPress.Security.NonceVerification -- publiczne wyszukiwanie (GET)
		$g    = wp_unslash( $_GET );
		$date = fn( $k ) => isset( $g[ $k ] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $g[ $k ] ) ? (string) $g[ $k ] : '';
		$ages = [];
		foreach ( explode( ',', (string) ( $g['bm_children'] ?? '' ) ) as $a ) {
			if ( preg_match( '/^\d{1,2}$/', trim( $a ) ) ) {
				$ages[] = min( BM_Apartment::MAX_CHILD_AGE, (int) $a );
			}
		}
		$q = [
			'in'     => $date( 'bm_in' ),
			'out'    => $date( 'bm_out' ),
			'adults' => max( 1, min( 30, (int) ( $g['bm_adults'] ?? 2 ) ) ),
			'ages'   => array_slice( $ages, 0, self::MAX_KIDS ),
			'loc'    => absint( $g['bm_loc'] ?? 0 ),
			'sort'   => in_array( $g['bm_sort'] ?? '', [ 'price', 'price_desc', 'size' ], true ) ? $g['bm_sort'] : '',
			'f'      => array_values( array_filter( array_map( 'absint', (array) ( $g['bm_f'] ?? [] ) ) ) ),
		];
		// phpcs:enable
		if ( $q['in'] && $q['out'] && $q['out'] <= $q['in'] ) {
			$q['out'] = '';
		}
		$q['dated'] = $q['in'] && $q['out'];
		return $q;
	}

	/** Dostawki potrzebne dla składu (najmniej, jak się da) albo null, gdy się nie zmieści. */
	public static function auto_party( array $cfg, int $adults, array $ages ): ?array {
		$maxA = $cfg['eb_adult']['enabled'] ? $cfg['eb_adult']['max'] : 0;
		$maxC = $cfg['eb_child']['enabled'] ? $cfg['eb_child']['max'] : 0;
		for ( $sum = 0; $sum <= $maxA + $maxC; $sum++ ) {
			for ( $a = min( $sum, $maxA ); $a >= 0; $a-- ) {
				$c = $sum - $a;
				if ( $c > $maxC ) {
					continue;
				}
				$p = [ 'adults' => $adults, 'children_ages' => $ages, 'eb_adult' => $a, 'eb_child' => $c, 'extras' => [] ];
				if ( ! is_wp_error( BM_Pricing::validate_party( $cfg, $p ) ) ) {
					return $p;
				}
			}
		}
		return null;
	}

	/** Największa liczba gości (miejsca + dostawki). */
	public static function capacity( array $cfg ): int {
		$eb = ( $cfg['eb_adult']['enabled'] ? $cfg['eb_adult']['max'] : 0 ) + ( $cfg['eb_child']['enabled'] ? $cfg['eb_child']['max'] : 0 );
		if ( null !== $cfg['eb_max_total'] ) {
			$eb = min( $eb, $cfg['eb_max_total'] );
		}
		return $cfg['beds'] + $eb;
	}

	/** Obiekty (lokalizacje najwyższego rzędu), w których są opublikowane apartamenty. */
	private static function objects( array $apts ): array {
		$out = [];
		foreach ( $apts as $a ) {
			$o = BM_Locations::object_of_apartment( $a->get_id() );
			if ( $o && ! isset( $out[ $o ] ) ) {
				$t         = get_term( $o );
				$out[ $o ] = $t && ! is_wp_error( $t ) ? $t->name : '#' . $o;
			}
		}
		asort( $out );
		return $out;
	}

	/** Udogodnienia do filtrowania: oznaczone „Filtry wyszukiwarki”, które ma choć jeden apartament. */
	private static function filters( array $apts ): array {
		$out = [];
		foreach ( $apts as $a ) {
			foreach ( BM_Features::for_apartment( $a->get_id(), 'filters' ) as $lvl ) {
				foreach ( $lvl['items'] as $f ) {
					if ( BM_Features::AMENITY === $f['kind'] ) { // zasady (cisza nocna…) nie są czymś, czego się szuka
						$out[ $f['id'] ] = $f['name'];
					}
				}
			}
		}
		asort( $out );
		return $out;
	}

	private static function feature_ids( int $apt ): array {
		$ids = [];
		foreach ( BM_Features::for_apartment( $apt, 'filters' ) as $lvl ) {
			foreach ( $lvl['items'] as $f ) {
				$ids[] = (int) $f['id'];
			}
		}
		return $ids;
	}

	/* ================= wynik ================= */

	/**
	 * Apartamenty z ceną i dostępnością: [['apt'=>…, 'cfg'=>…, 'quote'=>…|null, 'party'=>…, 'error'=>''], …]
	 * Bez dat: wszystkie, cena „od”. Z datami: wycena, błąd = niedostępny.
	 */
	public static function results( array $q, array $apts ): array {
		$out = [];
		foreach ( $apts as $apt ) {
			$cfg = BM_Apartment::config( $apt );
			if ( $q['loc'] && BM_Locations::object_of_apartment( $apt->get_id() ) !== $q['loc'] ) {
				continue;
			}
			if ( $q['f'] && array_diff( $q['f'], self::feature_ids( $apt->get_id() ) ) ) {
				continue;
			}
			$row = [ 'apt' => $apt, 'cfg' => $cfg, 'quote' => null, 'party' => null, 'error' => '' ];
			$guests = $q['adults'] + count( $q['ages'] );
			if ( $q['dated'] || $guests > 2 || $q['ages'] ) {
				$row['party'] = self::auto_party( $cfg, $q['adults'], $q['ages'] );
				if ( ! $row['party'] ) {
					$row['error'] = sprintf( 'Za mało miejsc — najwyżej %d %s.', self::capacity( $cfg ), BM_Pricing::pl( self::capacity( $cfg ), 'osoba', 'osoby', 'osób' ) );
				}
			}
			if ( $q['dated'] && ! $row['error'] ) {
				$quote = BM_Pricing::quote( $apt->get_id(), $q['in'], $q['out'], $row['party'] );
				if ( is_wp_error( $quote ) ) {
					$row['error'] = self::reason( $quote );
				} else {
					$row['quote'] = $quote;
				}
			}
			$out[] = $row;
		}
		$price = function ( $r ) {
			if ( $r['quote'] ) {
				return (float) $r['quote']['total'];
			}
			$p = BM_Apartment::from_price( $r['apt'] );
			return (float) $p['amount'] ?: PHP_INT_MAX;
		};
		switch ( $q['sort'] ) {
			case 'price':
				usort( $out, fn( $a, $b ) => $price( $a ) <=> $price( $b ) );
				break;
			case 'price_desc':
				usort( $out, fn( $a, $b ) => $price( $b ) <=> $price( $a ) );
				break;
			case 'size':
				usort( $out, fn( $a, $b ) => self::capacity( $b['cfg'] ) <=> self::capacity( $a['cfg'] ) );
				break;
		}
		return $out;
	}

	/** Krótki powód dla gościa. */
	private static function reason( WP_Error $e ): string {
		$code = $e->get_error_code();
		if ( in_array( $code, [ 'bm_unavailable', 'bm_booked', 'bm_not_available', 'bm_taken' ], true ) || str_contains( $e->get_error_message(), 'zaję' ) ) {
			return __( 'Zajęty w tym terminie.', 'bookmanager' );
		}
		return $e->get_error_message();
	}

	/* ================= HTML ================= */

	public static function shortcode( $atts = [] ): string {
		$atts = shortcode_atts( [ 'obiekt' => '', 'wyszukiwarka' => 'tak' ], $atts, 'bookmanager_lista' );
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_script( 'bookmanager-list' );

		$apts = wc_get_products( [ 'type' => 'bm_apartment', 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ] );
		if ( $atts['obiekt'] ) {
			$term = is_numeric( $atts['obiekt'] ) ? get_term( (int) $atts['obiekt'], BM_Locations::TAX ) : get_term_by( 'slug', $atts['obiekt'], BM_Locations::TAX );
			if ( $term && ! is_wp_error( $term ) ) {
				$in   = BM_Locations::apartments_in( $term->term_id );
				$apts = array_values( array_filter( $apts, fn( $a ) => in_array( $a->get_id(), $in, true ) ) );
			}
		}
		$q    = self::query();
		$rows = self::results( $q, $apts );
		$a    = BM_Appearance::all();

		$free = array_values( array_filter( $rows, fn( $r ) => ! $r['error'] ) );
		$off  = array_values( array_filter( $rows, fn( $r ) => $r['error'] ) );

		$html = 'nie' !== $atts['wyszukiwarka'] ? self::search( $q, $apts ) : '';
		$html .= '<div class="bm-apts__head"><p class="bm-apts__count" role="status">' . esc_html( self::summary( $q, count( $free ) ) ) . '</p>' . self::sort( $q ) . '</div>';

		if ( $free ) {
			$html .= '<div class="bm-apts__grid">' . implode( '', array_map( fn( $r ) => self::card( $r, $q ), $free ) ) . '</div>';
		} else {
			$html .= '<div class="bm-apts__empty"><p><strong>' . esc_html__( 'Brak wolnych apartamentów dla tych kryteriów.', 'bookmanager' ) . '</strong></p><p>'
				. esc_html__( 'Spróbuj innych dat, mniejszej liczby gości albo zobacz kalendarze poniżej.', 'bookmanager' ) . '</p></div>';
		}
		if ( $off ) {
			$html .= '<h2 class="bm-apts__subtitle">' . esc_html( $q['dated'] ? __( 'Niedostępne w wybranym terminie', 'bookmanager' ) : __( 'Nie pomieszczą tylu gości', 'bookmanager' ) ) . '</h2>'
				. '<div class="bm-apts__grid is-off">' . implode( '', array_map( fn( $r ) => self::card( $r, $q ), $off ) ) . '</div>';
		}

		return sprintf( '<div class="bm-ui bm-apts bm-apts--%s alignwide %s" style="%s">%s</div>',
			esc_attr( $a['list'] ), esc_attr( BM_Appearance::classes( $a ) ), esc_attr( BM_Appearance::style_vars( $a ) ), $html );
	}

	private static function summary( array $q, int $n ): string {
		$guests = $q['adults'] + count( $q['ages'] );
		$who    = sprintf( '%d %s', $guests, BM_Pricing::pl( $guests, 'gość', 'gości', 'gości' ) );
		if ( $q['dated'] ) {
			$nights = (int) round( ( strtotime( $q['out'] ) - strtotime( $q['in'] ) ) / DAY_IN_SECONDS );
			return sprintf( '%d %s · %s – %s · %d %s · %s', $n, BM_Pricing::pl( $n, 'wolny apartament', 'wolne apartamenty', 'wolnych apartamentów' ),
				BM_Checkout::short_date( $q['in'] ), BM_Checkout::short_date( $q['out'] ), $nights, BM_Pricing::pl( $nights, 'noc', 'noce', 'nocy' ), $who );
		}
		return sprintf( '%d %s · wybierz termin, aby zobaczyć wolne i cenę za pobyt', $n, BM_Pricing::pl( $n, 'apartament', 'apartamenty', 'apartamentów' ) );
	}

	private static function sort( array $q ): string {
		$opts = [ '' => __( 'Polecane', 'bookmanager' ), 'price' => __( 'Cena: od najniższej', 'bookmanager' ), 'price_desc' => __( 'Cena: od najwyższej', 'bookmanager' ), 'size' => __( 'Najwięcej miejsc', 'bookmanager' ) ];
		$o    = '';
		foreach ( $opts as $k => $l ) {
			$o .= '<option value="' . esc_attr( $k ) . '"' . selected( $q['sort'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		return '<label class="bm-apts__sort"><span>' . esc_html__( 'Sortuj', 'bookmanager' ) . '</span><select name="bm_sort" form="bm-search" class="bm-select" data-bm-autosubmit>' . $o . '</select></label>';
	}

	/** Pasek wyszukiwania (GET na tę samą stronę). */
	private static function search( array $q, array $apts ): string {
		$today  = wp_date( 'Y-m-d' );
		$max    = 0;
		foreach ( $apts as $a ) {
			$max = max( $max, self::capacity( BM_Apartment::config( $a ) ) );
		}
		$max     = max( 2, $max );
		$objects = self::objects( $apts );
		$filters = self::filters( $apts );

		$adults = '';
		for ( $i = 1; $i <= $max; $i++ ) {
			$adults .= '<option value="' . $i . '"' . selected( $q['adults'], $i, false ) . '>' . $i . '</option>';
		}
		$kids = '';
		for ( $i = 0; $i <= self::MAX_KIDS; $i++ ) {
			$kids .= '<option value="' . $i . '"' . selected( count( $q['ages'] ), $i, false ) . '>' . $i . '</option>';
		}
		$ages = '';
		for ( $i = 0; $i < self::MAX_KIDS; $i++ ) {
			$cur  = $q['ages'][ $i ] ?? '';
			$opts = '<option value="">' . esc_html__( 'wiek', 'bookmanager' ) . '</option>';
			for ( $y = 0; $y <= BM_Apartment::MAX_CHILD_AGE; $y++ ) {
				$opts .= '<option value="' . $y . '"' . selected( (string) $cur, (string) $y, false ) . '>' . ( 0 === $y ? __( 'do 1 roku', 'bookmanager' ) : $y . ' ' . BM_Pricing::pl( $y, 'rok', 'lata', 'lat' ) ) . '</option>';
			}
			$ages .= '<label class="bm-age"' . ( $i < count( $q['ages'] ) ? '' : ' hidden' ) . '><span class="screen-reader-text">' . esc_html( sprintf( __( 'Wiek dziecka %d', 'bookmanager' ), $i + 1 ) ) . '</span><select class="bm-select" data-bm-age>' . $opts . '</select></label>';
		}
		$guests_label = self::guests_label( $q['adults'], count( $q['ages'] ) );

		$loc = '';
		if ( count( $objects ) > 1 ) {
			$o = '<option value="">' . esc_html__( 'Wszystkie', 'bookmanager' ) . '</option>';
			foreach ( $objects as $id => $name ) {
				$o .= '<option value="' . (int) $id . '"' . selected( $q['loc'], $id, false ) . '>' . esc_html( $name ) . '</option>';
			}
			$loc = '<label class="bm-search__field bm-search__loc"><span class="bm-search__label">' . esc_html__( 'Lokalizacja', 'bookmanager' ) . '</span><select name="bm_loc" class="bm-search__input">' . $o . '</select></label>';
		}

		$chips = '';
		if ( $filters ) {
			foreach ( $filters as $id => $name ) {
				$chips .= '<label class="bm-chip-f"><input type="checkbox" name="bm_f[]" value="' . (int) $id . '"' . checked( in_array( (int) $id, $q['f'], true ), true, false ) . ' data-bm-autosubmit><span>' . esc_html( $name ) . '</span></label>';
			}
			$on    = count( $q['f'] );
			$chips = '<details class="bm-search__more"' . ( $on ? ' open' : '' ) . '><summary>' . BM_Page::icon( 'search' ) . esc_html__( 'Udogodnienia', 'bookmanager' )
				. ( $on ? ' <span class="bm-search__badge">' . (int) $on . '</span>' : '' ) . '</summary><div class="bm-search__chips">' . $chips . '</div></details>';
		}

		return sprintf(
			'<form class="bm-search" id="bm-search" method="get" action="%1$s" role="search">'
			. '<div class="bm-search__bar">'
			. '<label class="bm-search__field"><span class="bm-search__label">%2$s</span><input type="date" class="bm-search__input" name="bm_in" value="%3$s" min="%4$s" data-bm-in></label>'
			. '<label class="bm-search__field"><span class="bm-search__label">%5$s</span><input type="date" class="bm-search__input" name="bm_out" value="%6$s" min="%4$s" data-bm-out></label>'
			. '<div class="bm-search__field bm-search__guests"><span class="bm-search__label">%7$s</span>'
			. '<button type="button" class="bm-search__input bm-search__gbtn" aria-expanded="false" data-bm-guests>%8$s</button>'
			. '<div class="bm-gpop" hidden><div class="bm-gpop__row"><span>%9$s</span><select name="bm_adults" class="bm-select" data-bm-adults>%10$s</select></div>'
			. '<div class="bm-gpop__row"><span>%11$s<small>%12$s</small></span><select class="bm-select" data-bm-kids>%13$s</select></div>'
			. '<div class="bm-gpop__ages">%14$s</div><input type="hidden" name="bm_children" value="%15$s" data-bm-children>'
			. '<button type="button" class="bm-btn bm-btn--primary bm-btn--block" data-bm-gdone>%16$s</button></div></div>'
			. '%17$s<button type="submit" class="bm-btn bm-btn--primary bm-search__go">%18$s<span>%19$s</span></button></div>%20$s</form>',
			esc_url( get_permalink() ?: home_url( add_query_arg( [] ) ) ),
			esc_html__( 'Przyjazd', 'bookmanager' ),
			esc_attr( $q['in'] ),
			esc_attr( $today ),
			esc_html__( 'Wyjazd', 'bookmanager' ),
			esc_attr( $q['out'] ),
			esc_html__( 'Goście', 'bookmanager' ),
			esc_html( $guests_label ),
			esc_html__( 'Dorośli', 'bookmanager' ),
			$adults,
			esc_html__( 'Dzieci', 'bookmanager' ),
			esc_html__( '0–17 lat', 'bookmanager' ),
			$kids,
			$ages,
			esc_attr( implode( ',', $q['ages'] ) ),
			esc_html__( 'Gotowe', 'bookmanager' ),
			$loc,
			BM_Page::icon( 'search' ),
			esc_html__( 'Szukaj', 'bookmanager' ),
			$chips
		);
	}

	public static function guests_label( int $adults, int $kids ): string {
		$t = sprintf( '%d %s', $adults, BM_Pricing::pl( $adults, 'dorosły', 'dorosłych', 'dorosłych' ) );
		return $kids ? $t . sprintf( ', %d %s', $kids, BM_Pricing::pl( $kids, 'dziecko', 'dzieci', 'dzieci' ) ) : $t;
	}

	/** Karta apartamentu. */
	private static function card( array $r, array $q ): string {
		$apt  = $r['apt'];
		$cfg  = $r['cfg'];
		$args = array_filter( [
			'bm_in'       => $q['in'],
			'bm_out'      => $q['out'],
			'bm_adults'   => ( $q['dated'] || 2 !== $q['adults'] ) ? $q['adults'] : '',
			'bm_children' => implode( ',', $q['ages'] ),
		], fn( $v ) => '' !== $v && null !== $v );
		$url  = add_query_arg( array_map( 'rawurlencode', $args ), $apt->get_permalink() );
		if ( $q['dated'] ) {
			$url .= '#bm-rezerwacja';
		}

		// zdjęcia (do 5) — przewijane palcem / strzałkami
		$imgs  = array_slice( BM_Page::images( $apt ), 0, 5 );
		$media = '';
		foreach ( $imgs as $i => $img ) {
			$media .= '<a class="bm-lcard__slide" href="' . esc_url( $url ) . '" tabindex="' . ( $i ? '-1' : '0' ) . '">'
				. wp_get_attachment_image( $img['id'], 'large', false, [ 'class' => 'bm-img', 'alt' => $i ? '' : $img['alt'], 'loading' => 'lazy', 'sizes' => '(max-width: 700px) 100vw, 420px' ] ) . '</a>';
		}
		if ( ! $media ) {
			$media = '<a class="bm-lcard__slide bm-lcard__noimg" href="' . esc_url( $url ) . '" aria-hidden="true" tabindex="-1">' . BM_Page::icon( 'bed' ) . '</a>';
		}
		$nav = count( $imgs ) > 1
			? '<button type="button" class="bm-round bm-lcard__prev" aria-label="' . esc_attr__( 'Poprzednie zdjęcie', 'bookmanager' ) . '" hidden>' . BM_Page::icon( 'left' ) . '</button>'
			. '<button type="button" class="bm-round bm-lcard__next" aria-label="' . esc_attr__( 'Następne zdjęcie', 'bookmanager' ) . '">' . BM_Page::icon( 'right' ) . '</button>'
			. '<span class="bm-lcard__dots">' . str_repeat( '<i></i>', count( $imgs ) ) . '</span>'
			: '';

		$path  = array_reverse( BM_Locations::path( BM_Locations::of_apartment( $apt->get_id() ) ) );
		$where = implode( ' · ', array_filter( array_map( function ( $id ) {
			$t = get_term( $id );
			return $t && ! is_wp_error( $t ) ? $t->name : '';
		}, $path ) ) );

		// udogodnienia: oznaczone „Karta na liście”, a gdy brak — pierwsze 4 z apartamentu
		$amen = [];
		foreach ( BM_Features::for_apartment( $apt->get_id(), 'listing' ) as $lvl ) {
			foreach ( $lvl['items'] as $f ) {
				$amen[] = $f['name'];
			}
		}
		if ( ! $amen ) {
			foreach ( BM_Features::for_apartment( $apt->get_id(), 'apartment_page' ) as $lvl ) {
				foreach ( $lvl['items'] as $f ) {
					if ( BM_Features::AMENITY === $f['kind'] && ! $lvl['shared'] ) {
						$amen[] = $f['name'];
					}
				}
			}
		}
		$amen = array_slice( array_unique( $amen ), 0, 4 );

		if ( $r['quote'] ) {
			$n     = (int) $r['quote']['nights'];
			$price = '<strong class="bm-lcard__amount">' . wp_kses_post( wc_price( (float) $r['quote']['total'] ) ) . '</strong><span class="bm-lcard__unit">'
				. esc_html( sprintf( 'za %d %s', $n, BM_Pricing::pl( $n, 'noc', 'noce', 'nocy' ) ) ) . '</span>';
			$cta   = __( 'Rezerwuj', 'bookmanager' );
		} elseif ( $r['error'] ) {
			$price = '<span class="bm-lcard__why">' . esc_html( $r['error'] ) . '</span>';
			$cta   = __( 'Zobacz kalendarz', 'bookmanager' );
		} else {
			$from  = BM_Page::price_from_text( $apt );
			$price = $from ? '<strong class="bm-lcard__amount">' . esc_html( $from ) . '</strong>' : '';
			$cta   = __( 'Zobacz', 'bookmanager' );
		}

		$lead = wp_strip_all_tags( $apt->get_short_description() ?: $apt->get_description() );
		$lead = $lead ? wp_trim_words( $lead, 22, '…' ) : '';

		return sprintf(
			'<article class="bm-lcard%1$s"><div class="bm-lcard__media"><div class="bm-lcard__track">%2$s</div>%3$s</div>'
			. '<div class="bm-lcard__body">%4$s<h3 class="bm-lcard__title"><a href="%5$s">%6$s</a></h3>'
			. '<ul class="bm-lcard__facts"><li>%7$s%8$s</li>%9$s</ul>%10$s%11$s'
			. '<div class="bm-lcard__foot"><div class="bm-lcard__price">%12$s</div><a class="bm-btn %13$s bm-lcard__cta" href="%5$s">%14$s</a></div></div></article>',
			$r['error'] ? ' is-off' : '',
			$media,
			$nav,
			$where ? '<p class="bm-lcard__where">' . BM_Page::icon( 'pin' ) . '<span>' . esc_html( $where ) . '</span></p>' : '',
			esc_url( $url ),
			esc_html( $apt->get_name() ),
			BM_Page::icon( 'guests' ),
			esc_html( BM_Page::guests_text( $cfg ) ),
			'<li>' . BM_Page::icon( 'moon' ) . esc_html( sprintf( 'min. %d %s', $cfg['min_nights'], BM_Pricing::pl( $cfg['min_nights'], 'noc', 'noce', 'nocy' ) ) ) . '</li>',
			$lead ? '<p class="bm-lcard__lead">' . esc_html( $lead ) . '</p>' : '',
			$amen ? '<ul class="bm-lcard__amen">' . implode( '', array_map( fn( $x ) => '<li>' . BM_Page::icon( 'check' ) . esc_html( $x ) . '</li>', $amen ) ) . '</ul>' : '',
			$price,
			$r['quote'] ? 'bm-btn--primary' : 'bm-btn--ghost',
			esc_html( $cta )
		);
	}
}
