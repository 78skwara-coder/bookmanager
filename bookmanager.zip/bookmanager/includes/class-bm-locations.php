<?php
defined( 'ABSPATH' ) || exit;

/**
 * Drzewo lokalizacji: obiekt → budynek → piętro (typy można rozszerzać filtrem).
 * Natywna hierarchiczna taksonomia WordPressa przypięta do produktów.
 * Apartament należy do jednego węzła drzewa.
 */
class BM_Locations {

	const TAX       = 'bm_location';
	const META_TYPE = 'bm_level';

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'register' ], 5 );
	}

	/** Typy poziomów. Kolejność = typowa głębokość w drzewie. */
	public static function types(): array {
		return apply_filters( 'bm_location_types', [
			'object'   => __( 'Obiekt', 'bookmanager' ),
			'building' => __( 'Budynek', 'bookmanager' ),
			'floor'    => __( 'Piętro', 'bookmanager' ),
		] );
	}

	public static function register(): void {
		register_taxonomy( self::TAX, [ 'product' ], [
			'labels'            => [
				'name'          => __( 'Lokalizacje', 'bookmanager' ),
				'singular_name' => __( 'Lokalizacja', 'bookmanager' ),
				'add_new_item'  => __( 'Dodaj lokalizację', 'bookmanager' ),
				'edit_item'     => __( 'Edytuj lokalizację', 'bookmanager' ),
				'parent_item'   => __( 'Nadrzędna lokalizacja', 'bookmanager' ),
				'search_items'  => __( 'Szukaj lokalizacji', 'bookmanager' ),
				'not_found'     => __( 'Brak lokalizacji.', 'bookmanager' ),
			],
			'hierarchical'      => true,
			'public'            => false,
			'show_ui'           => true,
			'show_in_menu'      => false, // podpięte pod menu BookManager
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => false,
			'capabilities'      => [
				'manage_terms' => 'manage_woocommerce',
				'edit_terms'   => 'manage_woocommerce',
				'delete_terms' => 'manage_woocommerce',
				'assign_terms' => 'manage_woocommerce',
			],
		] );

		register_term_meta( self::TAX, self::META_TYPE, [
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => fn( $v ) => isset( self::types()[ $v ] ) ? $v : 'object',
		] );
	}

	public static function type_of( int $term_id ): string {
		$t = get_term_meta( $term_id, self::META_TYPE, true );
		return isset( self::types()[ $t ] ) ? $t : 'object';
	}

	/** Węzeł drzewa, do którego należy apartament (0 = nieprzypisany). */
	public static function of_apartment( int $apartment_id ): int {
		$terms = wp_get_object_terms( $apartment_id, self::TAX, [ 'fields' => 'ids' ] );
		return is_wp_error( $terms ) || ! $terms ? 0 : (int) $terms[0];
	}

	/** Ścieżka od węzła do korzenia: [węzeł, rodzic, …, korzeń]. */
	public static function path( int $term_id ): array {
		if ( ! $term_id ) {
			return [];
		}
		return array_merge( [ $term_id ], array_map( 'intval', get_ancestors( $term_id, self::TAX, 'taxonomy' ) ) );
	}

	/** Najbliższy przodek typu „obiekt” (lub korzeń drzewa, jeśli żaden nie jest oznaczony). */
	public static function object_of( int $term_id ): int {
		$path = self::path( $term_id );
		foreach ( $path as $id ) {
			if ( 'object' === self::type_of( $id ) ) {
				return $id;
			}
		}
		return $path ? end( $path ) : 0;
	}

	/** Obiekt, do którego należy apartament. */
	public static function object_of_apartment( int $apartment_id ): int {
		return self::object_of( self::of_apartment( $apartment_id ) );
	}

	/** ID węzła i wszystkich jego potomków. */
	public static function subtree( int $term_id ): array {
		$children = get_term_children( $term_id, self::TAX );
		return array_merge( [ $term_id ], is_wp_error( $children ) ? [] : array_map( 'intval', $children ) );
	}

	/** Apartamenty w węźle i całym poddrzewie. */
	public static function apartments_in( int $term_id ): array {
		return array_map( 'intval', get_objects_in_term( self::subtree( $term_id ), self::TAX ) ?: [] );
	}

	/**
	 * Apartamenty pogrupowane wg drzewa lokalizacji (kalendarz w kokpicie i w panelu).
	 * Zwraca [{title, type, depth, apartments: [WC_Product]}]; gałęzie bez apartamentów pomija.
	 */
	public static function groups( array $all ): array {
		$by_term  = [];
		$unsorted = [];
		foreach ( $all as $apt ) {
			$t = self::of_apartment( $apt->get_id() );
			if ( $t ) {
				$by_term[ $t ][] = $apt;
			} else {
				$unsorted[] = $apt;
			}
		}
		$groups = [];
		$ids    = array_map( fn( $a ) => $a->get_id(), $all );
		$walk   = function ( int $parent, int $depth ) use ( &$walk, &$groups, $by_term, $ids ) {
			foreach ( get_terms( [ 'taxonomy' => self::TAX, 'parent' => $parent, 'hide_empty' => false, 'orderby' => 'name' ] ) as $t ) {
				if ( ! array_intersect( self::apartments_in( $t->term_id ), $ids ) ) {
					continue; // gałąź bez apartamentów
				}
				$groups[] = [ 'title' => $t->name, 'type' => self::type_of( $t->term_id ), 'depth' => $depth, 'apartments' => $by_term[ $t->term_id ] ?? [] ];
				$walk( $t->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		if ( $unsorted ) {
			$groups[] = [ 'title' => __( 'Bez lokalizacji', 'bookmanager' ), 'type' => '', 'depth' => 0, 'apartments' => $unsorted ];
		}
		return $groups;
	}

	/** Wszystkie apartamenty (także szkice), alfabetycznie. */
	public static function all_apartments(): array {
		return wc_get_products( [
			'type'    => 'bm_apartment',
			'status'  => [ 'publish', 'draft', 'pending', 'private' ],
			'limit'   => -1,
			'orderby' => 'title',
			'order'   => 'ASC',
		] );
	}
}
