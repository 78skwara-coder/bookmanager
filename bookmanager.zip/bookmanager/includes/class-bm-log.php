<?php
defined( 'ABSPATH' ) || exit;

/**
 * Historia zmian: kto, kiedy i co zrobił (panel, kokpit, logowania).
 * Bez danych osobowych gości — tylko numery rezerwacji i zamówień.
 */
class BM_Log {

	public static function init(): void {
		// Zdarzenia z dowolnego miejsca (kokpit, panel, zamówienia).
		add_action( 'bm_block_created', fn( $id ) => self::add( 'block_created', 'booking', (int) $id, self::range( (int) $id ) ) );
		add_action( 'bm_booking_cancelled', fn( $id ) => self::add( 'booking_cancelled', 'booking', (int) $id, self::range( (int) $id ) ) );
		add_action( 'bm_booking_confirmed', fn( $id ) => self::add( 'booking_confirmed', 'booking', (int) $id, self::range( (int) $id ) ) );
	}

	public static function labels(): array {
		return [
			'block_created'     => __( 'Zablokowano termin', 'bookmanager' ),
			'booking_cancelled' => __( 'Zwolniono termin (anulowanie / usunięcie blokady)', 'bookmanager' ),
			'booking_confirmed' => __( 'Potwierdzono rezerwację', 'bookmanager' ),
			'order_cancelled'   => __( 'Anulowano zamówienie z panelu', 'bookmanager' ),
			'note_updated'      => __( 'Zmieniono notatkę', 'bookmanager' ),
			'login'             => __( 'Logowanie do panelu', 'bookmanager' ),
			'login_locked'      => __( 'Zablokowano logowanie po nieudanych próbach', 'bookmanager' ),
		];
	}

	private static function range( int $id ): array {
		$b = BM_Availability::get( $id );
		return $b ? [ 'apartment' => get_the_title( (int) $b->apartment_id ), 'from' => $b->check_in, 'to' => $b->check_out ] : [];
	}

	public static function ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	public static function add( string $action, string $type = '', int $id = 0, array $details = [], ?int $user_id = null ): void {
		global $wpdb;
		$wpdb->insert( BM_Installer::table( 'log' ), [
			'user_id'     => $user_id ?? get_current_user_id(),
			'action'      => $action,
			'object_type' => $type,
			'object_id'   => $id,
			'details'     => $details ? wp_json_encode( $details ) : null,
			'ip'          => self::ip(),
			'created_at'  => current_time( 'mysql', true ),
		] );
	}

	/** Ostatnie wpisy, najnowsze pierwsze. */
	public static function latest( int $limit = 50, int $offset = 0 ): array {
		global $wpdb;
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . BM_Installer::table( 'log' ) . ' ORDER BY id DESC LIMIT %d OFFSET %d', $limit, $offset ) );
		$labels = self::labels();
		$names  = [];
		$out    = [];
		foreach ( $rows as $r ) {
			$uid = (int) $r->user_id;
			if ( ! isset( $names[ $uid ] ) ) {
				$u             = $uid ? get_userdata( $uid ) : null;
				$names[ $uid ] = $u ? $u->display_name : ( $uid ? '#' . $uid : __( 'system / gość', 'bookmanager' ) );
			}
			$out[] = [
				'id'      => (int) $r->id,
				'when'    => get_date_from_gmt( $r->created_at, 'Y-m-d H:i' ),
				'who'     => $names[ $uid ],
				'action'  => $r->action,
				'label'   => $labels[ $r->action ] ?? $r->action,
				'object'  => $r->object_type ? $r->object_type . ' #' . $r->object_id : '',
				'details' => $r->details ? json_decode( $r->details, true ) : null,
			];
		}
		return $out;
	}
}
