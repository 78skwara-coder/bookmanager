<?php
defined( 'ABSPATH' ) || exit;

/**
 * Rezerwacje wprowadzane ręcznie (telefon, e-mail, osobiście) i rejestracja wpłat.
 *
 * Ręczna rezerwacja idzie tą samą drogą co online: wycena BM_Pricing (zasady pobytu, sezony), blokada nocy,
 * zwykłe zamówienie WooCommerce (dane gościa w jednym miejscu — RODO), oznaczone „telefon / obsługa”.
 * Płatność: zaliczka wpłacona / czeka na wpłatę do daty / bez zaliczki.
 * „Czeka na wpłatę”: noce zarezerwowane na stałe, zamówienie „wstrzymane” z terminem _bm_deposit_due; bez automatycznego anulowania.
 */
class BM_Manual {

	const METHODS = [ 'cash' => 'Gotówka', 'transfer' => 'Przelew', 'card' => 'Karta', 'blik' => 'BLIK', 'other' => 'Inna' ];

	/** Pola gościa: klucz => [etykieta, obowiązkowe]. */
	public static function guest_fields(): array {
		return [
			'first_name' => [ 'Imię', true ], 'last_name' => [ 'Nazwisko', true ], 'phone' => [ 'Telefon', true ], 'email' => [ 'E-mail', true ],
			'address_1' => [ 'Ulica i numer', true ], 'postcode' => [ 'Kod pocztowy', true ], 'city' => [ 'Miejscowość', true ], 'country' => [ 'Kraj', true ],
		];
	}

	private static function money( $v ): string {
		return trim( str_replace( "\xC2\xA0", ' ', html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	/**
	 * Tworzy rezerwację. $d:
	 *  apartment_id, check_in, check_out, party{adults, children_ages, eb_adult, eb_child, extras},
	 *  guest{first_name…country}, no_email (bool), note, arrival_time,
	 *  price (końcowa cena, opcjonalnie), price_reason,
	 *  payment{mode: paid|awaiting|none, amount, method, due}
	 * Zwraca ID rezerwacji albo WP_Error.
	 */
	public static function create( array $d ) {
		$apt = wc_get_product( absint( $d['apartment_id'] ?? 0 ) );
		if ( ! $apt || 'bm_apartment' !== $apt->get_type() ) {
			return new WP_Error( 'bm_manual', __( 'Wybierz apartament.', 'bookmanager' ) );
		}
		$in  = (string) ( $d['check_in'] ?? '' );
		$out = (string) ( $d['check_out'] ?? '' );

		// Dane gościa — komplet obowiązkowych pól; e-mail można pominąć tylko świadomie.
		$g       = (array) ( $d['guest'] ?? [] );
		$noemail = ! empty( $d['no_email'] );
		$missing = [];
		foreach ( self::guest_fields() as $k => [ $label, $req ] ) {
			$g[ $k ] = sanitize_text_field( (string) ( $g[ $k ] ?? '' ) );
			if ( $req && '' === $g[ $k ] && ! ( 'email' === $k && $noemail ) ) {
				$missing[] = $label;
			}
		}
		if ( $missing ) {
			return new WP_Error( 'bm_manual', sprintf( __( 'Uzupełnij dane gościa: %s.', 'bookmanager' ), implode( ', ', $missing ) ) );
		}
		if ( ! $noemail && ! is_email( $g['email'] ) ) {
			return new WP_Error( 'bm_manual', __( 'Nieprawidłowy adres e-mail gościa.', 'bookmanager' ) );
		}

		// Wycena: te same zasady co online.
		$quote = BM_Pricing::quote( $apt->get_id(), $in, $out, (array) ( $d['party'] ?? [] ) );
		if ( is_wp_error( $quote ) ) {
			return $quote;
		}
		if ( ! BM_Availability::is_available( $apt->get_id(), $in, $out ) ) {
			return new WP_Error( 'bm_unavailable', __( 'Ten termin jest już zajęty.', 'bookmanager' ) );
		}

		// Korekta ceny — zawsze z powodem.
		$calc   = (float) $quote['total'];
		$final  = isset( $d['price'] ) && '' !== (string) $d['price'] ? round( max( 0, (float) wc_format_decimal( $d['price'] ) ), 2 ) : $calc;
		$reason = mb_substr( sanitize_text_field( (string) ( $d['price_reason'] ?? '' ) ), 0, 200 );
		if ( abs( $final - $calc ) > 0.004 ) {
			if ( '' === $reason ) {
				return new WP_Error( 'bm_manual', __( 'Podaj powód zmiany ceny.', 'bookmanager' ) );
			}
			$quote['lines'][] = [ 'type' => 'adjust', 'label' => 'Korekta ceny: ' . $reason, 'qty' => 1, 'unit_price' => round( $final - $calc, 2 ), 'amount' => round( $final - $calc, 2 ) ];
			$quote['total']   = $final;
		}

		// Płatność.
		$p      = (array) ( $d['payment'] ?? [] );
		$mode   = in_array( $p['mode'] ?? '', [ 'paid', 'awaiting', 'none' ], true ) ? $p['mode'] : '';
		$amount = round( max( 0, (float) wc_format_decimal( $p['amount'] ?? 0 ) ), 2 );
		$method = isset( self::METHODS[ $p['method'] ?? '' ] ) ? $p['method'] : 'cash';
		$due    = (string) ( $p['due'] ?? '' );
		if ( ! $mode ) {
			return new WP_Error( 'bm_manual', __( 'Wybierz stan płatności.', 'bookmanager' ) );
		}
		if ( 'none' === $mode ) {
			$amount = 0;
		}
		if ( in_array( $mode, [ 'paid', 'awaiting' ], true ) && ( $amount <= 0 || $amount > $final + 0.004 ) ) {
			return new WP_Error( 'bm_manual', __( 'Podaj kwotę zaliczki (większą od zera, nie większą niż cena).', 'bookmanager' ) );
		}
		$today = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );
		if ( 'awaiting' === $mode && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $due ) || $due < $today ) ) {
			return new WP_Error( 'bm_manual', __( 'Podaj termin wpłaty (dziś lub później).', 'bookmanager' ) );
		}

		// Noce + zapis wyceny.
		$guests  = (int) $quote['party']['adults'] + count( $quote['party']['children_ages'] );
		$booking = BM_Availability::create_hold( $apt->get_id(), $in, $out, $guests, 60 );
		if ( is_wp_error( $booking ) ) {
			return $booking;
		}
		BM_Availability::save_quote( $booking, $quote, $amount );
		global $wpdb;
		$wpdb->update( BM_Installer::table( 'bookings' ), [
			'source'   => 'admin',
			'channel'  => 'phone',
			'discount' => round( $calc - $final, 2 ),
			'note'     => mb_substr( sanitize_textarea_field( (string) ( $d['internal_note'] ?? '' ) ), 0, 2000 ),
		], [ 'id' => $booking ] );

		// Zamówienie WooCommerce.
		$order = wc_create_order( [ 'created_via' => 'bookmanager', 'customer_note' => sanitize_textarea_field( (string) ( $d['note'] ?? '' ) ) ] );
		if ( is_wp_error( $order ) ) {
			BM_Availability::release( $booking, 'cancelled' );
			return $order;
		}
		$item = new WC_Order_Item_Product();
		$item->set_product( $apt );
		$item->set_quantity( 1 );
		$item->set_subtotal( $final );
		$item->set_total( $final );
		$item->add_meta_data( '_bm_booking_id', $booking, true );
		$item->add_meta_data( '_bm_deposit', $amount, true );
		$item->add_meta_data( '_bm_total', $final, true );
		foreach ( BM_Cart::describe( [ 'quote' => $quote, 'deposit' => $amount ] ) as $label => $value ) {
			$item->add_meta_data( 'Zaliczka teraz' === $label ? ( 'awaiting' === $mode ? 'Zaliczka do wpłaty' : 'Zaliczka' ) : $label, $value, true );
		}
		$order->add_item( $item );
		if ( $final - $amount > 0.004 ) {
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( (string) BM_Settings::get( 'balance_label' ) );
			$fee->set_amount( -round( $final - $amount, 2 ) );
			$fee->set_total( -round( $final - $amount, 2 ) );
			$fee->set_tax_status( 'none' );
			$order->add_item( $fee );
		}
		foreach ( $g as $k => $v ) {
			if ( 'email' === $k && $noemail ) {
				continue;
			}
			$order->{"set_billing_$k"}( $v );
		}
		$arrival = preg_match( '/^\d{2}:\d{2}$/', (string) ( $d['arrival_time'] ?? '' ) ) ? $d['arrival_time'] : '';
		if ( $arrival ) {
			$order->update_meta_data( BM_Checkout_Fields::meta_key( 'arrival-time' ), $arrival );
		}
		$order->update_meta_data( '_bm_manual', get_current_user_id() );
		if ( $noemail ) {
			$order->update_meta_data( '_bm_no_email', 1 );
		}
		if ( $reason ) {
			$order->update_meta_data( '_bm_price_reason', $reason );
		}
		$order->set_payment_method( 'bm_' . ( 'none' === $mode ? 'onsite' : $method ) );
		$order->set_payment_method_title( 'none' === $mode ? 'Płatność na miejscu' : ( 'awaiting' === $mode ? 'Oczekuje na wpłatę' : self::METHODS[ $method ] ) );
		$order->calculate_totals( false );
		$order->save();

		$who = wp_get_current_user()->display_name;
		$order->add_order_note( sprintf( 'Rezerwacja wprowadzona ręcznie w panelu BookManager (%s).%s', $who, $reason ? sprintf( ' Korekta ceny: %s → %s, powód: %s.', self::money( $calc ), self::money( $final ), $reason ) : '' ) );

		if ( 'awaiting' === $mode ) {
			// Noce na stałe, zamówienie czeka na wpłatę; bez potwierdzenia dla gościa (dostanie „rezerwacja wstępna”).
			BM_Cart::link_order( $order );
			$order->update_meta_data( '_bm_deposit_due', $due );
			$order->save();
			BM_Availability::confirm( $booking, $order->get_id() );
			self::set_money( $booking, 0, $final );
			$order->update_status( 'on-hold', sprintf( 'Czeka na wpłatę zaliczki %s do %s.', self::money( $amount ), $due ) );
			do_action( 'bm_booking_pending', $booking );
		} else {
			if ( $amount > 0 ) {
				$order->set_date_paid( time() );
				self::payment_row( $booking, 'deposit', $amount, $method, 'zaliczka przy rezerwacji' );
			}
			// „W realizacji” → standardowa ścieżka: potwierdzenie, saldo, Google, powiadomienia.
			$order->update_status( 'processing', 'none' === $mode ? 'Bez zaliczki — płatność na miejscu.' : sprintf( 'Zaliczka %s przyjęta (%s).', self::money( $amount ), self::METHODS[ $method ] ) );
		}
		$b = BM_Availability::get( $booking );
		if ( $b && $arrival ) {
			$wpdb->update( BM_Installer::table( 'bookings' ), [ 'arrival_time' => $arrival . ':00' ], [ 'id' => $booking ] );
		}
		BM_Log::add( 'booking_manual', 'booking', $booking, array_filter( [
			'apartment' => $apt->get_name(), 'from' => $in, 'to' => $out, 'order' => $order->get_order_number(),
			'reason' => $reason ? 'korekta ceny: ' . $reason : '',
		] ) );
		return $booking;
	}

	private static function set_money( int $booking, float $paid, float $total ): void {
		global $wpdb;
		$b    = BM_Availability::get( $booking );
		$days = (int) BM_Settings::get( 'balance_due_days' );
		$wpdb->update( BM_Installer::table( 'bookings' ), [
			'deposit_paid'     => round( $paid, 2 ),
			'balance_due'      => round( max( 0, $total - $paid ), 2 ),
			'balance_due_date' => $b ? gmdate( 'Y-m-d', strtotime( $b->check_in . " -$days days" ) ) : null,
			'updated_at'       => gmdate( 'Y-m-d H:i:s' ),
		], [ 'id' => $booking ] );
	}

	private static function payment_row( int $booking, string $kind, float $amount, string $method, string $note ): void {
		global $wpdb;
		$now = gmdate( 'Y-m-d H:i:s' );
		$wpdb->insert( BM_Installer::table( 'payments' ), [
			'booking_id' => $booking, 'kind' => $kind, 'amount' => $amount, 'method' => $method,
			'paid_at' => $now, 'note' => mb_substr( $note, 0, 255 ), 'created_by' => get_current_user_id(), 'created_at' => $now,
		] );
	}

	/** Wpłaty rezerwacji (zarejestrowane w panelu). */
	public static function payments( int $booking ): array {
		global $wpdb;
		return array_map( fn( $r ) => [
			'amount' => (float) $r->amount, 'kind' => $r->kind, 'method' => self::METHODS[ $r->method ] ?? $r->method,
			'when' => get_date_from_gmt( $r->paid_at, 'Y-m-d H:i' ), 'note' => $r->note,
			'by' => $r->created_by ? ( get_userdata( (int) $r->created_by )->display_name ?? '' ) : '',
		], $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . BM_Installer::table( 'payments' ) . ' WHERE booking_id = %d ORDER BY paid_at', $booking ) ) );
	}

	/** Stan „czeka na wpłatę”: ['due' => data, 'overdue' => bool] albo null. */
	public static function awaiting( object $b, ?WC_Order $o = null ): ?array {
		$o = $o ?? ( $b->order_id ? wc_get_order( (int) $b->order_id ) : null );
		if ( ! $o || 'confirmed' !== $b->status || ! $o->has_status( 'on-hold' ) ) {
			return null;
		}
		$due   = (string) $o->get_meta( '_bm_deposit_due' );
		$today = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );
		return [ 'due' => $due, 'overdue' => $due && $due < $today ];
	}

	/**
	 * Rejestruje wpłatę. Gdy rezerwacja czeka na zaliczkę — to zaliczka: zamówienie → „w realizacji”, gość dostaje potwierdzenie.
	 * W przeciwnym razie dopłata: zmniejsza saldo.
	 */
	public static function record_payment( int $booking_id, float $amount, string $method, string $note = '' ) {
		global $wpdb;
		$b = BM_Availability::get( $booking_id );
		if ( ! $b || ! in_array( $b->status, [ 'confirmed', 'conflict' ], true ) ) {
			return new WP_Error( 'bm_payment', __( 'Wpłatę można zarejestrować tylko dla potwierdzonej rezerwacji.', 'bookmanager' ) );
		}
		$amount = round( $amount, 2 );
		$method = isset( self::METHODS[ $method ] ) ? $method : 'cash';
		if ( $amount <= 0 ) {
			return new WP_Error( 'bm_payment', __( 'Podaj kwotę wpłaty.', 'bookmanager' ) );
		}
		$o    = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		$wait = self::awaiting( $b, $o );
		$paid = (float) $b->deposit_paid + ( (float) $b->total - (float) $b->deposit_paid - (float) $b->balance_due );
		if ( $amount > (float) $b->total - $paid + 0.004 ) {
			return new WP_Error( 'bm_payment', sprintf( __( 'Kwota większa niż pozostało do zapłaty (%s).', 'bookmanager' ), self::money( (float) $b->total - $paid ) ) );
		}
		$kind = $wait ? 'deposit' : 'balance';
		self::payment_row( $booking_id, $kind, $amount, $method, $note );
		$wpdb->update( BM_Installer::table( 'bookings' ), [
			'deposit_paid' => 'deposit' === $kind ? round( (float) $b->deposit_paid + $amount, 2 ) : $b->deposit_paid,
			'balance_due'  => round( max( 0, (float) $b->balance_due - $amount ), 2 ),
			'updated_at'   => gmdate( 'Y-m-d H:i:s' ),
		], [ 'id' => $booking_id ] );
		$who = wp_get_current_user()->display_name;
		if ( $o ) {
			$o->add_order_note( sprintf( 'Wpłata %s (%s) zarejestrowana w panelu BookManager (%s).%s', self::money( $amount ), self::METHODS[ $method ], $who, $note ? ' ' . $note : '' ) );
			if ( $wait ) {
				$o->delete_meta_data( '_bm_deposit_due' );
				$o->set_date_paid( time() );
				$o->set_payment_method( 'bm_' . $method );
				$o->set_payment_method_title( self::METHODS[ $method ] );
				$o->save();
				$o->update_status( 'processing' ); // rezerwacja już potwierdzona — status_changed niczego nie zmienia
				do_action( 'bm_booking_confirmed', $booking_id ); // gość dostaje potwierdzenie rezerwacji
			}
		}
		BM_Log::add( 'payment_recorded', 'booking', $booking_id, [ 'amount' => self::money( $amount ), 'method' => self::METHODS[ $method ], 'kind' => 'deposit' === $kind ? 'zaliczka' : 'dopłata' ] );
		if ( ! $wait ) {
			do_action( 'bm_payment_recorded', $booking_id );
		}
		return true;
	}
}
