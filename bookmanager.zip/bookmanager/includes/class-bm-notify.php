<?php
defined( 'ABSPATH' ) || exit;

/**
 * Powiadomienia BookManagera (e-mail).
 *
 * Szablon = komu + kiedy (zdarzenie albo X dni względem terminu, o godzinie) + warunki + temat + treść z polami {…}.
 * Zdarzenia: rezerwacja potwierdzona / wstępna (czeka na wpłatę) / anulowana / wpłata zarejestrowana — wysyłka w tle zaraz po zdarzeniu.
 * Czasowe: co godzinę (Action Scheduler) sprawdzamy, czyj termin wypada dziś; wysyłka od ustawionej godziny.
 * Dziennik (notification_log): każdy szablon idzie do rezerwacji najwyżej raz (chyba że „wyślij ponownie”).
 *
 * Treść: zwykły tekst; pusta linia = nowy akapit; **pogrubienie**; [tekst](adres) = link; [[Tekst przycisku|adres]] = przycisk.
 * Dla zamówień z apartamentami zastępuje e-maile WooCommerce do gościa (i „nowe / anulowane zamówienie” do obsługi) — ustawienie.
 */
class BM_Notify {

	const TICK = 'bm_notify_tick';
	const RUN  = 'bm_notify_event';

	public static function init(): void {
		foreach ( [ 'confirmed' => 'bm_booking_confirmed', 'pending' => 'bm_booking_pending', 'cancelled' => 'bm_booking_cancelled', 'payment' => 'bm_payment_recorded' ] as $event => $hook ) {
			add_action( $hook, fn( $id ) => self::queue( (int) $id, $event ), 20 );
		}
		add_action( self::RUN, [ __CLASS__, 'run_event' ], 10, 2 );
		add_action( self::TICK, [ __CLASS__, 'tick' ] );
		add_action( 'init', [ __CLASS__, 'schedule' ] );
		foreach ( [ 'customer_processing_order', 'customer_on_hold_order', 'customer_completed_order', 'customer_cancelled_order', 'new_order', 'cancelled_order' ] as $id ) {
			add_filter( "woocommerce_email_enabled_$id", [ __CLASS__, 'maybe_disable_wc' ], 20, 2 );
		}
	}

	public static function schedule(): void {
		if ( function_exists( 'as_has_scheduled_action' ) && ! as_has_scheduled_action( self::TICK ) ) {
			as_schedule_recurring_action( time() + 120, HOUR_IN_SECONDS, self::TICK, [], 'bookmanager' );
		}
	}

	private static function t(): string {
		return BM_Installer::table( 'notifications' );
	}

	private static function tl(): string {
		return BM_Installer::table( 'notification_log' );
	}

	/* ================= słowniki ================= */

	public static function triggers(): array {
		return [
			'confirmed'       => [ 'event', __( 'Po potwierdzeniu rezerwacji', 'bookmanager' ) ],
			'pending'         => [ 'event', __( 'Po przyjęciu rezerwacji wstępnej (czeka na wpłatę)', 'bookmanager' ) ],
			'cancelled'       => [ 'event', __( 'Po anulowaniu rezerwacji', 'bookmanager' ) ],
			'payment'         => [ 'event', __( 'Po zarejestrowaniu wpłaty', 'bookmanager' ) ],
			'before_arrival'  => [ 'time', __( 'Dni przed przyjazdem (0 = w dniu przyjazdu)', 'bookmanager' ) ],
			'after_departure' => [ 'time', __( 'Dni po wyjeździe', 'bookmanager' ) ],
			'before_balance'  => [ 'time', __( 'Dni przed terminem dopłaty', 'bookmanager' ) ],
			'before_deposit'  => [ 'time', __( 'Dni przed terminem wpłaty zaliczki', 'bookmanager' ) ],
			'deposit_overdue' => [ 'time', __( 'Dni po terminie wpłaty zaliczki (nie wpłacono)', 'bookmanager' ) ],
		];
	}

	/** Pola do wstawiania: klucz => opis. */
	public static function fields(): array {
		return [
			'imie' => 'imię gościa', 'nazwisko' => 'nazwisko', 'gosc' => 'imię i nazwisko', 'telefon' => 'telefon gościa', 'email' => 'e-mail gościa',
			'apartament' => 'nazwa apartamentu', 'obiekt' => 'nazwa obiektu', 'przyjazd' => 'data przyjazdu', 'wyjazd' => 'data wyjazdu',
			'przyjazd_krotko' => 'przyjazd (krótko)', 'wyjazd_krotko' => 'wyjazd (krótko)', 'noce' => 'liczba nocy', 'osoby' => 'goście',
			'godzina_przyjazdu' => 'planowana godzina przyjazdu', 'cena' => 'cena pobytu', 'zaliczka' => 'zaliczka (wpłacona lub do wpłaty)',
			'do_zaplaty' => 'pozostało do zapłaty', 'termin_doplaty' => 'termin dopłaty', 'informacja_o_doplacie' => 'zdanie o dopłacie albo „opłacony w całości”', 'termin_wplaty' => 'termin wpłaty zaliczki',
			'oplata_miejscowa' => 'opłata miejscowa', 'numer_rezerwacji' => 'nr rezerwacji', 'numer_zamowienia' => 'nr zamówienia',
			'kanal' => 'skąd rezerwacja (strona / telefon)', 'uwagi_goscia' => 'uwagi gościa',
			'link_zamowienia' => 'link do szczegółów zamówienia', 'link_apartamentu' => 'link do strony apartamentu', 'link_panelu' => 'link do rezerwacji w panelu (dla obsługi)',
			'nazwa_strony' => 'nazwa strony', 'adres_strony' => 'adres strony',
		];
	}

	public static function blocks(): array {
		return [
			'rozbicie_ceny' => 'tabela: rozbicie ceny i płatności',
			'zasady_pobytu' => 'lista: zasady pobytu',
			'opcje'         => 'lista: wybrane opcje dodatkowe',
			'dane_przelewu' => 'dane do przelewu (z ustawień przelewu WooCommerce)',
		];
	}

	/* ================= szablony ================= */

	private static function hydrate( object $r ): array {
		$c = json_decode( (string) $r->conditions, true );
		return [
			'id' => (int) $r->id, 'slug' => $r->slug, 'name' => $r->name, 'active' => (bool) $r->active,
			'recipient' => $r->recipient, 'recipient_email' => $r->recipient_email, 'trigger' => $r->trigger_type,
			'offset_days' => (int) $r->offset_days, 'send_hour' => (int) $r->send_hour,
			'conditions' => array_merge( [ 'objects' => [], 'channel' => 'any', 'only_balance' => false ], array_filter( is_array( $c ) ? $c : [], fn( $v ) => null !== $v ) ),
			'subject' => $r->subject, 'body' => $r->body, 'sort' => (int) $r->sort,
		];
	}

	public static function all(): array {
		global $wpdb;
		return array_map( [ __CLASS__, 'hydrate' ], $wpdb->get_results( 'SELECT * FROM ' . self::t() . ' ORDER BY sort, id' ) ); // phpcs:ignore
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE id = %d', $id ) );
		return $r ? self::hydrate( $r ) : null;
	}

	public static function save( array $d ) {
		global $wpdb;
		$name    = mb_substr( sanitize_text_field( (string) ( $d['name'] ?? '' ) ), 0, 120 );
		$subject = mb_substr( sanitize_text_field( (string) ( $d['subject'] ?? '' ) ), 0, 255 );
		$trigger = (string) ( $d['trigger'] ?? '' );
		if ( '' === $name || '' === $subject || ! isset( self::triggers()[ $trigger ] ) ) {
			return new WP_Error( 'bm_notify', __( 'Uzupełnij nazwę, temat i moment wysyłki.', 'bookmanager' ) );
		}
		$rcpt  = in_array( $d['recipient'] ?? '', [ 'guest', 'staff', 'custom' ], true ) ? $d['recipient'] : 'guest';
		$email = sanitize_email( (string) ( $d['recipient_email'] ?? '' ) );
		if ( 'custom' === $rcpt && ! is_email( $email ) ) {
			return new WP_Error( 'bm_notify', __( 'Podaj poprawny adres e-mail odbiorcy.', 'bookmanager' ) );
		}
		$c   = (array) ( $d['conditions'] ?? [] );
		$row = [
			'name'            => $name,
			'active'          => empty( $d['active'] ) ? 0 : 1,
			'recipient'       => $rcpt,
			'recipient_email' => $email,
			'trigger_type'    => $trigger,
			'offset_days'     => max( 0, min( 365, (int) ( $d['offset_days'] ?? 0 ) ) ),
			'send_hour'       => max( 0, min( 23, (int) ( $d['send_hour'] ?? 9 ) ) ),
			'conditions'      => wp_json_encode( [
				'objects'      => array_values( array_filter( array_map( 'absint', (array) ( $c['objects'] ?? [] ) ) ) ),
				'channel'      => in_array( $c['channel'] ?? 'any', [ 'www', 'phone' ], true ) ? $c['channel'] : 'any',
				'only_balance' => ! empty( $c['only_balance'] ),
			] ),
			'subject'         => $subject,
			'body'            => wp_kses_post( (string) ( $d['body'] ?? '' ) ),
			'updated_at'      => current_time( 'mysql', true ),
		];
		if ( ! empty( $d['id'] ) ) {
			$wpdb->update( self::t(), $row, [ 'id' => (int) $d['id'] ] );
			return (int) $d['id'];
		}
		$row += [ 'slug' => sanitize_key( (string) ( $d['slug'] ?? '' ) ), 'sort' => (int) ( $d['sort'] ?? 100 ), 'created_at' => $row['updated_at'] ];
		$wpdb->insert( self::t(), $row );
		return (int) $wpdb->insert_id;
	}

	public static function delete( int $id ): void {
		global $wpdb;
		$wpdb->delete( self::t(), [ 'id' => $id ] );
	}

	/** Opis „kiedy” po ludzku. */
	public static function when_text( array $n ): string {
		$d = $n['offset_days'];
		$h = sprintf( '%02d:00', $n['send_hour'] );
		$x = fn( $one, $many ) => $d . ' ' . BM_Pricing::pl( $d, $one, 'dni', $many );
		switch ( $n['trigger'] ) {
			case 'before_arrival':
				return 0 === $d ? "w dniu przyjazdu, od $h" : $x( 'dzień', 'dni' ) . " przed przyjazdem, od $h";
			case 'after_departure':
				return $x( 'dzień', 'dni' ) . " po wyjeździe, od $h";
			case 'before_balance':
				return 0 === $d ? "w dniu terminu dopłaty, od $h" : $x( 'dzień', 'dni' ) . " przed terminem dopłaty, od $h";
			case 'before_deposit':
				return 0 === $d ? "w dniu terminu wpłaty, od $h" : $x( 'dzień', 'dni' ) . " przed terminem wpłaty, od $h";
			case 'deposit_overdue':
				return $x( 'dzień', 'dni' ) . " po terminie wpłaty, od $h";
		}
		return self::triggers()[ $n['trigger'] ][1] ?? $n['trigger'];
	}

	/* ================= dane rezerwacji ================= */

	/** „16 listopada 2026 (poniedziałek)” — po polsku niezależnie od języka strony. */
	public static function date_long( string $d ): string {
		$m  = [ 1 => 'stycznia', 'lutego', 'marca', 'kwietnia', 'maja', 'czerwca', 'lipca', 'sierpnia', 'września', 'października', 'listopada', 'grudnia' ];
		$ts = strtotime( $d . ' 12:00:00' );
		return (int) gmdate( 'j', $ts ) . ' ' . $m[ (int) gmdate( 'n', $ts ) ] . ' ' . gmdate( 'Y', $ts ) . ' (' . BM_Seasons::DOW[ (int) gmdate( 'N', $ts ) ] . ')';
	}

	private static function money( $v ): string {
		return trim( str_replace( "\xC2\xA0", ' ', html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	/** Zamówienie rezerwacji albo null. */
	private static function order_of( object $b ): ?WC_Order {
		$o = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		return $o ?: null;
	}

	/** Oczekiwana zaliczka (wpłacona albo do wpłaty) z pozycji zamówienia. */
	private static function deposit_of( object $b, ?WC_Order $o ): float {
		if ( (float) $b->deposit_paid > 0 ) {
			return (float) $b->deposit_paid;
		}
		if ( $o ) {
			foreach ( $o->get_items() as $item ) {
				if ( (int) $item->get_meta( '_bm_booking_id' ) === (int) $b->id ) {
					return (float) $item->get_meta( '_bm_deposit' );
				}
			}
		}
		$pb = json_decode( (string) $b->price_breakdown, true );
		return (float) ( $pb['deposit'] ?? 0 );
	}

	/** Wartości pól {…} dla rezerwacji (tekst, bez HTML) i bloków (HTML). */
	public static function vars( object $b ): array {
		$o     = self::order_of( $b );
		$apt   = wc_get_product( (int) $b->apartment_id );
		$obj   = BM_Locations::object_of_apartment( (int) $b->apartment_id );
		$n     = (int) round( ( strtotime( $b->check_out . ' 12:00' ) - strtotime( $b->check_in . ' 12:00' ) ) / DAY_IN_SECONDS );
		$who   = $b->adults . ' ' . BM_Pricing::pl( (int) $b->adults, 'dorosły', 'dorosłych', 'dorosłych' )
			. ( $b->children ? ', ' . $b->children . ' ' . BM_Pricing::pl( (int) $b->children, 'dziecko', 'dzieci', 'dzieci' ) : '' );
		$dep   = self::deposit_of( $b, $o );
		$due   = $o ? (string) $o->get_meta( '_bm_deposit_due' ) : '';
		$due_t = $due ? self::date_long( $due ) : '';
		if ( ! $due && 'hold' === $b->status && $b->hold_expires ) { // przelew online: termin trzyma blokada (np. 24 h)
			$due_t = self::date_long( get_date_from_gmt( $b->hold_expires, 'Y-m-d' ) ) . ', godz. ' . get_date_from_gmt( $b->hold_expires, 'H:i' );
		}
		$panel = BM_Panel::url();
		$v     = [
			'imie'              => $o ? $o->get_billing_first_name() : '',
			'nazwisko'          => $o ? $o->get_billing_last_name() : '',
			'gosc'              => $o ? trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) : '',
			'telefon'           => $o ? $o->get_billing_phone() : '',
			'email'             => $o ? $o->get_billing_email() : '',
			'apartament'        => $apt ? $apt->get_name() : '',
			'obiekt'            => $obj ? get_term( $obj )->name : '',
			'przyjazd'          => self::date_long( $b->check_in ),
			'wyjazd'            => self::date_long( $b->check_out ),
			'przyjazd_krotko'   => gmdate( 'j.m', strtotime( $b->check_in . ' 12:00' ) ),
			'wyjazd_krotko'     => gmdate( 'j.m.Y', strtotime( $b->check_out . ' 12:00' ) ),
			'noce'              => (string) $n,
			'osoby'             => $who,
			'godzina_przyjazdu' => $b->arrival_time ? substr( $b->arrival_time, 0, 5 ) : 'nie podano',
			'cena'              => self::money( $b->total ),
			'zaliczka'          => self::money( $dep ),
			'do_zaplaty'        => self::money( $b->balance_due ),
			'termin_doplaty'    => $b->balance_due_date ? self::date_long( $b->balance_due_date ) : 'w dniu przyjazdu',
			'informacja_o_doplacie' => (float) $b->balance_due > 0
				? sprintf( 'Pozostałą kwotę %s prosimy uregulować do: %s.', self::money( $b->balance_due ), $b->balance_due_date ? self::date_long( $b->balance_due_date ) : 'dnia przyjazdu' )
				: 'Pobyt jest w całości opłacony.',
			'termin_wplaty'     => $due_t,
			'oplata_miejscowa'  => (float) $b->city_tax > 0 ? self::money( $b->city_tax ) . ' (płatna na miejscu)' : 'brak',
			'numer_rezerwacji'  => (string) $b->id,
			'numer_zamowienia'  => $o ? $o->get_order_number() : '',
			'kanal'             => 'phone' === $b->channel ? 'telefon / obsługa' : 'strona internetowa',
			'uwagi_goscia'      => $o ? (string) $o->get_customer_note() : '',
			'link_zamowienia'   => $o ? $o->get_checkout_order_received_url() : '',
			'link_apartamentu'  => $apt ? get_permalink( $apt->get_id() ) : '',
			'link_panelu'       => $panel ? $panel . '#rezerwacja/' . $b->id : '',
			'nazwa_strony'      => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'adres_strony'      => home_url( '/' ),
		];
		return $v;
	}

	/** Bloki HTML. */
	private static function block_html( string $key, object $b ): string {
		global $wpdb;
		$td = 'style="padding:6px 0;border-bottom:1px solid #eee;"';
		switch ( $key ) {
			case 'rozbicie_ceny':
				$pb  = json_decode( (string) $b->price_breakdown, true );
				$o   = self::order_of( $b );
				$h   = '<table cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;margin:8px 0 16px;">';
				foreach ( (array) ( $pb['lines'] ?? [] ) as $l ) {
					$h .= '<tr><td ' . $td . '>' . esc_html( $l['label'] ) . '</td><td ' . $td . ' align="right">' . esc_html( 0.0 !== (float) $l['amount'] ? self::money( $l['amount'] ) : 'gratis' ) . '</td></tr>';
				}
				$h .= '<tr><td style="padding:8px 0;font-weight:bold;">Razem</td><td style="padding:8px 0;font-weight:bold;" align="right">' . esc_html( self::money( $b->total ) ) . '</td></tr>';
				$dep = self::deposit_of( $b, $o );
				if ( $dep > 0 ) {
					$h .= '<tr><td ' . $td . '>' . ( (float) $b->deposit_paid > 0 ? 'Zaliczka wpłacona' : 'Zaliczka do wpłaty' ) . '</td><td ' . $td . ' align="right">' . esc_html( self::money( $dep ) ) . '</td></tr>';
				}
				if ( (float) $b->balance_due > 0 ) {
					$h .= '<tr><td ' . $td . '>Pozostało do zapłaty</td><td ' . $td . ' align="right">' . esc_html( self::money( $b->balance_due ) ) . '</td></tr>';
				}
				if ( (float) $b->city_tax > 0 ) {
					$h .= '<tr><td ' . $td . '>Opłata miejscowa (na miejscu)</td><td ' . $td . ' align="right">' . esc_html( self::money( $b->city_tax ) ) . '</td></tr>';
				}
				return $h . '</table>';
			case 'zasady_pobytu':
				$items = [];
				foreach ( BM_Features::for_apartment( (int) $b->apartment_id ) as $lvl ) {
					foreach ( $lvl['items'] as $f ) {
						if ( BM_Features::RULE === $f['kind'] ) {
							$items[] = '<li>' . esc_html( $f['name'] . ( $f['note'] ? ' — ' . $f['note'] : '' ) ) . '</li>';
						}
					}
				}
				return $items ? '<p><strong>Zasady pobytu</strong></p><ul>' . implode( '', $items ) . '</ul>' : '';
			case 'opcje':
				$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT name, qty FROM ' . BM_Installer::table( 'booking_extras' ) . ' WHERE booking_id = %d', $b->id ) );
				return $rows ? '<ul>' . implode( '', array_map( fn( $r ) => '<li>' . esc_html( $r->name . ( $r->qty > 1 ? ' × ' . $r->qty : '' ) ) . '</li>', $rows ) ) . '</ul>' : '';
			case 'dane_przelewu':
				$acc = (array) get_option( 'woocommerce_bacs_accounts', [] );
				$o   = self::order_of( $b );
				$out = '';
				foreach ( $acc as $a ) {
					if ( empty( $a['account_number'] ) ) {
						continue;
					}
					$out .= '<p style="margin:0 0 8px;">' . implode( '<br>', array_map( 'esc_html', array_filter( [
						$a['account_name'] ? 'Odbiorca: ' . $a['account_name'] : '', $a['bank_name'] ? 'Bank: ' . $a['bank_name'] : '',
						'Nr konta: ' . $a['account_number'], $o ? 'Tytuł: Rezerwacja ' . $o->get_order_number() : '',
					] ) ) ) . '</p>';
				}
				return $out;
		}
		return '';
	}

	/** Treść szablonu → HTML (bez ramki maila). */
	public static function render_body( string $body, object $b ): string {
		$vars = self::vars( $b );
		// 1. Bloki zastępujemy znacznikami, żeby nie przeszły przez escapowanie i wpautop.
		$blocks = [];
		$body   = preg_replace_callback( '/\{(' . implode( '|', array_keys( self::blocks() ) ) . ')\}/', function ( $m ) use ( $b, &$blocks ) {
			$k            = '%%BMBLOCK' . count( $blocks ) . '%%';
			$blocks[ $k ] = self::block_html( $m[1], $b );
			return "\n\n$k\n\n";
		}, $body );
		// 2. Tekst: escapowanie, potem nasze znaczniki (pola, przyciski, linki, pogrubienie).
		$html = self::format_text( $body, $vars );
		foreach ( $blocks as $k => $v ) {
			$html = str_replace( [ "<p>$k</p>", $k ], $v, $html );
		}
		return $html;
	}

	/** Tekst z prostymi znacznikami → HTML: {pole}, [[Przycisk|adres]], [tekst](adres), **pogrubienie**, akapity. */
	public static function format_text( string $body, array $vars ): string {
		$html = esc_html( $body );
		$html = preg_replace_callback( '/\{([a-z_]+)\}/', fn( $m ) => array_key_exists( $m[1], $vars ) ? esc_html( (string) $vars[ $m[1] ] ) : $m[0], $html );
		$html = preg_replace_callback( '/\[\[([^|\]]+)\|([^\]]+)\]\]/', fn( $m ) => self::button( html_entity_decode( $m[1] ), html_entity_decode( $m[2] ) ), $html );
		$html = preg_replace_callback( '/\[([^\]]+)\]\(([^)\s]+)\)/', fn( $m ) => '<a href="' . esc_url( html_entity_decode( $m[2] ) ) . '">' . $m[1] . '</a>', $html );
		$html = preg_replace( '/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $html );
		return wpautop( $html );
	}

	private static function button( string $text, string $url ): string {
		$c = self::accent();
		$r = (int) ( self::$look['mail_radius'] ?? BM_Site::get( 'mail_radius' ) );
		return sprintf( '<a href="%s" style="display:inline-block;background:%s;color:%s;padding:13px 24px;border-radius:%dpx;text-decoration:none;font-weight:600;">%s</a>',
			esc_url( $url ), esc_attr( $c ), esc_attr( BM_Appearance::readable_on( $c ) ), $r ? max( 6, (int) round( $r * .7 ) ) : 0, esc_html( $text ) );
	}

	/** Temat z polami (tekst). */
	public static function render_subject( string $subject, object $b ): string {
		$vars = self::vars( $b );
		return trim( preg_replace_callback( '/\{([a-z_]+)\}/', fn( $m ) => $vars[ $m[1] ] ?? $m[0], $subject ) );
	}

	/** Pełny e-mail w ramce maili WooCommerce (logo, kolory z WooCommerce → Ustawienia → E-maile). */
	/** Kolor akcentu maili: z ustawień wyglądu maili, inaczej z Wyglądu strony. */
	/** Ustawienia wyglądu do podglądu przed zapisem (przyciski w treści też je biorą). */
	public static $look = null;

	public static function accent( ?array $look = null ): string {
		$look = $look ?? self::$look ?? BM_Site::all();
		return $look['mail_accent'] ?: ( BM_Appearance::all()['accent'] ?: '#1f1f1f' );
	}

	/**
	 * Ramka e-maila (własna, lekka): logo albo nazwa w nagłówku, treść na karcie, stopka z danymi i linkami.
	 * Tabele i style w atrybutach — tak działa w Gmailu, Outlooku i Apple Mail.
	 * $opt: preheader (tekst podglądu w skrzynce), look (ustawienia do podglądu przed zapisem).
	 */
	public static function wrap( string $subject, string $html, array $opt = [] ): string {
		$l      = array_merge( BM_Site::all(), (array) ( $opt['look'] ?? [] ) );
		$accent = self::accent( $l );
		$font   = 'serif' === $l['mail_font'] ? "Georgia,'Times New Roman',serif" : "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
		$r      = (int) $l['mail_radius'];
		$align  = 'left' === $l['mail_align'] ? 'left' : 'center';
		$line   = 'yes' === $l['mail_divider'];
		$name   = $l['mail_header_text'] ?: wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		// nagłówek: logo (z linkiem do strony) albo nazwa
		$logo = '';
		if ( $l['mail_logo'] && ( $src = wp_get_attachment_image_url( (int) $l['mail_logo'], 'medium' ) ) ) { // phpcs:ignore
			$logo = '<img src="' . esc_url( $src ) . '" width="' . (int) $l['mail_logo_width'] . '" alt="' . esc_attr( $name ) . '" style="display:inline-block;width:' . (int) $l['mail_logo_width'] . 'px;max-width:100%;height:auto;border:0;outline:none;">';
			$head = $logo . ( $l['mail_header_text'] ? '<div style="margin-top:10px;font-size:13px;letter-spacing:.04em;color:#8a8780;">' . esc_html( $l['mail_header_text'] ) . '</div>' : '' );
		} else {
			$head = '<span style="font-size:20px;font-weight:600;letter-spacing:-.01em;color:#2b2b2b;">' . esc_html( $name ) . '</span>';
		}
		$head = '<a href="' . esc_url( home_url( '/' ) ) . '" style="text-decoration:none;color:#2b2b2b;">' . $head . '</a>';

		// treść: odstępy i kolory w atrybutach
		$html = preg_replace( '/<p>/', '<p style="margin:0 0 16px;">', $html );
		$html = preg_replace( '/<(ul|ol)>/', '<$1 style="margin:0 0 16px;padding-left:20px;">', $html );
		$html = preg_replace( '/<li>/', '<li style="margin:0 0 6px;">', $html );
		$html = preg_replace( '/<a (?![^>]*style=)/', '<a style="color:' . esc_attr( $accent ) . ';text-decoration:underline;" ', $html );

		// stopka: dane + linki
		$foot  = trim( strtr( (string) $l['mail_footer'], array_combine( array_map( fn( $k ) => '{' . $k . '}', array_keys( BM_Site::vars() ) ), array_values( BM_Site::vars() ) ) ) );
		$foot  = implode( '<br>', array_filter( array_map( fn( $x ) => esc_html( trim( $x, " ·\t" ) ), explode( "\n", $foot ) ) ) );
		$soc   = '';
		foreach ( (array) $l['mail_socials'] as $s ) {
			$label = $s['label'] ?: BM_Site::network_name( $s['url'] );
			$soc  .= '<a href="' . esc_url( $s['url'] ) . '" style="display:inline-block;margin:0 4px 8px;padding:6px 14px;border:1px solid #dcd9d2;border-radius:999px;color:#55524c;font-size:12px;text-decoration:none;">' . esc_html( $label ) . '</a>';
		}
		$pre = trim( (string) ( $opt['preheader'] ?? '' ) );
		if ( '' === $pre ) {
			$pre = mb_substr( trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( preg_replace( '/<table.*?<\/table>/s', ' ', $html ) ) ) ), 0, 110 );
		}
		$sep = $line ? '<tr><td style="padding:0 36px;"><div style="height:1px;line-height:1px;font-size:0;background:#ebe8e2;">&nbsp;</div></td></tr>' : '';

		return '<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>' . esc_html( $subject ) . '</title></head>'
			. '<body style="margin:0;padding:0;background:' . esc_attr( $l['mail_bg'] ) . ';-webkit-text-size-adjust:100%;">'
			. '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">' . esc_html( $pre ) . str_repeat( '&#8204;&nbsp;', 30 ) . '</div>'
			. '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:' . esc_attr( $l['mail_bg'] ) . ';"><tr><td align="center" style="padding:32px 12px;">'
			. '<table role="presentation" width="600" cellspacing="0" cellpadding="0" border="0" style="width:100%;max-width:600px;">'
			. '<tr><td><table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#ffffff;border-radius:' . $r . 'px;border:1px solid #ebe8e2;">'
			. '<tr><td align="' . $align . '" style="padding:28px 36px ' . ( $line ? '24px' : '8px' ) . ';font-family:' . esc_attr( $font ) . ';">' . $head . '</td></tr>'
			. $sep
			. '<tr><td style="padding:' . ( $line ? '28px' : '20px' ) . ' 36px 16px;font-family:' . esc_attr( $font ) . ';font-size:15px;line-height:1.65;color:#2b2b2b;">' . $html . '</td></tr>'
			. '</table></td></tr>'
			. '<tr><td align="center" style="padding:24px 24px 0;font-family:' . esc_attr( $font ) . ';font-size:12px;line-height:1.7;color:#8a8780;">'
			. ( $soc ? '<div style="margin:0 0 10px;">' . $soc . '</div>' : '' )
			. ( $foot ? '<div>' . $foot . '</div>' : '' )
			. '</td></tr></table></td></tr></table></body></html>';
	}

	/* ================= wysyłka ================= */

	/** Adres odbiorcy albo WP_Error z powodem (np. gość bez e-maila). */
	private static function recipient( array $n, object $b ) {
		if ( 'staff' === $n['recipient'] ) {
			return (string) ( BM_Settings::get( 'staff_email' ) ?: get_option( 'admin_email' ) );
		}
		if ( 'custom' === $n['recipient'] ) {
			return $n['recipient_email'];
		}
		$o = self::order_of( $b );
		if ( ! $o || $o->get_meta( '_bm_no_email' ) || ! is_email( $o->get_billing_email() ) ) {
			return new WP_Error( 'bm_no_email', __( 'gość nie ma adresu e-mail', 'bookmanager' ) );
		}
		return $o->get_billing_email();
	}

	public static function sent( int $booking_id, int $notification_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::tl() . " WHERE booking_id = %d AND notification_id = %d AND status = 'sent' LIMIT 1", $booking_id, $notification_id ) );
	}

	private static function log( int $booking_id, int $nid, string $to, string $subject, string $status, string $info = '' ): void {
		global $wpdb;
		$wpdb->insert( self::tl(), [
			'booking_id' => $booking_id, 'notification_id' => $nid, 'recipient' => mb_substr( $to, 0, 190 ), 'subject' => mb_substr( $subject, 0, 255 ),
			'status' => $status, 'info' => mb_substr( $info, 0, 255 ), 'sent_by' => get_current_user_id(), 'sent_at' => current_time( 'mysql', true ),
		] );
	}

	/**
	 * Wysyła szablon dla rezerwacji. $opt: force (mimo że już wysłany), to (inny adres — test), test (bez wpisu w dzienniku).
	 * Zwraca true albo WP_Error.
	 */
	public static function send( array $n, int $booking_id, array $opt = [] ) {
		$b = BM_Availability::get( $booking_id );
		if ( ! $b ) {
			return new WP_Error( 'bm_notify', __( 'Nie ma takiej rezerwacji.', 'bookmanager' ) );
		}
		if ( empty( $opt['force'] ) && empty( $opt['test'] ) && self::sent( $booking_id, $n['id'] ) ) {
			return new WP_Error( 'bm_notify_sent', __( 'To powiadomienie zostało już wysłane.', 'bookmanager' ) );
		}
		$to = $opt['to'] ?? self::recipient( $n, $b );
		$subject = self::render_subject( $n['subject'], $b );
		if ( is_wp_error( $to ) ) {
			if ( empty( $opt['test'] ) ) {
				self::log( $booking_id, $n['id'], '', $subject, 'skipped', $to->get_error_message() );
			}
			return $to;
		}
		$html = self::wrap( $subject, self::render_body( $n['body'], $b ) );
		$ok   = WC()->mailer()->send( $to, ( ! empty( $opt['test'] ) ? '[TEST] ' : '' ) . $subject, $html );
		if ( empty( $opt['test'] ) ) {
			self::log( $booking_id, $n['id'], $to, $subject, $ok ? 'sent' : 'failed', $ok ? '' : __( 'serwer nie wysłał wiadomości', 'bookmanager' ) );
		}
		return $ok ? true : new WP_Error( 'bm_mail', __( 'Serwer nie wysłał wiadomości. Sprawdź konfigurację poczty (np. wtyczkę SMTP).', 'bookmanager' ) );
	}

	/** Czy szablon dotyczy rezerwacji (warunki). */
	private static function matches( array $n, object $b ): bool {
		$c = $n['conditions'];
		if ( $c['objects'] && ! in_array( BM_Locations::object_of_apartment( (int) $b->apartment_id ), $c['objects'], true ) ) {
			return false;
		}
		if ( 'phone' === $c['channel'] && 'phone' !== $b->channel || 'www' === $c['channel'] && 'phone' === $b->channel ) {
			return false;
		}
		if ( $c['only_balance'] && (float) $b->balance_due <= 0 ) {
			return false;
		}
		return true;
	}

	/** Rezerwacja gościa (nie blokada właściciela). */
	private static function is_guest_booking( object $b ): bool {
		return 'block' !== $b->status && 'owner' !== $b->channel && $b->order_id;
	}

	/* ---------- zdarzenia ---------- */

	public static function queue( int $booking_id, string $event ): void {
		if ( function_exists( 'as_enqueue_async_action' ) && ! apply_filters( 'bm_notify_sync', false ) ) {
			as_enqueue_async_action( self::RUN, [ $booking_id, $event ], 'bookmanager' );
		} else {
			self::run_event( $booking_id, $event );
		}
	}

	public static function run_event( int $booking_id, string $event ): void {
		global $wpdb;
		$b = BM_Availability::get( $booking_id );
		if ( ! $b || ! self::is_guest_booking( $b ) ) {
			return;
		}
		// Anulowanie wysyłamy tylko, jeśli gość wcześniej dostał od nas coś o tej rezerwacji (nie przy nieudanej płatności online).
		if ( 'cancelled' === $event && ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::tl() . " WHERE booking_id = %d AND status = 'sent' LIMIT 1", $booking_id ) ) ) {
			$o = self::order_of( $b );
			if ( ! $o || ! $o->get_date_paid() ) {
				return;
			}
		}
		foreach ( self::all() as $n ) {
			if ( $n['active'] && $event === $n['trigger'] && self::matches( $n, $b ) ) {
				self::send( $n, $booking_id );
			}
		}
	}

	/* ---------- przypomnienia czasowe ---------- */

	public static function tick(): int {
		global $wpdb;
		$now   = new DateTimeImmutable( 'now', wp_timezone() );
		$today = $now->format( 'Y-m-d' );
		$hour  = (int) $now->format( 'G' );
		$count = 0;
		foreach ( self::all() as $n ) {
			if ( ! $n['active'] || 'time' !== ( self::triggers()[ $n['trigger'] ][0] ?? '' ) || $hour < $n['send_hour'] ) {
				continue;
			}
			$d   = $n['offset_days'];
			$tb  = BM_Installer::table( 'bookings' );
			$ids = [];
			switch ( $n['trigger'] ) {
				case 'before_arrival':
					$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $tb WHERE status = 'confirmed' AND check_in = %s", $now->modify( "+$d days" )->format( 'Y-m-d' ) ) );
					break;
				case 'after_departure':
					$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $tb WHERE status = 'confirmed' AND check_out = %s", $now->modify( "-$d days" )->format( 'Y-m-d' ) ) );
					break;
				case 'before_balance':
					$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $tb WHERE status = 'confirmed' AND balance_due > 0 AND balance_due_date = %s", $now->modify( "+$d days" )->format( 'Y-m-d' ) ) );
					break;
				case 'before_deposit':
				case 'deposit_overdue':
					$target = 'before_deposit' === $n['trigger'] ? $now->modify( "+$d days" )->format( 'Y-m-d' ) : $now->modify( "-$d days" )->format( 'Y-m-d' );
					foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT id, order_id FROM $tb WHERE status = 'confirmed' AND order_id IS NOT NULL AND check_out >= %s", $today ) ) as $r ) {
						$o = wc_get_order( (int) $r->order_id );
						if ( $o && $o->has_status( 'on-hold' ) && $o->get_meta( '_bm_deposit_due' ) === $target ) {
							$ids[] = $r->id;
						}
					}
					break;
			}
			foreach ( array_map( 'intval', $ids ) as $id ) {
				$b = BM_Availability::get( $id );
				if ( $b && self::is_guest_booking( $b ) && self::matches( $n, $b ) && ! self::sent( $id, $n['id'] ) ) {
					if ( true === self::send( $n, $id ) ) {
						$count++;
					}
				}
			}
		}
		return $count;
	}

	/** Dziennik wysyłek rezerwacji (najnowsze pierwsze). */
	public static function history( int $booking_id ): array {
		global $wpdb;
		$names = wp_list_pluck( self::all(), 'name', 'id' );
		return array_map( fn( $r ) => [
			'name'    => $names[ (int) $r->notification_id ] ?? __( '(usunięty szablon)', 'bookmanager' ),
			'to'      => $r->recipient,
			'status'  => $r->status,
			'info'    => $r->info,
			'when'    => get_date_from_gmt( $r->sent_at, 'Y-m-d H:i' ),
		], $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::tl() . ' WHERE booking_id = %d ORDER BY id DESC', $booking_id ) ) );
	}

	/* ================= e-maile WooCommerce ================= */

	public static function maybe_disable_wc( $enabled, $order ) {
		if ( ! $enabled || 'yes' !== BM_Settings::get( 'replace_wc_emails' ) || ! $order instanceof WC_Order ) {
			return $enabled;
		}
		foreach ( $order->get_items() as $item ) {
			if ( $item->get_meta( '_bm_booking_id' ) ) {
				return false; // zamówienie z apartamentem — wysyłają nasze szablony
			}
		}
		return $enabled;
	}

	/* ================= szablony domyślne ================= */

	public static function install_defaults(): void {
		global $wpdb;
		if ( (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t() ) > 0 ) { // phpcs:ignore
			return;
		}
		$sig = "W razie pytań po prostu odpowiedz na tę wiadomość.\n\nPozdrawiamy,\n{nazwa_strony}";
		$stay = "**Twój pobyt**\n{apartament}, {obiekt}\nPrzyjazd: {przyjazd}\nWyjazd: {wyjazd}\nNoce: {noce} · goście: {osoby}";
		$defs = [
			[ 'confirmed_guest', 'Potwierdzenie rezerwacji', 'guest', 'confirmed', 0, 9, [], 'Potwierdzamy rezerwację: {apartament}, {przyjazd_krotko}–{wyjazd_krotko}',
				"Dzień dobry {imie},\n\ndziękujemy za rezerwację — termin jest potwierdzony.\n\n$stay\n\n{rozbicie_ceny}\n\n{informacja_o_doplacie}\n\n{zasady_pobytu}\n\n[[Szczegóły rezerwacji|{link_zamowienia}]]\n\n$sig" ],
			[ 'pending_guest', 'Rezerwacja wstępna — czeka na wpłatę', 'guest', 'pending', 0, 9, [], 'Rezerwacja wstępna: {apartament}, {przyjazd_krotko}–{wyjazd_krotko} — czekamy na zaliczkę',
				"Dzień dobry {imie},\n\nwstępnie rezerwujemy dla Ciebie termin. Rezerwacja stanie się ostateczna po wpłacie zaliczki **{zaliczka}** do **{termin_wplaty}**.\n\n{dane_przelewu}\n\n$stay\n\n{rozbicie_ceny}\n\n$sig" ],
			[ 'deposit_reminder', 'Przypomnienie o wpłacie zaliczki', 'guest', 'before_deposit', 1, 9, [], 'Przypomnienie: zaliczka za pobyt w {apartament}',
				"Dzień dobry {imie},\n\nprzypominamy, że termin wpłaty zaliczki **{zaliczka}** mija {termin_wplaty}. Jeśli przelew jest już w drodze — dziękujemy, wiadomość możesz zignorować.\n\n{dane_przelewu}\n\n$sig" ],
			[ 'deposit_overdue_staff', 'Do obsługi: minął termin wpłaty', 'staff', 'deposit_overdue', 1, 8, [], 'Termin wpłaty minął: {gosc}, {apartament} ({przyjazd_krotko})',
				"Rezerwacja nr {numer_rezerwacji} — {gosc}, tel. {telefon}.\n{apartament}, {przyjazd} – {wyjazd}.\n\nTermin wpłaty zaliczki ({zaliczka}) minął {termin_wplaty}. Rezerwacja nadal blokuje termin — zdecyduj: kontakt z gościem albo anulowanie.\n\n[[Otwórz w panelu|{link_panelu}]]" ],
			[ 'before_arrival_info', 'Informacje przed przyjazdem', 'guest', 'before_arrival', 7, 10, [], 'Za tydzień przyjazd — informacje o pobycie w {apartament}',
				"Dzień dobry {imie},\n\nzostał tydzień do Twojego przyjazdu — cieszymy się!\n\n$stay\n\nPlanowana godzina przyjazdu: {godzina_przyjazdu}. Jeśli się zmieni, daj nam znać.\n\n{informacja_o_doplacie} Opłata miejscowa: {oplata_miejscowa}.\n\n{zasady_pobytu}\n\n$sig" ],
			[ 'balance_reminder', 'Przypomnienie o dopłacie', 'guest', 'before_balance', 3, 9, [ 'only_balance' => true ], 'Przypomnienie o dopłacie za pobyt w {apartament}',
				"Dzień dobry {imie},\n\nprzypominamy o dopłacie **{do_zaplaty}** za pobyt {przyjazd} – {wyjazd}. Termin: {termin_doplaty}.\n\n{dane_przelewu}\n\n$sig" ],
			[ 'day_before', 'Do zobaczenia jutro', 'guest', 'before_arrival', 1, 10, [], 'Do zobaczenia jutro w {apartament}!',
				"Dzień dobry {imie},\n\njutro przyjazd — czekamy na Ciebie!\n\n{apartament}, {obiekt}\nPrzyjazd: {przyjazd}, planowo o {godzina_przyjazdu}.\n\nSzczęśliwej podróży!\n{nazwa_strony}" ],
			[ 'thanks', 'Podziękowanie po pobycie', 'guest', 'after_departure', 1, 11, [], 'Dziękujemy za pobyt w {apartament}',
				"Dzień dobry {imie},\n\ndziękujemy, że byłeś naszym gościem. Mamy nadzieję, że wypoczynek się udał.\n\nJeśli coś mogliśmy zrobić lepiej — odpowiedz na tę wiadomość, czytamy wszystkie.\n\nDo zobaczenia!\n{nazwa_strony}" ],
			[ 'cancelled_guest', 'Anulowanie rezerwacji', 'guest', 'cancelled', 0, 9, [], 'Rezerwacja anulowana: {apartament}, {przyjazd_krotko}–{wyjazd_krotko}',
				"Dzień dobry {imie},\n\npotwierdzamy anulowanie rezerwacji nr {numer_rezerwacji} ({apartament}, {przyjazd} – {wyjazd}).\n\nW sprawie rozliczenia wpłaconych kwot skontaktujemy się z Tobą.\n\n$sig" ],
			[ 'payment_guest', 'Potwierdzenie wpłaty', 'guest', 'payment', 0, 9, [], 'Otrzymaliśmy wpłatę — {apartament}, {przyjazd_krotko}',
				"Dzień dobry {imie},\n\npotwierdzamy otrzymanie wpłaty. Dziękujemy!\n\n{rozbicie_ceny}\n\n$sig" ],
			[ 'new_staff', 'Do obsługi: nowa rezerwacja', 'staff', 'confirmed', 0, 9, [], 'Nowa rezerwacja: {apartament}, {przyjazd_krotko}–{wyjazd_krotko} — {gosc}',
				"{gosc}, tel. {telefon}, {email}\n{apartament} — {przyjazd} → {wyjazd} ({noce} nocy), {osoby}\nPrzyjazd ok. {godzina_przyjazdu} · źródło: {kanal}\n\n{rozbicie_ceny}\n\nUwagi gościa: {uwagi_goscia}\n\n[[Otwórz w panelu|{link_panelu}]]" ],
			[ 'cancelled_staff', 'Do obsługi: anulowanie', 'staff', 'cancelled', 0, 9, [], 'Anulowano rezerwację: {apartament}, {przyjazd_krotko}–{wyjazd_krotko} — {gosc}',
				"Rezerwacja nr {numer_rezerwacji} ({gosc}, tel. {telefon}) została anulowana. Termin wrócił do sprzedaży.\n\n[[Otwórz w panelu|{link_panelu}]]" ],
		];
		foreach ( $defs as $i => [ $slug, $name, $rcpt, $trigger, $off, $hour, $cond, $subject, $body ] ) {
			self::save( [
				'slug' => $slug, 'name' => $name, 'active' => 'payment_guest' !== $slug, 'recipient' => $rcpt, 'trigger' => $trigger,
				'offset_days' => $off, 'send_hour' => $hour, 'conditions' => $cond, 'subject' => $subject, 'body' => $body, 'sort' => ( $i + 1 ) * 10,
			] );
		}
	}
}
