<?php
defined( 'ABSPATH' ) || exit;

/**
 * Strona apartamentu rysowana przez BookManagera (zamiast szablonu produktu WooCommerce).
 * Nagłówek i stopka zostają z motywu; środek składamy z klocków w jednym z czterech układów.
 *
 * Klocki: galeria, nagłówek, cena „od”, widżet, opis, udogodnienia, zasady, okolica, pasek na telefon.
 */
class BM_Page {

	/** @var WC_Product|null */
	private static $apt = null;

	public static function init(): void {
		add_filter( 'template_include', [ __CLASS__, 'template' ], 99 );
		add_filter( 'body_class', [ __CLASS__, 'body_class' ] );
		// Bez sklepowego „Dodano do koszyka · Zobacz koszyk” — gość idzie od razu do zamówienia.
		add_filter( 'wc_add_to_cart_message_html', [ __CLASS__, 'no_cart_message' ], 10, 2 );
		// Niektóre motywy (np. Twenty Twenty-One) dopisują zdjęciom style w linii — u nas kadrowanie robi CSS.
		add_filter( 'wp_get_attachment_image_attributes', [ __CLASS__, 'clean_image_attr' ], 99 );
	}

	public static function clean_image_attr( $attr ) {
		if ( isset( $attr['class'] ) && str_contains( $attr['class'], 'bm-img' ) ) {
			unset( $attr['style'] );
		}
		return $attr;
	}

	public static function no_cart_message( $message, $products ) {
		foreach ( array_keys( (array) $products ) as $id ) {
			$p = wc_get_product( $id );
			if ( $p && 'bm_apartment' === $p->get_type() ) {
				return '';
			}
		}
		return $message;
	}

	/** Apartament na bieżącej stronie albo null. */
	public static function current(): ?WC_Product {
		if ( null === self::$apt && is_singular( 'product' ) ) {
			$p         = wc_get_product( get_queried_object_id() );
			self::$apt = $p && 'bm_apartment' === $p->get_type() ? $p : false;
		}
		return self::$apt ?: null;
	}

	public static function template( $template ) {
		return self::current() ? BM_PATH . 'templates/apartment.php' : $template;
	}

	public static function body_class( array $classes ): array {
		if ( self::current() ) {
			$classes[] = 'bm-apartment-page';
		}
		return $classes;
	}

	/* ================= całość ================= */

	public static function render( WC_Product $apt ): string {
		$a = BM_Appearance::for_apartment( $apt->get_id() );
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_script( 'bookmanager-page' );

		$images = self::images( $apt );
		$ctx    = [ 'apt' => $apt, 'a' => $a, 'images' => $images ];
		$body   = match ( $a['layout'] ) {
			'classic' => self::layout_classic( $ctx ),
			'hero'    => self::layout_hero( $ctx ),
			'wizard'  => self::layout_wizard( $ctx ),
			default   => self::layout_mosaic( $ctx ),
		};

		$lightbox = array_map( fn( $i ) => [ 'src' => $i['full'], 'w' => $i['w'], 'h' => $i['h'], 'alt' => $i['alt'] ], $images );

		return sprintf(
			'<div class="bm-page bm-layout--%1$s %2$s" style="%3$s" data-bm-gallery="%4$s">%5$s%6$s%7$s</div>',
			esc_attr( $a['layout'] ),
			esc_attr( BM_Appearance::classes( $a ) ),
			esc_attr( BM_Appearance::style_vars( $a ) ),
			esc_attr( wp_json_encode( $lightbox ) ),
			self::notices(),
			$body,
			'yes' === $a['bar'] ? self::mobile_bar( $apt ) : ''
		);
	}

	private static function notices(): string {
		if ( ! function_exists( 'wc_print_notices' ) || ! WC()->session ) {
			return '';
		}
		$html = wc_print_notices( true );
		return $html ? '<div class="bm-wrap bm-notices">' . $html . '</div>' : '';
	}

	/* ================= układy ================= */

	private static function layout_mosaic( array $c ): string {
		$apt = $c['apt'];
		return '<div class="bm-wrap">'
			. self::head( $apt )
			. self::gallery( $c['images'], 'mosaic' )
			. '<div class="bm-cols"><div class="bm-cols__main">'
			. self::lead( $apt ) . self::description( $apt ) . self::amenities( $apt ) . self::rules( $apt ) . self::area( $apt )
			. '</div><aside class="bm-cols__aside"><div class="bm-card bm-sticky">'
			. self::widget( $c, [ 'show_price' => true ] )
			. '</div></aside></div></div>';
	}

	private static function layout_classic( array $c ): string {
		$apt = $c['apt'];
		return '<div class="bm-wrap">'
			. '<div class="bm-classic">'
			. '<div class="bm-classic__gallery">' . self::gallery( $c['images'], 'thumbs' ) . '</div>'
			. '<div class="bm-classic__side">' . self::head( $apt ) . self::price_from( $apt ) . self::lead( $apt )
			. self::widget( $c, [] ) . '</div>'
			. '</div>'
			. '<div class="bm-classic__more">' . self::description( $apt ) . self::amenities( $apt ) . self::rules( $apt ) . self::area( $apt ) . '</div>'
			. '</div>';
	}

	private static function layout_hero( array $c ): string {
		$apt    = $c['apt'];
		$images = $c['images'];
		$cfg    = BM_Apartment::config( $apt );
		$side   = fn( int $i ) => isset( $images[ $i ] ) ? self::figure( $images[ $i ], $i ) : '';

		$bar = sprintf(
			'<div class="bm-wrap"><div class="bm-herobar bm-card"><div class="bm-herobar__item"><span class="bm-herobar__label">%s</span><span class="bm-herobar__value">%s</span></div>'
			. '<div class="bm-herobar__item"><span class="bm-herobar__label">%s</span><span class="bm-herobar__value">%s</span></div>'
			. '<div class="bm-herobar__item"><span class="bm-herobar__label">%s</span><span class="bm-herobar__value">%s</span></div>'
			. '<a class="bm-btn bm-btn--primary bm-herobar__cta" href="#bm-rezerwacja">%s</a></div></div>',
			esc_html__( 'Cena', 'bookmanager' ), self::price_from_text( $apt ),
			esc_html__( 'Pobyt', 'bookmanager' ), esc_html( sprintf( 'od %d %s', $cfg['min_nights'], BM_Pricing::pl( $cfg['min_nights'], 'nocy', 'nocy', 'nocy' ) ) ),
			esc_html__( 'Goście', 'bookmanager' ), esc_html( self::guests_text( $cfg ) ),
			esc_html__( 'Sprawdź dostępność', 'bookmanager' )
		);

		$about = self::lead( $apt ) . self::description( $apt );
		$amen  = self::amenities( $apt );
		$strip = '';
		if ( count( $images ) > 3 ) {
			$strip = '<div class="bm-wrap"><div class="bm-strip">';
			foreach ( array_slice( $images, 3, null, true ) as $i => $img ) {
				$strip .= self::figure( $img, $i );
			}
			$strip .= '</div></div>';
		}

		return self::gallery( $images, 'hero', $apt )
			. $bar
			. ( $about ? '<div class="bm-wrap"><div class="bm-split"><div class="bm-split__text">' . $about . '</div><div class="bm-split__media">' . $side( 1 ) . '</div></div></div>' : '' )
			. ( $amen ? '<div class="bm-wrap"><div class="bm-split bm-split--rev"><div class="bm-split__media">' . $side( 2 ) . '</div><div class="bm-split__text">' . $amen . '</div></div></div>' : '' )
			. $strip
			. '<div class="bm-wrap"><div class="bm-pair">' . self::rules( $apt ) . self::area( $apt ) . '</div></div>'
			. '<div class="bm-wrap"><section class="bm-section bm-reserve" id="bm-rezerwacja"><h2 class="bm-section__title">' . esc_html__( 'Rezerwacja', 'bookmanager' ) . '</h2>'
			. '<div class="bm-card">' . self::widget( $c, [ 'show_price' => true, 'split' => true ] ) . '</div></section></div>';
	}

	private static function layout_wizard( array $c ): string {
		$apt = $c['apt'];
		return '<div class="bm-wrap bm-wrap--narrow">'
			. self::gallery( $c['images'], 'slider' )
			. self::head( $apt )
			. '<div class="bm-card bm-wizard-card">' . self::widget( $c, [ 'show_price' => true, 'wizard' => true ] ) . '</div>'
			. self::lead( $apt ) . self::description( $apt ) . self::amenities( $apt ) . self::rules( $apt ) . self::area( $apt )
			. '</div>';
	}

	/* ================= klocki ================= */

	/** Zdjęcie główne + galeria produktu. */
	public static function images( WC_Product $apt ): array {
		$ids = array_values( array_unique( array_filter( array_merge( [ $apt->get_image_id() ], $apt->get_gallery_image_ids() ) ) ) );
		$out = [];
		foreach ( $ids as $id ) {
			$full  = wp_get_attachment_image_src( $id, 'full' );
			$large = wp_get_attachment_image_src( $id, 'large' );
			if ( ! $full ) {
				continue;
			}
			$alt   = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
			$out[] = [
				'id'    => $id,
				'full'  => $full[0],
				'w'     => (int) $full[1],
				'h'     => (int) $full[2],
				'large' => $large ? $large[0] : $full[0],
				'alt'   => '' !== $alt ? $alt : $apt->get_name(),
			];
		}
		return $out;
	}

	/** Pojedyncze zdjęcie otwierające podgląd na pełnym ekranie. */
	private static function figure( array $img, int $index, string $size = 'large', string $cls = '' ): string {
		return sprintf(
			'<button type="button" class="bm-shot %s" data-bm-open="%d" aria-label="%s">%s</button>',
			esc_attr( $cls ),
			$index,
			esc_attr( sprintf( __( 'Powiększ zdjęcie %d', 'bookmanager' ), $index + 1 ) ),
			wp_get_attachment_image( $img['id'], $size, false, [ 'class' => 'bm-img bm-shot__img', 'alt' => $img['alt'], 'loading' => $index ? 'lazy' : 'eager' ] )
		);
	}

	private static function gallery( array $images, string $variant, ?WC_Product $apt = null ): string {
		if ( ! $images ) {
			return 'hero' === $variant && $apt
				? '<div class="bm-hero bm-hero--empty"><div class="bm-wrap bm-hero__inner">' . self::head( $apt, true ) . '</div></div>'
				: '';
		}
		$n   = count( $images );
		$all = sprintf(
			'<button type="button" class="bm-btn bm-btn--light bm-gallery__all" data-bm-open="0">%s</button>',
			esc_html( sprintf( _n( 'Zobacz zdjęcie', 'Zobacz wszystkie zdjęcia (%d)', $n, 'bookmanager' ), $n ) )
		);

		switch ( $variant ) {
			case 'mosaic':
				$html = '<div class="bm-gallery bm-gallery--mosaic bm-gallery--n' . min( $n, 5 ) . '">';
				foreach ( array_slice( $images, 0, 5 ) as $i => $img ) {
					$html .= self::figure( $img, $i, 0 === $i ? 'full' : 'large' );
				}
				return $html . ( $n > 1 ? $all : '' ) . '</div>';

			case 'thumbs':
				$html = '<div class="bm-gallery bm-gallery--thumbs"><div class="bm-gallery__main">' . self::figure( $images[0], 0, 'full', 'bm-gallery__current' ) . '</div>';
				if ( $n > 1 ) {
					$html .= '<div class="bm-gallery__thumbs">';
					foreach ( $images as $i => $img ) {
						$html .= sprintf(
							'<button type="button" class="bm-thumb%s" data-bm-show="%d" aria-label="%s">%s</button>',
							0 === $i ? ' is-active' : '',
							$i,
							esc_attr( sprintf( __( 'Pokaż zdjęcie %d', 'bookmanager' ), $i + 1 ) ),
							wp_get_attachment_image( $img['id'], 'thumbnail', false, [ 'class' => 'bm-img', 'alt' => '', 'loading' => 'lazy' ] )
						);
					}
					$html .= '</div>';
				}
				return $html . '</div>';

			case 'slider':
				$html = '<div class="bm-gallery bm-gallery--slider"><div class="bm-slider" tabindex="0" aria-label="' . esc_attr__( 'Zdjęcia apartamentu', 'bookmanager' ) . '">';
				foreach ( $images as $i => $img ) {
					$html .= '<div class="bm-slider__slide">' . self::figure( $img, $i, 'full' ) . '</div>';
				}
				$html .= '</div>';
				if ( $n > 1 ) {
					$html .= '<button type="button" class="bm-round bm-slider__prev" aria-label="' . esc_attr__( 'Poprzednie zdjęcie', 'bookmanager' ) . '">' . self::icon( 'left' ) . '</button>'
						. '<button type="button" class="bm-round bm-slider__next" aria-label="' . esc_attr__( 'Następne zdjęcie', 'bookmanager' ) . '">' . self::icon( 'right' ) . '</button>'
						. '<span class="bm-slider__count">1 / ' . $n . '</span>';
				}
				return $html . '</div>';

			case 'hero':
				return sprintf(
					'<div class="bm-hero">%s<div class="bm-hero__shade"></div><div class="bm-wrap bm-hero__inner">%s%s</div></div>',
					wp_get_attachment_image( $images[0]['id'], 'full', false, [ 'class' => 'bm-img bm-hero__img', 'alt' => $images[0]['alt'], 'loading' => 'eager', 'fetchpriority' => 'high' ] ),
					$apt ? self::head( $apt, true ) : '',
					$n > 1 ? $all : ''
				);
		}
		return '';
	}

	/** Nazwa, położenie i najważniejsze fakty. */
	private static function head( WC_Product $apt, bool $on_photo = false ): string {
		$cfg   = BM_Apartment::config( $apt );
		$path  = array_reverse( BM_Locations::path( BM_Locations::of_apartment( $apt->get_id() ) ) );
		$where = implode( ' · ', array_map( fn( $id ) => get_term( $id )->name, $path ) );

		$facts = [
			self::icon( 'guests' ) . esc_html( self::guests_text( $cfg ) ),
			self::icon( 'moon' ) . esc_html( sprintf( 'min. %d %s', $cfg['min_nights'], BM_Pricing::pl( $cfg['min_nights'], 'noc', 'noce', 'nocy' ) ) ),
		];
		if ( null !== $cfg['infant_age'] ) {
			$facts[] = self::icon( 'child' ) . esc_html( sprintf( 'dzieci do %d lat bez miejsca', $cfg['infant_age'] ) );
		}

		return sprintf(
			'<header class="bm-head%s">%s<h1 class="bm-head__title">%s</h1><ul class="bm-facts">%s</ul></header>',
			$on_photo ? ' bm-head--photo' : '',
			$where ? '<p class="bm-head__where">' . self::icon( 'pin' ) . esc_html( $where ) . '</p>' : '',
			esc_html( $apt->get_name() ),
			implode( '', array_map( fn( $f ) => '<li class="bm-facts__item">' . $f . '</li>', $facts ) )
		);
	}

	public static function guests_text( array $cfg ): string {
		$eb = ( $cfg['eb_adult']['enabled'] ? $cfg['eb_adult']['max'] : 0 ) + ( $cfg['eb_child']['enabled'] ? $cfg['eb_child']['max'] : 0 );
		if ( null !== $cfg['eb_max_total'] ) {
			$eb = min( $eb, $cfg['eb_max_total'] );
		}
		$txt = sprintf( '%d %s', $cfg['beds'], BM_Pricing::pl( $cfg['beds'], 'miejsce', 'miejsca', 'miejsc' ) );
		return $eb ? $txt . sprintf( ' + %d %s', $eb, BM_Pricing::pl( $eb, 'dostawka', 'dostawki', 'dostawek' ) ) : $txt;
	}

	public static function price_from_text( WC_Product $apt ): string {
		$p = BM_Apartment::from_price( $apt );
		return $p['amount'] > 0 ? 'od ' . wp_strip_all_tags( wc_price( $p['amount'] ) ) . ' / ' . $p['unit'] : '';
	}

	private static function price_from( WC_Product $apt ): string {
		$t = self::price_from_text( $apt );
		return $t ? '<p class="bm-from">' . esc_html( $t ) . '</p>' : '';
	}

	private static function lead( WC_Product $apt ): string {
		$s = $apt->get_short_description();
		return $s ? '<div class="bm-lead">' . wp_kses_post( wpautop( $s ) ) . '</div>' : '';
	}

	private static function description( WC_Product $apt ): string {
		$d = $apt->get_description();
		if ( ! $d ) {
			return '';
		}
		return '<section class="bm-section bm-desc"><h2 class="bm-section__title">' . esc_html__( 'O apartamencie', 'bookmanager' ) . '</h2>'
			. '<div class="bm-desc__body">' . apply_filters( 'the_content', $d ) . '</div></section>'; // phpcs:ignore -- treść wpisu
	}

	private static function amenities( WC_Product $apt ): string {
		$groups = '';
		foreach ( BM_Features::for_apartment( $apt->get_id(), 'apartment_page' ) as $lvl ) {
			$items = array_filter( $lvl['items'], fn( $f ) => BM_Features::AMENITY === $f['kind'] );
			if ( ! $items ) {
				continue;
			}
			$title = $lvl['shared'] ? self::level_title( $lvl ) : __( 'W apartamencie', 'bookmanager' );
			$groups .= sprintf(
				'<div class="bm-amen__group"><h3 class="bm-amen__title">%s%s</h3><ul class="bm-amen__list">%s</ul></div>',
				esc_html( $title ),
				$lvl['shared'] ? ' <span class="bm-badge">' . esc_html__( 'wspólne z innymi gośćmi', 'bookmanager' ) . '</span>' : '',
				implode( '', array_map( fn( $f ) => self::item( $f, 'check' ), $items ) )
			);
		}
		return $groups ? '<section class="bm-section bm-amen"><h2 class="bm-section__title">' . esc_html__( 'Udogodnienia', 'bookmanager' ) . '</h2>' . $groups . '</section>' : '';
	}

	private static function level_title( array $lvl ): string {
		$map = [
			'floor'    => __( 'Na piętrze: %s', 'bookmanager' ),
			'building' => __( 'W budynku: %s', 'bookmanager' ),
			'object'   => __( 'Na terenie obiektu: %s', 'bookmanager' ),
		];
		return sprintf( $map[ $lvl['level'] ] ?? '%s', $lvl['label'] );
	}

	private static function rules( WC_Product $apt ): string {
		$items = [];
		foreach ( BM_Features::for_apartment( $apt->get_id(), 'apartment_page' ) as $lvl ) {
			foreach ( $lvl['items'] as $f ) {
				if ( BM_Features::RULE === $f['kind'] ) {
					$items[] = self::item( $f, 'info' );
				}
			}
		}
		return $items ? '<section class="bm-section bm-rules"><h2 class="bm-section__title">' . esc_html__( 'Zasady pobytu', 'bookmanager' ) . '</h2><ul class="bm-rules__list">' . implode( '', $items ) . '</ul></section>' : '';
	}

	/** Opisy obiektu, budynku i piętra — od ogółu do szczegółu. */
	private static function area( WC_Product $apt ): string {
		$html = '';
		foreach ( array_reverse( BM_Locations::path( BM_Locations::of_apartment( $apt->get_id() ) ) ) as $id ) {
			$t = get_term( $id );
			if ( $t && trim( $t->description ) ) {
				$html .= '<div class="bm-area__item"><h3 class="bm-area__title">' . esc_html( $t->name ) . '</h3>' . wp_kses_post( wpautop( $t->description ) ) . '</div>';
			}
		}
		return $html ? '<section class="bm-section bm-area"><h2 class="bm-section__title">' . esc_html__( 'Obiekt i okolica', 'bookmanager' ) . '</h2>' . $html . '</section>' : '';
	}

	private static function item( array $f, string $icon ): string {
		return sprintf(
			'<li class="bm-item">%s<span class="bm-item__body"><span class="bm-item__name">%s%s</span>%s%s</span></li>',
			self::icon( $icon ),
			esc_html( $f['name'] ),
			$f['qty'] > 1 ? ' <span class="bm-item__qty">×' . (int) $f['qty'] . '</span>' : '',
			$f['note'] ? ' <span class="bm-item__note">' . esc_html( $f['note'] ) . '</span>' : '',
			$f['description'] ? '<span class="bm-item__desc">' . esc_html( $f['description'] ) . '</span>' : ''
		);
	}

	private static function widget( array $c, array $opts ): string {
		return '<div class="bm-reserve-anchor" id="' . ( 'hero' === $c['a']['layout'] ? 'bm-widget' : 'bm-rezerwacja' ) . '"></div>'
			. BM_Frontend::widget_html( $c['apt'], $c['a'], $opts );
	}

	private static function mobile_bar( WC_Product $apt ): string {
		return sprintf(
			'<div class="bm-mbar" hidden><div class="bm-mbar__info"><strong class="bm-mbar__price">%s</strong><span class="bm-mbar__sub">%s</span></div><a class="bm-btn bm-btn--primary bm-mbar__cta" href="#bm-rezerwacja">%s</a></div>',
			esc_html( self::price_from_text( $apt ) ),
			esc_html__( 'Wybierz termin', 'bookmanager' ),
			esc_html__( 'Sprawdź termin', 'bookmanager' )
		);
	}

	/** Proste ikony liniowe (SVG w treści, kolor z tekstu). */
	public static function icon( string $name ): string {
		$p = [
			'check'  => '<path d="M5 12l5 5L20 7"/>',
			'info'   => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
			'pin'    => '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
			'guests' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6.5 6.5 0 0 1 3.5 6"/>',
			'moon'   => '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
			'child'  => '<circle cx="12" cy="6" r="2.5"/><path d="M8 21v-6l-2-4h12l-2 4v6M12 15v6"/>',
			'left'   => '<path d="M15 5l-7 7 7 7"/>',
			'right'  => '<path d="M9 5l7 7-7 7"/>',
		];
		return '<svg class="bm-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' . ( $p[ $name ] ?? '' ) . '</svg>';
	}
}
