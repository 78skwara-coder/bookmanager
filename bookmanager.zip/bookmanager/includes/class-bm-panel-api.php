<?php
defined( 'ABSPATH' ) || exit;

/**
 * REST dla panelu: /bookmanager/v1/panel/…
 * Każde wywołanie: zalogowany + uprawnienie (bm_desk albo bm_manage) + nonce wp_rest (ciasteczko WordPressa).
 * Logika rezerwacji jest w BM_Availability / zamówieniach WooCommerce — tu tylko odczyt i wywołania.
 */
class BM_Panel_API {

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	public static function routes(): void {
		$ns   = BM_REST::NS;
		$desk = fn() => is_user_logged_in() && BM_Roles::can_desk();
		$own  = fn() => is_user_logged_in() && BM_Roles::can_manage();
		$id   = [ 'id' => [ 'validate_callback' => fn( $v ) => is_numeric( $v ) ] ];

		register_rest_route( $ns, '/panel/calendar', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'calendar' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/today', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'summary' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/apartments', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'apartments' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/bookings', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'bookings' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/bookings/(?P<id>\d+)', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'booking' ], 'permission_callback' => $desk, 'args' => $id ] );
		register_rest_route( $ns, '/panel/bookings/(?P<id>\d+)/note', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'note' ], 'permission_callback' => $desk, 'args' => $id ] );
		register_rest_route( $ns, '/panel/bookings/(?P<id>\d+)/cancel', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'cancel' ], 'permission_callback' => $own, 'args' => $id ] );
		register_rest_route( $ns, '/panel/blocks', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'block_create' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/blocks/(?P<id>\d+)', [ 'methods' => 'DELETE', 'callback' => [ __CLASS__, 'block_delete' ], 'permission_callback' => $desk, 'args' => $id ] );
		register_rest_route( $ns, '/panel/log', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'log' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, '/panel/widget/(?P<id>\d+)', [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'widget' ], 'permission_callback' => $desk, 'args' => $id ] );
		register_rest_route( $ns, '/panel/manual', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'manual' ], 'permission_callback' => $desk ] );
		register_rest_route( $ns, '/panel/bookings/(?P<id>\d+)/payment', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'payment' ], 'permission_callback' => $desk, 'args' => $id ] );
		register_rest_route( $ns, '/panel/bookings/(?P<id>\d+)/notify', [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notify' ], 'permission_callback' => $desk, 'args' => $id ] );
	}

	/* ================= pomocnicze ================= */

	private static function tb(): string {
		return BM_Installer::table( 'bookings' );
	}

	private static function today(): string {
		return ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );
	}

	private static function nights( string $in, string $out ): int {
		return (int) round( ( strtotime( $out . ' 12:00' ) - strtotime( $in . ' 12:00' ) ) / DAY_IN_SECONDS );
	}

	/** Warunek SQL „rezerwacja zajmuje termin” (potwierdzone, blokady, konflikty i żywe blokady tymczasowe). */
	private static function active_sql(): string {
		global $wpdb;
		return $wpdb->prepare( "( status IN ('confirmed','block','conflict') OR ( status = 'hold' AND hold_expires >= %s ) )", gmdate( 'Y-m-d H:i:s' ) );
	}

	private static function guest_name( ?WC_Order $o ): string {
		return $o ? trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) : '';
	}

	/** Wiersz rezerwacji w skrócie (lista, kalendarz). */
	private static function brief( object $b, ?WC_Order $o = null ): array {
		$o     = $o ?? ( $b->order_id ? wc_get_order( (int) $b->order_id ) : null );
		$guest = self::guest_name( $o ?: null );
		$label = 'block' === $b->status ? ( $b->note ?: __( 'Blokada', 'bookmanager' ) ) : ( $guest ?: sprintf( __( 'Rezerwacja #%d', 'bookmanager' ), $b->id ) );
		$st    = BM_Availability::statuses()[ $b->status ] ?? $b->status;
		$flag  = '';
		if ( 'hold' === $b->status && $o ) {
			$st = $o->has_status( 'on-hold' ) ? __( 'Czeka na przelew', 'bookmanager' ) : __( 'W trakcie płatności', 'bookmanager' );
		}
		$wait = 'confirmed' === $b->status && $o ? BM_Manual::awaiting( $b, $o ) : null;
		if ( $wait ) {
			$flag = $wait['overdue'] ? 'overdue' : 'due';
			$st   = $wait['overdue']
				? sprintf( __( 'Termin wpłaty minął (%s)', 'bookmanager' ), gmdate( 'j.m', strtotime( $wait['due'] ) ) )
				: sprintf( __( 'Czeka na wpłatę do %s', 'bookmanager' ), gmdate( 'j.m', strtotime( $wait['due'] ) ) );
		}
		return [
			'id'           => (int) $b->id,
			'status'       => $b->status,
			'status_label' => $st,
			'flag'         => $flag,
			'channel'      => (string) $b->channel,
			'apartment'    => [ 'id' => (int) $b->apartment_id, 'name' => get_the_title( (int) $b->apartment_id ) ],
			'check_in'     => $b->check_in,
			'check_out'    => $b->check_out,
			'nights'       => self::nights( $b->check_in, $b->check_out ),
			'label'        => $label,
			'guest'        => $guest,
			'adults'       => (int) $b->adults,
			'children'     => (int) $b->children,
			'total'        => (float) $b->total,
			'balance_due'  => 'confirmed' === $b->status ? (float) $b->balance_due : 0.0,
			'order'        => $o ? $o->get_order_number() : '',
			'note'         => 'block' === $b->status ? '' : (string) $b->note,
		];
	}

	private static function not_found(): WP_Error {
		return new WP_Error( 'bm_not_found', __( 'Nie ma takiej rezerwacji.', 'bookmanager' ), [ 'status' => 404 ] );
	}

	/* ================= kalendarz ================= */

	public static function calendar( WP_REST_Request $r ) {
		global $wpdb;
		$tz = wp_timezone();
		$m  = (string) $r->get_param( 'month' );
		$m0 = preg_match( '/^\d{4}-\d{2}$/', $m ) ? DateTimeImmutable::createFromFormat( '!Y-m-d', $m . '-01', $tz ) : null;
		$m0 = $m0 ?: new DateTimeImmutable( 'first day of this month midnight', $tz );
		$m1 = $m0->modify( 'first day of next month' );
		$n  = (int) $m0->format( 't' );
		$today = self::today();

		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT * FROM ' . self::tb() . ' WHERE check_in < %s AND check_out > %s AND ' . self::active_sql() . ' ORDER BY check_in',
			$m1->format( 'Y-m-d' ), $m0->format( 'Y-m-d' )
		) );
		$by_apt = [];
		foreach ( $rows as $b ) {
			$first = max( $b->check_in, $m0->format( 'Y-m-d' ) );
			$last  = min( gmdate( 'Y-m-d', strtotime( $b->check_out . ' -1 day' ) ), $m1->modify( '-1 day' )->format( 'Y-m-d' ) );
			$item  = self::brief( $b );
			$item['start'] = (int) substr( $first, 8, 2 );
			$item['span']  = (int) substr( $last, 8, 2 ) - $item['start'] + 1;
			$by_apt[ (int) $b->apartment_id ][] = $item;
		}

		$days = [];
		for ( $i = 1; $i <= $n; $i++ ) {
			$d      = $m0->setDate( (int) $m0->format( 'Y' ), (int) $m0->format( 'm' ), $i );
			$days[] = [ 'date' => $d->format( 'Y-m-d' ), 'num' => $i, 'dow' => (int) $d->format( 'N' ) ];
		}
		$groups = [];
		foreach ( BM_Locations::groups( BM_Locations::all_apartments() ) as $g ) {
			$groups[] = [
				'title'      => $g['title'],
				'type'       => $g['type'],
				'depth'      => $g['depth'],
				'apartments' => array_map( fn( $a ) => [ 'id' => $a->get_id(), 'name' => $a->get_name(), 'items' => $by_apt[ $a->get_id() ] ?? [] ], $g['apartments'] ),
			];
		}
		return [
			'month'  => $m0->format( 'Y-m' ),
			'prev'   => $m0->modify( '-1 month' )->format( 'Y-m' ),
			'next'   => $m1->format( 'Y-m' ),
			'title'  => [ 1 => 'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień' ][ (int) $m0->format( 'n' ) ] . ' ' . $m0->format( 'Y' ),
			'today'  => $today,
			'days'   => $days,
			'groups' => $groups,
		];
	}

	/** Dziś i jutro: przyjazdy, wyjazdy, kto jest na miejscu. */
	public static function summary() {
		global $wpdb;
		$t   = self::today();
		$tm  = gmdate( 'Y-m-d', strtotime( $t . ' +1 day' ) );
		$sql = 'SELECT * FROM ' . self::tb() . " WHERE status IN ('confirmed','conflict') AND ";
		$map = fn( $rows ) => array_map( fn( $b ) => self::brief( $b ), $rows );
		return [
			'date'       => $t,
			'arrivals'   => $map( $wpdb->get_results( $wpdb->prepare( $sql . 'check_in = %s ORDER BY arrival_time', $t ) ) ),
			'departures' => $map( $wpdb->get_results( $wpdb->prepare( $sql . 'check_out = %s', $t ) ) ),
			'tomorrow'   => $map( $wpdb->get_results( $wpdb->prepare( $sql . 'check_in = %s ORDER BY arrival_time', $tm ) ) ),
			'overdue'    => self::overdue(),
			'staying'    => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::tb() . " WHERE status = 'confirmed' AND check_in <= %s AND check_out > %s", $t, $t ) ),
		];
	}

	/** Rezerwacje, którym minął termin wpłaty zaliczki (czerwone w panelu). */
	private static function overdue(): array {
		global $wpdb;
		$out = [];
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::tb() . " WHERE status = 'confirmed' AND order_id IS NOT NULL AND check_out >= %s ORDER BY check_in", self::today() ) ) as $b ) {
			$o = wc_get_order( (int) $b->order_id );
			$w = $o ? BM_Manual::awaiting( $b, $o ) : null;
			if ( $w && $w['overdue'] ) {
				$out[] = self::brief( $b, $o );
			}
		}
		return $out;
	}

	public static function apartments() {
		$out = [];
		foreach ( BM_Locations::groups( BM_Locations::all_apartments() ) as $g ) {
			foreach ( $g['apartments'] as $a ) {
				$out[] = [ 'id' => $a->get_id(), 'name' => $a->get_name(), 'group' => $g['title'] ];
			}
		}
		return $out;
	}

	/* ================= rezerwacje ================= */

	public static function bookings( WP_REST_Request $r ) {
		global $wpdb;
		$t     = self::today();
		$scope = sanitize_key( (string) $r->get_param( 'scope' ) ?: 'upcoming' );
		$apt   = absint( $r->get_param( 'apartment' ) );
		$q     = trim( sanitize_text_field( (string) $r->get_param( 'q' ) ) );
		$page  = max( 1, absint( $r->get_param( 'page' ) ) );
		$per   = 30;

		$where = [];
		$args  = [];
		$order = 'check_in ASC, id ASC';
		if ( '' !== $q ) {
			$scope = 'all'; // szukamy we wszystkich rezerwacjach, nie tylko w bieżącej zakładce
		}
		switch ( $scope ) {
			case 'current':
				$where[] = "status IN ('confirmed','conflict') AND check_in <= %s AND check_out > %s";
				array_push( $args, $t, $t );
				break;
			case 'past':
				$where[] = "status IN ('confirmed','conflict') AND check_out <= %s";
				$args[]  = $t;
				$order   = 'check_in DESC, id DESC';
				break;
			case 'cancelled':
				$where[] = "status IN ('cancelled','expired')";
				$order   = 'updated_at DESC, id DESC';
				break;
			case 'blocks':
				$where[] = "status = 'block' AND check_out > %s";
				$args[]  = $t;
				break;
			case 'all':
				$where[] = "status <> 'expired'";
				$order   = 'check_in DESC, id DESC';
				break;
			default: // upcoming
				$scope   = 'upcoming';
				$where[] = "check_in > %s AND status <> 'block' AND " . self::active_sql();
				$args[]  = $t;
		}
		if ( $apt ) {
			$where[] = 'apartment_id = %d';
			$args[]  = $apt;
		}
		$numeric = '' !== $q && ctype_digit( ltrim( $q, '#' ) );
		if ( $numeric ) {
			$where[] = '( id = %d OR order_id = %d )';
			array_push( $args, (int) ltrim( $q, '#' ), (int) ltrim( $q, '#' ) );
		}
		$sql = 'SELECT * FROM ' . self::tb() . ' WHERE ' . implode( ' AND ', $where ) . " ORDER BY $order";

		if ( '' !== $q && ! $numeric ) {
			// Szukanie po gościu: dane są w zamówieniach — filtrujemy w PHP (do 500 najbliższych pozycji).
			$rows = $wpdb->get_results( $wpdb->prepare( $sql . ' LIMIT 500', $args ) );
			$need = mb_strtolower( $q );
			$hits = [];
			foreach ( $rows as $b ) {
				$o   = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
				$hay = mb_strtolower( implode( ' ', [ self::guest_name( $o ?: null ), $o ? $o->get_billing_phone() : '', $o ? $o->get_billing_email() : '', get_the_title( (int) $b->apartment_id ), (string) $b->note ] ) );
				if ( str_contains( $hay, $need ) ) {
					$hits[] = self::brief( $b, $o ?: null );
				}
			}
			$total = count( $hits );
			$items = array_slice( $hits, ( $page - 1 ) * $per, $per );
		} else {
			$count = 'SELECT COUNT(*) FROM ' . self::tb() . ' WHERE ' . implode( ' AND ', $where );
			$total = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( $count, $args ) ) : $wpdb->get_var( $count ) ); // phpcs:ignore
			$q2    = $sql . $wpdb->prepare( ' LIMIT %d OFFSET %d', $per, ( $page - 1 ) * $per );
			$rows  = $args ? $wpdb->get_results( $wpdb->prepare( $q2, $args ) ) : $wpdb->get_results( $q2 ); // phpcs:ignore
			$items = array_map( fn( $b ) => self::brief( $b ), $rows );
		}
		return [ 'scope' => $scope, 'page' => $page, 'pages' => (int) max( 1, ceil( $total / $per ) ), 'total' => $total, 'items' => $items ];
	}

	public static function booking( WP_REST_Request $r ) {
		$b = BM_Availability::get( (int) $r['id'] );
		return $b ? self::detail( $b ) : self::not_found();
	}

	/** Pełne szczegóły rezerwacji. Dane gościa tylko z zamówienia (RODO: jedno miejsce). */
	private static function detail( object $b ): array {
		global $wpdb;
		$o      = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		$d      = self::brief( $b, $o ?: null );
		$pb     = $b->price_breakdown ? json_decode( $b->price_breakdown, true ) : [];
		$extras = $wpdb->get_results( $wpdb->prepare( 'SELECT name, qty, total FROM ' . BM_Installer::table( 'booking_extras' ) . ' WHERE booking_id = %d', $b->id ), ARRAY_A );
		$manage = BM_Roles::can_manage();
		$live   = in_array( $b->status, [ 'confirmed', 'hold', 'conflict' ], true );

		$d += [
			'children_ages'    => (string) $b->children_ages,
			'extra_beds'       => [ 'adult' => (int) $b->extra_beds_adult, 'child' => (int) $b->extra_beds_child ],
			'arrival_time'     => $b->arrival_time ? substr( $b->arrival_time, 0, 5 ) : '',
			'deposit'          => (float) ( $pb['deposit'] ?? 0 ),
			'balance_due_date' => (string) $b->balance_due_date,
			'city_tax'         => (float) $b->city_tax,
			'lines'            => array_values( array_map( fn( $l ) => [ 'label' => (string) $l['label'], 'amount' => (float) $l['amount'] ], (array) ( $pb['lines'] ?? [] ) ) ),
			'extras'           => $extras,
			'internal_note'    => 'block' === $b->status ? '' : (string) $b->note,
			'block_note'       => 'block' === $b->status ? (string) $b->note : '',
			'channel'          => (string) $b->channel,
			'created_at'       => get_date_from_gmt( $b->created_at, 'Y-m-d H:i' ),
			'contact'          => $o ? [
				'phone'   => $o->get_billing_phone(),
				'email'   => $o->get_billing_email(),
				'country' => $o->get_billing_country(),
				'note'    => (string) $o->get_customer_note(),
			] : null,
			'order_info'       => $o ? [
				'number'       => $o->get_order_number(),
				'status'       => $o->get_status(),
				'status_label' => wc_get_order_status_name( $o->get_status() ),
				'paid'         => (float) $o->get_total(),
				'payment'      => $o->get_payment_method_title(),
				'url'          => $manage && current_user_can( 'edit_shop_orders' ) ? $o->get_edit_order_url() : '',
			] : null,
			'awaiting'         => BM_Manual::awaiting( $b, $o ?: null ),
			'payments'         => BM_Manual::payments( (int) $b->id ),
			'methods'          => BM_Manual::METHODS,
			'manual'           => $o ? (bool) $o->get_meta( '_bm_manual' ) : false,
			'no_email'         => $o ? (bool) $o->get_meta( '_bm_no_email' ) : false,
			'price_reason'     => $o ? (string) $o->get_meta( '_bm_price_reason' ) : '',
			'notifications'    => 'block' === $b->status ? [] : BM_Notify::history( (int) $b->id ),
			'templates'        => 'block' === $b->status ? [] : array_values( array_map( fn( $n ) => [ 'id' => $n['id'], 'name' => $n['name'], 'recipient' => $n['recipient'] ], array_filter( BM_Notify::all(), fn( $n ) => $n['active'] ) ) ),
			'can'              => [
				'payment'      => 'confirmed' === $b->status && ( (float) $b->balance_due > 0 ),
				'note'         => 'block' !== $b->status,
				'delete_block' => 'block' === $b->status && $b->check_out > self::today(),
				'cancel'       => $manage && $live && 'block' !== $b->status,
			],
		];
		return $d;
	}

	public static function note( WP_REST_Request $r ) {
		global $wpdb;
		$b = BM_Availability::get( (int) $r['id'] );
		if ( ! $b || 'block' === $b->status ) {
			return self::not_found();
		}
		$note = mb_substr( sanitize_textarea_field( (string) $r->get_param( 'note' ) ), 0, 2000 );
		$wpdb->update( self::tb(), [ 'note' => $note, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ], [ 'id' => $b->id ] );
		BM_Log::add( 'note_updated', 'booking', (int) $b->id );
		return self::detail( BM_Availability::get( (int) $b->id ) );
	}

	/** Anulowanie przez właściciela: zamówienie → „anulowane” (zwalnia noce i Google), bez zamówienia → zwolnienie nocy. */
	public static function cancel( WP_REST_Request $r ) {
		$b = BM_Availability::get( (int) $r['id'] );
		if ( ! $b || ! in_array( $b->status, [ 'confirmed', 'hold', 'conflict' ], true ) ) {
			return new WP_Error( 'bm_cancel', __( 'Tej rezerwacji nie można anulować.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$reason = mb_substr( sanitize_text_field( (string) $r->get_param( 'reason' ) ), 0, 300 );
		$who    = wp_get_current_user()->display_name;
		$o      = $b->order_id ? wc_get_order( (int) $b->order_id ) : null;
		if ( $o && ! $o->has_status( 'cancelled' ) ) {
			$o->update_status( 'cancelled', sprintf( 'Anulowano w panelu BookManager (%s).%s', $who, $reason ? ' Powód: ' . $reason : '' ) );
		}
		$b = BM_Availability::get( (int) $b->id );
		if ( 'cancelled' !== $b->status ) { // bez zamówienia albo zamówienie już było anulowane
			BM_Availability::release( (int) $b->id, 'cancelled' );
			do_action( 'bm_booking_cancelled', (int) $b->id );
		}
		BM_Log::add( 'order_cancelled', 'booking', (int) $b->id, array_filter( [ 'order' => $o ? $o->get_order_number() : '', 'reason' => $reason ] ) );
		return self::detail( BM_Availability::get( (int) $b->id ) );
	}

	/* ================= blokady ================= */

	public static function block_create( WP_REST_Request $r ) {
		$apt = wc_get_product( absint( $r->get_param( 'apartment_id' ) ) );
		if ( ! $apt || 'bm_apartment' !== $apt->get_type() ) {
			return new WP_Error( 'bm_block', __( 'Wybierz apartament.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$in  = (string) $r->get_param( 'check_in' );
		$out = (string) $r->get_param( 'check_out' );
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $out ) || $out <= $in ) {
			return new WP_Error( 'bm_block', __( 'Podaj poprawny zakres: pierwsza noc i dzień zwolnienia (po ostatniej nocy).', 'bookmanager' ), [ 'status' => 400 ] );
		}
		if ( $in < self::today() ) {
			return new WP_Error( 'bm_block', __( 'Blokować można tylko przyszłe noce.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$res = BM_Availability::create_block( $apt->get_id(), $in, $out, mb_substr( sanitize_text_field( (string) $r->get_param( 'note' ) ), 0, 190 ) );
		if ( is_wp_error( $res ) ) {
			$res->add_data( [ 'status' => 409 ] );
			return $res;
		}
		do_action( 'bm_block_created', $res );
		return self::detail( BM_Availability::get( (int) $res ) );
	}

	public static function block_delete( WP_REST_Request $r ) {
		$b = BM_Availability::get( (int) $r['id'] );
		if ( ! $b || 'block' !== $b->status ) {
			return self::not_found();
		}
		BM_Availability::release( (int) $b->id, 'cancelled' );
		do_action( 'bm_booking_cancelled', (int) $b->id );
		return [ 'deleted' => true, 'id' => (int) $b->id ];
	}

	/* ================= ręczna rezerwacja, wpłaty, powiadomienia ================= */

	/** Konfiguracja widżetu rezerwacji dla panelu (ręczna rezerwacja). */
	public static function widget( WP_REST_Request $r ) {
		$apt = wc_get_product( (int) $r['id'] );
		if ( ! $apt || 'bm_apartment' !== $apt->get_type() ) {
			return self::not_found();
		}
		return array_merge( BM_Frontend::widget_config( $apt ), [ 'months' => 2, 'panel' => true, 'show_price' => false, 'acceptance' => '' ] );
	}

	public static function manual( WP_REST_Request $r ) {
		$res = BM_Manual::create( (array) $r->get_json_params() );
		if ( is_wp_error( $res ) ) {
			$res->add_data( [ 'status' => 400 ] );
			return $res;
		}
		return self::detail( BM_Availability::get( (int) $res ) );
	}

	public static function payment( WP_REST_Request $r ) {
		$res = BM_Manual::record_payment( (int) $r['id'], (float) wc_format_decimal( $r->get_param( 'amount' ) ), (string) $r->get_param( 'method' ), mb_substr( sanitize_text_field( (string) $r->get_param( 'note' ) ), 0, 200 ) );
		if ( is_wp_error( $res ) ) {
			$res->add_data( [ 'status' => 400 ] );
			return $res;
		}
		return self::detail( BM_Availability::get( (int) $r['id'] ) );
	}

	/** Wyślij (ponownie) wybrane powiadomienie dla rezerwacji. */
	public static function notify( WP_REST_Request $r ) {
		$n = BM_Notify::get( absint( $r->get_param( 'notification_id' ) ) );
		if ( ! $n ) {
			return new WP_Error( 'bm_notify', __( 'Nie ma takiego szablonu.', 'bookmanager' ), [ 'status' => 404 ] );
		}
		$res = BM_Notify::send( $n, (int) $r['id'], [ 'force' => true ] );
		if ( is_wp_error( $res ) ) {
			$res->add_data( [ 'status' => 400 ] );
			return $res;
		}
		BM_Log::add( 'notification_sent', 'booking', (int) $r['id'], [ 'reason' => $n['name'] ] );
		return self::detail( BM_Availability::get( (int) $r['id'] ) );
	}

	/* ================= historia ================= */

	public static function log( WP_REST_Request $r ) {
		$page = max( 1, absint( $r->get_param( 'page' ) ) );
		return [ 'page' => $page, 'items' => BM_Log::latest( 50, ( $page - 1 ) * 50 ) ];
	}
}
