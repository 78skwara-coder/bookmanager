<?php
defined( 'ABSPATH' ) || exit;

/**
 * REST panelu — konfiguracja (tylko Właściciel, bm_manage): apartamenty i sezony.
 * /bookmanager/v1/panel/manage/…  Zapis przez te same funkcje co kokpit (BM_Apartment::save_config, BM_Extras, BM_Seasons).
 */
class BM_Panel_Manage_API {

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	public static function routes(): void {
		$ns  = BM_REST::NS;
		$own = fn() => is_user_logged_in() && BM_Roles::can_manage();
		$id  = [ 'id' => [ 'validate_callback' => fn( $v ) => is_numeric( $v ) ] ];
		$b   = '/panel/manage';

		register_rest_route( $ns, "$b/meta", [ 'methods' => 'GET', 'callback' => [ __CLASS__, 'meta' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/apartments", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'apartments' ], 'permission_callback' => $own ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'apartment_create' ], 'permission_callback' => $own ],
		] );
		register_rest_route( $ns, "$b/apartments/(?P<id>\d+)", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'apartment' ], 'permission_callback' => $own, 'args' => $id ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'apartment_save' ], 'permission_callback' => $own, 'args' => $id ],
		] );
		register_rest_route( $ns, "$b/apartments/(?P<id>\d+)/images", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'image_upload' ], 'permission_callback' => $own, 'args' => $id ] );
		register_rest_route( $ns, "$b/seasons", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'seasons' ], 'permission_callback' => $own ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'season_save' ], 'permission_callback' => $own ],
		] );
		register_rest_route( $ns, "$b/seasons/(?P<id>\d+)", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'season' ], 'permission_callback' => $own, 'args' => $id ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'season_save' ], 'permission_callback' => $own, 'args' => $id ],
			[ 'methods' => 'DELETE', 'callback' => [ __CLASS__, 'season_delete' ], 'permission_callback' => $own, 'args' => $id ],
		] );
		register_rest_route( $ns, "$b/seasons/(?P<id>\d+)/copy", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'season_copy' ], 'permission_callback' => $own, 'args' => $id ] );
		register_rest_route( $ns, "$b/notifications", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'notifications' ], 'permission_callback' => $own ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notification_save' ], 'permission_callback' => $own ],
		] );
		register_rest_route( $ns, "$b/notifications/(?P<id>\d+)", [
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notification_save' ], 'permission_callback' => $own, 'args' => $id ],
			[ 'methods' => 'DELETE', 'callback' => [ __CLASS__, 'notification_delete' ], 'permission_callback' => $own, 'args' => $id ],
		] );
		register_rest_route( $ns, "$b/notifications/preview", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notification_preview' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/notifications/test", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notification_test' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/notifications/settings", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'notification_settings' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/site", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'site' ], 'permission_callback' => $own ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'site_save' ], 'permission_callback' => $own ],
		] );
		register_rest_route( $ns, "$b/site/page", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'site_page' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/mail-look", [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'mail_look' ], 'permission_callback' => $own ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'mail_look_save' ], 'permission_callback' => $own ],
		] );
		register_rest_route( $ns, "$b/mail-look/preview", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'mail_look_preview' ], 'permission_callback' => $own ] );
		register_rest_route( $ns, "$b/mail-look/logo", [ 'methods' => 'POST', 'callback' => [ __CLASS__, 'mail_logo_upload' ], 'permission_callback' => $own ] );
	}

	/* ================= pomocnicze ================= */

	private static function apt( int $id ) {
		$p = wc_get_product( $id );
		return $p && 'bm_apartment' === $p->get_type() ? $p : new WP_Error( 'bm_not_found', __( 'Nie ma takiego apartamentu.', 'bookmanager' ), [ 'status' => 404 ] );
	}

	/** Drzewo lokalizacji jako płaska lista z wcięciem. */
	private static function locations(): array {
		$out   = [];
		$types = BM_Locations::types();
		$walk  = function ( int $parent, int $depth ) use ( &$walk, &$out, $types ) {
			foreach ( get_terms( [ 'taxonomy' => BM_Locations::TAX, 'parent' => $parent, 'hide_empty' => false, 'orderby' => 'name' ] ) as $t ) {
				$type  = BM_Locations::type_of( $t->term_id );
				$out[] = [ 'id' => $t->term_id, 'name' => $t->name, 'depth' => $depth, 'type' => $type, 'type_label' => $types[ $type ] ?? '' ];
				$walk( $t->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		return $out;
	}

	private static function images( WC_Product $p ): array {
		$ids = array_values( array_unique( array_filter( array_merge( [ (int) $p->get_image_id() ], array_map( 'intval', $p->get_gallery_image_ids() ) ) ) ) );
		$out = [];
		foreach ( $ids as $id ) {
			$t = wp_get_attachment_image_src( $id, 'medium' );
			if ( $t ) {
				$out[] = [ 'id' => $id, 'thumb' => $t[0] ];
			}
		}
		return $out;
	}

	/** Słowniki do formularzy: lokalizacje, obiekty, układy, typy opłat. */
	public static function meta() {
		$locs = self::locations();
		return [
			'locations' => $locs,
			'objects'   => array_values( array_filter( $locs, fn( $l ) => 'object' === $l['type'] ) ),
			'layouts'   => array_map( fn( $k, $v ) => [ 'id' => $k, 'name' => $v[0] ], array_keys( BM_Appearance::layouts() ), BM_Appearance::layouts() ),
			'defaults'  => [ 'min_nights' => (int) BM_Settings::get( 'min_nights' ), 'layout' => BM_Appearance::all()['layout'] ],
			'google'    => (bool) BM_Google::credentials(),
		];
	}

	/* ================= apartamenty ================= */

	public static function apartments() {
		$out = [];
		foreach ( BM_Locations::all_apartments() as $p ) {
			$cfg   = BM_Apartment::config( $p );
			$path  = array_reverse( BM_Locations::path( BM_Locations::of_apartment( $p->get_id() ) ) );
			$img   = $p->get_image_id() ? wp_get_attachment_image_src( (int) $p->get_image_id(), 'thumbnail' ) : null;
			$out[] = [
				'id'       => $p->get_id(),
				'name'     => $p->get_name(),
				'status'   => $p->get_status(),
				'where'    => implode( ' · ', array_map( fn( $id ) => get_term( $id )->name, $path ) ),
				'price'    => BM_Page::price_from_text( $p ),
				'guests'   => BM_Page::guests_text( $cfg ),
				'thumb'    => $img ? $img[0] : '',
				'url'      => get_permalink( $p->get_id() ),
				'problems' => self::problems( $p, $cfg ),
			];
		}
		return $out;
	}

	/** Braki, przez które apartamentu nie da się zarezerwować (pokazujemy właścicielowi). */
	private static function problems( WC_Product $p, array $cfg ): array {
		$x = [];
		if ( $cfg['beds'] < 1 ) {
			$x[] = __( 'brak liczby miejsc', 'bookmanager' );
		}
		if ( BM_Apartment::MODE_FLAT === $cfg['mode'] ? $cfg['rate'] <= 0 : $cfg['adult_rate'] <= 0 ) {
			$x[] = __( 'brak ceny', 'bookmanager' );
		}
		if ( ! $p->get_image_id() ) {
			$x[] = __( 'brak zdjęcia', 'bookmanager' );
		}
		if ( ! BM_Locations::of_apartment( $p->get_id() ) ) {
			$x[] = __( 'brak lokalizacji', 'bookmanager' );
		}
		return $x;
	}

	public static function apartment( WP_REST_Request $r ) {
		$p = self::apt( (int) $r['id'] );
		return is_wp_error( $p ) ? $p : self::detail( $p );
	}

	private static function detail( WC_Product $p ): array {
		$id      = $p->get_id();
		$cfg     = BM_Apartment::config( $p );
		$seasons = [];
		foreach ( BM_Seasons::all( BM_Locations::object_of_apartment( $id ), gmdate( 'Y-m-d', strtotime( '-1 day' ) ) ) as $s ) {
			$s['rates'] = BM_Seasons::rates( $id, $s['id'] );
			$seasons[]  = $s;
		}
		return [
			'id'          => $id,
			'name'        => $p->get_name(),
			'status'      => $p->get_status(),
			'url'         => get_permalink( $id ),
			'edit_url'    => current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id, 'raw' ) : '',
			'short'       => $p->get_short_description(),
			'description' => $p->get_description(),
			'location'    => BM_Locations::of_apartment( $id ),
			'layout'      => (string) get_post_meta( $id, BM_Appearance::META, true ),
			'gcal'        => BM_Google::calendar_of( $id ),
			'config'      => BM_Apartment::editable( $p ),
			'effective'   => [ 'min_nights' => $cfg['min_nights'], 'infant_max' => $cfg['infant_max'] ],
			'extras'      => BM_Extras::assignable( $id ),
			'images'      => self::images( $p ),
			'seasons'     => $seasons,
			'problems'    => self::problems( $p, $cfg ),
		];
	}

	public static function apartment_create( WP_REST_Request $r ) {
		$name = mb_substr( sanitize_text_field( (string) $r->get_param( 'name' ) ), 0, 190 );
		if ( '' === $name ) {
			return new WP_Error( 'bm_apt', __( 'Podaj nazwę apartamentu.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$p = new WC_Product_BM_Apartment();
		$p->set_name( $name );
		$p->set_status( 'draft' );
		$p->set_catalog_visibility( 'visible' );
		BM_Apartment::save_config( $p, [ 'beds' => 2, 'fill_gaps' => true ] );
		$id  = $p->save();
		$loc = absint( $r->get_param( 'location' ) );
		if ( $loc ) {
			wp_set_object_terms( $id, [ $loc ], BM_Locations::TAX );
		}
		BM_Log::add( 'apartment_created', 'apartment', $id, [ 'apartment' => $name ] );
		return self::detail( wc_get_product( $id ) );
	}

	/** Zapis częściowy: tylko przesłane sekcje. */
	public static function apartment_save( WP_REST_Request $r ) {
		$p = self::apt( (int) $r['id'] );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$id = $p->get_id();
		$d  = (array) $r->get_json_params();

		if ( isset( $d['name'] ) ) {
			$name = mb_substr( sanitize_text_field( (string) $d['name'] ), 0, 190 );
			if ( '' === $name ) {
				return new WP_Error( 'bm_apt', __( 'Nazwa nie może być pusta.', 'bookmanager' ), [ 'status' => 400 ] );
			}
			$p->set_name( $name );
		}
		if ( isset( $d['short'] ) ) {
			$p->set_short_description( wp_kses_post( (string) $d['short'] ) );
		}
		if ( isset( $d['description'] ) ) {
			$p->set_description( wp_kses_post( (string) $d['description'] ) );
		}
		if ( isset( $d['config'] ) && is_array( $d['config'] ) ) {
			BM_Apartment::save_config( $p, $d['config'] );
		}
		if ( isset( $d['images'] ) && is_array( $d['images'] ) ) {
			$ids = array_values( array_filter( array_map( 'absint', $d['images'] ), fn( $i ) => 'attachment' === get_post_type( $i ) ) );
			$p->set_image_id( $ids[0] ?? 0 );
			$p->set_gallery_image_ids( array_slice( $ids, 1 ) );
		}
		$publish = null;
		if ( isset( $d['status'] ) && in_array( $d['status'], [ 'publish', 'draft' ], true ) ) {
			$publish = $d['status'];
		}
		if ( 'publish' === $publish ) {
			$problems = self::problems( $p, BM_Apartment::config( $p ) );
			$blocking = array_intersect( $problems, [ __( 'brak liczby miejsc', 'bookmanager' ), __( 'brak ceny', 'bookmanager' ) ] );
			if ( $blocking ) {
				return new WP_Error( 'bm_apt', sprintf( __( 'Nie można opublikować: %s.', 'bookmanager' ), implode( ', ', $blocking ) ), [ 'status' => 400 ] );
			}
		}
		if ( $publish ) {
			$p->set_status( $publish );
		}
		$p->save();

		if ( array_key_exists( 'location', $d ) ) {
			$loc = absint( $d['location'] );
			wp_set_object_terms( $id, $loc ? [ $loc ] : [], BM_Locations::TAX );
		}
		if ( array_key_exists( 'layout', $d ) ) {
			isset( BM_Appearance::layouts()[ $d['layout'] ] ) ? update_post_meta( $id, BM_Appearance::META, $d['layout'] ) : delete_post_meta( $id, BM_Appearance::META );
		}
		if ( array_key_exists( 'gcal', $d ) ) {
			$cal = sanitize_text_field( (string) $d['gcal'] );
			'' === $cal ? delete_post_meta( $id, '_bm_gcal_id' ) : update_post_meta( $id, '_bm_gcal_id', $cal );
		}
		if ( isset( $d['extras'] ) && is_array( $d['extras'] ) ) {
			BM_Extras::set_for_apartment( $id, $d['extras'] );
		}
		if ( isset( $d['season_rates'] ) && is_array( $d['season_rates'] ) ) {
			$allowed = wp_list_pluck( BM_Seasons::all( BM_Locations::object_of_apartment( $id ) ), 'id' );
			foreach ( $d['season_rates'] as $sid => $rates ) {
				if ( in_array( (int) $sid, $allowed, true ) ) {
					BM_Seasons::save_rates( $id, (int) $sid, (array) $rates );
				}
			}
		}
		BM_Log::add( 'apartment_saved', 'apartment', $id, [ 'apartment' => $p->get_name(), 'sections' => implode( ', ', array_keys( $d ) ) ] );
		return self::detail( wc_get_product( $id ) );
	}

	/** Wgranie zdjęcia (z telefonu) do biblioteki mediów i dopisanie na koniec galerii. */
	public static function image_upload( WP_REST_Request $r ) {
		$p = self::apt( (int) $r['id'] );
		if ( is_wp_error( $p ) ) {
			return $p;
		}
		$files = $r->get_file_params();
		if ( empty( $files['file'] ) ) {
			return new WP_Error( 'bm_img', __( 'Nie wybrano pliku.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$type = wp_check_filetype( $files['file']['name'] ?? '' );
		if ( ! in_array( $type['ext'] ?? '', [ 'jpg', 'jpeg', 'png', 'webp', 'avif' ], true ) ) {
			return new WP_Error( 'bm_img', __( 'Dozwolone są zdjęcia JPG, PNG, WebP i AVIF.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$_FILES = [ 'file' => $files['file'] ]; // media_handle_upload czyta z $_FILES
		$att    = media_handle_upload( 'file', $p->get_id(), [ 'post_title' => $p->get_name() ] );
		if ( is_wp_error( $att ) ) {
			$att->add_data( [ 'status' => 400 ] );
			return $att;
		}
		update_post_meta( $att, '_wp_attachment_image_alt', $p->get_name() );
		if ( ! $p->get_image_id() ) {
			$p->set_image_id( $att );
		} else {
			$p->set_gallery_image_ids( array_merge( $p->get_gallery_image_ids(), [ $att ] ) );
		}
		$p->save();
		return [ 'id' => $att, 'images' => self::images( wc_get_product( $p->get_id() ) ) ];
	}

	/* ================= sezony ================= */

	public static function seasons() {
		global $wpdb;
		$counts = [];
		foreach ( $wpdb->get_results( 'SELECT season_id, COUNT(*) n FROM ' . BM_Installer::table( 'season_rates' ) . ' GROUP BY season_id' ) as $c ) { // phpcs:ignore
			$counts[ (int) $c->season_id ] = (int) $c->n;
		}
		$today = ( new DateTimeImmutable( 'today', wp_timezone() ) )->format( 'Y-m-d' );
		return array_map( function ( $s ) use ( $counts, $today ) {
			$o = $s['object_id'] ? get_term( $s['object_id'] ) : null;
			return $s + [
				'object'      => $o && ! is_wp_error( $o ) ? $o->name : __( 'wszystkie obiekty', 'bookmanager' ),
				'apartments'  => $counts[ $s['id'] ] ?? 0,
				'past'        => $s['date_to'] < $today,
				'arrival_txt' => BM_Seasons::days_text( $s['arrival_days'] ),
			];
		}, BM_Seasons::all() );
	}

	/** Sezon + apartamenty jego obiektu z cenami (tabela „wszystkie apartamenty naraz”). */
	public static function season( WP_REST_Request $r ) {
		$s = BM_Seasons::get( (int) $r['id'] );
		return $s ? self::season_detail( $s ) : new WP_Error( 'bm_not_found', __( 'Nie ma takiego sezonu.', 'bookmanager' ), [ 'status' => 404 ] );
	}

	private static function season_detail( array $s ): array {
		$rates = BM_Seasons::rates_for_season( $s['id'] );
		$apts  = [];
		foreach ( BM_Locations::all_apartments() as $p ) {
			if ( $s['object_id'] && BM_Locations::object_of_apartment( $p->get_id() ) !== $s['object_id'] ) {
				continue;
			}
			$cfg    = BM_Apartment::config( $p );
			$apts[] = [
				'id'    => $p->get_id(),
				'name'  => $p->get_name(),
				'mode'  => $cfg['mode'],
				'base'  => [
					'rate' => $cfg['rate'], 'adult_rate' => $cfg['adult_rate'], 'min_nights' => $cfg['min_nights'],
					'eb_adult' => $cfg['eb_adult']['enabled'] ? $cfg['eb_adult']['price'] : null,
					'eb_child' => $cfg['eb_child']['enabled'] ? $cfg['eb_child']['price'] : null,
					'bands'    => array_map( fn( $b ) => [ 'key' => $b['from'] . '-' . $b['to'], 'label' => $b['from'] . '–' . $b['to'] . ' l.', 'price' => $b['price'] ], $cfg['child_bands'] ),
				],
				'rates' => $rates[ $p->get_id() ] ?? null,
			];
		}
		return $s + [ 'apartments' => $apts, 'arrival_txt' => BM_Seasons::days_text( $s['arrival_days'] ) ];
	}

	public static function season_save( WP_REST_Request $r ) {
		$d = (array) $r->get_json_params();
		if ( ! empty( $r['id'] ) ) {
			if ( ! BM_Seasons::get( (int) $r['id'] ) ) {
				return new WP_Error( 'bm_not_found', __( 'Nie ma takiego sezonu.', 'bookmanager' ), [ 'status' => 404 ] );
			}
			$d['id'] = (int) $r['id'];
		}
		$id = BM_Seasons::save( $d );
		if ( is_wp_error( $id ) ) {
			$id->add_data( [ 'status' => 400 ] );
			return $id;
		}
		$s = BM_Seasons::get( $id );
		if ( isset( $d['rates'] ) && is_array( $d['rates'] ) ) {
			foreach ( $d['rates'] as $apt_id => $rates ) {
				$apt_id = (int) $apt_id;
				if ( ! $s['object_id'] || BM_Locations::object_of_apartment( $apt_id ) === $s['object_id'] ) {
					BM_Seasons::save_rates( $apt_id, $id, (array) $rates );
				}
			}
		}
		BM_Log::add( 'season_saved', 'season', $id, [ 'season' => $s['name'], 'from' => $s['date_from'], 'to' => $s['date_to'] ] );
		return self::season_detail( BM_Seasons::get( $id ) );
	}

	public static function season_delete( WP_REST_Request $r ) {
		$s = BM_Seasons::get( (int) $r['id'] );
		if ( ! $s ) {
			return new WP_Error( 'bm_not_found', __( 'Nie ma takiego sezonu.', 'bookmanager' ), [ 'status' => 404 ] );
		}
		BM_Seasons::delete( $s['id'] );
		BM_Log::add( 'season_deleted', 'season', $s['id'], [ 'season' => $s['name'], 'from' => $s['date_from'], 'to' => $s['date_to'] ] );
		return [ 'deleted' => true ];
	}

	public static function season_copy( WP_REST_Request $r ) {
		$new = BM_Seasons::copy_next_year( (int) $r['id'] );
		if ( is_wp_error( $new ) ) {
			$new->add_data( [ 'status' => 400 ] );
			return $new;
		}
		$s = BM_Seasons::get( $new );
		BM_Log::add( 'season_saved', 'season', $new, [ 'season' => $s['name'], 'from' => $s['date_from'], 'to' => $s['date_to'] ] );
		return self::season_detail( $s );
	}

	/* ================= powiadomienia ================= */

	public static function notifications() {
		global $wpdb;
		$recent = [];
		foreach ( $wpdb->get_results( 'SELECT * FROM ' . BM_Installer::table( 'bookings' ) . " WHERE status IN ('confirmed','conflict') AND order_id IS NOT NULL ORDER BY id DESC LIMIT 20" ) as $b ) { // phpcs:ignore
			$o        = wc_get_order( (int) $b->order_id );
			$recent[] = [ 'id' => (int) $b->id, 'label' => sprintf( '#%d · %s · %s → %s', $b->id, $o ? trim( $o->get_billing_first_name() . ' ' . $o->get_billing_last_name() ) : '', $b->check_in, $b->check_out ) ];
		}
		return [
			'items'    => array_map( fn( $n ) => $n + [ 'when' => BM_Notify::when_text( $n ) ], BM_Notify::all() ),
			'settings' => [ 'staff_email' => (string) BM_Settings::get( 'staff_email' ), 'replace_wc_emails' => 'yes' === BM_Settings::get( 'replace_wc_emails' ), 'admin_email' => get_option( 'admin_email' ) ],
			'triggers' => array_map( fn( $k, $v ) => [ 'id' => $k, 'kind' => $v[0], 'name' => $v[1] ], array_keys( BM_Notify::triggers() ), BM_Notify::triggers() ),
			'fields'   => BM_Notify::fields(),
			'blocks'   => BM_Notify::blocks(),
			'bookings' => $recent,
			'me'       => wp_get_current_user()->user_email,
		];
	}

	public static function notification_save( WP_REST_Request $r ) {
		$d = (array) $r->get_json_params();
		if ( ! empty( $r['id'] ) ) {
			$cur = BM_Notify::get( (int) $r['id'] );
			if ( ! $cur ) {
				return new WP_Error( 'bm_not_found', __( 'Nie ma takiego szablonu.', 'bookmanager' ), [ 'status' => 404 ] );
			}
			$d = array_merge( $cur, $d, [ 'id' => $cur['id'] ] ); // np. samo włączenie / wyłączenie
		}
		$id = BM_Notify::save( $d );
		if ( is_wp_error( $id ) ) {
			$id->add_data( [ 'status' => 400 ] );
			return $id;
		}
		BM_Log::add( 'notification_saved', 'notification', $id, [ 'reason' => $d['name'] ?? '' ] );
		$n = BM_Notify::get( $id );
		return $n + [ 'when' => BM_Notify::when_text( $n ) ];
	}

	public static function notification_delete( WP_REST_Request $r ) {
		BM_Notify::delete( (int) $r['id'] );
		return [ 'deleted' => true ];
	}

	/** Rezerwacja do podglądu: wskazana albo najnowsza potwierdzona. */
	private static function sample( int $id ): ?object {
		global $wpdb;
		$b = $id ? BM_Availability::get( $id ) : null;
		if ( ! $b ) {
			$b = $wpdb->get_row( 'SELECT * FROM ' . BM_Installer::table( 'bookings' ) . " WHERE status = 'confirmed' AND order_id IS NOT NULL ORDER BY id DESC LIMIT 1" ); // phpcs:ignore
		}
		return $b ?: null;
	}

	public static function notification_preview( WP_REST_Request $r ) {
		$b = self::sample( absint( $r->get_param( 'booking_id' ) ) );
		if ( ! $b ) {
			return new WP_Error( 'bm_notify', __( 'Do podglądu potrzebna jest choć jedna potwierdzona rezerwacja.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$subject = BM_Notify::render_subject( (string) $r->get_param( 'subject' ), $b );
		return [ 'subject' => $subject, 'html' => BM_Notify::wrap( $subject, BM_Notify::render_body( wp_kses_post( (string) $r->get_param( 'body' ) ), $b ) ) ];
	}

	public static function notification_test( WP_REST_Request $r ) {
		$b = self::sample( absint( $r->get_param( 'booking_id' ) ) );
		if ( ! $b ) {
			return new WP_Error( 'bm_notify', __( 'Do testu potrzebna jest choć jedna potwierdzona rezerwacja.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$to  = wp_get_current_user()->user_email;
		$res = BM_Notify::send( [ 'id' => 0, 'subject' => (string) $r->get_param( 'subject' ), 'body' => wp_kses_post( (string) $r->get_param( 'body' ) ), 'recipient' => 'custom', 'recipient_email' => $to ], (int) $b->id, [ 'test' => true, 'to' => $to ] );
		if ( is_wp_error( $res ) ) {
			$res->add_data( [ 'status' => 400 ] );
			return $res;
		}
		return [ 'sent' => true, 'to' => $to ];
	}

	public static function notification_settings( WP_REST_Request $r ) {
		$s = BM_Settings::all();
		$s['staff_email']       = sanitize_email( (string) $r->get_param( 'staff_email' ) );
		$s['replace_wc_emails'] = $r->get_param( 'replace_wc_emails' ) ? 'yes' : 'no';
		update_option( BM_Settings::OPTION, BM_Settings::sanitize( $s ) );
		return [ 'saved' => true ];
	}

	/* ================= strona: dane obiektu, strony, kontakt ================= */

	private const SITE_KEYS = [ 'company', 'address', 'postcode', 'city', 'nip', 'phone', 'email', 'hours', 'map', 'list_page', 'contact_page', 'terms_page', 'privacy_page', 'contact_to', 'contact_autoreply', 'contact_subject', 'contact_body' ];

	public static function site() {
		$s = BM_Site::all();
		$out = array_intersect_key( $s, array_flip( self::SITE_KEYS ) );
		foreach ( [ 'map', 'contact_autoreply' ] as $k ) {
			$out[ $k ] = 'yes' === $out[ $k ];
		}
		return [
			'site'     => $out,
			'pages'    => BM_Site::pages(),
			'urls'     => [
				'list'    => BM_Site::page_url( 'list_page' ),
				'contact' => BM_Site::page_url( 'contact_page' ),
				'terms'   => BM_Site::page_url( 'terms_page' ),
				'privacy' => BM_Site::page_url( 'privacy_page' ),
			],
			'problems' => BM_Site::problems(),
			'fallback' => BM_Contact::recipient(),
			'hide_shop'=> 'yes' === BM_Settings::get( 'hide_shop_pages' ),
		];
	}

	public static function site_save( WP_REST_Request $r ) {
		$d = array_intersect_key( (array) $r->get_json_params(), array_flip( self::SITE_KEYS ) );
		if ( isset( $d['email'] ) && '' !== $d['email'] && ! is_email( $d['email'] ) ) {
			return new WP_Error( 'bm_site', __( 'Sprawdź adres e-mail obiektu.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		if ( isset( $d['contact_to'] ) && '' !== $d['contact_to'] && ! is_email( $d['contact_to'] ) ) {
			return new WP_Error( 'bm_site', __( 'Sprawdź adres, na który mają przychodzić wiadomości.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		BM_Site::save( $d );
		BM_Log::add( 'site_saved', 'site', 0, [ 'fields' => implode( ', ', array_keys( $d ) ) ] );
		return self::site();
	}

	public static function site_page( WP_REST_Request $r ) {
		$id = BM_Site::create_page( (string) $r->get_param( 'kind' ) );
		if ( is_wp_error( $id ) ) {
			$id->add_data( [ 'status' => 400 ] );
			return $id;
		}
		return self::site() + [ 'created' => $id, 'edit' => get_edit_post_link( $id, 'raw' ) ];
	}

	/* ================= wygląd e-maili ================= */

	private const LOOK_KEYS = [ 'mail_logo', 'mail_logo_width', 'mail_align', 'mail_header_text', 'mail_bg', 'mail_accent', 'mail_radius', 'mail_divider', 'mail_font', 'mail_footer', 'mail_socials' ];

	private static function look_out( array $s ): array {
		$out                 = array_intersect_key( $s, array_flip( self::LOOK_KEYS ) );
		$out['mail_divider'] = 'yes' === $out['mail_divider'];
		$out['logo_url']     = $out['mail_logo'] ? (string) wp_get_attachment_image_url( (int) $out['mail_logo'], 'medium' ) : '';
		return $out;
	}

	public static function mail_look() {
		return [
			'look'          => self::look_out( BM_Site::all() ),
			'site_accent'   => BM_Appearance::all()['accent'] ?: '#1f1f1f',
			'footer_fields' => array_keys( BM_Site::vars() ),
		];
	}

	public static function mail_look_save( WP_REST_Request $r ) {
		$d = array_intersect_key( (array) $r->get_json_params(), array_flip( self::LOOK_KEYS ) );
		BM_Site::save( $d );
		BM_Log::add( 'mail_look_saved', 'site', 0 );
		return self::mail_look();
	}

	/** Podgląd przed zapisem: przykładowa treść (albo szablon na prawdziwej rezerwacji) w ramce z przesłanymi ustawieniami. */
	public static function mail_look_preview( WP_REST_Request $r ) {
		$look = (array) $r->get_param( 'look' );
		// te same reguły co przy zapisie, ale bez zapisywania
		$clean = [];
		foreach ( BM_Site::defaults() as $k => $def ) {
			if ( array_key_exists( $k, $look ) && in_array( $k, self::LOOK_KEYS, true ) ) {
				$clean[ $k ] = $look[ $k ];
			}
		}
		$look_all     = array_intersect_key( BM_Site::clean( $clean ), array_flip( self::LOOK_KEYS ) );
		BM_Notify::$look = $look_all;
		$sample = __( "Dzień dobry Anno,\n\ndziękujemy za rezerwację! **Apartament Morski** czeka na Państwa od soboty, 12 lipca.\n\nZameldowanie od 15:00, wymeldowanie do 11:00. Szczegóły dojazdu znajdą Państwo [na naszej stronie](%s).\n\n[[Zobacz rezerwację|%s]]\n\nDo zobaczenia!", 'bookmanager' );
		$html   = BM_Notify::format_text( sprintf( $sample, home_url( '/' ), home_url( '/' ) ), [] );
		return [ 'html' => BM_Notify::wrap( __( 'Potwierdzenie rezerwacji', 'bookmanager' ), $html, [ 'look' => $look_all ] ) ];
	}

	public static function mail_logo_upload( WP_REST_Request $r ) {
		$files = $r->get_file_params();
		if ( empty( $files['file'] ) ) {
			return new WP_Error( 'bm_img', __( 'Nie wybrano pliku.', 'bookmanager' ), [ 'status' => 400 ] );
		}
		$type = wp_check_filetype( $files['file']['name'] ?? '' );
		if ( ! in_array( $type['ext'] ?? '', [ 'jpg', 'jpeg', 'png', 'gif' ], true ) ) {
			return new WP_Error( 'bm_img', __( 'Logo do maili: PNG albo JPG (WebP i SVG nie wyświetlają się w części skrzynek, np. w Outlooku).', 'bookmanager' ), [ 'status' => 400 ] );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$_FILES = [ 'file' => $files['file'] ];
		$att    = media_handle_upload( 'file', 0, [ 'post_title' => __( 'Logo do e-maili', 'bookmanager' ) ] );
		if ( is_wp_error( $att ) ) {
			$att->add_data( [ 'status' => 400 ] );
			return $att;
		}
		return [ 'id' => $att, 'url' => (string) wp_get_attachment_image_url( $att, 'medium' ) ];
	}
}
