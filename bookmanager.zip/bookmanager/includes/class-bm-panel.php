<?php
defined( 'ABSPATH' ) || exit;

/**
 * Panel BookManager na stronie: [bookmanager_panel].
 *
 * Niezalogowany → formularz logowania (konto WordPressa, Turnstile, limit prób).
 * Zalogowany z uprawnieniem bm_desk → aplikacja (assets/panel.js) działająca przez REST (BM_Panel_API).
 * Strona panelu: bez nagłówka i stopki motywu, wyłączona z wyszukiwarek i z pamięci podręcznej.
 */
class BM_Panel {

	const SHORTCODE = 'bookmanager_panel';
	const OPTION    = 'bm_panel_page';

	/** @var WP_Error|null błąd logowania do pokazania w formularzu */
	private static $login_error = null;

	public static function init(): void {
		add_shortcode( self::SHORTCODE, [ __CLASS__, 'shortcode' ] );
		add_action( 'template_redirect', [ __CLASS__, 'handle' ], 1 );
		add_filter( 'template_include', [ __CLASS__, 'template' ], 100 );
		add_filter( 'wp_robots', [ __CLASS__, 'robots' ] );
		add_action( 'save_post_page', [ __CLASS__, 'remember_page' ], 10, 2 );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'register_assets' ] );
	}

	public static function register_assets(): void {
		wp_register_style( 'bookmanager-panel', plugins_url( 'assets/panel.css', BM_FILE ), [ 'bookmanager' ], BM_VERSION );
		wp_register_script( 'bookmanager-panel', plugins_url( 'assets/panel.js', BM_FILE ), [], BM_VERSION, true );
	}

	/** Czy bieżąca strona to strona panelu. */
	public static function is_panel_page(): bool {
		if ( ! is_singular() ) {
			return false;
		}
		$p = get_queried_object();
		return $p instanceof WP_Post && has_shortcode( (string) $p->post_content, self::SHORTCODE );
	}

	/** Adres strony panelu (zapamiętany przy zapisie strony z shortcode'em). */
	public static function url(): string {
		$id = (int) get_option( self::OPTION );
		if ( $id && 'publish' === get_post_status( $id ) && has_shortcode( (string) get_post_field( 'post_content', $id ), self::SHORTCODE ) ) {
			return (string) get_permalink( $id );
		}
		return '';
	}

	public static function remember_page( int $id, WP_Post $post ): void {
		if ( 'publish' === $post->post_status && has_shortcode( (string) $post->post_content, self::SHORTCODE ) ) {
			update_option( self::OPTION, $id, false );
		} elseif ( (int) get_option( self::OPTION ) === $id ) {
			delete_option( self::OPTION );
		}
	}

	public static function robots( array $robots ): array {
		if ( self::is_panel_page() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}

	/** Logowanie (POST na stronę panelu) — przed wysłaniem nagłówków, żeby ustawić ciasteczka. */
	public static function handle(): void {
		if ( ! self::is_panel_page() ) {
			return;
		}
		nocache_headers();
		if ( (int) get_option( self::OPTION ) !== get_queried_object_id() ) {
			update_option( self::OPTION, get_queried_object_id(), false );
		}
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || empty( $_POST['bm_panel_login'] ) || is_user_logged_in() ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- formularz logowania jak wp-login.php (chroni Turnstile + limit prób)
		if ( BM_Security::locked_minutes() ) {
			self::$login_error = BM_Security::locked_error();
			return;
		}
		if ( ! BM_Security::verify() ) {
			self::$login_error = new WP_Error( 'bm_turnstile', __( 'Potwierdź, że nie jesteś robotem.', 'bookmanager' ) );
			return;
		}
		$user = wp_signon( [
			'user_login'    => sanitize_user( wp_unslash( $_POST['log'] ?? '' ) ),
			'user_password' => (string) wp_unslash( $_POST['pwd'] ?? '' ), // phpcs:ignore -- hasło bez zmian
			'remember'      => ! empty( $_POST['rememberme'] ),
		], is_ssl() );
		// phpcs:enable
		if ( is_wp_error( $user ) ) {
			self::$login_error = 'bm_locked' === $user->get_error_code()
				? $user
				: new WP_Error( 'bm_login', __( 'Nieprawidłowy login lub hasło.', 'bookmanager' ) );
			return;
		}
		BM_Log::add( 'login', 'user', $user->ID, [], $user->ID );
		wp_safe_redirect( get_permalink( get_queried_object_id() ) );
		exit;
	}

	/** Strona panelu we własnym szablonie: bez nagłówka i stopki motywu, cała szerokość. */
	public static function template( $template ) {
		return self::is_panel_page() ? BM_PATH . 'templates/panel.php' : $template;
	}

	/* ================= widok ================= */

	public static function shortcode(): string {
		wp_enqueue_style( 'bookmanager' );
		wp_enqueue_style( 'bookmanager-panel' );
		$a   = BM_Appearance::all();
		$cls = 'bm-panel ' . BM_Appearance::classes( $a );
		$sty = BM_Appearance::style_vars( $a );

		if ( ! is_user_logged_in() ) {
			return '<div class="' . esc_attr( $cls ) . '" style="' . esc_attr( $sty ) . '">' . self::login_form() . '</div>';
		}
		if ( ! BM_Roles::can_desk() ) {
			return '<div class="' . esc_attr( $cls ) . '" style="' . esc_attr( $sty ) . '"><div class="bm-login bm-card"><h1 class="bm-login__title">' . esc_html__( 'Brak dostępu', 'bookmanager' ) . '</h1><p>'
				. esc_html__( 'To konto nie ma dostępu do panelu BookManager. Poproś właściciela o rolę „Recepcja” lub „Właściciel”.', 'bookmanager' )
				. '</p><p><a class="bm-btn bm-btn--ghost" href="' . esc_url( wp_logout_url( get_permalink() ) ) . '">' . esc_html__( 'Wyloguj', 'bookmanager' ) . '</a></p></div></div>';
		}

		wp_enqueue_script( 'bookmanager-panel' );
		$u   = wp_get_current_user();
		$cfg = [
			'api'      => esc_url_raw( rest_url( BM_REST::NS . '/panel' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'currency' => get_woocommerce_currency(),
			'user'     => [ 'name' => $u->display_name, 'manage' => BM_Roles::can_manage() ],
			'logout'   => wp_logout_url( get_permalink() ),
			'admin'    => BM_Roles::can_manage() && current_user_can( 'manage_woocommerce' ) ? admin_url( 'admin.php?page=bookmanager' ) : '',
			'site'     => get_bloginfo( 'name' ),
		];
		return sprintf(
			'<div class="%s" style="%s" id="bm-panel" data-bm-panel="%s"><p class="bm-panel__loading">%s</p><noscript>%s</noscript></div>',
			esc_attr( $cls ), esc_attr( $sty ), esc_attr( wp_json_encode( $cfg ) ),
			esc_html__( 'Ładowanie panelu…', 'bookmanager' ),
			esc_html__( 'Panel wymaga włączonej obsługi JavaScript.', 'bookmanager' )
		);
	}

	private static function login_form(): string {
		$lock = BM_Security::locked_minutes();
		$e    = self::$login_error ?: ( $lock ? BM_Security::locked_error() : null );
		$err  = $e ? '<p class="bm-login__error" role="alert">' . esc_html( $e->get_error_message() ) . '</p>' : '';
		$user = isset( $_POST['log'] ) ? sanitize_user( wp_unslash( $_POST['log'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		$html  = '<form class="bm-login bm-card" method="post" action="' . esc_url( get_permalink() ) . '">';
		$html .= '<p class="bm-login__site">' . esc_html( get_bloginfo( 'name' ) ) . '</p>';
		$html .= '<h1 class="bm-login__title">' . esc_html__( 'Panel rezerwacji', 'bookmanager' ) . '</h1>' . $err;
		$html .= '<label class="bm-field"><span class="bm-field__label">' . esc_html__( 'Login lub e-mail', 'bookmanager' ) . '</span>'
			. '<input class="bm-input" type="text" name="log" value="' . esc_attr( $user ) . '" autocomplete="username" required autocapitalize="off"></label>';
		$html .= '<label class="bm-field"><span class="bm-field__label">' . esc_html__( 'Hasło', 'bookmanager' ) . '</span>'
			. '<input class="bm-input" type="password" name="pwd" autocomplete="current-password" required></label>';
		$html .= '<label class="bm-login__remember"><input type="checkbox" class="bm-check" name="rememberme" value="1"> ' . esc_html__( 'Zapamiętaj mnie na tym urządzeniu', 'bookmanager' ) . '</label>';
		$html .= BM_Security::widget();
		$html .= '<input type="hidden" name="bm_panel_login" value="1">';
		$html .= '<button type="submit" class="bm-btn bm-btn--primary bm-btn--block"' . ( $lock ? ' disabled' : '' ) . '>' . esc_html__( 'Zaloguj', 'bookmanager' ) . '</button>';
		$html .= '<p class="bm-login__lost"><a href="' . esc_url( wp_lostpassword_url( get_permalink() ) ) . '">' . esc_html__( 'Nie pamiętasz hasła?', 'bookmanager' ) . '</a></p>';
		return $html . '</form>';
	}
}
