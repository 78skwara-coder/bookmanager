<?php
defined( 'ABSPATH' ) || exit;

/**
 * Wycena pobytu.
 *
 * Tryb „cena stała”:      noce × stawka.
 * Tryb „cena za osobę”:   noce × (dorośli × stawka dorosłego + dzieci wg przedziałów wieku),
 *                         nie mniej niż „minimum płatnych osób” × stawka dorosłego.
 * Osoba na dostawce płaci tylko za dostawkę.
 * Do tego: dostawki, opcje dodatkowe, opłata serwisowa.
 * Opłata miejscowa — tylko informacja (płatna na miejscu), poza sumą i poza zaliczką.
 *
 * Sezony: każda noc po cenach swojego sezonu (BM_Seasons), na pozycji osobna linia na sezon.
 *
 * Liczymy w groszach (int). Klient płaci dokładne `total`; `per_night` — tylko do wyświetlenia.
 */
class BM_Pricing {

	/** Stawka nocy w trybie stałym, w groszach (z uwzględnieniem sezonu). */
	public static function night_rate( WC_Product $apt, string $date ): int {
		$cfg = BM_Apartment::config( $apt );
		$s   = BM_Seasons::pick( BM_Seasons::for_apartment( $apt->get_id(), $date, gmdate( 'Y-m-d', strtotime( $date . ' +1 day' ) ) ), $date );
		return self::gr( BM_Seasons::apply( $cfg, $s )['rate'] );
	}

	public static function min_nights( WC_Product $apt ): int {
		return BM_Apartment::config( $apt )['min_nights'];
	}

	public static function gaps_allowed( WC_Product $apt ): bool {
		return BM_Apartment::config( $apt )['fill_gaps'];
	}

	/** Polska odmiana: 1 miejsce, 2–4 miejsca, 5 miejsc. */
	public static function pl( int $n, string $one, string $few, string $many ): string {
		if ( 1 === $n ) {
			return $one;
		}
		$d = $n % 10;
		$t = $n % 100;
		return ( $d >= 2 && $d <= 4 && ( $t < 12 || $t > 14 ) ) ? $few : $many;
	}

	private static function gr( float $zl ): int {
		return (int) round( $zl * 100 );
	}

	/** Skład pobytu z wejścia (REST, koszyk, recepcja) → postać znormalizowana. */
	public static function normalize_party( array $p ): array {
		$ages = $p['children_ages'] ?? [];
		if ( is_string( $ages ) ) {
			$ages = '' === trim( $ages ) ? [] : explode( ',', $ages );
		}
		$extras = [];
		foreach ( (array) ( $p['extras'] ?? [] ) as $id => $qty ) {
			if ( (int) $id > 0 && (int) $qty > 0 ) {
				$extras[ (int) $id ] = (int) $qty;
			}
		}
		return [
			'adults'        => max( 0, (int) ( $p['adults'] ?? 1 ) ),
			'children_ages' => array_map( 'intval', array_values( (array) $ages ) ),
			'eb_adult'      => max( 0, (int) ( $p['eb_adult'] ?? 0 ) ),
			'eb_child'      => max( 0, (int) ( $p['eb_child'] ?? 0 ) ),
			'extras'        => $extras,
		];
	}

	/**
	 * Sprawdza skład względem pojemności i dostawek.
	 * Zwraca rozkład osób (kto płaci, kto śpi na dostawce) albo WP_Error.
	 */
	public static function validate_party( array $cfg, array $party ) {
		$ages = $party['children_ages'];

		if ( $party['adults'] < 1 ) {
			return new WP_Error( 'bm_no_adult', 'Rezerwacja wymaga co najmniej jednej osoby dorosłej.' );
		}
		if ( count( $ages ) > 20 ) {
			return new WP_Error( 'bm_party', 'Nieprawidłowa liczba dzieci.' );
		}
		foreach ( $ages as $age ) {
			if ( $age < 0 || $age > BM_Apartment::MAX_CHILD_AGE ) {
				return new WP_Error( 'bm_child_age', sprintf( 'Wiek dziecka musi być w zakresie 0–%d lat.', BM_Apartment::MAX_CHILD_AGE ) );
			}
		}
		if ( $cfg['beds'] < 1 ) {
			return new WP_Error( 'bm_no_capacity', 'Apartament nie ma ustawionej liczby miejsc.' );
		}

		// Dostawki: dostępność i limity.
		foreach ( [ 'eb_adult' => 'dorosłej', 'eb_child' => 'dziecięcej' ] as $k => $name ) {
			$n = $party[ $k ];
			if ( $n > 0 && ! $cfg[ $k ]['enabled'] ) {
				return new WP_Error( 'bm_extra_bed', "Ten apartament nie oferuje dostawki $name." );
			}
			if ( $n > $cfg[ $k ]['max'] ) {
				return new WP_Error( 'bm_extra_bed', sprintf( "Maksymalna liczba dostawek $name: %d.", $cfg[ $k ]['max'] ) );
			}
		}
		$eb_total = $party['eb_adult'] + $party['eb_child'];
		if ( null !== $cfg['eb_max_total'] && $eb_total > $cfg['eb_max_total'] ) {
			return new WP_Error( 'bm_extra_bed', sprintf( 'Łącznie można zamówić najwyżej %d %s.', $cfg['eb_max_total'], self::pl( $cfg['eb_max_total'], 'dostawkę', 'dostawki', 'dostawek' ) ) );
		}

		// Maluchy (wiek ≤ próg) nie zajmują miejsca — ale najwyżej infant_max; kolejne śpią na normalnym miejscu.
		$sleeper = BM_Apartment::sleepers( $cfg, $ages );

		$fits = function ( int $eb_a, int $eb_c ) use ( $cfg, $party, $sleeper ): bool {
			return $party['adults'] <= $cfg['beds'] + $eb_a
				&& $party['adults'] + count( $sleeper ) <= $cfg['beds'] + $eb_a + $eb_c;
		};

		if ( ! $fits( $party['eb_adult'], $party['eb_child'] ) ) {
			$hint = ( $cfg['eb_adult']['enabled'] || $cfg['eb_child']['enabled'] ) ? ' Dodaj dostawkę, aby zmieścić więcej osób.' : '';
			return new WP_Error( 'bm_capacity', sprintf( 'Apartament ma %d %s — za dużo osób.%s', $cfg['beds'], self::pl( $cfg['beds'], 'miejsce', 'miejsca', 'miejsc' ), $hint ) );
		}
		// Każda zamówiona dostawka musi być potrzebna.
		if ( $party['eb_adult'] > 0 && $fits( $party['eb_adult'] - 1, $party['eb_child'] ) ) {
			return new WP_Error( 'bm_extra_bed_unneeded', 'Dostawka dorosła nie jest potrzebna dla tej liczby osób.' );
		}
		if ( $party['eb_child'] > 0 && $fits( $party['eb_adult'], $party['eb_child'] - 1 ) ) {
			return new WP_Error( 'bm_extra_bed_unneeded', 'Dostawka dziecięca nie jest potrzebna dla tej liczby osób.' );
		}

		// Kto śpi na dostawkach: dorośli ponad stałe miejsca, potem najmłodsze dzieci.
		$adults_on_eb   = min( $party['eb_adult'], max( 0, $party['adults'] - $cfg['beds'] ) );
		$child_eb_slots = $party['eb_adult'] - $adults_on_eb + $party['eb_child'];
		$sorted         = $sleeper;
		sort( $sorted );
		$children_on_eb = array_slice( $sorted, 0, min( $child_eb_slots, count( $sorted ) ) );

		// Dzieci płacące osobowo = wszystkie minus te na dostawkach.
		$paying_children = $ages;
		foreach ( $children_on_eb as $age ) {
			unset( $paying_children[ array_search( $age, $paying_children, true ) ] );
		}

		return [
			'paying_adults'   => $party['adults'] - $adults_on_eb,
			'paying_children' => array_values( $paying_children ),
			'infants'         => count( $ages ) - count( $sleeper ),
			'occupants'       => $party['adults'] + count( $sleeper ),
		];
	}

	/** Zwraca wycenę lub WP_Error. Nie sprawdza dostępności terminu — to robi BM_Availability. */
	public static function quote( int $apartment_id, string $check_in, string $check_out, array $party = [], int $exclude_booking = 0 ) {
		$apt = wc_get_product( $apartment_id );
		if ( ! $apt || 'bm_apartment' !== $apt->get_type() ) {
			return new WP_Error( 'bm_no_apartment', 'Nie ma takiego apartamentu.' );
		}
		$cfg   = BM_Apartment::config( $apt );
		$party = self::normalize_party( $party );

		$range = BM_Availability::parse_range( $check_in, $check_out );
		if ( is_wp_error( $range ) ) {
			return $range;
		}
		$nights = BM_Availability::nights( ...$range );
		$n      = count( $nights );

		// Sezony w terminie pobytu; zasady (minimalny pobyt, dni przyjazdu) z sezonu nocy przyjazdu.
		$seasons = BM_Seasons::for_apartment( $apartment_id, $check_in, $check_out );
		$first   = BM_Seasons::pick( $seasons, $check_in );
		$min     = BM_Seasons::min_nights( $first, $cfg['min_nights'] );

		// Minimalny pobyt; krótszy tylko, gdy dokładnie wypełnia lukę.
		$is_gap = false;
		if ( $n < $min ) {
			$is_gap = $cfg['fill_gaps'] && BM_Availability::is_gap( $apartment_id, $check_in, $check_out );
			if ( ! $is_gap ) {
				return new WP_Error( 'bm_min_stay', $first && $min !== $cfg['min_nights']
					? sprintf( 'W terminie „%s” minimalny pobyt to %d %s.', $first['name'], $min, self::pl( $min, 'noc', 'noce', 'nocy' ) )
					: sprintf( 'Minimalny pobyt: %d %s.', $min, self::pl( $min, 'noc', 'noce', 'nocy' ) ) );
			}
		}
		// Dni przyjazdu w sezonie (np. tylko sobota) — nie dotyczy wypełniania luki.
		if ( $first && $first['arrival_days'] && ! $is_gap && ! in_array( (int) gmdate( 'N', strtotime( $check_in . ' 12:00' ) ), $first['arrival_days'], true ) ) {
			return new WP_Error( 'bm_arrival_day', sprintf( 'W terminie „%s” przyjazd jest możliwy w: %s.', $first['name'], BM_Seasons::days_text( $first['arrival_days'] ) ) );
		}

		$who = self::validate_party( $cfg, $party );
		if ( is_wp_error( $who ) ) {
			return $who;
		}

		$lines = [];
		$add   = function ( string $type, string $label, float $qty, int $unit, int $amount ) use ( &$lines ) {
			$lines[] = [ 'type' => $type, 'label' => $label, 'qty' => $qty, 'unit_price' => $unit / 100, 'amount' => $amount / 100 ];
			return $amount;
		};

		// Noce pogrupowane wg sezonu (0 = cena bazowa); każda grupa liczona po swoich cenach.
		$groups = [];
		foreach ( $nights as $date ) {
			$season = BM_Seasons::pick( $seasons, $date );
			$key    = $season && $season['rates'] ? $season['id'] : 0;
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = [ 'suffix' => $key ? ' – ' . $season['name'] : '', 'cfg' => BM_Seasons::apply( $cfg, $key ? $season : null ), 'nights' => 0 ];
			}
			$groups[ $key ]['nights']++;
		}
		$nl = fn( int $k ) => $k . ' ' . self::pl( $k, 'noc', 'noce', 'nocy' );

		// 1. Nocleg.
		$acc = 0;
		foreach ( $groups as $g ) {
			$gc = $g['cfg'];
			$k  = $g['nights'];
			$sx = $g['suffix'];
			if ( BM_Apartment::MODE_FLAT === $cfg['mode'] ) {
				$rate = self::gr( $gc['rate'] );
				if ( $rate <= 0 ) {
					return new WP_Error( 'bm_no_rate', 'Apartament nie ma ustawionej stawki.' );
				}
				$acc += $add( 'nights', sprintf( 'Nocleg%s (%s)', $sx, $nl( $k ) ), $k, $rate, $rate * $k );
				continue;
			}
			$adult = self::gr( $gc['adult_rate'] );
			if ( $adult <= 0 ) {
				return new WP_Error( 'bm_no_rate', 'Apartament nie ma ustawionej stawki za osobę.' );
			}
			$nightly = 0;
			if ( $who['paying_adults'] > 0 ) {
				$nightly += $add( 'adults', sprintf( 'Dorośli%s: %d × %s', $sx, $who['paying_adults'], $nl( $k ) ), $who['paying_adults'] * $k, $adult, $who['paying_adults'] * $adult * $k ) / $k;
			}
			foreach ( $who['paying_children'] as $age ) {
				$price    = self::gr( BM_Apartment::child_price( $gc, $age ) );
				$nightly += $add( 'child', sprintf( 'Dziecko %d l.%s × %s', $age, $sx, $nl( $k ) ), $k, $price, $price * $k ) / $k;
			}
			$min_nightly = $cfg['min_paying'] * $adult;
			if ( $nightly < $min_nightly ) {
				$add( 'min_charge', sprintf( 'Dopłata do minimum %d os.%s × %s', $cfg['min_paying'], $sx, $nl( $k ) ), $k, (int) ( $min_nightly - $nightly ), (int) ( ( $min_nightly - $nightly ) * $k ) );
				$nightly = $min_nightly;
			}
			$acc += (int) round( $nightly * $k );
		}

		// 2. Dostawki (cena może zależeć od sezonu).
		$beds = 0;
		foreach ( [ 'eb_adult' => 'Dostawka dorosła', 'eb_child' => 'Dostawka dziecięca' ] as $t => $label ) {
			if ( $party[ $t ] <= 0 ) {
				continue;
			}
			foreach ( $groups as $g ) {
				$unit  = self::gr( $g['cfg'][ $t ]['price'] );
				$beds += $add( $t, sprintf( '%s%s: %d × %s', $label, $g['suffix'], $party[ $t ], $nl( $g['nights'] ) ), $party[ $t ] * $g['nights'], $unit, $unit * $party[ $t ] * $g['nights'] );
			}
		}

		// 3. Opcje dodatkowe — tylko przypisane do apartamentu, w limicie ilości.
		$available = BM_Extras::for_apartment( $apartment_id );
		$extras    = 0;
		$chosen    = [];
		foreach ( $party['extras'] as $id => $qty ) {
			if ( ! isset( $available[ $id ] ) ) {
				return new WP_Error( 'bm_extra', 'Wybrana opcja nie jest dostępna w tym apartamencie.' );
			}
			$x = $available[ $id ];
			if ( $qty > $x['max_qty'] ) {
				return new WP_Error( 'bm_extra', sprintf( '%s: maksymalnie %d.', $x['name'], $x['max_qty'] ) );
			}
			$unit   = self::gr( $x['price'] );
			$mult   = BM_Extras::CHARGE_NIGHT === $x['charge_type'] ? $n : 1;
			$label  = $x['name'] . ( $qty > 1 ? " × $qty" : '' ) . ( BM_Extras::CHARGE_NIGHT === $x['charge_type'] ? " × $n nocy" : '' );
			$amount = $add( 'extra', $label, $qty * $mult, $unit, $unit * $qty * $mult );
			$extras += $amount;
			$chosen[] = [ 'id' => $id, 'name' => $x['name'], 'charge_type' => $x['charge_type'], 'qty' => $qty, 'unit_price' => $unit / 100, 'total' => $amount / 100 ];
		}

		// Pule sztuk w obiekcie (np. 2 łóżeczka na budynek).
		if ( $party['extras'] ) {
			$pool = BM_Extras::check_pools( $apartment_id, $check_in, $check_out, $party['extras'], $exclude_booking );
			if ( is_wp_error( $pool ) ) {
				return $pool;
			}
		}

		// 4. Opłata serwisowa.
		$service = self::gr( $cfg['service_fee'] );
		if ( $service > 0 ) {
			$add( 'service', 'Opłata serwisowa', 1, $service, $service );
		}

		$total = $acc + $beds + $extras + $service;

		// Opłata miejscowa — informacyjnie.
		$city = 0;
		if ( $cfg['city_tax']['enabled'] && $cfg['city_tax']['amount'] > 0 ) {
			$exempt = $cfg['city_tax']['exempt_age'];
			$liable = $party['adults'] + count( array_filter( $party['children_ages'], fn( $a ) => null === $exempt || $a > $exempt ) );
			$city   = $liable * self::gr( $cfg['city_tax']['amount'] ) * $n;
		}

		$pct = (int) BM_Settings::get( 'min_deposit_percent' );

		return [
			'apartment_id'     => $apartment_id,
			'check_in'         => $check_in,
			'check_out'        => $check_out,
			'nights'           => $n,
			'is_gap'           => $is_gap,
			'mode'             => $cfg['mode'],
			'party'            => $party,
			'occupants'        => $who['occupants'],
			'lines'            => $lines,
			'extras'           => $chosen,
			'price_nights'     => $acc / 100,
			'price_extra_beds' => $beds / 100,
			'price_extras'     => $extras / 100,
			'service_fee'      => $service / 100,
			'total'            => $total / 100,
			'per_night'        => round( $total / $n / 100, 2 ),
			'city_tax'         => [ 'amount' => $city / 100, 'payable' => 'on_site' ],
			'deposit_percent'  => $pct,
			'deposit_min'      => (int) ceil( $total * $pct / 100 ) / 100,
		];
	}
}
