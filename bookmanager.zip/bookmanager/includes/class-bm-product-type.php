<?php
defined( 'ABSPATH' ) || exit;

/**
 * Typ produktu „Apartament”: zakładki „Cennik” i „Pojemność” w panelu produktu.
 * Odczyt konfiguracji — BM_Apartment::config().
 */
class BM_Product_Type {

	public static function init(): void {
		require_once BM_PATH . 'includes/class-wc-product-bm-apartment.php';

		add_filter( 'product_type_selector', [ __CLASS__, 'add_type' ] );
		add_filter( 'woocommerce_product_class', [ __CLASS__, 'product_class' ], 10, 2 );
		add_filter( 'woocommerce_product_data_tabs', [ __CLASS__, 'add_tabs' ] );
		add_action( 'woocommerce_product_data_panels', [ __CLASS__, 'render_panels' ] );
		add_action( 'woocommerce_admin_process_product_object', [ __CLASS__, 'save' ] );
		add_filter( 'woocommerce_get_price_html', [ __CLASS__, 'price_html' ], 10, 2 );
		add_action( 'admin_footer', [ __CLASS__, 'script' ] );
	}

	public static function add_type( array $types ): array {
		$types['bm_apartment'] = __( 'Apartament', 'bookmanager' );
		return $types;
	}

	public static function product_class( string $class, string $type ): string {
		return 'bm_apartment' === $type ? 'WC_Product_BM_Apartment' : $class;
	}

	public static function add_tabs( array $tabs ): array {
		$tabs['bm_pricing']  = [ 'label' => __( 'Cennik', 'bookmanager' ), 'target' => 'bm_pricing_data', 'class' => [ 'show_if_bm_apartment' ], 'priority' => 15 ];
		$tabs['bm_capacity'] = [ 'label' => __( 'Pojemność', 'bookmanager' ), 'target' => 'bm_capacity_data', 'class' => [ 'show_if_bm_apartment' ], 'priority' => 16 ];
		return $tabs;
	}

	/* ---------- Pola ---------- */

	private static function money( string $id, string $label, string $wrap = '', string $desc = '' ): void {
		woocommerce_wp_text_input( [
			'id' => $id, 'label' => $label, 'data_type' => 'price', 'wrapper_class' => $wrap,
			'desc_tip' => (bool) $desc, 'description' => $desc,
		] );
	}

	private static function number( string $id, string $label, string $wrap = '', string $desc = '', array $attr = [], string $placeholder = '' ): void {
		woocommerce_wp_text_input( [
			'id' => $id, 'label' => $label, 'type' => 'number', 'wrapper_class' => $wrap, 'placeholder' => $placeholder,
			'custom_attributes' => $attr + [ 'min' => 0, 'step' => 1 ], 'desc_tip' => (bool) $desc, 'description' => $desc,
		] );
	}

	private static function toggle( string $id, string $label, string $desc, string $controls ): void {
		woocommerce_wp_checkbox( [
			'id' => $id, 'label' => $label, 'description' => $desc,
			'custom_attributes' => [ 'data-bm-controls' => $controls ],
		] );
	}

	private static function heading( string $text ): void {
		echo '<h4 class="bm-section">' . esc_html( $text ) . '</h4>';
	}

	public static function render_panels(): void {
		global $post;
		$apt = $post ? wc_get_product( $post->ID ) : null;
		$cfg = $apt && 'bm_apartment' === $apt->get_type() ? BM_Apartment::config( $apt ) : null;

		/* Cennik */
		echo '<div id="bm_pricing_data" class="panel woocommerce_options_panel hidden">';

		self::heading( __( 'Cena noclegu', 'bookmanager' ) );
		woocommerce_wp_select( [
			'id'      => '_bm_price_mode',
			'label'   => __( 'Sposób liczenia', 'bookmanager' ),
			'desc_tip'    => true,
			'description' => __( 'Stała — ta sama cena bez względu na liczbę osób. Za osobę — dorośli i dzieci (wg wieku) liczeni osobno.', 'bookmanager' ),
			'value'   => $cfg['mode'] ?? BM_Apartment::MODE_FLAT,
			'options' => [
				BM_Apartment::MODE_FLAT       => __( 'Cena stała za noc', 'bookmanager' ),
				BM_Apartment::MODE_PER_PERSON => __( 'Cena za osobę', 'bookmanager' ),
			],
		] );
		self::money( '_bm_rate', __( 'Stawka za noc (zł)', 'bookmanager' ), 'bm-mode-flat' );
		self::money( '_bm_adult_rate', __( 'Dorosły za noc (zł)', 'bookmanager' ), 'bm-mode-pp' );

		echo '<div class="form-field bm-mode-pp bm-bands"><label>' . esc_html__( 'Dzieci za noc', 'bookmanager' ) . '</label>';
		echo '<table class="bm-bands-table"><thead><tr><th>' . esc_html__( 'wiek od', 'bookmanager' ) . '</th><th>' . esc_html__( 'do', 'bookmanager' ) . '</th><th>' . esc_html__( 'cena (zł)', 'bookmanager' ) . '</th><th></th></tr></thead><tbody>';
		$bands = $cfg['child_bands'] ?? [];
		foreach ( $bands ?: [ [ 'from' => '', 'to' => '', 'price' => '' ] ] as $i => $b ) {
			self::band_row( $i, $b );
		}
		echo '</tbody></table>';
		echo '<button type="button" class="button bm-band-add">' . esc_html__( '+ przedział wieku', 'bookmanager' ) . '</button>';
		echo '<p class="description">' . esc_html__( 'Dziecko starsze niż ostatni przedział płaci jak dorosły. Cena 0 = bezpłatnie.', 'bookmanager' ) . '</p>';
		echo '<script type="text/template" id="bm-band-tpl">';
		self::band_row( '__i__', [ 'from' => '', 'to' => '', 'price' => '' ] );
		echo '</script></div>';

		self::number( '_bm_min_paying', __( 'Minimum płatnych osób', 'bookmanager' ), 'bm-mode-pp',
			__( 'Za noc liczymy co najmniej tyle osób dorosłych. Puste = bez minimum.', 'bookmanager' ), [ 'min' => 0, 'max' => 50 ] );

		self::money( '_bm_service_fee', __( 'Opłata serwisowa (zł)', 'bookmanager' ), '', __( 'Jednorazowo za pobyt.', 'bookmanager' ) );

		self::heading( __( 'Długość pobytu', 'bookmanager' ) );
		self::number( '_bm_min_nights', __( 'Minimalny pobyt (nocy)', 'bookmanager' ), '', '', [ 'min' => 1 ],
			sprintf( __( 'domyślnie %d', 'bookmanager' ), BM_Settings::get( 'min_nights' ) ) );
		woocommerce_wp_checkbox( [
			'id'          => '_bm_fill_gaps',
			'label'       => __( 'Wypełnianie luk', 'bookmanager' ),
			'description' => __( 'Pozwól na krótszy pobyt, jeśli dokładnie wypełnia lukę między rezerwacjami.', 'bookmanager' ),
			'value'       => ( $cfg['fill_gaps'] ?? true ) ? 'yes' : 'no',
		] );

		self::heading( __( 'Opłata miejscowa', 'bookmanager' ) );
		self::toggle( '_bm_city_tax', __( 'Pobierana', 'bookmanager' ), __( 'Informacja dla gościa — płatna na miejscu, nie wchodzi do zaliczki.', 'bookmanager' ), 'bm-city' );
		self::money( '_bm_city_tax_amount', __( 'Za osobę za noc (zł)', 'bookmanager' ), 'bm-city' );
		self::number( '_bm_city_tax_exempt_age', __( 'Dzieci zwolnione do (lat, włącznie)', 'bookmanager' ), 'bm-city', '', [ 'max' => 17 ] );

		echo '</div>';

		/* Pojemność */
		echo '<div id="bm_capacity_data" class="panel woocommerce_options_panel hidden">';

		self::heading( __( 'Miejsca', 'bookmanager' ) );
		self::number( '_bm_beds', __( 'Stałe miejsca do spania', 'bookmanager' ), '', '', [ 'min' => 1, 'max' => 50 ] );
		self::number( '_bm_infant_age', __( 'Dzieci nie zajmują miejsca do (lat, włącznie)', 'bookmanager' ), '',
			__( 'Np. 2 — maluch do 2 lat śpi z rodzicami. Puste = każde dziecko zajmuje miejsce.', 'bookmanager' ), [ 'max' => 17 ] );
		self::number( '_bm_infant_max', __( 'Maks. dzieci bez miejsca', 'bookmanager' ), '',
			__( 'Ile takich maluchów zmieści się bez własnego miejsca (puste = 1). Kolejne zajmują normalne miejsce albo dostawkę.', 'bookmanager' ), [ 'min' => 0, 'max' => 10 ], '1' );

		self::heading( __( 'Dostawki', 'bookmanager' ) );
		self::toggle( '_bm_eb_adult', __( 'Dostawka dorosła', 'bookmanager' ), __( 'dostępna — pozwala dodać jedną osobę dorosłą więcej', 'bookmanager' ), 'bm-eba' );
		self::number( '_bm_eb_adult_max', __( 'Maks. liczba', 'bookmanager' ), 'bm-eba', '', [ 'min' => 1, 'max' => 10 ] );
		self::money( '_bm_eb_adult_price', __( 'Cena za noc (zł)', 'bookmanager' ), 'bm-eba' );
		self::toggle( '_bm_eb_child', __( 'Dostawka dziecięca', 'bookmanager' ), __( 'dostępna — pozwala dodać jedno dziecko więcej', 'bookmanager' ), 'bm-ebc' );
		self::number( '_bm_eb_child_max', __( 'Maks. liczba', 'bookmanager' ), 'bm-ebc', '', [ 'min' => 1, 'max' => 10 ] );
		self::money( '_bm_eb_child_price', __( 'Cena za noc (zł)', 'bookmanager' ), 'bm-ebc' );
		self::number( '_bm_eb_max_total', __( 'Maks. dostawek łącznie', 'bookmanager' ), '',
			__( 'Np. 1 — gość wybierze dorosłą albo dziecięcą, nie obie. Puste = suma limitów.', 'bookmanager' ), [ 'max' => 20 ] );
		echo '<p class="bm-note">' . esc_html__( 'Osoba śpiąca na dostawce płaci tylko za dostawkę.', 'bookmanager' ) . '</p>';

		echo '</div>';
	}

	private static function band_row( $i, array $b ): void {
		printf(
			'<tr><td><input type="number" min="0" max="17" name="bm_bands[%1$s][from]" value="%2$s"></td>'
			. '<td><input type="number" min="0" max="17" name="bm_bands[%1$s][to]" value="%3$s"></td>'
			. '<td><input type="text" class="wc_input_price" name="bm_bands[%1$s][price]" value="%4$s"></td>'
			. '<td><button type="button" class="button-link bm-band-del" aria-label="usuń">✕</button></td></tr>',
			esc_attr( (string) $i ), esc_attr( (string) $b['from'] ), esc_attr( (string) $b['to'] ),
			esc_attr( '' === $b['price'] ? '' : wc_format_localized_price( wc_format_decimal( $b['price'], 2 ) ) )
		);
	}

	/* ---------- Zapis ---------- */

	public static function save( WC_Product $product ): void {
		if ( 'bm_apartment' !== $product->get_type() ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification -- nonce sprawdza WooCommerce.
		$post  = wp_unslash( $_POST );
		$money = fn( $k ) => wc_format_decimal( $post[ $k ] ?? '' );
		$int   = fn( $k ) => '' === trim( (string) ( $post[ $k ] ?? '' ) ) ? '' : absint( $post[ $k ] );
		$flag  = fn( $k ) => isset( $post[ $k ] ) ? 'yes' : 'no';

		$mode = ( $post['_bm_price_mode'] ?? '' ) === BM_Apartment::MODE_PER_PERSON ? BM_Apartment::MODE_PER_PERSON : BM_Apartment::MODE_FLAT;

		$meta = [
			'_bm_price_mode'          => $mode,
			'_bm_rate'                => $money( '_bm_rate' ),
			'_bm_adult_rate'          => $money( '_bm_adult_rate' ),
			'_bm_child_bands'         => wp_json_encode( BM_Apartment::sanitize_bands( (array) ( $post['bm_bands'] ?? [] ) ) ),
			'_bm_min_paying'          => $int( '_bm_min_paying' ),
			'_bm_service_fee'         => $money( '_bm_service_fee' ),
			'_bm_min_nights'          => $int( '_bm_min_nights' ) ?: '',
			'_bm_fill_gaps'           => $flag( '_bm_fill_gaps' ),
			'_bm_city_tax'            => $flag( '_bm_city_tax' ),
			'_bm_city_tax_amount'     => $money( '_bm_city_tax_amount' ),
			'_bm_city_tax_exempt_age' => $int( '_bm_city_tax_exempt_age' ),
			'_bm_beds'                => $int( '_bm_beds' ),
			'_bm_infant_age'          => $int( '_bm_infant_age' ),
			'_bm_infant_max'          => $int( '_bm_infant_max' ),
			'_bm_eb_adult'            => $flag( '_bm_eb_adult' ),
			'_bm_eb_adult_max'        => $int( '_bm_eb_adult_max' ),
			'_bm_eb_adult_price'      => $money( '_bm_eb_adult_price' ),
			'_bm_eb_child'            => $flag( '_bm_eb_child' ),
			'_bm_eb_child_max'        => $int( '_bm_eb_child_max' ),
			'_bm_eb_child_price'      => $money( '_bm_eb_child_price' ),
			'_bm_eb_max_total'        => $int( '_bm_eb_max_total' ),
		];
		// phpcs:enable

		// Włączona dostawka bez limitu = 1 sztuka.
		foreach ( [ 'adult', 'child' ] as $t ) {
			if ( 'yes' === $meta[ "_bm_eb_$t" ] && ! $meta[ "_bm_eb_{$t}_max" ] ) {
				$meta[ "_bm_eb_{$t}_max" ] = 1;
			}
		}
		foreach ( $meta as $k => $v ) {
			$product->update_meta_data( $k, $v );
		}
	}

	/** Na listach: „od X zł / noc” albo „od X zł / os. / noc”. */
	public static function price_html( string $html, WC_Product $product ): string {
		if ( 'bm_apartment' !== $product->get_type() ) {
			return $html;
		}
		$from = BM_Apartment::from_price( $product );
		return $from['amount'] > 0 ? sprintf( __( 'od %1$s / %2$s', 'bookmanager' ), wc_price( $from['amount'] ), $from['unit'] ) : '';
	}

	/** Pokazywanie i ukrywanie pól zależnie od trybu i przełączników + powielanie przedziałów wieku. */
	public static function script(): void {
		$screen = get_current_screen();
		if ( ! $screen || 'product' !== $screen->id ) {
			return;
		}
		?>
		<style>
			#woocommerce-product-data .bm-section{margin:14px 12px 4px;padding-top:10px;border-top:1px solid #eee;font-size:13px}
			#woocommerce-product-data .panel .bm-section:first-child{border-top:0;padding-top:0}
			.bm-bands{padding:5px 20px 5px 162px!important}
			.bm-bands label{margin-left:-150px!important;float:left;width:150px}
			.bm-bands-table input{width:80px!important;float:none!important}
			.bm-bands-table th{text-align:left;font-weight:400;color:#646970;padding:0 4px}
			.bm-band-del{color:#b32d2e;text-decoration:none}
			.bm-bands .description{display:block;clear:both;margin:6px 0 0!important;padding:0!important}
			.bm-note{margin:4px 12px 12px 162px;color:#646970;font-style:italic}
		</style>
		<script>
		jQuery(function ($) {
			function sync() {
				var pp = $('#_bm_price_mode').val() === 'per_person';
				$('.bm-mode-flat').toggle(!pp); $('.bm-mode-pp').toggle(pp);
				$('[data-bm-controls]').each(function () { $('.' + $(this).data('bm-controls')).toggle(this.checked); });
			}
			$(document).on('change', '#_bm_price_mode, [data-bm-controls]', sync);
			sync();
			var n = 1000;
			$('.bm-band-add').on('click', function () {
				$('.bm-bands-table tbody').append($('#bm-band-tpl').html().replace(/__i__/g, n++));
			});
			$(document).on('click', '.bm-band-del', function () { $(this).closest('tr').remove(); });
		});
		</script>
		<?php
	}
}
