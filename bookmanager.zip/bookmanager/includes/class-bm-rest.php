<?php
defined( 'ABSPATH' ) || exit;

/**
 * Publiczne endpointy dla widżetu rezerwacji.
 *
 * GET /wp-json/bookmanager/v1/apartments/{id}/calendar?from=2026-11-01&to=2026-12-01
 * GET /wp-json/bookmanager/v1/apartments/{id}/quote?check_in=2026-11-10&check_out=2026-11-15
 *
 * Zwracają tylko daty i ceny — nigdy danych gości.
 */
class BM_REST {

	const NS            = 'bookmanager/v1';
	const MAX_SPAN_DAYS = 93;  // ok. 3 miesiące na jedno zapytanie
	const MAX_AHEAD     = 730; // nie dalej niż 2 lata w przód

	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
	}

	public static function routes(): void {
		$date = [
			'type'              => 'string',
			'required'          => true,
			'validate_callback' => fn( $v ) => is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ),
		];

		register_rest_route( self::NS, '/apartments/(?P<id>\d+)/calendar', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'calendar' ],
			'permission_callback' => '__return_true',
			'args'                => [ 'from' => $date, 'to' => $date ],
		] );

		register_rest_route( self::NS, '/apartments/(?P<id>\d+)/quote', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ __CLASS__, 'quote' ],
			'permission_callback' => '__return_true',
			'args'                => [
				'check_in'  => $date,
				'check_out' => $date,
				'adults'    => [ 'type' => 'integer', 'default' => 1, 'minimum' => 1, 'maximum' => 50 ],
				'children'  => [ 'type' => 'string', 'default' => '', 'description' => 'Wiek dzieci po przecinku, np. 5,1', 'validate_callback' => fn( $v ) => '' === $v || preg_match( '/^\d{1,2}(,\d{1,2}){0,19}$/', $v ) ],
				'eb_adult'  => [ 'type' => 'integer', 'default' => 0, 'minimum' => 0, 'maximum' => 10 ],
				'eb_child'  => [ 'type' => 'integer', 'default' => 0, 'minimum' => 0, 'maximum' => 10 ],
				'extras'    => [ 'type' => 'string', 'default' => '', 'description' => 'id:ilość po przecinku, np. 3:1,5:2', 'validate_callback' => fn( $v ) => '' === $v || preg_match( '/^\d+:\d{1,2}(,\d+:\d{1,2}){0,19}$/', $v ) ],
			],
		] );
	}

	/** Opublikowany apartament albo WP_Error 404. */
	private static function apartment( int $id ) {
		$apt = wc_get_product( $id );
		if ( ! $apt || 'bm_apartment' !== $apt->get_type() || 'publish' !== $apt->get_status() ) {
			return new WP_Error( 'bm_no_apartment', 'Nie ma takiego apartamentu.', [ 'status' => 404 ] );
		}
		return $apt;
	}

	public static function calendar( WP_REST_Request $req ) {
		$apt = self::apartment( (int) $req['id'] );
		if ( is_wp_error( $apt ) ) {
			return $apt;
		}

		$tz    = wp_timezone();
		$today = new DateTimeImmutable( 'today', $tz );
		$from  = DateTimeImmutable::createFromFormat( '!Y-m-d', $req['from'], $tz );
		$to    = DateTimeImmutable::createFromFormat( '!Y-m-d', $req['to'], $tz );

		if ( ! $from || ! $to || $to <= $from || $from->diff( $to )->days > self::MAX_SPAN_DAYS ) {
			return new WP_Error( 'bm_bad_range', 'Nieprawidłowy zakres dat.', [ 'status' => 400 ] );
		}
		if ( $from < $today ) {
			$from = $today; // przeszłość nikogo nie interesuje
		}
		if ( $today->diff( $to )->days > self::MAX_AHEAD ) {
			return new WP_Error( 'bm_too_far', 'Za daleki termin.', [ 'status' => 400 ] );
		}

		$from_s = $from->format( 'Y-m-d' );
		$to_s   = $to->format( 'Y-m-d' );
		$cal    = $from < $to
			? BM_Availability::get_calendar( $apt->get_id(), $from_s, $to_s )
			: [ 'booked' => [], 'firm' => [] ];

		$res = rest_ensure_response( [
			'apartment_id' => $apt->get_id(),
			'from'         => $from_s,
			'to'           => $to_s,
			'today'        => $today->format( 'Y-m-d' ),
			'min_nights'   => BM_Pricing::min_nights( $apt ),
			'fill_gaps'    => BM_Pricing::gaps_allowed( $apt ),
			'booked'       => $cal['booked'],
			'firm'         => $cal['firm'],
		] );
		$res->header( 'Cache-Control', 'no-store' ); // dostępność musi być świeża
		return $res;
	}

	public static function quote( WP_REST_Request $req ) {
		$apt = self::apartment( (int) $req['id'] );
		if ( is_wp_error( $apt ) ) {
			return $apt;
		}
		$in  = $req['check_in'];
		$out = $req['check_out'];

		$extras = [];
		foreach ( array_filter( explode( ',', (string) $req['extras'] ) ) as $pair ) {
			[ $id, $qty ] = array_map( 'intval', explode( ':', $pair ) );
			$extras[ $id ] = $qty;
		}
		$quote = BM_Pricing::quote( $apt->get_id(), $in, $out, [
			'adults'        => (int) $req['adults'],
			'children_ages' => (string) $req['children'],
			'eb_adult'      => (int) $req['eb_adult'],
			'eb_child'      => (int) $req['eb_child'],
			'extras'        => $extras,
		] );
		if ( is_wp_error( $quote ) ) {
			$quote->add_data( [ 'status' => 422 ] );
			return $quote;
		}
		if ( ! BM_Availability::is_available( $apt->get_id(), $in, $out ) ) {
			return new WP_Error( 'bm_unavailable', 'Ten termin jest już zajęty.', [ 'status' => 409 ] );
		}

		$res = rest_ensure_response( $quote );
		$res->header( 'Cache-Control', 'no-store' );
		return $res;
	}
}
