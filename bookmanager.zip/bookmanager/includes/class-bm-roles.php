<?php
defined( 'ABSPATH' ) || exit;

/**
 * Role i uprawnienia panelu BookManager.
 *
 *   bm_desk   — obsługa: kalendarz, rezerwacje, blokady, notatki (rola „Recepcja”)
 *   bm_manage — właściciel: wszystko z obsługi + anulowanie rezerwacji, historia zmian, ustawienia (rola „Właściciel”)
 *
 * Administrator i Kierownik sklepu (manage_woocommerce) mają oba uprawnienia automatycznie.
 */
class BM_Roles {

	const DESK    = 'bm_desk';
	const MANAGE  = 'bm_manage';
	const VERSION = 1;

	public static function init(): void {
		add_action( 'init', [ __CLASS__, 'ensure' ] );
		add_filter( 'user_has_cap', [ __CLASS__, 'grant_admins' ], 10, 1 );
		// Konta panelu nie potrzebują kokpitu WordPressa ani paska administratora.
		add_filter( 'show_admin_bar', [ __CLASS__, 'admin_bar' ] );
		add_action( 'admin_init', [ __CLASS__, 'keep_out_of_admin' ] );
		add_filter( 'login_redirect', [ __CLASS__, 'login_redirect' ], 10, 3 );
	}

	/** Zakłada role raz (i po zmianie ich definicji). Aktualizacja wtyczki nie uruchamia aktywacji, dlatego sprawdzamy przy init. */
	public static function ensure(): void {
		if ( (int) get_option( 'bm_roles_version' ) === self::VERSION ) {
			return;
		}
		remove_role( 'bm_desk' );
		remove_role( 'bm_owner' );
		add_role( 'bm_desk', __( 'Recepcja (BookManager)', 'bookmanager' ), [ 'read' => true, self::DESK => true ] );
		add_role( 'bm_owner', __( 'Właściciel (BookManager)', 'bookmanager' ), [ 'read' => true, self::DESK => true, self::MANAGE => true ] );
		update_option( 'bm_roles_version', self::VERSION, false );
	}

	public static function grant_admins( array $allcaps ): array {
		if ( ! empty( $allcaps['manage_woocommerce'] ) ) {
			$allcaps[ self::DESK ]   = true;
			$allcaps[ self::MANAGE ] = true;
		}
		return $allcaps;
	}

	/** Czy użytkownik ma tylko rolę panelu (bez dostępu do kokpitu). */
	public static function panel_only( ?WP_User $u = null ): bool {
		$u = $u ?: wp_get_current_user();
		return $u && $u->exists() && $u->has_cap( self::DESK ) && ! $u->has_cap( 'edit_posts' ) && ! $u->has_cap( 'manage_woocommerce' );
	}

	public static function admin_bar( $show ) {
		return self::panel_only() ? false : $show;
	}

	public static function keep_out_of_admin(): void {
		if ( wp_doing_ajax() || ! self::panel_only() ) {
			return;
		}
		$url = BM_Panel::url();
		if ( $url ) {
			wp_safe_redirect( $url );
			exit;
		}
	}

	public static function login_redirect( $to, $requested, $user ) {
		if ( $user instanceof WP_User && self::panel_only( $user ) && BM_Panel::url() ) {
			return BM_Panel::url();
		}
		return $to;
	}

	public static function can_desk(): bool {
		return current_user_can( self::DESK );
	}

	public static function can_manage(): bool {
		return current_user_can( self::MANAGE );
	}
}
