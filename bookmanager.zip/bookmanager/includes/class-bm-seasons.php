<?php
defined( 'ABSPATH' ) || exit;

/**
 * Sezony cenowe.
 *
 * Sezon = nazwany zakres nocy (date_from … date_to włącznie) przypisany do obiektu (object_id, 0 = wszystkie obiekty).
 * Ceny apartamentu w sezonie: wp_bm_season_rates (NULL = cena bazowa). Brak wiersza = apartament liczy się po cenie bazowej.
 * Nakładające się sezony: wygrywa krótszy (np. Sylwester w Zimie), przy równej długości — nowszy.
 * Minimalny pobyt i dni przyjazdu: z sezonu nocy przyjazdu (apartament w sezonie → sezon → apartament).
 */
class BM_Seasons {

	const DOW = [ 1 => 'poniedziałek', 'wtorek', 'środa', 'czwartek', 'piątek', 'sobota', 'niedziela' ];

	private static function ts(): string {
		return BM_Installer::table( 'seasons' );
	}

	private static function tr(): string {
		return BM_Installer::table( 'season_rates' );
	}

	/* ================= odczyt ================= */

	private static function hydrate( object $r ): array {
		return [
			'id'           => (int) $r->id,
			'object_id'    => (int) $r->object_id,
			'name'         => (string) $r->name,
			'date_from'    => (string) $r->date_from,
			'date_to'      => (string) $r->date_to,
			'min_nights'   => null === $r->min_nights ? null : (int) $r->min_nights,
			'arrival_days' => self::days( (string) $r->arrival_days ),
			'color'        => (string) $r->color,
			'length'       => (int) round( ( strtotime( $r->date_to . ' 12:00' ) - strtotime( $r->date_from . ' 12:00' ) ) / DAY_IN_SECONDS ) + 1,
		];
	}

	/** „6,7” → [6, 7] (ISO: 1 = poniedziałek). */
	public static function days( string $s ): array {
		$d = array_values( array_unique( array_filter( array_map( 'intval', explode( ',', $s ) ), fn( $x ) => $x >= 1 && $x <= 7 ) ) );
		sort( $d );
		return $d;
	}

	public static function days_text( array $days ): string {
		return implode( ', ', array_map( fn( $d ) => self::DOW[ $d ], $days ) );
	}

	public static function get( int $id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::ts() . ' WHERE id = %d', $id ) );
		return $r ? self::hydrate( $r ) : null;
	}

	/** Lista sezonów (opcjonalnie jednego obiektu i/lub od daty), chronologicznie. */
	public static function all( ?int $object_id = null, string $from = '' ): array {
		global $wpdb;
		$where = [ '1=1' ];
		$args  = [];
		if ( null !== $object_id ) {
			$where[] = 'object_id IN (0, %d)';
			$args[]  = $object_id;
		}
		if ( $from ) {
			$where[] = 'date_to >= %s';
			$args[]  = $from;
		}
		$sql  = 'SELECT * FROM ' . self::ts() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY date_from, id';
		$rows = $args ? $wpdb->get_results( $wpdb->prepare( $sql, $args ) ) : $wpdb->get_results( $sql ); // phpcs:ignore
		return array_map( [ __CLASS__, 'hydrate' ], $rows );
	}

	/** Ceny apartamentu w sezonie (surowe; null = bazowa) albo null, gdy brak wiersza. */
	public static function rates( int $apartment_id, int $season_id ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tr() . ' WHERE apartment_id = %d AND season_id = %d', $apartment_id, $season_id ) );
		return $r ? self::hydrate_rates( $r ) : null;
	}

	private static function hydrate_rates( object $r ): array {
		$f  = fn( $v ) => null === $v ? null : (float) $v;
		$cp = json_decode( (string) $r->child_prices, true );
		return [
			'rate'           => $f( $r->rate ),
			'adult_rate'     => $f( $r->adult_rate ),
			'child_prices'   => is_array( $cp ) ? array_map( 'floatval', $cp ) : [],
			'eb_adult_price' => $f( $r->eb_adult_price ),
			'eb_child_price' => $f( $r->eb_child_price ),
			'min_nights'     => null === $r->min_nights ? null : (int) $r->min_nights,
		];
	}

	/**
	 * Sezony dotyczące apartamentu w zakresie nocy [from, to) wraz z jego cenami.
	 * Każdy element: sezon + 'rates' (null = brak cen tego apartamentu).
	 */
	public static function for_apartment( int $apartment_id, string $from, string $to ): array {
		global $wpdb;
		$object = BM_Locations::object_of_apartment( $apartment_id );
		$rows   = $wpdb->get_results( $wpdb->prepare(
			'SELECT s.*, r.apartment_id AS r_apt, r.rate, r.adult_rate, r.child_prices, r.eb_adult_price, r.eb_child_price, r.min_nights AS r_min
			 FROM ' . self::ts() . ' s LEFT JOIN ' . self::tr() . ' r ON r.season_id = s.id AND r.apartment_id = %d
			 WHERE s.object_id IN (0, %d) AND s.date_from < %s AND s.date_to >= %s
			 ORDER BY s.date_from, s.id',
			$apartment_id, $object, $to, $from
		) );
		$out = [];
		foreach ( $rows as $r ) {
			$s          = self::hydrate( $r );
			$s['rates'] = null;
			if ( $r->r_apt ) {
				$r->min_nights = $r->r_min;
				$s['rates']    = self::hydrate_rates( $r );
			}
			$out[] = $s;
		}
		return $out;
	}

	/** Sezon obowiązujący w danej nocy (z listy for_apartment) albo null. Krótszy wygrywa, przy remisie nowszy. */
	public static function pick( array $seasons, string $date ): ?array {
		$best = null;
		foreach ( $seasons as $s ) {
			if ( $date < $s['date_from'] || $date > $s['date_to'] ) {
				continue;
			}
			if ( ! $best || $s['length'] < $best['length'] || ( $s['length'] === $best['length'] && $s['id'] > $best['id'] ) ) {
				$best = $s;
			}
		}
		return $best;
	}

	/** Minimalny pobyt dla przyjazdu w sezonie: apartament w sezonie → sezon → apartament. */
	public static function min_nights( ?array $season, int $base ): int {
		if ( ! $season ) {
			return $base;
		}
		return $season['rates']['min_nights'] ?? $season['min_nights'] ?? $base;
	}

	/** Konfiguracja apartamentu z nadpisaniami sezonu (do wyceny nocy). */
	public static function apply( array $cfg, ?array $season ): array {
		$r = $season['rates'] ?? null;
		if ( ! $r ) {
			return $cfg;
		}
		if ( null !== $r['rate'] ) {
			$cfg['rate'] = $r['rate'];
		}
		if ( null !== $r['adult_rate'] ) {
			$cfg['adult_rate'] = $r['adult_rate'];
		}
		foreach ( $cfg['child_bands'] as &$b ) {
			$key = $b['from'] . '-' . $b['to'];
			if ( isset( $r['child_prices'][ $key ] ) ) {
				$b['price'] = $r['child_prices'][ $key ];
			}
		}
		unset( $b );
		if ( null !== $r['eb_adult_price'] ) {
			$cfg['eb_adult']['price'] = $r['eb_adult_price'];
		}
		if ( null !== $r['eb_child_price'] ) {
			$cfg['eb_child']['price'] = $r['eb_child_price'];
		}
		return $cfg;
	}

	/* ================= zapis ================= */

	/** Zapis sezonu. Zwraca ID albo WP_Error. */
	public static function save( array $d ) {
		global $wpdb;
		$name = mb_substr( sanitize_text_field( (string) ( $d['name'] ?? '' ) ), 0, 100 );
		$from = (string) ( $d['date_from'] ?? '' );
		$to   = (string) ( $d['date_to'] ?? '' );
		if ( '' === $name ) {
			return new WP_Error( 'bm_season', __( 'Podaj nazwę sezonu (widzi ją gość, np. „Wakacje”).', 'bookmanager' ) );
		}
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) || $to < $from ) {
			return new WP_Error( 'bm_season', __( 'Podaj poprawny zakres: pierwsza i ostatnia noc sezonu.', 'bookmanager' ) );
		}
		$min = trim( (string) ( $d['min_nights'] ?? '' ) );
		$row = [
			'object_id'    => absint( $d['object_id'] ?? 0 ),
			'name'         => $name,
			'date_from'    => $from,
			'date_to'      => $to,
			'min_nights'   => '' === $min ? null : max( 1, min( 60, absint( $min ) ) ),
			'arrival_days' => implode( ',', self::days( is_array( $d['arrival_days'] ?? null ) ? implode( ',', $d['arrival_days'] ) : (string) ( $d['arrival_days'] ?? '' ) ) ),
			'color'        => (string) ( sanitize_hex_color( (string) ( $d['color'] ?? '' ) ) ?: '' ),
			'updated_at'   => current_time( 'mysql', true ),
		];
		if ( ! empty( $d['id'] ) ) {
			$wpdb->update( self::ts(), $row, [ 'id' => (int) $d['id'] ] );
			return (int) $d['id'];
		}
		$row['created_at'] = $row['updated_at'];
		$wpdb->insert( self::ts(), $row );
		return (int) $wpdb->insert_id;
	}

	/**
	 * Zapis cen apartamentu w sezonie. Wszystkie pola puste = usuń wiersz (apartament po cenie bazowej).
	 * $d: rate, adult_rate, child_prices {"0-3": 0, …}, eb_adult_price, eb_child_price, min_nights.
	 */
	public static function save_rates( int $apartment_id, int $season_id, array $d ): void {
		global $wpdb;
		$money = fn( $v ) => null === $v || '' === trim( (string) $v ) ? null : max( 0, (float) wc_format_decimal( $v ) );
		$cp    = [];
		foreach ( (array) ( $d['child_prices'] ?? [] ) as $k => $v ) {
			if ( preg_match( '/^\d{1,2}-\d{1,2}$/', (string) $k ) && null !== $money( $v ) ) {
				$cp[ $k ] = $money( $v );
			}
		}
		$min = trim( (string) ( $d['min_nights'] ?? '' ) );
		$row = [
			'rate'           => $money( $d['rate'] ?? null ),
			'adult_rate'     => $money( $d['adult_rate'] ?? null ),
			'child_prices'   => $cp ? wp_json_encode( $cp ) : null,
			'eb_adult_price' => $money( $d['eb_adult_price'] ?? null ),
			'eb_child_price' => $money( $d['eb_child_price'] ?? null ),
			'min_nights'     => '' === $min ? null : max( 1, min( 60, absint( $min ) ) ),
		];
		$wpdb->delete( self::tr(), [ 'apartment_id' => $apartment_id, 'season_id' => $season_id ] );
		if ( array_filter( $row, fn( $v ) => null !== $v ) ) {
			$wpdb->insert( self::tr(), [ 'apartment_id' => $apartment_id, 'season_id' => $season_id ] + $row );
		}
	}

	/** Ceny wszystkich apartamentów w sezonie: [apartment_id => rates]. */
	public static function rates_for_season( int $season_id ): array {
		global $wpdb;
		$out = [];
		foreach ( $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::tr() . ' WHERE season_id = %d', $season_id ) ) as $r ) {
			$out[ (int) $r->apartment_id ] = self::hydrate_rates( $r );
		}
		return $out;
	}

	public static function delete( int $id ): void {
		global $wpdb;
		$wpdb->delete( self::tr(), [ 'season_id' => $id ] );
		$wpdb->delete( self::ts(), [ 'id' => $id ] );
	}

	/** Kopia sezonu z cenami przesunięta o rok. Zwraca ID nowego sezonu. */
	public static function copy_next_year( int $id ) {
		global $wpdb;
		$s = self::get( $id );
		if ( ! $s ) {
			return new WP_Error( 'bm_season', __( 'Nie ma takiego sezonu.', 'bookmanager' ) );
		}
		$shift = fn( string $d ) => ( new DateTimeImmutable( $d ) )->modify( '+1 year' )->format( 'Y-m-d' );
		$name  = preg_replace_callback( '/\b(20\d\d)\b/', fn( $m ) => (string) ( (int) $m[1] + 1 ), $s['name'] );
		$new   = self::save( [
			'object_id' => $s['object_id'], 'name' => $name, 'date_from' => $shift( $s['date_from'] ), 'date_to' => $shift( $s['date_to'] ),
			'min_nights' => $s['min_nights'] ?? '', 'arrival_days' => $s['arrival_days'], 'color' => $s['color'],
		] );
		if ( is_wp_error( $new ) ) {
			return $new;
		}
		$wpdb->query( $wpdb->prepare(
			'INSERT INTO ' . self::tr() . ' (apartment_id, season_id, rate, adult_rate, child_prices, eb_adult_price, eb_child_price, min_nights)
			 SELECT apartment_id, %d, rate, adult_rate, child_prices, eb_adult_price, eb_child_price, min_nights FROM ' . self::tr() . ' WHERE season_id = %d',
			$new, $id
		) );
		return $new;
	}

	/**
	 * Zasady sezonów dla kalendarza widżetu (zakres nocy): [{from, to, name, min_nights, arrival_days}]
	 * — wszystkie sezony (także bez zmian zasad), bo krótszy sezon przykrywa dłuższy także wtedy, gdy niczego nie zmienia.
	 */
	public static function calendar_rules( int $apartment_id, string $from, string $to, int $base_min ): array {
		$out = [];
		foreach ( self::for_apartment( $apartment_id, $from, $to ) as $s ) {
			$min   = self::min_nights( $s, $base_min );
			$out[] = [ 'id' => $s['id'], 'from' => $s['date_from'], 'to' => $s['date_to'], 'length' => $s['length'], 'name' => $s['name'], 'min_nights' => $min, 'arrival_days' => $s['arrival_days'] ];
		}
		return $out;
	}
}
