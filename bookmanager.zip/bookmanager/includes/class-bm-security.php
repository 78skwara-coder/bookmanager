<?php
defined( 'ABSPATH' ) || exit;

/**
 * Ochrona logowania:
 *  - limit nieudanych prób z jednego adresu IP (każde logowanie do WordPressa: panel, wp-login.php, XML-RPC, hasła aplikacji),
 *  - Cloudflare Turnstile („nie jestem robotem”) na logowaniu do panelu, opcjonalnie też na wp-login.php.
 *
 * Klucze Turnstile: BookManager → Ustawienia → Panel i logowanie, albo stałe w wp-config.php:
 *   define( 'BM_TURNSTILE_SITE_KEY', '…' );  define( 'BM_TURNSTILE_SECRET', '…' );
 * Awaryjnie (np. zablokowane logowanie przez złe klucze): define( 'BM_TURNSTILE_OFF', true );
 */
class BM_Security {

	const VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
	const SCRIPT_URL = 'https://challenges.cloudflare.com/turnstile/v0/api.js';

	public static function init(): void {
		add_filter( 'authenticate', [ __CLASS__, 'block_if_locked' ], 99 );
		add_filter( 'authenticate', [ __CLASS__, 'wp_login_turnstile' ], 30, 1 );
		add_action( 'wp_login_failed', [ __CLASS__, 'failed' ] );
		add_action( 'wp_login', [ __CLASS__, 'succeeded' ], 10, 2 );
		add_action( 'login_enqueue_scripts', [ __CLASS__, 'wp_login_script' ] );
		add_action( 'login_form', [ __CLASS__, 'wp_login_widget' ] );
	}

	/* ================= limit prób ================= */

	private static function key(): string {
		return 'bm_lf_' . md5( BM_Log::ip() );
	}

	public static function max_attempts(): int {
		return max( 3, (int) BM_Settings::get( 'login_max_attempts' ) );
	}

	public static function lock_minutes(): int {
		return max( 5, (int) BM_Settings::get( 'login_lock_minutes' ) );
	}

	/** Ile minut zostało do końca blokady (0 = brak blokady). */
	public static function locked_minutes(): int {
		$s = get_transient( self::key() );
		if ( is_array( $s ) && ! empty( $s['until'] ) && $s['until'] > time() ) {
			return (int) ceil( ( $s['until'] - time() ) / 60 );
		}
		return 0;
	}

	public static function locked_error(): WP_Error {
		$m = max( 1, self::locked_minutes() );
		return new WP_Error( 'bm_locked', sprintf(
			/* translators: %d: minuty */
			__( 'Zbyt wiele nieudanych prób logowania. Spróbuj ponownie za %d min.', 'bookmanager' ), $m
		) );
	}

	public static function block_if_locked( $user ) {
		return self::locked_minutes() ? self::locked_error() : $user;
	}

	public static function failed(): void {
		if ( self::locked_minutes() ) {
			return;
		}
		$s = get_transient( self::key() );
		$n = ( is_array( $s ) ? (int) ( $s['n'] ?? 0 ) : 0 ) + 1;
		$s = [ 'n' => $n, 'until' => 0 ];
		if ( $n >= self::max_attempts() ) {
			$s['until'] = time() + self::lock_minutes() * MINUTE_IN_SECONDS;
			BM_Log::add( 'login_locked', '', 0, [ 'attempts' => $n ], 0 );
		}
		set_transient( self::key(), $s, self::lock_minutes() * MINUTE_IN_SECONDS );
	}

	public static function succeeded(): void {
		delete_transient( self::key() );
	}

	/* ================= Turnstile ================= */

	public static function site_key(): string {
		return defined( 'BM_TURNSTILE_SITE_KEY' ) ? (string) BM_TURNSTILE_SITE_KEY : (string) BM_Settings::get( 'turnstile_site' );
	}

	private static function secret(): string {
		return defined( 'BM_TURNSTILE_SECRET' ) ? (string) BM_TURNSTILE_SECRET : (string) BM_Settings::get( 'turnstile_secret' );
	}

	public static function turnstile_on(): bool {
		return ! ( defined( 'BM_TURNSTILE_OFF' ) && BM_TURNSTILE_OFF ) && '' !== self::site_key() && '' !== self::secret();
	}

	/** Pole widżetu Turnstile w formularzu. */
	public static function widget(): string {
		if ( ! self::turnstile_on() ) {
			return '';
		}
		wp_enqueue_script( 'cf-turnstile', self::SCRIPT_URL, [], null, [ 'strategy' => 'defer' ] ); // phpcs:ignore -- skrypt Cloudflare bez wersji
		return '<div class="cf-turnstile" data-sitekey="' . esc_attr( self::site_key() ) . '" data-language="pl" data-theme="light"></div>';
	}

	/** Sprawdza odpowiedź Turnstile z formularza. Bez kluczy — zawsze true. Bez połączenia z Cloudflare — false (bezpieczniej). */
	public static function verify(): bool {
		if ( ! self::turnstile_on() ) {
			return true;
		}
		$token = isset( $_POST['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $_POST['cf-turnstile-response'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$pre   = apply_filters( 'bm_turnstile_verify', null, $token ); // testy / własna weryfikacja
		if ( null !== $pre ) {
			return (bool) $pre;
		}
		if ( '' === $token ) {
			return false;
		}
		$res = wp_remote_post( self::VERIFY_URL, [
			'timeout' => 10,
			'body'    => [ 'secret' => self::secret(), 'response' => $token, 'remoteip' => BM_Log::ip() ],
		] );
		if ( is_wp_error( $res ) ) {
			return false;
		}
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		return ! empty( $data['success'] );
	}

	/* ---------- wp-login.php (opcjonalnie) ---------- */

	private static function on_wp_login(): bool {
		return self::turnstile_on() && 'yes' === BM_Settings::get( 'turnstile_wp_login' )
			&& isset( $GLOBALS['pagenow'] ) && 'wp-login.php' === $GLOBALS['pagenow'];
	}

	public static function wp_login_script(): void {
		if ( self::on_wp_login() ) {
			wp_enqueue_script( 'cf-turnstile', self::SCRIPT_URL, [], null, [ 'strategy' => 'defer' ] ); // phpcs:ignore
		}
	}

	public static function wp_login_widget(): void {
		if ( self::on_wp_login() ) {
			echo '<div class="cf-turnstile" data-sitekey="' . esc_attr( self::site_key() ) . '" data-language="pl" style="margin:0 0 16px"></div>';
		}
	}

	public static function wp_login_turnstile( $user ) {
		// Tylko formularz wp-login.php (POST z loginem) — nie hasła aplikacji, nie XML-RPC, nie logowanie panelu.
		if ( ! self::on_wp_login() || empty( $_POST['log'] ) || is_wp_error( $user ) && 'bm_locked' === $user->get_error_code() ) { // phpcs:ignore
			return $user;
		}
		return self::verify() ? $user : new WP_Error( 'bm_turnstile', __( 'Potwierdź, że nie jesteś robotem.', 'bookmanager' ) );
	}
}
