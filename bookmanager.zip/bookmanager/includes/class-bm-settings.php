<?php
defined( 'ABSPATH' ) || exit;

/**
 * Ustawienia globalne BookManagera — jedna opcja `bm_settings` (tablica).
 */
class BM_Settings {

	const OPTION = 'bm_settings';

	public static function defaults(): array {
		return [
			'min_nights'          => 5,   // domyślny minimalny pobyt (apartament może nadpisać)
			'hold_minutes'        => 15,  // ile trwa blokada tymczasowa przed płatnością
			'min_deposit_percent' => 20,  // minimalna zaliczka w % ceny pobytu
			'transfer_hold_hours' => 24,  // ile godzin termin czeka na przelew (zamówienie „wstrzymane”)
			'balance_due_days'    => 0,   // termin dopłaty: X dni przed przyjazdem (0 = w dniu przyjazdu)
			'balance_label'       => 'Do zapłaty na miejscu (wg umowy)',
			'collect_id_number'   => 'no', // pole „numer dowodu” w zamówieniu
			'id_number_required'  => 'no',
			'id_retention_days'   => 30,  // usuń numer dowodu X dni po wyjeździe (0 = nie usuwaj)
			'delete_data'         => 'no', // usuwać tabele i ustawienia przy odinstalowaniu
			'turnstile_site'      => '',   // Cloudflare Turnstile — klucz witryny
			'turnstile_secret'    => '',   // Cloudflare Turnstile — klucz tajny (nie wyświetlamy go z powrotem)
			'turnstile_wp_login'  => 'no', // Turnstile także na wp-login.php
			'login_max_attempts'  => 5,    // nieudane próby logowania z jednego IP…
			'login_lock_minutes'  => 15,   // …po których logowanie jest zablokowane na tyle minut
		];
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : [] );
	}

	public static function get( string $key ) {
		return self::all()[ $key ] ?? null;
	}

	public static function sanitize( $input ): array {
		$in  = is_array( $input ) ? $input : [];
		$out = self::defaults();

		$out['min_nights']          = max( 1, min( 60, absint( $in['min_nights'] ?? $out['min_nights'] ) ) );
		$out['hold_minutes']        = max( 5, min( 240, absint( $in['hold_minutes'] ?? $out['hold_minutes'] ) ) );
		$out['min_deposit_percent'] = max( 1, min( 100, absint( $in['min_deposit_percent'] ?? $out['min_deposit_percent'] ) ) );
		$out['transfer_hold_hours'] = max( 1, min( 240, absint( $in['transfer_hold_hours'] ?? $out['transfer_hold_hours'] ) ) );
		$out['balance_due_days']    = min( 365, absint( $in['balance_due_days'] ?? 0 ) );
		$out['balance_label']       = sanitize_text_field( $in['balance_label'] ?? '' ) ?: $out['balance_label'];
		$out['collect_id_number']   = ! empty( $in['collect_id_number'] ) ? 'yes' : 'no';
		$out['id_number_required']  = ! empty( $in['id_number_required'] ) ? 'yes' : 'no';
		$out['id_retention_days']   = min( 3650, absint( $in['id_retention_days'] ?? 30 ) );
		$out['delete_data']         = ! empty( $in['delete_data'] ) ? 'yes' : 'no';
		$out['turnstile_site']      = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $in['turnstile_site'] ?? '' ) );
		// Pusty klucz tajny w formularzu = zostaw zapisany; „-” = usuń.
		$secret                     = trim( (string) ( $in['turnstile_secret'] ?? '' ) );
		$out['turnstile_secret']    = '-' === $secret ? '' : ( '' === $secret ? (string) ( ( (array) get_option( self::OPTION, [] ) )['turnstile_secret'] ?? '' ) : preg_replace( '/[^A-Za-z0-9_\-]/', '', $secret ) );
		$out['turnstile_wp_login']  = ! empty( $in['turnstile_wp_login'] ) ? 'yes' : 'no';
		$out['login_max_attempts']  = max( 3, min( 20, absint( $in['login_max_attempts'] ?? 5 ) ) );
		$out['login_lock_minutes']  = max( 5, min( 1440, absint( $in['login_lock_minutes'] ?? 15 ) ) );

		return $out;
	}
}
