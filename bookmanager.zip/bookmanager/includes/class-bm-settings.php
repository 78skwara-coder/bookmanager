<?php
defined( 'ABSPATH' ) || exit;

/**
 * Ustawienia globalne BookManagera — jedna opcja `bm_settings` (tablica).
 */
class BM_Settings {

	const OPTION = 'bm_settings';

	public static function defaults(): array {
		return [
			'min_nights'          => 5,   // domyślny minimalny pobyt (apartament może nadpisać)
			'hold_minutes'        => 15,  // ile trwa blokada tymczasowa przed płatnością
			'min_deposit_percent' => 20,  // minimalna zaliczka w % ceny pobytu
			'transfer_hold_hours' => 24,  // ile godzin termin czeka na przelew (zamówienie „wstrzymane”)
			'balance_due_days'    => 0,   // termin dopłaty: X dni przed przyjazdem (0 = w dniu przyjazdu)
			'balance_label'       => 'Do zapłaty na miejscu (wg umowy)',
			'collect_id_number'   => 'no', // pole „numer dowodu” w zamówieniu
			'id_number_required'  => 'no',
			'id_retention_days'   => 30,  // usuń numer dowodu X dni po wyjeździe (0 = nie usuwaj)
			'delete_data'         => 'no', // usuwać tabele i ustawienia przy odinstalowaniu
			'turnstile_site'      => '',   // Cloudflare Turnstile — klucz witryny
			'turnstile_secret'    => '',   // Cloudflare Turnstile — klucz tajny (nie wyświetlamy go z powrotem)
			'turnstile_wp_login'  => 'no', // Turnstile także na wp-login.php
			'login_max_attempts'  => 5,    // nieudane próby logowania z jednego IP…
			'login_lock_minutes'  => 15,   // …po których logowanie jest zablokowane na tyle minut
			'hide_shop_pages'     => 'yes', // strony Sklep, kategorie i tagi produktów → przekierowanie na stronę główną
			'staff_email'         => '',    // powiadomienia „do obsługi” (puste = e-mail administratora)
			'replace_wc_emails'   => 'yes', // dla zamówień z apartamentami wysyłają nasze szablony zamiast maili WooCommerce
		];
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : [] );
	}

	public static function get( string $key ) {
		return self::all()[ $key ] ?? null;
	}

	/**
	 * Brakujący klucz = zostaw zapisaną wartość (formularz kokpitu i panel zapisują tylko swoje pola).
	 * Pola tak/nie przyjmują 1/0, yes/no, true/false — kokpit dokłada ukryte „0” przed każdym polem wyboru.
	 */
	public static function sanitize( $input ): array {
		$in   = is_array( $input ) ? $input : [];
		$cur  = self::all();
		$out  = $cur;
		$v    = fn( string $k ) => array_key_exists( $k, $in ) ? $in[ $k ] : $cur[ $k ];
		$shown = array_filter( explode( ',', (string) ( $in['_flags'] ?? '' ) ) ); // pola wyboru obecne w formularzu (odznaczone nie są wysyłane)
		$flag  = function ( string $k ) use ( $in, $cur, $shown ): string {
			if ( ! array_key_exists( $k, $in ) ) {
				return in_array( $k, $shown, true ) ? 'no' : ( 'yes' === $cur[ $k ] ? 'yes' : 'no' );
			}
			return in_array( $in[ $k ], [ true, 1, '1', 'yes', 'on', 'true' ], true ) ? 'yes' : 'no';
		};
		$d = self::defaults();

		$out['min_nights']          = max( 1, min( 60, absint( $v( 'min_nights' ) ) ) );
		$out['hold_minutes']        = max( 5, min( 240, absint( $v( 'hold_minutes' ) ) ) );
		$out['min_deposit_percent'] = max( 1, min( 100, absint( $v( 'min_deposit_percent' ) ) ) );
		$out['transfer_hold_hours'] = max( 1, min( 240, absint( $v( 'transfer_hold_hours' ) ) ) );
		$out['balance_due_days']    = min( 365, absint( $v( 'balance_due_days' ) ) );
		$out['balance_label']       = sanitize_text_field( (string) $v( 'balance_label' ) ) ?: $d['balance_label'];
		$out['id_retention_days']   = min( 3650, absint( $v( 'id_retention_days' ) ) );
		$out['turnstile_site']      = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $v( 'turnstile_site' ) );
		// Pusty klucz tajny w formularzu = zostaw zapisany; „-” = usuń.
		$secret                     = trim( (string) ( $in['turnstile_secret'] ?? '' ) );
		$out['turnstile_secret']    = '-' === $secret ? '' : ( '' === $secret ? (string) $cur['turnstile_secret'] : preg_replace( '/[^A-Za-z0-9_\-]/', '', $secret ) );
		$out['login_max_attempts']  = max( 3, min( 20, absint( $v( 'login_max_attempts' ) ) ) );
		$out['login_lock_minutes']  = max( 5, min( 1440, absint( $v( 'login_lock_minutes' ) ) ) );
		$out['staff_email']         = sanitize_email( (string) $v( 'staff_email' ) );
		foreach ( [ 'collect_id_number', 'id_number_required', 'delete_data', 'turnstile_wp_login', 'hide_shop_pages', 'replace_wc_emails' ] as $k ) {
			$out[ $k ] = $flag( $k );
		}

		return $out;
	}
}
