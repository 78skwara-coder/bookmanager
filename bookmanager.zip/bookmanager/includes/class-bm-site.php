<?php
defined( 'ABSPATH' ) || exit;

/**
 * Dane obiektu i strony serwisu — jedno miejsce dla kontaktu, stopki maili, regulaminu i listy apartamentów.
 *
 * Opcja `bm_site`. Regulamin i polityka prywatności są zapisywane w opcjach WordPressa/WooCommerce
 * (woocommerce_terms_page_id, wp_page_for_privacy_policy), żeby inne wtyczki widziały te same strony.
 */
class BM_Site {

	const OPTION = 'bm_site';

	public static function defaults(): array {
		return [
			// dane obiektu
			'company'   => '',
			'address'   => '',
			'postcode'  => '',
			'city'      => '',
			'nip'       => '',
			'phone'     => '',
			'email'     => '',
			'hours'     => '',
			'map'       => 'yes',
			// strony
			'list_page'    => 0,
			'contact_page' => 0,
			// formularz kontaktowy
			'contact_to'        => '',
			'contact_autoreply' => 'yes',
			'contact_subject'   => 'Dziękujemy za wiadomość',
			'contact_body'      => "Dzień dobry {imie},\n\ndziękujemy za wiadomość — odpowiemy najszybciej, jak to możliwe, zwykle w ciągu jednego dnia roboczego.\n\nTwoja wiadomość:\n{wiadomosc}\n\nPozdrawiamy,\n{nazwa_strony}",
			// wygląd e-maili
			'mail_logo'        => 0,
			'mail_logo_width'  => 140,
			'mail_align'       => 'center',
			'mail_header_text' => '',
			'mail_bg'          => '#f4f2ee',
			'mail_accent'      => '',
			'mail_radius'      => 12,
			'mail_divider'     => 'yes',
			'mail_font'        => 'sans',
			'mail_footer'      => "{nazwa_firmy}\n{adres}\n{telefon} · {email}",
			'mail_socials'     => [],
		];
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		$out   = array_merge( self::defaults(), is_array( $saved ) ? $saved : [] );
		$out['terms_page']   = (int) get_option( 'woocommerce_terms_page_id', 0 );
		$out['privacy_page'] = (int) get_option( 'wp_page_for_privacy_policy', 0 );
		return $out;
	}

	public static function get( string $key ) {
		return self::all()[ $key ] ?? null;
	}

	/** Zapis części ustawień (klucze spoza listy są pomijane). */
	public static function save( array $in ): array {
		update_option( self::OPTION, self::clean( $in, true ), false );
		return self::all();
	}

	/** Aktualne ustawienia z naniesionymi zmianami (bez zapisu; strony prawne zapisuje tylko przy $write). */
	public static function clean( array $in, bool $write = false ): array {
		$cur = self::all();
		$out = array_intersect_key( $cur, self::defaults() );
		$txt = fn( $k, $max = 190 ) => mb_substr( sanitize_text_field( (string) $in[ $k ] ), 0, $max );
		$flag = fn( $k ) => in_array( $in[ $k ], [ true, 1, '1', 'yes', 'on', 'true' ], true ) ? 'yes' : 'no';
		$page = function ( $v ): int {
			$id = absint( $v );
			return $id && 'page' === get_post_type( $id ) ? $id : 0;
		};
		$color = fn( $v, $def ) => preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $v ) ? strtolower( (string) $v ) : $def;

		foreach ( $in as $k => $v ) {
			switch ( $k ) {
				case 'company': case 'address': case 'city': case 'hours':
					$out[ $k ] = $txt( $k );
					break;
				case 'postcode':
					$out[ $k ] = $txt( $k, 12 );
					break;
				case 'nip':
					$out[ $k ] = $txt( $k, 30 );
					break;
				case 'phone':
					$out[ $k ] = preg_replace( '/[^0-9+ ()\-]/', '', (string) $v );
					break;
				case 'email': case 'contact_to':
					$out[ $k ] = sanitize_email( (string) $v );
					break;
				case 'map': case 'contact_autoreply': case 'mail_divider':
					$out[ $k ] = $flag( $k );
					break;
				case 'list_page': case 'contact_page':
					$out[ $k ] = $page( $v );
					break;
				case 'terms_page':
					$write && update_option( 'woocommerce_terms_page_id', $page( $v ) );
					break;
				case 'privacy_page':
					$write && update_option( 'wp_page_for_privacy_policy', $page( $v ) );
					break;
				case 'contact_subject':
					$out[ $k ] = $txt( $k, 190 ) ?: self::defaults()[ $k ];
					break;
				case 'contact_body': case 'mail_footer':
					$out[ $k ] = mb_substr( sanitize_textarea_field( (string) $v ), 0, 4000 );
					break;
				case 'mail_header_text':
					$out[ $k ] = $txt( $k, 190 );
					break;
				case 'mail_logo':
					$id        = absint( $v );
					$out[ $k ] = $id && wp_attachment_is_image( $id ) ? $id : 0;
					break;
				case 'mail_logo_width':
					$out[ $k ] = max( 40, min( 300, absint( $v ) ) );
					break;
				case 'mail_align':
					$out[ $k ] = 'left' === $v ? 'left' : 'center';
					break;
				case 'mail_bg':
					$out[ $k ] = $color( $v, self::defaults()['mail_bg'] );
					break;
				case 'mail_accent':
					$out[ $k ] = '' === $v ? '' : $color( $v, '' );
					break;
				case 'mail_radius':
					$out[ $k ] = in_array( (int) $v, [ 0, 6, 12, 20 ], true ) ? (int) $v : 12;
					break;
				case 'mail_font':
					$out[ $k ] = 'serif' === $v ? 'serif' : 'sans';
					break;
				case 'mail_socials':
					$out[ $k ] = self::sanitize_socials( (array) $v );
					break;
			}
		}
		return $out;
	}

	/* ================= linki w stopce ================= */

	/** Znane serwisy: fragment domeny => nazwa. */
	private static function networks(): array {
		return [
			'youtube.com' => 'YouTube', 'youtu.be' => 'YouTube', 'facebook.com' => 'Facebook', 'fb.com' => 'Facebook',
			'instagram.com' => 'Instagram', 'tiktok.com' => 'TikTok', 'x.com' => 'X', 'twitter.com' => 'X',
			'linkedin.com' => 'LinkedIn', 'pinterest.' => 'Pinterest', 'wa.me' => 'WhatsApp', 'whatsapp.com' => 'WhatsApp',
			'maps.app.goo.gl' => 'Mapa', 'google.com/maps' => 'Mapa', 'g.page' => 'Google', 'tripadvisor.' => 'Tripadvisor',
			'booking.com' => 'Booking.com', 'airbnb.' => 'Airbnb', 'threads.net' => 'Threads', 'spotify.com' => 'Spotify',
		];
	}

	public static function network_name( string $url ): string {
		foreach ( self::networks() as $needle => $name ) {
			if ( false !== stripos( $url, $needle ) ) {
				return $name;
			}
		}
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		return preg_replace( '/^www\./', '', $host );
	}

	/** [{url, label}] — najwyżej 8, tylko http(s). Pusta etykieta = nazwa serwisu z adresu. */
	public static function sanitize_socials( array $rows ): array {
		$out = [];
		foreach ( $rows as $r ) {
			$url = esc_url_raw( trim( (string) ( is_array( $r ) ? ( $r['url'] ?? '' ) : $r ) ), [ 'http', 'https' ] );
			if ( ! $url ) {
				continue;
			}
			$label = is_array( $r ) ? mb_substr( sanitize_text_field( (string) ( $r['label'] ?? '' ) ), 0, 40 ) : '';
			$out[] = [ 'url' => $url, 'label' => $label ];
			if ( count( $out ) >= 8 ) {
				break;
			}
		}
		return $out;
	}

	/* ================= dane obiektu ================= */

	public static function address_line(): string {
		$s = self::all();
		return trim( implode( ', ', array_filter( [ $s['address'], trim( $s['postcode'] . ' ' . $s['city'] ) ] ) ) );
	}

	/** Pola z danymi obiektu do treści (stopka maili, autoodpowiedź). */
	public static function vars(): array {
		$s = self::all();
		return [
			'nazwa_firmy'  => $s['company'] ?: wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'adres'        => self::address_line(),
			'telefon'      => $s['phone'],
			'email'        => $s['email'] ?: (string) get_option( 'admin_email' ),
			'nip'          => $s['nip'] ? 'NIP ' . $s['nip'] : '',
			'godziny'      => $s['hours'],
			'nazwa_strony' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'adres_strony' => home_url( '/' ),
		];
	}

	/* ================= strony ================= */

	public static function page_url( string $key ): string {
		$id = (int) self::get( $key );
		return $id && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : '';
	}

	/** Lista apartamentów; bez niej — strona główna. */
	public static function list_url( array $args = [] ): string {
		$url = self::page_url( 'list_page' ) ?: home_url( '/' );
		return $args ? add_query_arg( array_map( 'rawurlencode', array_filter( $args, fn( $v ) => '' !== $v && null !== $v ) ), $url ) : $url;
	}

	/** Gotowe strony z krótkim kodem. */
	public static function create_page( string $kind ) {
		$map = [
			'list_page'    => [ __( 'Apartamenty', 'bookmanager' ), '[bookmanager_lista]' ],
			'contact_page' => [ __( 'Kontakt', 'bookmanager' ), '[bookmanager_kontakt]' ],
			'terms_page'   => [ __( 'Regulamin', 'bookmanager' ), '' ],
		];
		if ( ! isset( $map[ $kind ] ) ) {
			return new WP_Error( 'bm_page', __( 'Nieznany rodzaj strony.', 'bookmanager' ) );
		}
		[ $title, $code ] = $map[ $kind ];
		$id = wp_insert_post( [
			'post_type'    => 'page',
			'post_status'  => '' === $code ? 'draft' : 'publish',
			'post_title'   => $title,
			'post_content' => '' === $code ? '' : "<!-- wp:shortcode -->\n$code\n<!-- /wp:shortcode -->",
		], true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		self::save( [ $kind => $id ] );
		return $id;
	}

	/** Strony dla panelu: [{id, title, status}]. */
	public static function pages(): array {
		return array_map( fn( $p ) => [ 'id' => $p->ID, 'title' => $p->post_title ?: '#' . $p->ID, 'status' => $p->post_status ],
			get_pages( [ 'post_status' => [ 'publish', 'draft', 'private' ], 'sort_column' => 'post_title' ] ) );
	}

	/** Braki, które warto pokazać właścicielowi. */
	public static function problems(): array {
		$s   = self::all();
		$out = [];
		if ( ! self::page_url( 'terms_page' ) ) {
			$out[] = __( 'Brak opublikowanego regulaminu — operator płatności (np. Przelewy24) wymaga go przy weryfikacji sklepu.', 'bookmanager' );
		}
		if ( ! self::page_url( 'privacy_page' ) ) {
			$out[] = __( 'Brak opublikowanej polityki prywatności.', 'bookmanager' );
		}
		if ( ! $s['company'] || ! self::address_line() || ! $s['phone'] && ! $s['email'] ) {
			$out[] = __( 'Uzupełnij dane obiektu (nazwa, adres, telefon lub e-mail) — pokazujemy je w kontakcie i w stopce maili.', 'bookmanager' );
		}
		return $out;
	}
}
