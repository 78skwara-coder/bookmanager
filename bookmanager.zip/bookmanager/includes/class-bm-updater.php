<?php
defined( 'ABSPATH' ) || exit;

/**
 * Aktualizacje BookManagera przez GitHub — ten sam schemat co we wtyczce restauracji.
 *
 * WordPress co jakiś czas sam pyta w tle o aktualizacje wtyczek. Podpinamy się pod to
 * pytanie, czytamy update.json z GitHuba i jeśli jest tam wyższa wersja, WordPress
 * pokazuje zwykłe „Dostępna aktualizacja → Aktualizuj teraz” i pobiera ZIP z Release.
 *
 * update.json i Release tworzy GitHub Actions (.github/workflows/wydanie.yml)
 * po wgraniu bookmanager.zip do głównego katalogu repozytorium.
 *
 * Adres manifestu można nadpisać w wp-config.php: BM_UPDATE_MANIFEST_URL.
 */
class BM_Updater {

	const NAME = 'BookManager';

	private static $manifest = null; // jedno zapytanie sieciowe na cały request

	public static function init(): void {
		if ( ! BM_UPDATE_MANIFEST_URL ) {
			return;
		}
		add_filter( 'pre_set_site_transient_update_plugins', [ __CLASS__, 'check' ] );
		add_filter( 'upgrader_source_selection', [ __CLASS__, 'fix_folder' ], 10, 4 );
		add_filter( 'plugins_api', [ __CLASS__, 'info' ], 10, 3 );
	}

	/** „bookmanager/bookmanager.php” — tak WordPress identyfikuje wtyczkę. */
	private static function plugin_file(): string {
		return plugin_basename( BM_FILE );
	}

	private static function manifest() {
		if ( null !== self::$manifest ) {
			return self::$manifest;
		}
		$res = wp_remote_get( BM_UPDATE_MANIFEST_URL, [ 'timeout' => 8 ] );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return self::$manifest = false;
		}
		$data = json_decode( wp_remote_retrieve_body( $res ) );
		return self::$manifest = ( $data && ! empty( $data->version ) ) ? $data : false;
	}

	public static function check( $transient ) {
		if ( empty( $transient ) || ! is_object( $transient ) ) {
			return $transient;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $transient;
		}

		$file         = self::plugin_file();
		$item         = new stdClass();
		$item->id     = $file;
		$item->slug   = dirname( $file );
		$item->plugin = $file;

		if ( version_compare( $m->version, BM_VERSION, '>' ) ) {
			$item->new_version  = $m->version;
			$item->url          = $m->homepage ?? '';
			$item->package      = $m->download_url ?? '';
			$item->tested       = $m->tested ?? '';
			$item->requires_php = $m->requires_php ?? '';
			$transient->response[ $file ] = $item;
		} else {
			// Jawne „aktualne” — bez tego ekran wtyczek potrafi „sprawdzać” w nieskończoność.
			$item->new_version             = BM_VERSION;
			$transient->no_update[ $file ] = $item;
		}
		return $transient;
	}

	/**
	 * Po rozpakowaniu ZIP-a zmieniamy nazwę folderu na tę, w której wtyczka jest
	 * zainstalowana teraz. Chroni przed drugim folderem obok (np. „bookmanager(1)”)
	 * i błędem „Cannot redeclare”.
	 */
	public static function fix_folder( $source, $remote_source, $upgrader, $hook_extra = [] ) {
		global $wp_filesystem;
		if ( empty( $hook_extra['plugin'] ) || self::plugin_file() !== $hook_extra['plugin'] || is_wp_error( $source ) ) {
			return $source;
		}
		$want = trailingslashit( $remote_source ) . dirname( self::plugin_file() );
		if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) {
			return $source;
		}
		if ( untrailingslashit( $source ) === untrailingslashit( $remote_source ) ) {
			return new WP_Error( 'bm_zip_layout', 'ZIP aktualizacji musi mieć w środku folder „bookmanager/”.' );
		}
		if ( $wp_filesystem && $wp_filesystem->move( untrailingslashit( $source ), $want, true ) ) {
			return trailingslashit( $want );
		}
		return new WP_Error( 'bm_rename', 'Nie udało się przygotować folderu aktualizacji.' );
	}

	/** Okienko „Zobacz szczegóły wersji”. */
	public static function info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || dirname( self::plugin_file() ) !== $args->slug ) {
			return $result;
		}
		$m = self::manifest();
		if ( ! $m ) {
			return $result;
		}
		$info                = new stdClass();
		$info->name          = self::NAME;
		$info->slug          = $args->slug;
		$info->version       = $m->version;
		$info->homepage      = $m->homepage ?? '';
		$info->download_link = $m->download_url ?? '';
		$info->sections      = [ 'changelog' => wp_kses_post( $m->changelog ?? '' ) ];
		return $info;
	}
}
