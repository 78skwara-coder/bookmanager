<?php
defined( 'ABSPATH' ) || exit;

/**
 * Typ produktu „Apartament”. Cena nie jest stała — liczy ją BM_Pricing po wybraniu dat.
 */
class WC_Product_BM_Apartment extends WC_Product_Simple {

	public function get_type() {
		return 'bm_apartment';
	}

	// Kupowalny mimo pustej ceny — cena powstaje dopiero z dat.
	public function is_purchasable() {
		return apply_filters(
			'woocommerce_is_purchasable',
			$this->exists() && ( 'publish' === $this->get_status() || current_user_can( 'edit_post', $this->get_id() ) ),
			$this
		);
	}

	public function is_virtual() {
		return true; // bez wysyłki
	}

	public function is_sold_individually() {
		return true; // ilość zawsze 1
	}

	public function add_to_cart_text() {
		return __( 'Sprawdź termin', 'bookmanager' );
	}
}
