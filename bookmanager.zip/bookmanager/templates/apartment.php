<?php
/**
 * Szablon strony apartamentu. Nagłówek i stopka z motywu, środek z BookManagera.
 * Działa z motywami blokowymi (części szablonu header/footer) i klasycznymi (get_header/get_footer).
 */
defined( 'ABSPATH' ) || exit;

$bm_apt = BM_Page::current();
the_post();
$bm_body = BM_Page::render( $bm_apt );

if ( wp_is_block_theme() ) {
	// Części szablonu renderujemy przed wp_head, żeby ich style trafiły do <head>.
	$bm_header = do_blocks( '<!-- wp:template-part {"slug":"header","tagName":"header"} /-->' );
	$bm_footer = do_blocks( '<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->' );
	?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="wp-site-blocks">
	<?php echo $bm_header; // phpcs:ignore -- HTML z bloków motywu ?>
	<main class="bm-main" id="wp--skip-link--target"><?php echo $bm_body; // phpcs:ignore -- zbudowane z escapowanych części ?></main>
	<?php echo $bm_footer; // phpcs:ignore ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
	<?php
} else {
	get_header();
	echo '<main class="bm-main">' . $bm_body . '</main>'; // phpcs:ignore
	get_footer();
}
