<?php
/**
 * Potwierdzenie rezerwacji (krok 3) — zamiast sklepowego „Zamówienie otrzymane”.
 */
defined( 'ABSPATH' ) || exit;

BM_Page::shell( BM_Checkout::confirmation( BM_Checkout::received_order() ) );
