<?php
/**
 * Szablon strony panelu: pełna szerokość, bez nagłówka i stopki motywu (aplikacja, nie strona).
 * Style i skrypty motywu nadal się ładują (fonty, kolory z theme.json).
 */
defined( 'ABSPATH' ) || exit;

the_post();
$bm_body = do_shortcode( '[' . BM_Panel::SHORTCODE . ']' );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'bm-panel-page' ); ?>>
<?php wp_body_open(); ?>
<main class="bm-panel-main"><?php echo $bm_body; // phpcs:ignore -- zbudowane z escapowanych części ?></main>
<?php wp_footer(); ?>
</body>
</html>
