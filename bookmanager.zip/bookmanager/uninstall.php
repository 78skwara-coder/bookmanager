<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Dane kasujemy tylko na wyraźne życzenie (opcja ustawiana w panelu pluginu).
$bm_settings = get_option( 'bm_settings', [] );
if ( ( $bm_settings['delete_data'] ?? 'no' ) !== 'yes' ) {
	return;
}

global $wpdb;
foreach ( [ 'nights', 'bookings', 'payments', 'extras', 'apartment_extras', 'booking_extras', 'features', 'feature_links', 'acceptances' ] as $bm_t ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bm_{$bm_t}" ); // phpcs:ignore
}
// Lokalizacje (terminy taksonomii) usuwamy razem z metadanymi.
$bm_terms = $wpdb->get_col( "SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = 'bm_location'" );
foreach ( $bm_terms as $bm_id ) {
	$wpdb->delete( $wpdb->termmeta, [ 'term_id' => $bm_id ] );
	$wpdb->delete( $wpdb->term_relationships, [ 'term_taxonomy_id' => $wpdb->get_var( $wpdb->prepare( "SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id = %d AND taxonomy = 'bm_location'", $bm_id ) ) ] );
	$wpdb->delete( $wpdb->term_taxonomy, [ 'term_id' => $bm_id, 'taxonomy' => 'bm_location' ] );
	$wpdb->delete( $wpdb->terms, [ 'term_id' => $bm_id ] );
}
delete_option( 'bm_db_version' );
delete_option( 'bm_settings' );
delete_option( 'bm_google_sa' );
